const http = require('http');
const https = require('https');
const pkg = require('../package.json');
const { postWithCurl } = require('./curl-transport');
const { requestTimeout } = require('./keychain-timeout');
const brokerClients = new WeakSet();
const CONTROL_PLANE_METHODS = new Set(['initialize', 'notifications/initialized', 'ping', 'tools/list']);
function authorizeBrokerClient(client) { brokerClients.add(client); }

class McpClient {
  constructor(server) {
    this.server = server;
    const u = new URL(server.url);
    this.mod = u.protocol === 'https:' ? https : http;
    this.reqOpts = {
      hostname: u.hostname,
      port: u.port || (u.protocol === 'https:' ? 443 : 80),
      path: u.pathname + u.search,
      agent: new this.mod.Agent({ keepAlive: true, maxSockets: 1 }),
    };
  }

  _post(payload, sessionId, controlPlane = false) {
    if (!brokerClients.has(this) && !(controlPlane && CONTROL_PLANE_METHODS.has(payload?.method))) {
      require('./queue-client').assertDirectAccess();
    }
    const timeoutMs = requestTimeout(this.server);
    if (this.server.transport === 'windows-curl') return postWithCurl({ ...this.server, timeoutMs }, payload, sessionId);
    let timer;
    return new Promise((resolve, reject) => {
      const body = Buffer.from(JSON.stringify(payload));
      const headers = {
        'Content-Type': 'application/json',
        Accept: 'application/json, text/event-stream',
        'Content-Length': body.length,
        ...this.server.headers,
      };
      if (sessionId) headers['Mcp-Session-Id'] = sessionId;
      const req = this.mod.request(
        { ...this.reqOpts, method: 'POST', headers },
        (res) => {
          let raw = '';
          res.setEncoding('utf8');
          res.on('data', (chunk) => (raw += chunk));
          res.on('error', reject);
          res.on('aborted', () => reject(new Error('Backend response aborted; outcome unknown; inspect before retry')));
          res.on('end', () =>
            resolve({
              status: res.statusCode,
              sessionId: res.headers['mcp-session-id'],
              raw,
            })
          );
        }
      );
      if (timeoutMs > 0) timer = setTimeout(() => {
        req.destroy(new Error(`timeout after ${timeoutMs} ms; outcome unknown; inspect before retry`));
      }, timeoutMs);
      req.on('error', reject);
      req.end(body);
    }).finally(() => clearTimeout(timer));
  }

  controlPost(payload, sessionId, protocolVersion) {
    if (!payload || !CONTROL_PLANE_METHODS.has(payload.method)) {
      return Promise.reject(Object.assign(new Error('Only MCP control-plane methods may bypass the Fusion queue'), { code: 'CONTROL_METHOD_DENIED' }));
    }
    const previousHeaders = this.server.headers;
    const headers = Object.fromEntries(Object.entries(previousHeaders || {})
      .filter(([name]) => name.toLowerCase() !== 'mcp-protocol-version'));
    if (protocolVersion) headers['MCP-Protocol-Version'] = protocolVersion;
    this.server.headers = headers;
    return this._post(payload, sessionId, true).finally(() => { this.server.headers = previousHeaders; });
  }

  _parse(raw) {
    const text = (raw || '').trim();
    if (!text) return null;
    if (text.startsWith('{') || text.startsWith('[')) return JSON.parse(text);
    if (text.startsWith('data:') || text.includes('event:')) {
      let data = null;
      for (const line of text.split(/\r?\n/)) {
        if (line.startsWith('data:')) data = line.slice(5).trim();
      }
      return data ? JSON.parse(data) : null;
    }
    return JSON.parse(text);
  }

  async _openSession() {
    this.serverInfo = undefined;
    this.negotiatedProtocolVersion = undefined;
    const init = await this._post({
      jsonrpc: '2.0',
      id: 1,
      method: 'initialize',
      params: {
        protocolVersion: this.server.protocolVersion || '2024-11-05',
        capabilities: {},
        clientInfo: { name: 'fmcad', version: pkg.version },
      },
    });
    if (init.status !== 200) throw new Error(`initialize failed: HTTP ${init.status}`);
    const resp = this._parse(init.raw);
    if (resp && resp.error) throw new Error('initialize failed: ' + JSON.stringify(resp.error));
    const result = resp?.result;
    const info = {};
    for (const key of ['name', 'version']) {
      const value = result?.serverInfo?.[key];
      if (typeof value === 'string' && value.trim()) info[key] = value;
    }
    if (Object.keys(info).length) this.serverInfo = info;
    if (typeof result?.protocolVersion === 'string' && result.protocolVersion.trim()) {
      this.negotiatedProtocolVersion = result.protocolVersion;
    }
    try {
      await this._post({ jsonrpc: '2.0', method: 'notifications/initialized' }, init.sessionId);
    } catch (e) {
      /* some servers close the response without body; ignore */
    }
    return init.sessionId;
  }

  async callTool(argumentsObj, toolName) {
    const sid = await this._openSession();
    const res = await this._post(
      {
        jsonrpc: '2.0',
        id: 2,
        method: 'tools/call',
        params: { name: toolName || this.server.tool, arguments: argumentsObj },
      },
      sid
    );
    if (res.status < 200 || res.status >= 300) throw new Error(`tools/call failed: HTTP ${res.status}`);
    const resp = this._parse(res.raw);
    if (!resp) throw new Error('empty response from server');
    if (resp.error) throw new Error('MCP_ERROR ' + JSON.stringify(resp.error));
    let text = '';
    for (const item of (resp.result && resp.result.content) || []) {
      if (item && item.type === 'text') text += item.text || '';
    }
    if (!text) text = (resp.result && (resp.result.message || JSON.stringify(resp.result))) || '';
    let failed = !!(resp.result && resp.result.isError);
    let data = null;
    const sc = resp.result && resp.result.structuredContent;
    if (sc !== undefined && sc !== null) data = sc;
    try {
      const parsed = JSON.parse(text);
      if (parsed.success === false || parsed.error) failed = true;
      if (parsed.message) text = parsed.message;
      if (!data && parsed.success !== undefined) data = parsed;
    } catch (e) {
      /* not JSON; leave as plain text */
    }
    if (/^ERROR /m.test(text)) failed = true;
    if (data && typeof data.message === 'string' && /^ERROR /m.test(data.message)) failed = true;
    if (data && (data.success === false || data.error || data.isError)) failed = true;
    return { text, failed, data };
  }

  async listTools() {
    const sid = await this._openSession();
    const res = await this._post({ jsonrpc: '2.0', id: 2, method: 'tools/list' }, sid);
    if (res.status < 200 || res.status >= 300) throw new Error(`tools/list failed: HTTP ${res.status}`);
    const resp = this._parse(res.raw);
    if (resp && resp.error) throw new Error('MCP_ERROR ' + JSON.stringify(resp.error));
    return (resp && resp.result && resp.result.tools) || [];
  }
}

module.exports = { McpClient, authorizeBrokerClient };
