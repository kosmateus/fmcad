const path = require('path');
const fs = require('fs');
const config = require('./config');
const { McpClient } = require('./client');
const ops = require('./ops');
const run = require('./run');
const docops = require('./docops');
const review = require('./review');
const { detail, globalHelp } = require('./help');
const { findCommand, globalFlags } = require('./commands');
const { parseCadInput } = require('./cad-input');
const { catalog, validateCad, executeCad } = require('./cad');
const { createBackend } = require('./backends');
const { checkPublishTarget, publishComplete } = require('./publish');
const { formatBatchSummary } = require('./batch');

function flagValue(argv, index) {
  const value = argv[index + 1];
  if (value === undefined || value === '' || /^--|^-[A-Za-z]/.test(value)) {
    throw new Error(`missing value for ${argv[index]}`);
  }
  return value;
}

function parseFlags(argv) {
  const opts = { headers: {} };
  const rest = [];
  for (let i = 0; i < argv.length; i++) {
    const flag = argv[i];
    if (!Object.hasOwn(globalFlags, flag)) {
      rest.push(flag);
      continue;
    }
    const value = flagValue(argv, i++);
    if (flag === '--header') {
      const colon = value.indexOf(':');
      if (colon < 1) throw new Error('--header requires K:V');
      opts.headers[value.slice(0, colon)] = value.slice(colon + 1);
    } else if (flag === '--timeout') {
      opts.timeoutMs = Number(value);
      if (!Number.isFinite(opts.timeoutMs)) throw new Error('--timeout requires a number');
    } else opts[flag.slice(2)] = value;
  }
  return { opts, rest };
}

function parseCommand(entry, rawArgs) {
  const args = [];
  const flags = {};
  for (let i = 0; i < rawArgs.length; i++) {
    const token = rawArgs[i];
    if (Object.hasOwn(entry.flags, token)) {
      if (entry.kind === 'run' && ['--doc-id', '--doc-file-id'].includes(token)) {
        if (Object.hasOwn(flags, token)) throw new Error(`Duplicate run option: ${token}`);
        const value = flagValue(rawArgs, i);
        if (typeof value !== 'string' || !value || /\s/.test(value) || value.startsWith('-')) {
          throw new Error(`${token} requires a nonempty identity without whitespace`);
        }
      }
      flags[token] = entry.flags[token] === 'value' ? flagValue(rawArgs, i++) : true;
    } else if (/^--|^-[A-Za-z]/.test(token)) {
      throw new Error(`unknown option for ${entry.key}: ${token}`);
    } else args.push(token);
  }
  const listing = entry.listFlags && entry.listFlags.some((flag) => flags[flag]);
  if (entry.kind === 'run') run.validateRunOutput(flags, listing);
  if (entry.kind === 'run') run.validateRunIdentity(flags, listing);
  if (entry.kind === 'run' && flags['--args'] !== undefined && flags['--args-file'] !== undefined) {
    throw new Error('run accepts only one of --args or --args-file');
  }
  if (args.length < (listing ? 0 : entry.minArgs) || args.length > entry.maxArgs) {
    throw new Error(`usage: fmcad ${entry.usage}`);
  }
  if (entry.requiresDoc && !flags['--doc']) {
    throw new Error(`${entry.key} requires --doc <name> (document commands always target an explicit document)`);
  }
  if (entry.exactlyOne && entry.exactlyOne.filter((flag) => flags[flag]).length !== 1) {
    throw new Error(`${entry.key} requires exactly one of ${entry.exactlyOne.join(' or ')}`);
  }
  if (entry.key === 'plane_add') {
    const count = { offset: 4, mid: 4, angle: 5 }[args[1]];
    if (!count || args.length !== count) throw new Error(`usage: fmcad ${entry.usage}`);
  }
  if (entry.key === 'projects' && args.length) throw new Error('usage: fmcad projects');
  return { args, flags, listing };
}

function toWindowsPath(p) {
  const m = p.match(/^\/mnt\/([a-zA-Z])\/(.*)$/);
  if (m) return m[1].toUpperCase() + ':\\' + m[2].replace(/\//g, '\\');
  const distro = process.env.WSL_DISTRO_NAME || 'Ubuntu';
  return '\\\\wsl$\\' + distro + p.replace(/\//g, '\\');
}

async function main(argv, dependencies = {}) {
  const deps = { ...config, McpClient, createBackend, ...ops, ...run, docops,
    stdout: process.stdout, stderr: process.stderr, ...dependencies };
  const { redactDiagnostic, formatJsonError } = require('./diagnostics');
  let diagnosticBackend = {};
  const load = deps.loadConfig;
  deps.loadConfig = (...args) => {
    const result = load(...args);
    diagnosticBackend = result.cfg;
    return result;
  };
  const fail = (code) => {
    if (dependencies.setExitCode) dependencies.setExitCode(code);
    else process.exitCode = code;
    return code;
  };
  try {
    if (argv[0] === 'diagnostic') {
      const code = await require('./diagnostic').main(argv.slice(1), deps);
      return code ? fail(code) : 0;
    }
    if (argv[0] === 'queue' && argv[1] && !argv.includes('--help') && !argv.includes('-h')) {
      const code = await require('./queue-cli').queueCommand(argv.slice(1), deps);
      return code ? fail(code) : 0;
    }
    const engineering = require('./engineering-local');
    const engineeringKey = argv.slice(0, 2).join(' ');
    if (Object.hasOwn(engineering.methods, engineeringKey)) {
      if (argv.includes('--help') || argv.includes('-h')) {
        deps.stdout.write(detail(...argv.slice(0, 2)));
        return 0;
      }
      const code = await engineering.execute(engineeringKey, argv.slice(2), deps);
      return code ? fail(code) : 0;
    }
    if (argv[0] === 'keychain' && ['prepare', 'status', 'approve', 'build', 'verify'].includes(argv[1])) {
      if (argv.includes('--help') || argv.includes('-h')) {
        deps.stdout.write(detail('keychain', argv[1]));
        return 0;
      }
      if (argv[1] === 'build') {
        require('./queue-client').assertDirectAccess();
        if (process.env.FMCAD_QUEUE_WORKER_JOB || deps.loadConfig().cfg.routing === 'queue') throw new Error('unsupported_queue_route: keychain build is excluded; no direct fallback');
      }
      const code = await require('./keychain').keychain(argv[1], argv.slice(2), deps);
      return code ? fail(code) : 0;
    }
    // Local image processing must not parse backend flags or load Fusion configuration.
    if (argv[0] === 'image' && argv[1] === 'trace') {
      if (argv.includes('--help') || argv.includes('-h')) {
        deps.stdout.write(detail('image', 'trace'));
        return 0;
      }
      const code = await require('./image-trace').traceImage(argv.slice(2), deps);
      return code ? fail(code) : 0;
    }
    if (argv[0] === 'image' && argv[1] === 'optimize') {
      if (argv.includes('--help') || argv.includes('-h')) {
        deps.stdout.write(detail('image', 'optimize'));
        return 0;
      }
      const code = await require('./image-optimize').optimizeImage(argv.slice(2), deps);
      return code ? fail(code) : 0;
    }
    if (argv[0] === 'image' && argv[1] === 'boundaries') {
      if (argv.includes('--help') || argv.includes('-h')) {
        deps.stdout.write(detail('image', 'boundaries'));
        return 0;
      }
      const code = await require('./image-boundaries').boundariesImage(argv.slice(2), deps);
      return code ? fail(code) : 0;
    }
    const { opts, rest } = parseFlags(argv);
    if (!rest.length) rest.push('help');
    const entry = findCommand(rest);
    if (!entry) throw new Error(`unknown command: ${rest[0]}\n\n${globalHelp()}`);
    if (entry.kind === 'help') {
      deps.stdout.write(rest[0] === 'help' && rest[1] && !rest[1].startsWith('-')
        ? detail(...rest.slice(1)) : globalHelp());
      return 0;
    }
    if (rest.includes('--help') || rest.includes('-h')) {
      deps.stdout.write(detail(...rest.filter(a => a !== '--help' && a !== '-h')));
      return 0;
    }
    if (entry.kind === 'family') throw new Error(`usage: fmcad ${entry.usage}`);
    if (entry.kind === 'local') throw new Error(`Local ${entry.key} options must follow "fmcad ${entry.key}"; backend/global flags are not supported.`);
    if (entry.kind === 'cad') {
      const spellings = [entry.key, ...(entry.aliases || [])].sort((a,b) => b.length - a.length);
      const spelling = spellings.find(s => rest.slice(0, s.split(' ').length).join(' ') === s);
      const spec = catalog[entry.target];
      const input = parseCadInput(rest.slice(spelling.split(' ').length), spec.inputs,
        { ...spec, observeShortcut: entry.target === 'batch.reconcile' });
      if (entry.requiresDoc && !input.doc) throw new Error(`${entry.key} requires --doc <name>`);
      validateCad(entry.target, input.data);
      const offline = spec.offline || require('./data-import').isOffline(entry.target, input.data) || input.preview ||
        (entry.target === 'references.refresh' && input.data.phase === 'inspect') || ['batch.validate', 'batch.preview'].includes(entry.target) ||
        (entry.target === 'definition.instantiate' && input.data.mode && input.data.mode !== 'run');
      if (spec.dataImport && !offline && !input.doc) throw new Error(`${entry.key} with inspectModel requires --doc <name>`);
      const cfg = offline ? null : deps.loadConfig(opts).cfg;
      if (cfg?.routing === 'queue' && !process.env.FMCAD_QUEUE_WORKER_JOB) {
        const code = await require('./queue-client').runQueued(argv, cfg, opts, deps);
        return code ? fail(code) : 0;
      }
      const client = offline ? null : deps.createBackend(cfg, deps);
      const result = await executeCad(client, entry.target, input.data,
        { doc: input.doc, component: input.component, projectId: input.projectId, preview: input.preview,
          ...(input.docId !== undefined ? { docId: input.docId } : {}),
          ...(input.docFileId !== undefined ? { docFileId: input.docFileId } : {}) });
      deps.stdout.write(!input.json && (input.summary || spec.textSummary)
        ? formatBatchSummary(result) : JSON.stringify(result, null, input.json ? 0 : 2) + '\n');
      return result.success === false || result.status === 'failed' ||
        (['batch.reconcile', 'batch.finalize'].includes(entry.target) && result.outcome === 'unknown') ? fail(1) : 0;
    }
    const rawArgs = rest.slice(entry.key.split(' ').length);
    const { args, flags, listing } = parseCommand(entry, rawArgs);
    if (entry.kind === 'review') review.parseReviewArgs(rawArgs);
    if (entry.kind === 'init') {
      const res = deps.initConfig({ fromOpencode: !!flags['--from-opencode'], force: !!flags['--force'], config: opts.config,
        ...(opts.backend ? { backend: opts.backend } : {}) });
      deps.stdout.write(`WROTE ${res.path} (${res.note})\n`);
      return 0;
    }
    if (listing) {
      for (const s of deps.listScripts()) deps.stdout.write(`${s.name} (${s.dir})\n`);
      return 0;
    }

    // Build scripts and parse JSON before loading config or constructing a client.
    let script;
    let callArgs;
    let runOutPath;
    switch (entry.kind) {
      case 'call': callArgs = JSON.parse(args[1]); break;
      case 'run': {
        if (flags['--out'] !== undefined) {
          runOutPath = path.resolve(flags['--out']);
          await checkPublishTarget(runOutPath);
        }
        const argsBytes = flags['--args-file'] !== undefined ? fs.readFileSync(flags['--args-file']) : undefined;
        if (argsBytes && process.env.FMCAD_QUEUE_WORKER_JOB) require('./queue-client').verifyInputBytes(flags['--args-file'], argsBytes);
        const payload = argsBytes !== undefined ? argsBytes.toString('utf8') : flags['--args'];
        const identityPinned = flags['--doc-id'] !== undefined || flags['--doc-file-id'] !== undefined;
        const runIdentity = {
          docId: flags['--doc-id'], docFileId: flags['--doc-file-id'], readOnly: !!flags['--readonly'],
        };
        script = deps.buildRunScript(args[0], payload !== undefined ? JSON.parse(payload) : [],
          payload !== undefined, flags['--doc'] || '',
          ...(identityPinned || flags['--helpers'] !== undefined ? [runIdentity] : []),
          ...(flags['--helpers'] !== undefined ? [flags['--helpers'], Object.entries(catalog).filter(([, spec]) => spec.readOnly).map(([name]) => name)] : []));
        break;
      }
      case 'op':
        if (entry.target === 'param_add') {
          while (args.length < 4) args.push('');
        }
        script = deps.buildOpScript(entry.target, entry.requiresDoc ? args.concat(flags['--doc']) : args);
        break;
      case 'upload':
        script = deps.buildOpScript(entry.target, [toWindowsPath(path.resolve(args[0])), flags['--project'] || '', flags['--folder'] || '']);
        break;
      case 'export': {
        const name = String(flags['--doc']).replace(/[^A-Za-z0-9_.-]+/g, '_');
        const outPath = flags['--out'] || path.join(process.cwd(), name + '.' + entry.target);
        script = deps.buildExportScript([entry.target, flags['--body'] || '', toWindowsPath(outPath), flags['--doc']]);
        break;
      }
    }
    const { cfg } = deps.loadConfig(opts);
    if (cfg.routing === 'queue' && !process.env.FMCAD_QUEUE_WORKER_JOB) {
      const code = await require('./queue-client').runQueued(argv, cfg, opts, deps);
      return code ? fail(code) : 0;
    }
    const client = deps.createBackend(cfg, deps);
    if (entry.kind === 'review') {
      const code = await review.reviewCmd(client, rawArgs, toWindowsPath, { stdout: deps.stdout });
      return code ? fail(code) : 0;
    }
    if (entry.kind === 'tools' || entry.kind === 'doctor') {
      if (entry.kind === 'doctor') deps.stdout.write(`CONFIG url=${new URL(cfg.url).origin}/[endpoint-redacted] tool=${cfg.tool} timeoutMs=${cfg.timeoutMs}\n`);
      if (entry.kind === 'doctor') deps.stdout.write(`BACKEND name=${cfg.backend || 'mcp'} transport=${cfg.transport || 'node'}\n`);
      if (entry.kind === 'doctor' && client.capabilities) deps.stdout.write('CAPABILITIES ' + JSON.stringify(client.capabilities) + '\n');
      const tools = await client.listTools();
      if (entry.kind === 'doctor') {
        const reported = value => typeof value === 'string' && value.trim()
          ? redactDiagnostic(value, cfg) : 'not reported';
        deps.stdout.write('SERVER ' + JSON.stringify({
          name: reported(client.serverInfo?.name),
          version: reported(client.serverInfo?.version),
          protocolVersion: reported(client.negotiatedProtocolVersion),
        }) + '\n');
      }
      if (entry.kind === 'tools') {
        if (flags['--json']) deps.stdout.write(JSON.stringify(tools, null, 2) + '\n');
        else for (const t of tools) deps.stdout.write(t.name + '\n');
      }
      else deps.stdout.write(`MCP_OK tools=${tools.length} (${tools.map((t) => t.name).join(', ')})\n`);
      return 0;
    }
    if (entry.kind === 'docops') {
      const code = await deps.docops[entry.target](client, entry.targetArg || rawArgs,
        entry.pathMapper ? toWindowsPath : undefined);
      return code ? fail(code) : 0;
    }
    const object = { script };
    if (entry.readOnly || flags['--readonly']) object.readOnly = true;
    if (flags['--readonly'] && cfg.backend === 'addin') {
      deps.stderr.write('WARNING: addin does not enforce a read-only sandbox; --readonly is a declaration only.\n');
    }
    const out = entry.kind === 'call'
      ? await client.callTool(callArgs, args[0])
      : await client.callTool({ featureType: 'script', object });
    if (out.data) deps.onOutcome?.(out.data);
    if (entry.kind === 'run' && out.uiGuard) {
      deps.stdout.write(JSON.stringify({ success: false, operation: 'run',
        status: out.uiGuard.status, script: args[0], userCodeSubmitted: out.uiGuard.notStarted === true,
        activeCommand: out.uiGuard.activeCommand ?? null,
        activeCommandIdentityAvailable: out.uiGuard.identityAvailable === true,
        originalOperationOutcome: 'notEvaluated',
        suggestedRecovery: ['ui.inspect', 'ui.resolve'],
        limitations: ['This receipt proves only that this new script was rejected before user code; it does not resolve any underlying pending/unknown operation.'] }, null, 2) + '\n');
      return fail(1);
    }
    deps.stdout.write(out.text + '\n');
    if (out.stderr && !out.failed) deps.stderr.write(redactDiagnostic(out.stderr, diagnosticBackend));
    if (runOutPath && !out.failed) {
      try {
        await publishComplete(runOutPath, run.formatRunOutput(out.text, flags['--out-format'], flags['--pretty'] === 'true'));
      } catch (error) {
        throw new Error(`Run output was not confirmed published: ${error.message}. Script may have mutated Fusion; inspect before another run. No automatic retry.`);
      }
    }
    return out.failed ? fail(1) : 0;
  } catch (e) {
    // Preserve SDK/execution SyntaxErrors that did not originate in JSON.parse.
    const message = e instanceof SyntaxError && /^\s+at JSON\.parse \(/m.test(e.stack || '')
      ? formatJsonError(e) : e.message;
    deps.stderr.write(redactDiagnostic('ERROR ' + message + '\n', diagnosticBackend));
    return fail(1);
  }
}

module.exports = { main, parseFlags };
