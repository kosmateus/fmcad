const fs = require('fs');
const os = require('os');
const path = require('path');
const { pythonValue } = require('./python');

function userScriptsDir() {
  const base = process.env.XDG_CONFIG_HOME || path.join(os.homedir(), '.config');
  return path.join(base, 'fmcad', 'scripts');
}

function pkgScriptsDir() {
  return path.join(__dirname, '..', 'assets', 'scripts');
}

function resolveScript(name) {
  if (name.includes('/') || name.endsWith('.py')) {
    const p = path.resolve(name);
    if (fs.existsSync(p)) return p;
    throw new Error(`script not found: ${p}`);
  }
  const candidates = [path.join(userScriptsDir(), name + '.py'), path.join(pkgScriptsDir(), name + '.py')];
  for (const c of candidates) {
    if (fs.existsSync(c)) return c;
  }
  throw new Error(`script "${name}" not found in ${userScriptsDir()} or ${pkgScriptsDir()}`);
}

function validateRunIdentity(flags, listing) {
  const guarded = ['--doc-id', '--doc-file-id'].some(flag => flags[flag] !== undefined);
  if (!guarded) return;
  if (listing) throw new Error('run identity guards cannot be combined with --list');
  if (typeof flags['--doc'] !== 'string' || !flags['--doc'].trim()) {
    throw new Error('run identity guards require --doc <name>');
  }
  for (const flag of ['--doc-id', '--doc-file-id']) {
    const value = flags[flag];
    if (value !== undefined && (typeof value !== 'string' || !value || /\s/.test(value) || value.startsWith('-'))) {
      throw new Error(`${flag} requires a nonempty identity without whitespace`);
    }
  }
}

function buildRunScript(name, args, hasArgs, docName, identity = {}, helperVersion, readOnlyOperations = []) {
  if (helperVersion !== undefined && helperVersion !== 'cad-v1') throw new Error(`unknown helper version: ${helperVersion}`);
  if (helperVersion && (!docName || (identity.docId === undefined && identity.docFileId === undefined))) throw new Error('--helpers cad-v1 requires --doc and --doc-id or --doc-file-id');
  validateRunIdentity({ '--doc': docName, '--doc-id': identity.docId, '--doc-file-id': identity.docFileId });
  const file = resolveScript(name);
  const bytes = fs.readFileSync(file);
  if (process.env.FMCAD_QUEUE_WORKER_JOB) require('./queue-client').verifyInputBytes(file, bytes);
  let code = bytes.toString('utf8');
  if (hasArgs) {
    if (!/^ARGS = .*$/m.test(code)) {
      throw new Error(`${file} has no "ARGS = ..." config line; cannot inject --args`);
    }
    code = code.replace(/^ARGS = .*$/m, () => 'ARGS = ' + pythonValue(args));
  }
  if (docName) {
    if (!/^DOC_NAME = .*$/m.test(code)) {
      throw new Error(`${file} has no "DOC_NAME = ..." config line; cannot inject --doc`);
    }
    code = code.replace(/^DOC_NAME = .*$/m, () => 'DOC_NAME = ' + pythonValue(docName));
  }
  if (identity.docId === undefined && identity.docFileId === undefined && !helperVersion) return code;
  const dir = path.join(__dirname, '..', 'assets', 'cad');
  const helpers = fs.readFileSync(path.join(dir, 'identity.py'), 'utf8');
  const helper = helperVersion ? fs.readFileSync(path.join(dir, 'helpers.py'), 'utf8') : '';
  const cadFiles = helperVersion ? ['core.py', ...fs.readdirSync(dir).filter(f => f.endsWith('.py') && !['core.py', 'identity.py', 'helpers.py'].includes(f)).sort()] : [];
  const cadBundle = cadFiles.map(f => fs.readFileSync(path.join(dir, f), 'utf8')).join('\n\n');
  return helpers + '\n' + cadBundle + '\n' + helper + `
def run(_context):
    import adsk.core
    app = adsk.core.Application.get()
    doc = _document_target(app, ${pythonValue(docName)})
    doc_id, doc_file_id = ${pythonValue(identity.docId ?? null)}, ${pythonValue(identity.docFileId ?? null)}
    _document_assert_identity(doc, doc_id, doc_file_id)
    if ${identity.readOnly ? 'False' : 'True'}:
        _document_activate_target(app, doc, doc_id, doc_file_id)
    # Trusted-code precondition, not a sandbox. Do not inherit this wrapper's run.
    namespace = {'__name__': '__fmcad_script__', '__file__': ${pythonValue(file)}}
    exec(compile(${pythonValue(code)}, ${pythonValue(file)}, 'exec', dont_inherit=True), namespace)
    if 'run' in namespace:
        if ${helperVersion ? 'True' : 'False'}:
            ctx = CadContext(${pythonValue(docName)}, None, None, doc_id, doc_file_id)
            ctx.read_only_operations = ${pythonValue(readOnlyOperations)}
            facade = FMCAD(ctx, ${identity.readOnly ? 'True' : 'False'})
            try:
                namespace['FMCAD'] = facade
                value = namespace['run'](_context)
                if value is not None and facade._emitted is _NOT_EMITTED: facade.emit(value)
                facade._terminal()
                return value
            except BaseException as exc:
                facade._terminal(exc)
                raise
        return namespace['run'](_context)
`;
}

function listScripts() {
  const entries = [];
  for (const dir of [userScriptsDir(), pkgScriptsDir()]) {
    if (!fs.existsSync(dir)) continue;
    for (const f of fs.readdirSync(dir).sort()) {
      if (f.endsWith('.py')) entries.push({ name: f.replace(/\.py$/, ''), dir });
    }
  }
  return entries;
}

function validateRunOutput(flags, listing) {
  const format = flags['--out-format'];
  const pretty = flags['--pretty'];
  if (listing && ['--out', '--out-format', '--pretty'].some(flag => flags[flag] !== undefined)) {
    throw new Error('run --list cannot be combined with output file options');
  }
  if ((format !== undefined || pretty !== undefined) && flags['--out'] === undefined) {
    throw new Error('--out-format and --pretty require --out');
  }
  if (format !== undefined && !['text', 'json'].includes(format)) throw new Error('--out-format must be text or json');
  if (pretty !== undefined && format !== 'json') throw new Error('--pretty requires --out-format json');
  if (pretty !== undefined && !['true', 'false'].includes(pretty)) throw new Error('--pretty must be true or false');
}

function formatRunOutput(text, format = 'text', pretty = false) {
  if (format === 'text') return text;
  let value;
  try { value = JSON.parse(text); }
  catch {
    const markers = text.split(/\r?\n/).filter(line => /^(FMCAD_RESULT|KEYCHAIN_RESULT)(?:\s|$)/.test(line));
    if (markers.length !== 1) throw new Error('JSON output requires a whole JSON value or exactly one FMCAD_RESULT/KEYCHAIN_RESULT marker');
    try { value = JSON.parse(markers[0].replace(/^(FMCAD_RESULT|KEYCHAIN_RESULT)/, '')); }
    catch { throw new Error('Malformed JSON output result marker'); }
  }
  return JSON.stringify(value, null, pretty ? 2 : 0) + '\n';
}

module.exports = { buildRunScript, resolveScript, listScripts, userScriptsDir, pkgScriptsDir, validateRunIdentity, validateRunOutput, formatRunOutput };
