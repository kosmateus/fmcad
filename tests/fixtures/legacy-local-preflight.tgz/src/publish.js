const fs = require('node:fs/promises');
const path = require('node:path');
const { randomUUID } = require('node:crypto');

async function withCleanup(action, cleanup) {
  let primary;
  try { return await action(); }
  catch (error) { primary = error; throw error; }
  finally {
    try { await cleanup(); }
    catch (error) {
      if (!primary) throw error;
      (primary.cleanupErrors ||= []).push(error);
      primary.message += `; cleanup failed: ${error.message}`;
    }
  }
}

async function checkPublishTarget(target, io = fs) {
  const parent = path.dirname(target);
  if (!(await io.stat(parent)).isDirectory()) throw new Error(`Output parent is not a directory: ${parent}`);
  await io.access(parent, fs.constants.W_OK | fs.constants.X_OK);
  try {
    await io.lstat(target);
  } catch (error) {
    if (error.code === 'ENOENT') return;
    throw error;
  }
  throw new Error(`Output already exists; refusing to replace: ${target}`);
}

async function publishComplete(target, contents, io = fs) {
  const parent = path.dirname(target);
  const temporary = path.join(parent, `.snapshot-${randomUUID()}`);
  const file = await io.open(temporary, 'wx', 0o600);
  await withCleanup(async () => {
    await withCleanup(async () => {
      await file.writeFile(contents);
      await file.sync();
    }, () => file.close());
    // The destination becomes visible only when complete; link never replaces it.
    await io.link(temporary, target);
  }, () => io.unlink(temporary));
  const directory = await io.open(parent, 'r');
  await withCleanup(() => directory.sync(), () => directory.close());
}

module.exports = { checkPublishTarget, publishComplete };
