'use strict';
const { parseFlags } = require('./cli');
const { findCommand } = require('./commands');

function documentSelector(job) {
  if (job.kind === 'rpc') {
    return ['initialize', 'notifications/initialized', 'ping', 'tools/list'].includes(job.request.payload?.method)
      ? { metadataOnly: true } : null;
  }
  const { rest } = parseFlags(job.request.argv);
  const entry = findCommand(rest);
  if (['tools', 'doctor'].includes(entry?.kind)) return { metadataOnly: true };
  const selector = {};
  for (const [flag, key] of [['--doc', 'name'], ['--doc-id', 'creationId'], ['--doc-file-id', 'fileId']]) {
    const index = rest.indexOf(flag);
    if (index >= 0 && rest[index + 1]) selector[key] = rest[index + 1];
  }
  return Object.keys(selector).length ? selector : null;
}

function compareDocumentState(previous, current) {
  if (previous?.status === 'metadata-only' && current?.status === 'metadata-only') return null;
  if (current?.status !== 'complete') return 'DOCUMENT_STATE_UNAVAILABLE';
  if (previous?.status !== 'complete') return 'DOCUMENT_BASELINE_REQUIRED';
  if (previous.state?.identity?.creationId !== current.state?.identity?.creationId) return 'DOCUMENT_TARGET_CHANGED';
  return previous.fingerprint === current.fingerprint ? null : 'DOCUMENT_CHANGED';
}

module.exports = { documentSelector, compareDocumentState };
