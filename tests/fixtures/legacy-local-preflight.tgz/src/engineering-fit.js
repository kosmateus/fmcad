const { object, number, text, list, quantity: q, output: out, hash, context, envelope } = require('./engineering-common');

function fit(data) {
  const c = context(data, ['terms', 'minimum', 'maximum', 'statistics']);
  const terms = list(data.terms, 'terms');
  const ids = new Set();
  const contributions = terms.map((t, i) => {
    c.tick();
    object(t, ['id', 'sign', 'nominal', 'minus', 'plus', 'deflection', 'thermal', 'angle', 'sigma'], `terms[${i}]`, ['id', 'sign']);
    text(t.id, 'term.id'); if (ids.has(t.id)) throw new Error('Duplicate term id'); ids.add(t.id);
    if (![1, -1].includes(t.sign)) throw new Error('term.sign must be +1 or -1');
    let nominal = q(t.nominal, 'length', `${t.id}.nominal`, c);
    const minus = q(t.minus, 'length', `${t.id}.minus`, c, 0), plus = q(t.plus, 'length', `${t.id}.plus`, c, 0);
    let low = nominal === null || minus === null ? null : nominal - minus;
    let high = nominal === null || plus === null ? null : nominal + plus;
    if (t.deflection !== undefined) {
      object(t.deflection, ['nominal', 'minimum', 'maximum'], 'deflection');
      const n = q(t.deflection.nominal, 'length', 'deflection.nominal', c), a = q(t.deflection.minimum, 'length', 'deflection.minimum', c), b = q(t.deflection.maximum, 'length', 'deflection.maximum', c);
      if (a !== null && b !== null && (a > b || n !== null && (n < a || n > b))) throw new Error('Invalid deflection interval');
      nominal = add(nominal, n); low = add(low, a); high = add(high, b);
    }
    if (t.thermal !== undefined) {
      object(t.thermal, ['alpha', 'delta', 'minimumDelta', 'maximumDelta'], 'thermal');
      const alpha = q(t.thermal.alpha, 'expansion', 'thermal.alpha', c);
      const dt = q(t.thermal.delta, 'temperatureDelta', 'thermal.delta', c);
      const a = q(t.thermal.minimumDelta, 'temperatureDelta', 'thermal.minimumDelta', c), b = q(t.thermal.maximumDelta, 'temperatureDelta', 'thermal.maximumDelta', c);
      if (a !== null && b !== null && (a > b || dt !== null && (dt < a || dt > b))) throw new Error('Invalid temperature interval');
      if ([alpha, dt, a, b, low, high, nominal].includes(null)) { nominal = low = high = null; }
      else {
        const factors = [1 + alpha * a, 1 + alpha * b];
        if (Math.min(...factors) <= 0) throw new Error('Thermal scale must remain positive');
        const corners = [low * factors[0], low * factors[1], high * factors[0], high * factors[1]];
        nominal *= 1 + alpha * dt; low = Math.min(...corners); high = Math.max(...corners);
      }
    }
    if (t.angle !== undefined) {
      object(t.angle, ['nominal', 'minus', 'plus'], 'angle');
      const n = q(t.angle.nominal, 'angle', 'angle.nominal', c, -1e6, 1e6), a = q(t.angle.minus, 'angle', 'angle.minus', c, 0, 1e6), b = q(t.angle.plus, 'angle', 'angle.plus', c, 0, 1e6);
      if ([n, a, b, nominal, low, high].includes(null)) nominal = low = high = null;
      else {
        const lo = n - a, hi = n + b;
        const values = [Math.sin(lo), Math.sin(hi)];
        if (hi - lo >= 2 * Math.PI) values.push(-1, 1);
        else {
          const first = Math.ceil((lo - Math.PI / 2) / Math.PI), last = Math.floor((hi - Math.PI / 2) / Math.PI);
          for (let k = first; k <= last; k++) { c.tick(); values.push(k % 2 === 0 ? 1 : -1); }
        }
        const corners = values.flatMap(v => [low * v, high * v]);
        nominal *= Math.sin(n); low = Math.min(...corners); high = Math.max(...corners);
      }
    }
    const sigma = t.sigma === undefined ? null : q(t.sigma, 'length', `${t.id}.sigma`, c, 0);
    return { id: t.id, nominal: nominal === null ? null : nominal * t.sign,
      minimum: low === null || high === null ? null : t.sign === 1 ? low : -high,
      maximum: low === null || high === null ? null : t.sign === 1 ? high : -low, sign: t.sign, sigma };
  });
  const sum = key => contributions.some(t => t[key] === null) ? null : contributions.reduce((s, t) => s + t[key], 0);
  const nominal = sum('nominal'), low = sum('minimum'), high = sum('maximum');
  const minimum = data.minimum === undefined ? null : q(data.minimum, 'length', 'minimum', c);
  const maximum = data.maximum === undefined ? null : q(data.maximum, 'length', 'maximum', c);
  if (minimum !== null && maximum !== null && minimum > maximum) throw new Error('minimum exceeds maximum');
  let statistical = null;
  if (data.statistics !== undefined) {
    object(data.statistics, ['model', 'coverage', 'correlation', 'assumptions'], 'statistics', ['model', 'coverage', 'correlation', 'assumptions']);
    if (data.statistics.model !== 'linear-normal') throw new Error('Only explicit linear-normal statistics are supported');
    list(data.statistics.assumptions, 'statistical assumptions').forEach(x => text(x, 'assumption'));
    const coverage = number(data.statistics.coverage, 'coverage', Number.MIN_VALUE, 10);
    const r = list(data.statistics.correlation, 'correlation', terms.length, terms.length);
    r.forEach(row => list(row, 'correlation row', terms.length, terms.length).forEach(x => number(x, 'correlation', -1, 1)));
    // Semidefinite Cholesky, allowing perfectly correlated inputs.
    const l = r.map(row => row.map(() => 0));
    for (let i = 0; i < r.length; i++) for (let j = 0; j <= i; j++) {
      c.tick();
      if (Math.abs(r[i][j] - r[j][i]) > 1e-12 || r[i][i] !== 1) throw new Error('Correlation must be symmetric with unit diagonal');
      let v = r[i][j]; for (let k = 0; k < j; k++) v -= l[i][k] * l[j][k];
      if (i === j) { if (v < -1e-12) throw new Error('Correlation must be positive semidefinite'); l[i][j] = Math.sqrt(Math.max(0, v)); }
      else if (l[j][j] > 1e-12) l[i][j] = v / l[j][j];
      else if (Math.abs(v) > 1e-12) throw new Error('Correlation must be positive semidefinite');
    }
    contributions.forEach(t => { if (t.sigma === null) c.missing.push(`${t.id}.sigma`); });
    if (contributions.every(t => t.sigma !== null) && nominal !== null) {
      let variance = 0;
      contributions.forEach((a, i) => contributions.forEach((b, j) => { c.tick(); variance += a.sign * b.sign * a.sigma * b.sigma * r[i][j]; }));
      const sigma = Math.sqrt(Math.max(0, variance));
      statistical = { model: 'linear-normal', sigma: out(sigma, 'm'), minimum: out(nominal - coverage * sigma, 'm'), maximum: out(nominal + coverage * sigma, 'm'), coverage,
        assumptions: data.statistics.assumptions, interpretation: 'Input sigmas describe final projected contributions; this interval is not worst case.' };
    }
  }
  c.limitations.push('One-dimensional signed stack in the declared common datum/frame; angle uses length*sin(angle). No general 3D GD&T solver. WC treats bounded terms independently; correlations affect only the separate statistical model.');
  const status = low === null || high === null ? 'unknown' : minimum === null && maximum === null ? 'notEvaluated' : minimum !== null && low < minimum || maximum !== null && high > maximum ? 'fail' : 'pass';
  return envelope('fit.stack', data, c, { nominal: out(nominal, 'm'), minimum: out(low, 'm'), maximum: out(high, 'm'),
    contributions: contributions.map(t => ({ id: t.id, nominal: out(t.nominal, 'm'), minimum: out(t.minimum, 'm'), maximum: out(t.maximum, 'm') })), statistical }, status);
}
function add(a, b) { return a === null || b === null ? null : a + b; }

function definition(data) {
  const c = context(data, ['id', 'revision', 'parts', 'datums', 'requirements', 'representation', 'nativeRefs']);
  text(data.id, 'id'); text(data.revision, 'revision');
  const parts = list(data.parts, 'parts', 2).map(x => text(x, 'part occurrence path'));
  if (new Set(parts).size !== parts.length) throw new Error('parts must be unique occurrence paths');
  list(data.datums, 'datums').forEach(x => text(x, 'datum'));
  if (!['snapshot', 'nativeReference'].includes(data.representation)) throw new Error('representation must be snapshot or nativeReference');
  const requirements = list(data.requirements, 'requirements').map(f => {
    if (hash(f.identity) !== hash(data.identity) || f.frame !== data.frame) throw new Error('Requirement identity/frame mismatch');
    const r = fit(f); c.tick(r.work.completed);
    c.sources.push(...r.provenance.sources); c.missing.push(...r.warnings);
    return r;
  });
  const contract = { schemaVersion: 1, id: data.id, revision: data.revision, identity: data.identity, frame: data.frame,
    parts, datums: data.datums, requirements: data.requirements, representation: data.representation, nativeRefs: data.nativeRefs || null };
  const result = { contract, fingerprint: hash(contract), checks: requirements, dependentParts: parts };
  c.limitations.push('Local immutable interface manifest. Native query/datum/reference resolution requires main-agent live handoff.');
  const reply = envelope('interface.define', data, c, result, data.representation === 'nativeReference' ? 'blocked' : 'notEvaluated');
  reply.affected = parts;
  return reply;
}
function check(data) {
  const c = context(data, ['definition', 'previous']);
  const current = definition(data.definition);
  c.tick(current.work.completed);
  c.sources.push(...current.provenance.sources); c.missing.push(...current.warnings);
  if (hash(data.identity) !== hash(data.definition.identity) || data.frame !== data.definition.frame) throw new Error('Interface identity/frame mismatch');
  let changed = false, invalidatedParts = [];
  if (data.previous !== undefined) {
    object(data.previous, ['contract', 'fingerprint'], 'previous', ['contract', 'fingerprint']);
    if (hash(data.previous.contract) !== data.previous.fingerprint) throw new Error('Invalid previous interface fingerprint');
    if (data.previous.contract.id !== data.definition.id) throw new Error('Previous interface ID mismatch');
    changed = data.previous.fingerprint !== current.result.fingerprint;
    if (changed) invalidatedParts = [...new Set([...data.previous.contract.parts, ...current.result.dependentParts])];
  }
  const checks = current.result.checks;
  let status = current.status === 'blocked' ? 'blocked' : checks.some(x => x.status === 'fail') ? 'fail' : checks.every(x => x.status === 'pass') ? 'pass' : 'unknown';
  if (changed) status = 'blocked';
  c.limitations.push(...current.limitations, 'Changed contracts invalidate evidence for all old and new mating occurrences. Rerun dependent part checks against the new fingerprint.');
  const reply = envelope('interface.check', data, c, { ...current.result, changed, invalidatedParts, reusePreviousEvidence: data.previous !== undefined && !changed,
    handoff: current.status === 'blocked' ? 'Resolve native interface refs in the identified live document and revision.' : null }, status);
  reply.affected = invalidatedParts;
  return reply;
}
module.exports = { fit, definition, check };
