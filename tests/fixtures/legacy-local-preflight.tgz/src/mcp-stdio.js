const readline = require('node:readline');
const { parseArgs } = require('node:util');
const { randomUUID } = require('node:crypto');
const { McpClient } = require('./client');
const { QueueClient } = require('./queue-client');
const { loadConfig } = require('./config');
const { redactDiagnostic, formatJsonError } = require('./diagnostics');

function responseMessages(raw) {
  const text = raw.trim();
  if (!text) return [];
  if (text.startsWith('{')) return [JSON.parse(text)];
  return text.split(/\r?\n\r?\n/).map(block => block.split(/\r?\n/)
    .filter(line => line.startsWith('data:'))
    .map(line => line.slice(5).trimStart()).join('\n'))
    .filter(Boolean).map(value => JSON.parse(value));
}

const queueTools = [
  ['begin', 'Begin an explicit queue sequence lease; returns sequenceId and revision.', {}],
  ['end', 'Release an idle queue sequence lease.', { sequenceId: { type: 'string', minLength: 1, maxLength: 256 } }],
  ['status', 'Read broker queue status and revision.', {}],
  ['result', 'Read an owned queue job and its available result.', { jobId: { type: 'string', minLength: 1, maxLength: 256 } }],
  ['reconcile', 'Reconcile an owned uncertain job using existing receipts; never replay it.', { jobId: { type: 'string', minLength: 1, maxLength: 256 } }],
].map(([name, description, properties]) => ({
  name: 'fmcad_queue_' + name, description,
  inputSchema: { type: 'object', properties, required: Object.keys(properties), additionalProperties: false },
}));
const QUEUED_ACCEPT_MS = 1000;

const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const identifier = value => typeof value === 'string' && value.trim().length > 0 && value.length <= 256;
const invalidQueueParams = message => { throw Object.assign(new Error(message), { code: 'INVALID_QUEUE_PARAMS' }); };

function receipt(job) {
  return { jobId: job.id, revision: job.revision ?? null, sequenceId: job.sequenceId ?? null,
    sequenceState: job.sequenceState ?? null, state: job.state };
}

function queueMetadata(request) {
  const meta = request.params?._meta;
  if (request.method !== 'tools/call' || !object(meta) || !Object.hasOwn(meta, 'fmcad')) return { payload: request, options: {} };
  const options = meta.fmcad;
  if (!object(options) || Object.keys(options).some(key => !['sequence', 'expectedRevision', 'requestId'].includes(key))) {
    invalidQueueParams('params._meta.fmcad accepts only sequence, expectedRevision and requestId');
  }
  if (options.sequence !== undefined) {
    const seq = options.sequence;
    if (!object(seq) || Object.keys(seq).some(key => !['action', 'id'].includes(key)) ||
        !['continue', 'end'].includes(seq.action) || !identifier(seq.id)) {
      invalidQueueParams('sequence requires action continue|end and id; begin with fmcad_queue_begin');
    }
  }
  if (options.expectedRevision !== undefined && (!Number.isSafeInteger(options.expectedRevision) || options.expectedRevision < 0)) {
    invalidQueueParams('expectedRevision must be a nonnegative safe integer');
  }
  if (options.requestId !== undefined && !identifier(options.requestId)) invalidQueueParams('requestId must contain 1..256 characters');
  const upstreamMeta = { ...meta };
  delete upstreamMeta.fmcad;
  const params = { ...request.params, _meta: upstreamMeta };
  if (!Object.keys(upstreamMeta).length) delete params._meta;
  return { payload: { ...request, params }, options };
}

function createQueuePost(client, cfg, queueTimeoutMs, McpClientClass = McpClient) {
  let registration;
  const controlClient = new McpClientClass(cfg);
  const ready = (autoStart = true) => registration ||= Promise.resolve().then(() => client.register({ autoStart })).catch(error => {
    registration = undefined;
    throw error;
  });
  const post = async (request, session, version) => {
    let requestId = randomUUID(), job;
    const reply = result => ({ status: 200, raw: JSON.stringify({ jsonrpc: '2.0', id: request.id, result }) });
    const helperResult = value => reply({ content: [{ type: 'text', text: JSON.stringify(value) }], structuredContent: value });
    try {
      if (['initialize', 'notifications/initialized', 'ping', 'tools/list'].includes(request.method)) {
        const response = await controlClient.controlPost(request, session, version);
        return { ...response, ...(request.method === 'tools/list' ? { queueTools: true } : {}) };
      }
      const helper = request.method === 'tools/call' && queueTools.find(tool => tool.name === request.params?.name);
      const { payload, options } = queueMetadata(request);
      requestId = options.requestId || requestId;
      if (helper) {
        if (!Object.hasOwn(request, 'id')) throw Object.assign(new Error('Queue helpers require a request id'), { code: 'unsupported_queue_route' });
        if (request.params?._meta && Object.hasOwn(request.params._meta, 'fmcad')) invalidQueueParams('Queue helper tools do not accept fmcad metadata');
        const args = request.params.arguments === undefined ? {} : request.params.arguments;
        const keys = helper.inputSchema.required;
        if (!object(args) || Object.keys(args).some(key => !keys.includes(key)) || keys.some(key => !identifier(args[key]))) {
          invalidQueueParams(helper.name + ' requires exactly: ' + (keys.join(', ') || 'empty arguments'));
        }
        await ready(helper.name === 'fmcad_queue_begin');
        switch (helper.name) {
          case 'fmcad_queue_end': return helperResult(await client.call('release', { sequenceId: args.sequenceId }));
          case 'fmcad_queue_status': return helperResult(await client.call('status'));
          case 'fmcad_queue_result': {
            const value = await client.call('result', { jobId: args.jobId });
            const response = helperResult(value);
            return { ...response, queueReceipt: receipt(value.job) };
          }
          case 'fmcad_queue_reconcile': {
            const value = await client.call('reconcile', { jobId: args.jobId });
            return { ...helperResult(value), queueReceipt: receipt(value) };
          }
        }
      }
      await ready();
      const begin = helper?.name === 'fmcad_queue_begin';
      const input = { kind: 'rpc', payload: begin ? { jsonrpc: '2.0', id: request.id, method: 'ping' } : payload,
        ...(session ? { sessionId: session } : {}), ...(version ? { protocolVersion: version } : {}), timeoutMs: cfg.timeoutMs, cwd: process.cwd(),
        requestId, backend: cfg.backend, ...options,
        ...(queueTimeoutMs !== undefined ? { queueTimeoutMs } : {}),
        ...(begin ? { sequence: { action: 'begin', mode: 'exclusive' } } : {}) };
      job = await client.submit(input);
      const controller = new AbortController();
      const completion = client.wait(job.id, { signal: controller.signal })
        .then(value => ({ value }), error => ({ error }));
      let timer;
      const first = await Promise.race([completion, new Promise(resolve => {
        timer = setTimeout(() => resolve(null), QUEUED_ACCEPT_MS);
      })]);
      clearTimeout(timer);
      if (first === null) {
        const current = await client.call('result', { jobId: job.id });
        if (current.job?.state === 'queued') {
          controller.abort();
          const accepted = { status: 'QUEUED', jobId: job.id, state: 'queued', executed: false,
            instruction: 'Poll fmcad_queue_result with this jobId; do not resubmit this task.' };
          return { ...reply({ content: [{ type: 'text', text: JSON.stringify(accepted) }], structuredContent: accepted }),
            queueReceipt: receipt(current.job), queueTools: true };
        }
      }
      const outcome = first || await completion;
      if (outcome.error) throw outcome.error;
      const value = outcome.value;
      job = value.job;
      if (!value.rpc && value.outputs?.rpc) {
        const fs = require('node:fs'), path = require('node:path');
        const expected = path.join(client.dir, 'jobs', job.id, 'rpc-result.json');
        if (path.resolve(value.outputs.rpc.path) !== expected) throw new Error('Unexpected owned RPC artifact path');
        const fd = fs.openSync(expected, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
        try {
          if (fs.fstatSync(fd).size > 16 * 1024 * 1024) throw new Error('Owned RPC artifact exceeds supported 16 MiB');
          value.rpc = JSON.parse(fs.readFileSync(fd, 'utf8'));
        } finally { fs.closeSync(fd); }
      }
      if (!['succeeded', 'failed'].includes(job.state) || !value.rpc) {
        throw Object.assign(new Error('Queue job ' + job.id + ' is ' + job.state +
          ' (' + (job.code || value.execution?.code || 'RAW_RESULT_UNAVAILABLE') + '); inspect its result before any resubmission'), { code: 'QUEUE_RESULT_UNAVAILABLE' });
      }
      const response = { ...value.rpc, queueReceipt: receipt(job), queueTools: true };
      if (begin) {
        // Validate the physical ping before replacing its payload with the lease receipt.
        const messages = responseMessages(response.raw);
        const ping = messages.find(message => message.id === request.id && (Object.hasOwn(message, 'result') || Object.hasOwn(message, 'error')));
        if (response.status < 200 || response.status >= 300 || !ping || messages.some(message => message.jsonrpc !== '2.0')) {
          throw new Error('Missing or invalid matching MCP response for queue sequence begin');
        }
        if (ping.error) return response;
        if (job.state !== 'succeeded') throw new Error('Queue sequence begin failed; inspect job ' + job.id);
        const result = { content: [{ type: 'text', text: JSON.stringify(receipt(job)) }], structuredContent: receipt(job) };
        const replies = messages.map(message => message === ping ? { ...message, result } : message);
        return { ...response, raw: replies.length === 1 ? JSON.stringify(replies[0])
          : replies.map(message => 'data: ' + JSON.stringify(message) + '\n\n').join('') };
      }
      return response;
    } catch (error) {
      if (!Object.hasOwn(request, 'id')) throw error;
      return { status: 200, raw: JSON.stringify({ jsonrpc: '2.0', id: request.id, error: {
        code: -32000, message: error instanceof SyntaxError ? formatJsonError(error)
          : redactDiagnostic((error.code ? error.code + ': ' : '') + error.message, cfg),
        data: { requestId, ...(job ? { fmcad: receipt(job) } : {}) },
      } }) };
    }
  };
  post.close = () => controlClient.reqOpts?.agent?.destroy();
  return post;
}

// Framing/transport only: forward the backend's own tools, resources and schemas.
// Do not initialize a second session, adapt Python, or retry a failed request.
function createForwarder(post, send, log = () => {}, cfg = {}) {
  let session;
  let version;
  return async line => {
    let request;
    try {
      request = JSON.parse(line);
    } catch (_) {
      send({ jsonrpc: '2.0', id: null, error: { code: -32700, message: 'Invalid JSON' } });
      return;
    }
    if (!request || Array.isArray(request) || request.jsonrpc !== '2.0' || typeof request.method !== 'string') {
      send({ jsonrpc: '2.0', id: null, error: { code: -32600, message: 'Expected a JSON-RPC request or notification' } });
      return;
    }
    const hasId = Object.hasOwn(request, 'id');
    let response;
    try {
      response = await post(request, session, version);
      if (response.status < 200 || response.status >= 300) throw new Error('HTTP ' + response.status);
      if (response.sessionId) session = response.sessionId;
      const messages = responseMessages(response.raw);
      if (hasId && !messages.some(message => message.id === request.id &&
          (Object.hasOwn(message, 'result') || Object.hasOwn(message, 'error')))) {
        throw new Error('Missing matching MCP response');
      }
      for (const message of messages) {
        if (message.jsonrpc !== '2.0') throw new Error('Invalid upstream JSON-RPC message');
      }
      for (const message of messages) {
        if (message.id !== request.id) continue;
        if (response.queueTools && request.method === 'tools/list' && Array.isArray(message.result?.tools)) {
          message.result.tools = [...message.result.tools.filter(tool => !queueTools.some(local => local.name === tool.name)), ...queueTools];
        }
        if (response.queueReceipt && object(message.result)) message.result._meta = { ...message.result._meta, fmcad: response.queueReceipt };
        if (response.queueReceipt && object(message.error)) message.error.data = { ...message.error.data, fmcad: response.queueReceipt };
      }
      if (request.method === 'initialize') {
        version = messages.find(message => message.id === request.id)?.result?.protocolVersion;
      }
      for (const message of messages) send(message);
    } catch (error) {
      const detail = error instanceof SyntaxError && /^\s+at JSON\.parse \(/m.test(error.stack || '')
        ? formatJsonError(error) : redactDiagnostic(error.message, cfg);
      const message = 'Fusion MCP connection error; no retry was performed. An operation may have run: ' + detail;
      if (hasId) send({ jsonrpc: '2.0', id: request.id, error: { code: -32000, message,
        ...(response?.queueReceipt ? { data: { fmcad: response.queueReceipt } } : {}) } });
      else log(message);
    }
  };
}

function startStdio(args = [], {
  loadConfig: resolveConfig = loadConfig, McpClient: Client = McpClient,
  QueueClient: QueuedClient = QueueClient,
  stdin = process.stdin, stdout = process.stdout, stderr = process.stderr,
} = {}) {
  const { values } = parseArgs({ args, options: {
    backend: { type: 'string' },
    routing: { type: 'string' },
    client: { type: 'string' },
    timeout: { type: 'string' },
    'queue-timeout': { type: 'string' },
    help: { type: 'boolean' },
  }, strict: true, allowPositionals: false });
  if (values.backend !== undefined && !['mcp', 'addin'].includes(values.backend)) {
    throw new Error(`Invalid backend: ${values.backend} (expected mcp or addin)`);
  }
  if (values.help) {
    stdout.write('Usage: fmcad-mcp [--backend mcp|addin] [--routing direct|queue] [--client LABEL]\n' +
      '                 [--timeout positive-ms] [--queue-timeout positive-ms] [--help]\n\n' +
      'Forward stdio MCP to the selected backend (queue: configured backend; direct default: addin).\n' +
      'Uses existing fmcad configuration (FMCAD_CONFIG) and backend transport settings.\n' +
      'Routing: flag, FMCAD_ROUTING, then config (default: direct).\n' +
      'Queue client: --client or FMCAD_CLIENT; otherwise a unique id per process.\n' +
      'Timeout limits active execution; queue-timeout optionally limits waiting for a slot.\n' +
      'Queue tools provide explicit leases; tool metadata uses params._meta.fmcad.\n' +
      'No automatic backend fallback or retry.\n');
    return;
  }
  for (const name of ['timeout', 'queue-timeout']) {
    if (values[name] !== undefined && (!/^\d+$/.test(values[name]) || !Number.isSafeInteger(Number(values[name])) || Number(values[name]) <= 0)) {
      throw new Error('--' + name + ' must be a positive integer in milliseconds');
    }
  }
  const selection = { ...(values.backend !== undefined ? { backend: values.backend } : {}),
    ...(values.routing !== undefined ? { routing: values.routing } : {}),
    ...(values.timeout !== undefined ? { timeout: Number(values.timeout) } : {}) };
  let { cfg } = resolveConfig(selection);
  // Queued aliases follow one configured physical backend. Retain the historical
  // direct bridge default when no backend is explicitly selected.
  if (values.backend === undefined && cfg.routing !== 'queue') cfg = resolveConfig({ ...selection, backend: 'addin' }).cfg;
  const routing = cfg.routing || 'direct';
  if (!['direct', 'queue'].includes(routing)) throw new Error('routing must be direct or queue');
  const queued = routing === 'queue';
  const queueTimeoutMs = values['queue-timeout'] !== undefined ? Number(values['queue-timeout']) : cfg.queue?.waitTimeoutMs;
  if (queued && (!Number.isSafeInteger(cfg.timeoutMs) || cfg.timeoutMs <= 0 || cfg.timeoutMs > 2147483647)) {
    throw new Error('Queue execution timeout must be 1..2147483647 ms');
  }
  if (queued && queueTimeoutMs !== undefined && (!Number.isSafeInteger(queueTimeoutMs) || queueTimeoutMs <= 0)) {
    throw new Error('Queue wait timeout must be a positive safe integer in milliseconds');
  }
  const client = queued ? new QueuedClient(values.client ?? process.env.FMCAD_CLIENT ?? 'mcp-stdio:' + randomUUID(), { cfg }) : new Client(cfg);
  const send = message => stdout.write(JSON.stringify(message) + '\n');
  const queuePost = queued ? createQueuePost(client, cfg, queueTimeoutMs, Client) : null;
  const forward = createForwarder(queuePost || ((request, session, version) => {
    client.server.headers = { ...cfg.headers, ...(version ? { 'MCP-Protocol-Version': version } : {}) };
    return client._post(request, session);
  }), send, message => stderr.write(message + '\n'), cfg);
  const pending = new Set();
  let ordered = Promise.resolve();
  const input = readline.createInterface({ input: stdin, crlfDelay: Infinity });
  input.on('line', line => {
    if (!line.trim()) return;
    let control = false;
    if (queued) try {
      const request = JSON.parse(line);
      control = request.method === 'tools/call' && queueTools.some(tool => tool.name !== 'fmcad_queue_begin' && tool.name === request.params?.name);
    } catch { /* malformed framing is handled by createForwarder */ }
    const work = queued && !control ? (ordered = ordered.then(() => forward(line))) : forward(line);
    pending.add(work);
    work.finally(() => pending.delete(work));
  });
  input.on('close', () => {
    Promise.allSettled([...pending]).finally(() => {
      if (queued) queuePost.close(); else client.reqOpts.agent.destroy();
    });
  });
}

module.exports = { responseMessages, createForwarder, startStdio };
