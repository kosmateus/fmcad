'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { readJson, durable, buildHash, hash, fail, workflowNonterminal } = require('./queue-instance');

async function run(file) {
  const job = readJson(file);
  if (job.id !== process.env.FMCAD_QUEUE_WORKER_JOB || !process.env.FMCAD_QUEUE_WORKER_TOKEN) fail('INVALID_WORKER', 'Missing job-bound worker capability');
  if (!Number.isSafeInteger(job.deadline) || job.deadline <= Date.now()) fail('RUN_TIMEOUT', 'Worker execution deadline expired before starting');
  if (buildHash() !== job.buildHash) fail('BUILD_CHANGED', 'Executable build changed before worker execution');
  const request = job.request;
  process.env.FMCAD_QUEUE_INPUT_FILES = JSON.stringify(request.inputFiles || []);
  for (const input of request.inputFiles || []) {
    if (hash(fs.readFileSync(path.resolve(request.cwd, input.path))) !== input.sha256) fail('INPUT_CHANGED', `Input changed: ${input.path}`);
  }
  const cfg = JSON.parse(process.env.FMCAD_QUEUE_WORKER_CONFIG);
  // No worker may construct an HTTP client, including CLI paths using deps.McpClient.
  class WorkerBackend {
    constructor() { this.server = cfg; Object.assign(this, job.properties || {}); }
    async invoke(method, args) {
      const remaining = job.deadline - Date.now();
      if (remaining <= 0) fail('RUN_TIMEOUT', 'Worker execution deadline expired');
      const response = await require('./queue-connection').request(process.env.FMCAD_QUEUE_DIR, {
        action: 'backend', jobId: job.id, workerToken: process.env.FMCAD_QUEUE_WORKER_TOKEN,
        method, args, rpcTimeoutMs: Math.max(1, Math.floor(Math.min(cfg.timeoutMs, remaining))),
      }, { timeoutMs: remaining + 1000 });
      Object.assign(this, response.properties || {});
      return response.value;
    }
    callTool(...args) { return this.invoke('callTool', args); }
    listTools(...args) { return this.invoke('listTools', args); }
    executeUiGuardedScript(...args) { return this.invoke('executeUiGuardedScript', args); }
  }
  let workflowOutcome = null;
  const resultFile = path.join(path.dirname(file), 'worker-result.json');
  const code = await require('./cli').main(request.argv, {
    loadConfig: () => ({ path: '<broker-pinned>', cfg: { ...cfg } }),
    createBackend: () => new WorkerBackend(), McpClient: WorkerBackend,
    setExitCode: () => {},
    onOutcome: value => {
      workflowOutcome = value;
      durable(resultFile, { jobId: job.id, code: null, terminal: false,
        workflowOutcome, nonterminal: workflowNonterminal(workflowOutcome) });
    },
  });
  durable(resultFile, { jobId: job.id, code, terminal: true,
    workflowOutcome, nonterminal: workflowNonterminal(workflowOutcome) });
  return code;
}

if (require.main === module) {
  run(process.argv[2]).then(code => { process.exitCode = code; }, error => {
    process.stderr.write(`ERROR ${error.code || 'WORKER_ERROR'}: ${error.message}\n`);
    process.exitCode = 1;
  });
}

module.exports = { run };
