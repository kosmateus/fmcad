const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');

const tunables = {
  'blur-sigma': 'number [0, 100]; default 0 (disabled)',
  'median-size': 'integer 0, 3, 5, 7; default 0 (disabled)',
  'label-mode-size': 'integer 0, 3, 5, 7; default 0 (disabled); nonzero requires palette',
  'filter-speckle': 'integer [0, 65535]; default 4',
  'corner-threshold': 'number [0, 180]; default 60',
  'length-threshold': 'number [0.01, 1000]; default 4',
  'splice-threshold': 'number [0, 180]; default 45',
  'max-iterations': 'integer [1, 1000]; default 10',
  'path-precision': 'integer [0, 15]; default 4',
  'color-precision': 'integer [1, 8]; default 8',
  'layer-difference': 'integer [0, 255]; default 0',
  mode: 'spline or polygon; default spline',
  'width-mm': 'number [1e-9, 1e9]; default 50',
  'mirror-x': 'boolean true or false; default false',
  'trace-scale': 'integer 1 or 2; default 1. Exact nearest-neighbor tracing, normalized source coordinates; scale 2 limited to 30 million working pixels and may greatly increase spline count',
  'trace-detail-area-px2': 'number [0, 1e9] in source px²; default 0 (off). Opt-in exact SS2 small cutout bundles; requires palette, spline mode, trace-scale 1; ambiguity refuses the candidate',
};
const camelCase = key => key.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
const worker = path.resolve(__dirname, '../assets/image_trace.py');
const requirements = path.resolve(__dirname, '../assets/image_trace_requirements.txt');
const descriptor = {
  usage: 'image trace --input PATH --out NEWDIR [--palette JSON] [--python PATH] [tunables] [--json]',
  desc: 'LOCAL raster tracing and previews only. No Fusion mutation, --doc, MCP, config or connection required.',
  example: 'fmcad image trace --input rectangle.png --out rectangle-trace --mode polygon --width-mm 50',
  extra: `Alternative: fmcad image trace --file request.json [additional input flags] [--python PATH] [--json]
All flags require values except --json and help. --palette is a JSON FILE path.
Request keys are input, out, palette and camelCase tunables (e.g. blurSigma, mirrorX).
Flags may supplement --file; duplicate fields or repeated options are errors, not last-wins overrides.
Unknown options/fields are rejected. --python is CLI-only, defaults to python3, and never enters the request.
All paths are CLI-host local, never converted to Fusion/Windows paths. Relative paths, including
values inside request.json, resolve against the invocation cwd, NOT the request file directory.
out must be NEW with an existing parent. Existing outputs are never overwritten; partial failures
are retained. Retry with another NEWDIR. Worker stdout JSON envelope is passed through unchanged;
--json is accepted for consistency (output is always JSON). Errors use stderr and a nonzero exit.

Tunables (validated by the worker):
${Object.entries(tunables).map(([key, spec]) => `  --${key}: ${spec}`).join('\n')}

Preprocessing: raw RGB median (--median-size), then Gaussian blur (--blur-sigma),
then palette classification, then optional integer-label mode filtering (--label-mode-size).
labelModeSize removes isolated spurious third-color pixels without generating new colors;
it is NOT RGB filtering. Nonzero requires a palette with at most 256 labels including background.

Dependencies: use a user-owned venv; nothing is installed automatically.
  python3 -m venv "$HOME/.venvs/fmcad-image"
  "$HOME/.venvs/fmcad-image/bin/python" -m pip install -r ${JSON.stringify(requirements)}
Select that interpreter with --python "$HOME/.venvs/fmcad-image/bin/python".
CairoSVG also requires the system Cairo library.

Outputs: segmented.png, raw_contours.svg, contours.svg, preview.png, overlay.svg, overlay.png, report.json,
sketches/*.json and import_sketches.json. Review overlays and report before any separate import.
With a palette, contours.svg preserves exact declared palette fills by nearest RGB mapping
of traced fills to palette colors or background. Ties prefer background then declaration order.
raw_contours.svg retains the original vtracer output; report.rawToSnappedColors records the mapping.
Snapping does not change geometry or undo merged regions; rendered antialiasing may blend colors.
Spline mode preserves traced cubic Bezier control points via the existing bezier primitive,
not sampled fit splines; raster-to-vector tracing itself is approximate. No solid validation.
Palette example: fmcad image trace --input palette-image.png --out palette-trace --palette palette.json --label-mode-size 3
See docs/IMAGE_TRACE.md for palette schema, preprocessing, scaling and explicit import workflow.`,
};

async function traceImage(args, deps) {
  const flags = {};
  for (let i = 0; i < args.length; i++) {
    const flag = args[i];
    const key = flag.slice(2);
    if (!flag.startsWith('--') || !['input', 'out', 'palette', 'python', 'file', 'json'].includes(key) && !Object.hasOwn(tunables, key)) {
      throw new Error(`unknown option for image trace: ${flag}`);
    }
    if (Object.hasOwn(flags, key)) throw new Error(`Duplicate image trace option: ${flag}`);
    if (key === 'json') flags[key] = true;
    else {
      const value = args[++i];
      if (!value || /^--|^-[A-Za-z]/.test(value)) throw new Error(`${flag} requires a value`);
      flags[key] = value;
    }
  }
  const request = flags.file ? JSON.parse(fs.readFileSync(path.resolve(flags.file), 'utf8')) : {};
  if (!request || typeof request !== 'object' || Array.isArray(request)) throw new Error('Image trace request must be a JSON object');
  const allowed = ['input', 'out', 'palette', ...Object.keys(tunables).map(camelCase)];
  for (const key of Object.keys(request)) {
    if (!allowed.includes(key)) throw new Error(`Unknown image trace request field: ${key}`);
  }
  for (const [key, value] of Object.entries(flags)) {
    if (['file', 'python', 'json'].includes(key)) continue;
    const field = camelCase(key);
    if (Object.hasOwn(request, field)) throw new Error(`Duplicate image trace input: ${field}`);
    request[field] = Object.hasOwn(tunables, key) && key !== 'mode' ? JSON.parse(value) : value;
  }
  for (const key of ['input', 'out', 'palette']) {
    if (key === 'palette' && !Object.hasOwn(request, key)) continue;
    if (typeof request[key] !== 'string' || !request[key].trim()) throw new Error(`image trace requires ${key} as a nonempty path`);
    request[key] = path.resolve(request[key]);
  }
  const python = flags.python || 'python3';
  const setup = `Image tracing dependencies: run ${JSON.stringify(python)} -m pip install -r ${JSON.stringify(requirements)} in your user-owned environment. CairoSVG also needs the system Cairo library. Nothing was installed automatically.\n`;
  return new Promise((resolve, reject) => {
    const child = (deps.spawnImageTrace || spawn)(python, [worker], { shell: false, stdio: ['pipe', 'pipe', 'pipe'] });
    child.stdout.on('data', chunk => deps.stdout.write(chunk));
    child.stderr.on('data', chunk => deps.stderr.write(chunk));
    child.on('error', error => reject(new Error(`Cannot start local Python ${JSON.stringify(python)}: ${error.message}. Select an installed interpreter with --python PATH.\n${setup}`)));
    child.stdin.on('error', error => {
      if (error.code !== 'EPIPE') reject(error);
    });
    child.on('close', (code, signal) => {
      if (code !== 0) deps.stderr.write(`image trace worker failed (${signal || code}). ${setup}`);
      resolve(code === 0 ? 0 : 1);
    });
    child.stdin.end(JSON.stringify(request));
  });
}

const manual = {
  sections: [{ title: 'Local Return Contract', text: descriptor.desc }],
  examples: [{ label: 'Rectangle preview', requires: 'Existing rectangle.png, new output directory and local Python dependencies.',
    argv: ['image', 'trace', '--input', 'rectangle.png', '--out', 'rectangle-trace', '--mode', 'polygon'],
    output: 'Unchanged image.trace JSON envelope, local previews and import_sketches.json; no Fusion mutation.' }],
  audit: {
    sources: ['src/image-trace.js', 'assets/image_trace.py', 'docs/IMAGE_TRACE.md'],
    verified: ['local routing without configuration', 'flag-to-worker mapping and JSON stdin', 'duplicate/unknown options and required paths', 'stdout envelope passthrough and interpreter failure guidance'],
    tests: ['tests/image-trace.test.js', 'tests/image_trace_test.py'], gaps: [],
    bugs: ['Raster tracing is approximate; exact traced cubic import does not certify CAD profiles or solids. Partial output is retained on failure.'],
  },
};

module.exports = { descriptor, traceImage, manual };
