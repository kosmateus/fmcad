'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { randomUUID, createHash } = require('node:crypto');
const { pythonValue } = require('./python');
const { validateRunIdentity, formatRunOutput } = require('./run');

const views = ['front', 'back', 'left', 'right', 'top', 'bottom', 'iso-top-left', 'iso-bottom-right'];
const flags = Object.fromEntries(['--doc', '--doc-id', '--doc-file-id', '--out', '--width', '--height'].map(f => [f, 'value']));
const descriptor = {
  usage: 'review --doc <name> (--doc-id <creationId> | --doc-file-id <cloudId>) --out <new-local-directory> [--width N] [--height N]',
  desc: 'Capture six orthographic sides and two isometric views, shaded with visible edges, with identity and restoration evidence. Requires visual review; never CAD acceptance.',
  example: 'fmcad review --doc Model --doc-id DISCOVER_CREATION_ID --out ./review-new',
};

function parseReviewArgs(args) {
  const values = {};
  for (let i = 0; i < args.length; i++) {
    const flag = args[i];
    if (!Object.hasOwn(flags, flag)) throw new Error('Unknown review option: ' + flag);
    if (Object.hasOwn(values, flag)) throw new Error('Duplicate review option: ' + flag);
    const value = args[++i];
    if (typeof value !== 'string' || !value.trim() || value.startsWith('-')) throw new Error(flag + ' requires a value');
    values[flag] = value;
  }
  if (!values['--doc'] || (!values['--doc-id'] && !values['--doc-file-id'])) throw new Error('review requires --doc and --doc-id or --doc-file-id');
  validateRunIdentity(values, false);
  if (!values['--out']) throw new Error('review requires --out <new-local-directory>');
  if (process.platform !== 'win32' && /^[A-Za-z]:[\\/]|^\\\\/.test(values['--out'])) throw new Error('--out must be a CLI-local path, not a Windows/UNC path');
  const dimension = (flag, fallback) => {
    const value = values[flag] ?? String(fallback);
    if (!/^\d+$/.test(value) || Number(value) < 32 || Number(value) > 4096) throw new Error(flag + ' must be an integer from 32 to 4096');
    return Number(value);
  };
  const width = dimension('--width', 1600), height = dimension('--height', 1200);
  if (width * height > 16000000) throw new Error('review images must not exceed 16 megapixels');
  return { doc: values['--doc'], docId: values['--doc-id'] ?? null, docFileId: values['--doc-file-id'] ?? null,
    out: path.resolve(values['--out']), width, height };
}

function buildReviewScript(request) {
  const dir = path.join(__dirname, '..', 'assets');
  return fs.readFileSync(path.join(dir, 'cad', 'identity.py'), 'utf8') + '\n' +
    fs.readFileSync(path.join(dir, 'review.py'), 'utf8').replace(/^ARGS = .*$/m, () => 'ARGS = ' + pythonValue(request));
}

function writeJson(file, value) {
  fs.writeFileSync(file, JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
}

function verifyReport(report, request) {
  if (report?.operation !== 'review' || report.schemaVersion !== 1 || report.requestId !== request.requestId ||
      report.requiresVisualReview !== true || !Array.isArray(report.views) || !Array.isArray(report.errors)) {
    throw new Error('Invalid review report identity/contract');
  }
  if (!report.success) return;
  const identity = report.documentIdentity;
  if (report.status !== 'captured' || report.restoration?.status !== 'restored' || report.errors.length ||
      identity?.name !== request.doc || (request.docId && identity.creationId !== request.docId) ||
      (request.docFileId && identity.fileId !== request.docFileId) ||
      typeof identity.isSaved !== 'boolean' || typeof identity.isModified !== 'boolean' ||
      !report.fusionBuild || report.views.length !== views.length ||
      report.orientationVerification?.status !== 'verified') throw new Error('Incomplete successful review report');
  for (const [index, view] of report.views.entries()) {
    if (view.name !== views[index] || view.file !== views[index] + '.png' || view.status !== 'captured') throw new Error('Incomplete review view set');
    const filename = path.join(request.out, view.file);
    if (!fs.lstatSync(filename).isFile()) throw new Error('Review output is not a regular file: ' + view.file);
    const bytes = fs.readFileSync(filename);
    if (bytes.length < 24 || bytes.subarray(0, 8).toString('hex') !== '89504e470d0a1a0a' ||
        bytes.toString('ascii', 12, 16) !== 'IHDR' || bytes.readUInt32BE(16) !== request.width || bytes.readUInt32BE(20) !== request.height ||
        bytes.length !== view.sizeBytes || createHash('sha256').update(bytes).digest('hex') !== view.sha256) {
      throw new Error('Review PNG readback mismatch: ' + view.file);
    }
  }
}

// Same client.callTool contract as docops; caller supplies the existing CLI path mapper.
// A fourth argument supplies streams for offline tests/embedding, not another backend.
async function reviewCmd(client, args, toWindowsPath, io = process) {
  const options = parseReviewArgs(args);
  if (typeof toWindowsPath !== 'function') throw new Error('review requires the CLI Fusion path mapper');
  const fusionOut = ['win32', 'darwin'].includes(process.platform) ? options.out : toWindowsPath(options.out);
  const request = { ...options, fusionOut, requestId: randomUUID() };
  const script = buildReviewScript(request);
  // Atomic directory claim also rejects empty directories and dangling symlinks.
  // Parent must exist. Never delete a failed review or reuse its destination.
  fs.mkdirSync(options.out, { mode: 0o700 });
  let report = { schemaVersion: 1, operation: 'review', requestId: request.requestId,
    success: false, status: 'not-submitted', requiresVisualReview: true, views: [], errors: [],
    restoration: { status: 'not-needed' } };
  let submitted = false;
  try {
    writeJson(path.join(options.out, 'request.json'), request);
    submitted = true;
    const response = await client.callTool({ featureType: 'script', object: { script } }, 'fusion_mcp_execute');
    if (response.uiGuard?.notStarted === true) {
      report.status = 'rejected-before-capture';
      report.errors.push({ stage: 'preflight', message: 'Backend active-command guard rejected script', guard: response.uiGuard });
    } else {
      const terminal = JSON.parse(formatRunOutput(response.text, 'json'));
      const disk = JSON.parse(fs.readFileSync(path.join(options.out, 'backend-report.json'), 'utf8'));
      if (JSON.stringify(terminal) !== JSON.stringify(disk)) throw new Error('Terminal and durable backend reports differ');
      verifyReport(disk, request);
      report = disk;
      if (response.failed) {
        report = { ...report, success: false, status: 'failed', errors: [...report.errors,
          { stage: 'transport', message: 'Backend marked execution failed; capture is not accepted' }] };
      }
    }
  } catch (error) {
    report = { ...report, success: false, status: submitted ? 'unknown' : 'not-submitted',
      restoration: submitted ? { status: 'unknown' } : report.restoration,
      errors: [...report.errors, { stage: 'command', message: error.message }],
      recovery: 'Preserve all outputs. Inspect backend-report.json and Fusion state before any new invocation; do not replay.' };
  }
  const manifestPath = path.join(options.out, 'manifest.json');
  writeJson(manifestPath, { ...report, localDirectory: options.out, fusionDirectory: fusionOut });
  io.stdout.write(JSON.stringify({ ...report, manifestPath }) + '\n');
  return report.success === true && report.status === 'captured' ? 0 : 1;
}

const manual = {
  sections: [
    { title: 'Input Contract', text: 'No positionals. Required --doc is an exact unique open top-level name; --doc-id (creationId) or --doc-file-id (DataFile.id) pins it, both may be supplied and must match. Duplicate names fail even with an ID. Required --out is a new CLI-local directory with an existing parent; relative paths resolve against cwd before the existing WSL path mapper. Existing directories, files and symlinks are rejected. --width/--height are integer pixels, defaults 1600/1200, each 32..4096 and total <=16,000,000. No overwrite flag.' },
    { title: 'Return Contract', text: 'One JSON result and manifest.json. Success means only eight PNGs captured and state restoration verified: front, back, left, right, top, bottom, iso-top-left, iso-bottom-right. All use orthographic projection, fit, shaded visible edges and component colors disabled. documentIdentity includes creationId/fileId/version/isSaved/isModified; fusionBuild, per-view camera, filenames, bytes and SHA256 are recorded. requiresVisualReview=true always. Exit 1 for capture, restoration, transport, identity or readback failures. Partial images and backend-report.json are retained; missing terminal evidence is unknown, never success.' },
    { title: 'Prerequisites And Safety', text: 'Requires an owned, idle Fusion instance and a uniquely named already-open Design. One backend script invocation; no retry, cloud open, geometry edit or document save. This changes viewport/UI state and is not submitted as readOnly. try/finally restores target and original camera/projection/framing, visual style, component-colour display and original active document with independent error reporting. CLI and Fusion must share the mapped output directory; request.json verifies mapping. Transport timeout does not cancel the backend: inspect durable evidence and current state before further work. Current visibility, sections, selection and graphics determine the image; this does not inspect hidden interiors, generate critical-interface closeups, assess interference or confer CAD/physical acceptance.' },
  ],
  examples: [{ label: 'Pinned open document', argv: ['review', '--doc', 'Model', '--doc-id', 'DISCOVER_CREATION_ID', '--out', './review-new'],
    requires: 'Replace Model and DISCOVER_CREATION_ID with the exact open name and discovered creationId. Own Fusion, finish interactive commands, and choose a fresh mapped destination. This example is not run by help.',
    output: 'manifest.json and eight named PNGs; status captured with requiresVisualReview=true only after capture and restoration succeed.' }],
  audit: { sources: ['src/review.js:parseReviewArgs,buildReviewScript,verifyReport,reviewCmd', 'assets/review.py:run,capture_review,restore_camera', 'assets/cad/identity.py:_document_target,_document_assert_identity,_document_activate_target'],
    verified: ['offline argument and destination validation', 'single script dispatch and complete durable/terminal report comparison', 'identity and active-command guards', 'independent restoration and preserved partial failure outputs using SDK stubs', 'primary-owned scratch qualification on Fusion2705.1.25: eight images personally inspected, orthogonal/isometric camera vectors verified, target/original viewport and active document restored'],
    tests: ['tests/review.test.js', 'tests/review_test.py'], gaps: [], bugs: ['Live qualification covers Fusion2705.1.25 and the tested mapped filesystem only, not every SDK/build. The viewOrientation getter can return arbitrary after a successful named view; actual camera-vector relationships are checked instead. Current visibility/sections determine the images; capture is not CAD or physical acceptance.'] },
};

module.exports = { reviewCmd, parseReviewArgs, buildReviewScript, verifyReport, views, flags, descriptor, manual };
