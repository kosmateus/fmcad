'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { queueDirectory } = require('./queue-connection');
const { readJson, durable, processBirth } = require('./queue-instance');
const { releaseStart, startupResult } = require('./queue-autostart');
const { redactDiagnostic } = require('./diagnostics');

async function main() {
  const nonce = process.argv[2];
  if (!/^[a-f0-9-]{36}$/.test(nonce || '')) throw new Error('Invalid autostart nonce');
  const dir = queueDirectory();
  if (readJson(path.join(dir, 'autostart.lock')).nonce !== nonce) throw new Error('Startup claim changed');
  let text = '', cfg = {};
  try {
    durable(path.join(dir, 'autostart', nonce + '.process.json'), { nonce, pid: process.pid, birth: processBirth() }, true);
    if (readJson(path.join(dir, 'autostart.lock')).nonce !== nonce) throw new Error('Startup claim changed before daemon ownership');
    for await (const bytes of process.stdin) {
      text += bytes.toString('utf8');
      if (Buffer.byteLength(text) > 1024 * 1024) throw new Error('Startup configuration exceeds 1 MiB');
    }
    cfg = JSON.parse(text);
    if (cfg.routing !== 'queue' || cfg.queue?.autoStart === false) throw new Error('Automatic queue ownership was not enabled');
    const handle = await require('./queue-broker').serve({ ...cfg, routing: 'direct', queue: {} },
      { confirmOwnership: true, autoReconcile: cfg.queue?.autoRecover !== false });
    startupResult(dir, nonce, { state: 'ready', pid: process.pid, buildHash: handle.buildHash });
    releaseStart(dir, nonce);
    for (const signal of ['SIGTERM', 'SIGINT']) process.once(signal, () => {
      handle.close().catch(error => process.stderr.write('Broker retained: ' + redactDiagnostic(error.message, cfg) + '\n'));
    });
  } catch (error) {
    startupResult(dir, nonce, { state: 'failed', code: error.code || 'BROKER_START_FAILED', message: redactDiagnostic(error.message, cfg) });
    releaseStart(dir, nonce);
    process.stderr.write('Broker startup failed: ' + redactDiagnostic(error.message, cfg) + '\n');
    process.exitCode = 1;
  }
}

if (require.main === module) main().catch(error => { process.stderr.write(error.message + '\n'); process.exitCode = 1; });
