'use strict';

const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const { spawn } = require('node:child_process');
const { randomUUID, randomBytes, timingSafeEqual } = require('node:crypto');
const { QueueState } = require('./queue-state');
const { queueDirectory, queueSocket } = require('./queue-connection');
const { documentSelector, compareDocumentState } = require('./queue-document');
const { durable, readJson, processBirth, priorProcessAlive, reclaim, buildHash, probe, sameInstance, idle, workflowNonterminal, wrapScript, hash, fail } = require('./queue-instance');

const MAX = 16 * 1024 * 1024;
const own = (object, key) => Object.hasOwn(object, key);
const equal = (a, b) => typeof a === 'string' && typeof b === 'string' && Buffer.byteLength(a) === Buffer.byteLength(b) && timingSafeEqual(Buffer.from(a), Buffer.from(b));
const identifier = value => typeof value === 'string' && value.length > 0 && value.length <= 256;

function isolatedTool(name, args = {}) {
  if (!args || typeof args !== 'object' || Array.isArray(args)) fail('INVALID_REQUEST', 'Tool arguments must be a JSON object');
  if (args.remember_as !== undefined || /"\$[^"\n]*"/.test(JSON.stringify(args)) || ['call_autodesk_api', 'get_active_selection'].includes(name)) {
    fail('unsupported_queue_route', 'Persistent API object references cannot be isolated between queued clients');
  }
  if (name === 'execute_python' && (args.persistent !== false || args.session_id !== undefined)) {
    fail('unsupported_queue_route', 'Queued Python requires persistent:false without a shared session_id');
  }
}

function validateRaw(payload) {
  if (!payload || payload.jsonrpc !== '2.0' || typeof payload.method !== 'string' ||
      (own(payload, 'id') && !['string', 'number'].includes(typeof payload.id))) fail('INVALID_RPC', 'Expected one JSON-RPC 2.0 request or notification');
  if (!['initialize', 'notifications/initialized', 'ping', 'tools/list', 'tools/call'].includes(payload.method)) fail('unsupported_queue_route', 'Unsupported raw JSON-RPC route');
  if (!own(payload, 'id') && payload.method !== 'notifications/initialized') fail('unsupported_queue_route', 'Only the initialized notification has supported completion semantics');
  if (payload.method !== 'tools/call') return;
  if (!own(payload, 'id')) fail('unsupported_queue_route', 'Tool notifications cannot prove completion');
  const name = payload.params?.name;
  const args = payload.params?.arguments || {};
  isolatedTool(name, args);
  if (name === 'fusion_mcp_execute' && !['script', 'document'].includes(args.featureType)) fail('unsupported_queue_route', 'Raw execute feature has unsupported completion semantics');
  if (name === 'execute_python') {
    if (args.persistent !== false || args.session_id !== undefined) fail('unsupported_queue_route', 'Raw Python requires persistent:false without a shared session_id');
  } else if (!['fusion_mcp_execute', 'fusion_mcp_read', 'fetch_api_documentation', 'fetch_design_guide', 'capture_viewport', 'get_viewport'].includes(name)) {
    fail('unsupported_queue_route', 'Raw tools with global references or unknown background semantics are unsupported');
  }
  if (args.remember_as !== undefined || /"\$[^"\n]*"/.test(JSON.stringify(args))) fail('unsupported_queue_route', 'Remembered objects/global references are unsupported');
  const code = name === 'execute_python' ? args.code : args.featureType === 'script' ? args.object?.script : null;
  if ((name === 'execute_python' || args.featureType === 'script') && (typeof code !== 'string' || !code.trim())) fail('INVALID_SCRIPT', 'Raw script source must be a nonempty string');
  if (code && /\b(threading|asyncio|subprocess|multiprocessing|executeTextCommand|registerCustomEvent|addCustomEvent)\b/.test(code)) {
    fail('unsupported_queue_route', 'Background/native UI raw scripts require an existing workflow receipt and are unsupported here');
  }
}

function matching(client, response, payload) {
  if (!response || !Number.isInteger(response.status) || response.status < 200 || response.status >= 300) fail('UNKNOWN_RPC', 'Invalid HTTP response; outcome unknown');
  if (!own(payload, 'id')) {
    if (payload.method !== 'notifications/initialized') fail('UNKNOWN_RPC', 'Unacknowledged notification');
    return null;
  }
  const reply = client._parse(response.raw);
  if (!reply || Array.isArray(reply) || reply.jsonrpc !== '2.0' || reply.id !== payload.id ||
      (own(reply, 'result') === own(reply, 'error'))) fail('UNKNOWN_RPC', 'Missing/mismatched JSON-RPC reply; outcome unknown');
  if (reply.error && (typeof reply.error !== 'object' || typeof reply.error.message !== 'string')) fail('UNKNOWN_RPC', 'Malformed JSON-RPC error');
  return reply;
}

function privateDirectory(dir) {
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const stat = fs.lstatSync(dir);
  if (!stat.isDirectory() || stat.isSymbolicLink() || (process.getuid && stat.uid !== process.getuid())) fail('UNSAFE_DIRECTORY', 'Queue directory must be a real directory owned by this user');
  fs.chmodSync(dir, 0o700);
  return fs.realpathSync(dir);
}

function commandEntry(argv) {
  const { rest } = require('./cli').parseFlags(argv);
  return require('./commands').findCommand(rest);
}

async function serve(cfg, options = {}) {
  if (options.confirmOwnership !== true) fail('OWNERSHIP_REQUIRED', 'Explicit Fusion ownership confirmation is required before starting the broker');
  const dir = privateDirectory(path.resolve(options.dir || queueDirectory()));
  // Endpoint spelling is not a lock domain. Production always uses the one user-global directory.
  if (!options.createBackend && dir !== privateDirectory(path.resolve(queueDirectory()))) fail('QUEUE_DIRECTORY_MISMATCH', 'Production brokers must use the user-global queueDirectory()');
  if (fs.existsSync(path.join(dir, 'recovery.lock'))) fail('RECOVERY_IN_PROGRESS', 'Explicit broker recovery is incomplete');
  const codeHash = buildHash();
  const pinned = JSON.parse(JSON.stringify(cfg));
  const configHash = hash(JSON.stringify(pinned));
  const identityFile = path.join(dir, 'instance.json');
  let oldIdentity = fs.existsSync(identityFile) ? readJson(identityFile) : null;
  // A known local configuration rejection must not reserve Fusion or leave a
  // dead marker that prevents the correctly configured backend from starting.
  if (oldIdentity && oldIdentity.configHash !== configHash) fail('CONFIG_CHANGED', 'Pinned backend configuration differs from the durable broker identity');
  const marker = { pid: process.pid, birth: processBirth(), nonce: randomUUID(), protocol: 2 };
  const lock = path.join(dir, 'broker.lock');
  durable(lock, marker, true); // Never steal a lock, even if its PID looks stale.
  const state = new QueueState(dir, options.stateOptions);
  if (state.data.blocked && oldIdentity) {
    const directory = path.join(dir, 'jobs', state.data.active);
    const evidence = require('./queue-preflight').legacyBusyEvidence(state.data, oldIdentity.instance, oldIdentity.buildHash, directory);
    if (evidence) {
      // Preserve the original files and owner/request. Publish a labelled derived
      // resolution; never invent preflight.json or a remote SDK receipt.
      durable(path.join(directory, 'legacy-preflight-busy-evidence.json'), evidence);
      const outcome = { state: 'failed', code: 'FUSION_BUSY', executionOutcome: 'not_started',
        userScriptSubmitted: false, mayHaveMutated: false, source: evidence.method };
      state.resolve(evidence.jobId, outcome);
      durable(path.join(directory, 'outcome.json'), outcome);
    }
  }
  // The public backend factory may route ordinary callers into this queue. The
  // broker alone constructs the physical client, so routing cannot recurse.
  const factory = options.createBackend || (server => {
    if (server.backend === 'addin') return new (require('./addin-client').AddinClient)(server);
    if (!server.backend || server.backend === 'mcp') return new (require('./client').McpClient)(server);
    fail('INVALID_BACKEND', 'Unknown physical backend');
  });
  const client = factory(pinned);
  require('./client').authorizeBrokerClient(client);
  if (!client.server || typeof client._post !== 'function' || typeof client._parse !== 'function') fail('INVALID_BACKEND', 'Backend must expose server and the physical McpClient _post/_parse boundary');
  let clients = {};
  const clientsFile = path.join(dir, 'clients.json');
  if (fs.existsSync(clientsFile)) clients = readJson(clientsFile);
  let active = null, busy = false, stopping = false, closed = false, timer, instance;
  let closing = false, closeTask, closeResolve, closeReject;
  let held = null;
  let recovery = null, lastRecoveryCheck = 0;
  const lifecycleFile = path.join(dir, `broker-lifecycle-${marker.nonce}.json`);
  const startupReceipt = path.join(dir, `broker-startup-${marker.nonce}.receipt.json`);
  const startupBinding = { brokerNonce: marker.nonce, ownerPid: marker.pid, ownerBirth: marker.birth, buildHash: codeHash, stage: 'startup' };
  const lifecycle = { owner: marker, buildHash: codeHash, configHash,
    stage: state.summary().blocked ? 'recovery' : 'starting', receipt: startupReceipt, binding: startupBinding };
  durable(lifecycleFile, lifecycle, true);
  try {
    oldIdentity = fs.existsSync(identityFile) ? readJson(identityFile) : null;
    if (oldIdentity && oldIdentity.configHash !== configHash) fail('CONFIG_CHANGED', 'Pinned backend configuration differs from the durable broker identity');
    if (state.summary().blocked) {
      // No Fusion traffic at all until receipt evidence proves the old dispatch ended.
      instance = oldIdentity?.instance;
      if (oldIdentity && oldIdentity.buildHash !== codeHash) fail('BUILD_CHANGED', 'Restore the original executable build before reconciling the unfinished job');
      held = 'Restored unfinished job; matching remote terminal receipts are required before any probe';
    } else {
      // A completed busy observation is not an unfinished RPC. Keep the control
      // plane available; modeling workflows still require idle in preflight.
      instance = await probe(client, { receiptPath: startupReceipt, binding: startupBinding, requireIdle: false,
        diagnosticPath: path.join(dir, `broker-startup-${marker.nonce}.result.json`) });
      if (oldIdentity && !sameInstance(instance, oldIdentity.instance)) {
        const previousAlive = priorProcessAlive(oldIdentity.instance);
        if (typeof oldIdentity.buildHash !== 'string' || oldIdentity.instance.version !== instance.version ||
            previousAlive !== false || !idle(instance) || !Array.isArray(instance.documents) ||
            instance.documents.some(document => document?.isModified !== false)) {
          fail('INSTANCE_CHANGED', 'Fusion identity changed; automatic recovery requires the old process gone, the same Fusion version, idle UI and unmodified documents');
        }
        const transitionId = hash(JSON.stringify({ configHash, buildHash: codeHash,
          previous: oldIdentity.instance, current: instance }));
        const queueTransition = state.advanceInstanceEpoch(transitionId);
        durable(path.join(dir, `instance-transition-${transitionId}.json`), {
          source: 'automatic-quiescent-restart-recovery', transitionId, at: new Date().toISOString(),
          configHash, previousBuildHash: oldIdentity.buildHash, buildHash: codeHash,
          previous: oldIdentity.instance, current: instance,
          queueTransition,
        });
      }
      durable(identityFile, { configHash, buildHash: codeHash, instance });
    }
  } catch (error) {
    // Only proven local/terminal startup rejections can release our own marker.
    // Transport uncertainty, restored unknowns and storage faults retain it.
    if (['CONFIG_CHANGED', 'INSTANCE_CHANGED', 'FUSION_BUSY'].includes(error.code)) {
      try {
        const snapshot = state.status();
        if (!snapshot.active && !snapshot.blocked && !snapshot.lease &&
            Object.values(snapshot.jobs).every(job => ['succeeded', 'failed', 'cancelled', 'expired'].includes(job.state)) &&
            readJson(lock).nonce === marker.nonce) {
          durable(lifecycleFile, { ...lifecycle, stage: 'rejected', safeToRecover: true, code: error.code });
          client.reqOpts?.agent?.destroy();
          fs.unlinkSync(lock);
          const fd = fs.openSync(dir, 'r');
          try { fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
        }
      } catch { /* Uncertain cleanup never justifies removing another marker. */ }
    }
    throw error;
  }
  const originalPost = client._post.bind(client);

  function clientProperties() {
    const properties = {};
    for (const key of ['capabilities', 'serverInfo', 'negotiatedProtocolVersion']) if (client[key] !== undefined) properties[key] = client[key];
    return properties;
  }

  function jobDir(id) { return path.join(dir, 'jobs', id); }
  function diagnostics() {
    // Passive observer input, never completion evidence or a queue state override.
    try { durable(path.join(dir, 'queue-diagnostics.json'), { at: Date.now(), buildHash: codeHash,
      held, recovery, activeJobId: state.summary().active }); } catch { /* Diagnostics cannot change execution. */ }
  }
  function hold(job, reason) {
    held = reason;
    if (state.status(job.id).state !== 'needs_reconciliation') state.block(job.id, reason);
    diagnostics();
  }
  async function checkInstance(probeOptions) {
    if (buildHash() !== codeHash) fail('BUILD_CHANGED', 'Pinned executable build changed');
    const actual = await probe(client, { diagnosticPath: active ? path.join(jobDir(active.job.id), 'instance-probe-result.json') : undefined,
      ...probeOptions, requireIdle: false });
    if (!sameInstance(actual, instance)) fail('INSTANCE_CHANGED', 'Fusion PID/birth/build identity changed');
    if (probeOptions?.requireIdle !== false && !idle(actual)) throw Object.assign(new Error('An interactive Fusion command is open'), {
      code: 'FUSION_BUSY', probeCompleted: true, observation: actual,
    });
    return actual;
  }
  function remoteReceipt(record, requireIdle = true, saved) {
    if (!record.receipt) fail('RECEIPT_UNAVAILABLE', 'This unresolved non-script RPC has no remote terminal completion receipt');
    let value = saved;
    if (value === undefined) {
      try { value = readJson(record.receipt); }
      catch { fail('RECEIPT_UNAVAILABLE', 'Matching durable remote terminal receipt is unavailable or unreadable; no probe sent'); }
    }
    const binding = record.binding;
    if (value.terminal !== true || !['succeeded', 'failed'].includes(value.outcome) ||
        !['jobId', 'rpcId', 'requestHash', 'buildHash'].every(key => value[key] === binding[key]) ||
        !sameInstance(value.instance, record.instance)) fail('RECEIPT_MISMATCH', 'Receipt is not terminal or bound to the original request/instance/build');
    if (requireIdle && !idle(value.instance)) fail('NATIVE_RECEIPT_REQUIRED', 'Remote script returned with a native command pending; an existing matching terminal batch receipt is required. Generic queue reconciliation cannot certify it');
    return value;
  }

  // All adapter calls eventually cross this one physical dispatch boundary.
  client._post = async function (payload, sessionId) {
    const context = active;
    if (!context) return originalPost(payload, sessionId); // Broker-only read-only probes.
    if (context.unknown || state.summary().blocked) fail('RECONCILIATION_REQUIRED', 'Earlier dispatch requires reconciliation');
    const remaining = Math.min(context.deadline, context.rpcDeadline || context.deadline) - Date.now();
    if (remaining <= 0) fail('RUN_TIMEOUT', 'Active execution budget expired before dispatch');
    const rpcId = randomUUID();
    const binding = { jobId: context.job.id, rpcId, requestHash: hash(JSON.stringify(payload)), buildHash: codeHash };
    const request = { jsonrpc: '2.0', method: payload.method };
    if (own(payload, 'id')) request.id = payload.id;
    const record = { binding, instance, request, terminal: false, method: payload.method };
    let outgoing = structuredClone(payload);
    if (payload.method === 'tools/call') {
      const args = outgoing.params?.arguments;
      isolatedTool(outgoing.params?.name, args);
      const python = outgoing.params?.name === 'execute_python';
      const official = outgoing.params?.name === 'fusion_mcp_execute' && args?.featureType === 'script';
      if (python || official) {
        const code = python ? args.code : args.object?.script;
        if (typeof code !== 'string') fail('INVALID_SCRIPT', 'Script source must be a string');
        if (python && args.persistent !== false) fail('unsupported_queue_route', 'Queued low-level Python must use persistent:false');
        record.receipt = path.join(jobDir(context.job.id), `remote-${rpcId}.json`);
        const wrapped = wrapScript(code, official, record.receipt, binding);
        if (python) args.code = wrapped;
        else args.object.script = wrapped;
      }
    }
    const journal = path.join(jobDir(context.job.id), `rpc-${rpcId}.json`);
    durable(journal, record, true);
    const before = state.status(context.job.id).dispatch;
    const count = (before?.rpcCount || 0) + 1;
    state.markDispatch(context.job.id, { rpcCount: count, completedCount: before?.completedCount || 0, rpcId });
    context.dispatched = true;
    try {
      const previousTimeout = client.server.timeoutMs;
      let response;
      client.server.timeoutMs = remaining;
      try { response = await originalPost(outgoing, sessionId); }
      finally { client.server.timeoutMs = previousTimeout; }
      const reply = matching(client, response, outgoing);
      if (payload.method === 'tools/list' && !reply?.error && !Array.isArray(reply?.result?.tools)) fail('UNKNOWN_RPC', 'Malformed tools/list response');
      const receipt = record.receipt ? remoteReceipt(record, false) : null;
      const failed = !!(reply?.error || reply?.result?.isError || receipt?.outcome === 'failed');
      if (failed) context.executionFailed = true;
      context.lastRpc = { rpcId, failed };
      let typedNonterminal = workflowNonterminal(reply?.result) || workflowNonterminal(reply?.result?.structuredContent);
      for (const item of reply?.result?.content || []) {
        if (item?.type === 'text' && typeof item.text === 'string') {
          try { typedNonterminal ||= workflowNonterminal(JSON.parse(item.text)); } catch { /* Plain text is not a typed workflow result. */ }
        }
      }
      const nonterminal = context.job.kind === 'rpc' && typedNonterminal;
      if (nonterminal) context.workflowUnknown = true;
      durable(journal, { ...record, terminal: true, failed, nonterminal, response, ...(receipt ? { remoteReceipt: receipt } : {}) });
      const current = state.status(context.job.id).dispatch;
      state.markDispatch(context.job.id, { rpcCount: current.rpcCount, completedCount: current.completedCount + 1, rpcId, rpcState: 'terminal' });
      return response;
    } catch (error) {
      context.unknown = true;
      hold(context.job, 'Physical RPC outcome is unknown; observe the durable receipt without replay');
      throw error;
    }
  };

  function auth(message) {
    const value = message.auth;
    if (!value || !identifier(value.clientId) || !identifier(value.clientToken) || !own(clients, value.clientId) ||
        !equal(clients[value.clientId], hash(value.clientToken))) fail('UNAUTHORIZED', 'Valid registered client credentials required');
    return value.clientId;
  }
  function owned(id, clientId) {
    const job = state.status(id);
    if (job.clientId !== clientId) fail('NOT_OWNER', 'Only the submitting client may access this job result');
    return job;
  }
  function outputs(id) {
    const result = {};
    for (const stream of ['stdout', 'stderr']) {
      const file = path.join(jobDir(id), `${stream}.txt`);
      if (!fs.existsSync(file)) { result[stream] = ''; continue; }
      const size = fs.statSync(file).size;
      if (size <= 1024 * 1024) result[stream] = fs.readFileSync(file, 'utf8');
      else { result.outputs ||= {}; result.outputs[stream] = { path: file, bytes: size }; }
    }
    const raw = path.join(jobDir(id), 'rpc-result.json');
    if (fs.existsSync(raw)) {
      const size = fs.statSync(raw).size;
      if (size <= 1024 * 1024) result.rpc = readJson(raw);
      else { result.outputs ||= {}; result.outputs.rpc = { path: raw, bytes: size }; }
    }
    const outcome = path.join(jobDir(id), 'outcome.json');
    if (fs.existsSync(outcome)) result.execution = readJson(outcome);
    return result;
  }
  async function backend(message) {
    const context = active;
    if (!context || message.jobId !== context.job.id || !equal(message.workerToken, context.token) ||
        !['running', 'sending'].includes(state.status(context.job.id).state)) fail('INVALID_CAPABILITY', 'No active worker capability for this job');
    if (!['callTool', 'listTools', 'executeUiGuardedScript'].includes(message.method) || !Array.isArray(message.args)) fail('INVALID_BACKEND_METHOD', 'Unsupported worker backend method');
    if (context.pending.size || context.workerClosed || context.timedOut) fail('WORKER_BUSY', 'Worker RPC is concurrent, closed, or past its deadline');
    if (!Number.isSafeInteger(message.rpcTimeoutMs) || message.rpcTimeoutMs <= 0) fail('INVALID_TIMEOUT', 'Positive RPC timeout required');
    const timeout = Math.min(message.rpcTimeoutMs, context.deadline - Date.now());
    if (timeout <= 0) fail('RUN_TIMEOUT', 'Worker execution deadline expired');
    const initialRpcCount = state.status(context.job.id).dispatch?.rpcCount || 0;
    const operation = (async () => {
      const savedTimeout = client.server.timeoutMs;
      client.server.timeoutMs = timeout;
      context.rpcDeadline = Date.now() + timeout;
      try {
        const value = await client[message.method](...message.args);
        if (message.method === 'listTools' ? !Array.isArray(value) || value.some(tool => !tool || typeof tool.name !== 'string')
          : !value || typeof value.text !== 'string' || typeof value.failed !== 'boolean') {
          fail('MALFORMED_BACKEND_RESULT', 'Physical adapter returned malformed result fields');
        }
        if (value?.failed) context.executionFailed = true;
        const properties = clientProperties();
        if (Buffer.byteLength(JSON.stringify({ value, properties })) > MAX - 128) {
          context.publicationError = true;
          fail('OUTPUT_PUBLICATION_FAILED', 'Adapted backend result exceeds the bounded IPC response size');
        }
        return { value, properties };
      } catch (error) {
        const newDispatch = (state.status(context.job.id).dispatch?.rpcCount || 0) > initialRpcCount;
        const malformed = error instanceof SyntaxError || /malformed|missing .*result|empty response|invalid.*response/i.test(error.message);
        const rejectedBeforeDispatch = ['unsupported_queue_route', 'INVALID_SCRIPT', 'INVALID_REQUEST'].includes(error.code);
        if (newDispatch && !context.unknown && !rejectedBeforeDispatch && error.code !== 'OUTPUT_PUBLICATION_FAILED' && (malformed || !context.lastRpc?.failed)) {
          context.unknown = true;
          durable(path.join(jobDir(context.job.id), 'adapter-outcome.json'), {
            jobId: context.job.id, buildHash: codeHash, unknown: true, reason: 'Adapter could not validate the physical response',
          });
          hold(context.job, 'Physical adapter outcome is unknown; generic synchronous receipts cannot certify its result');
        }
        throw error;
      } finally { client.server.timeoutMs = savedTimeout; delete context.rpcDeadline; }
    })();
    context.pending.add(operation);
    let timer;
    const deadline = new Promise((resolve, reject) => { timer = setTimeout(() => {
      context.timedOut = true;
      if (context.dispatched) hold(context.job, 'Worker backend RPC exceeded its deadline; completion remains unknown');
      reject(Object.assign(new Error('Worker backend RPC deadline expired; no remote cancellation'), { code: 'RUN_TIMEOUT' }));
    }, timeout); });
    operation.then(() => context.pending.delete(operation), () => context.pending.delete(operation));
    try { return await Promise.race([operation, deadline]); }
    finally { clearTimeout(timer); }
  }

  async function reconcile(id, clientId) {
    const job = owned(id, clientId);
    if (job.state !== 'needs_reconciliation') fail('NOT_BLOCKED', 'Job does not require reconciliation');
    if (active && (active.pending.size || active.child && !active.workerClosed)) fail('WORKER_PENDING', 'Owned worker or broker RPC is still pending; no probe sent');
    if (!instance) fail('INSTANCE_UNAVAILABLE', 'Original pinned instance record unavailable; no probe sent');
    const directory = privateDirectory(jobDir(id));
    const optional = name => fs.existsSync(path.join(directory, name)) ? readJson(path.join(directory, name)) : null;
    const worker = optional('worker-result.json');
    if (worker && worker.jobId !== id) fail('RECEIPT_MISMATCH', 'Worker result belongs to a different job');
    if (worker?.nonterminal || workflowNonterminal(worker?.workflowOutcome)) {
      fail('WORKFLOW_RECONCILIATION_REQUIRED', 'Typed workflow outcome is unknown/nonterminal; a generic synchronous script receipt does not prove workflow completion. No probe sent');
    }
    const adapter = optional('adapter-outcome.json');
    if (adapter) {
      if (adapter.jobId !== id || adapter.buildHash !== codeHash) fail('RECEIPT_MISMATCH', 'Adapter evidence belongs to a different job/build');
      if (adapter.unknown) fail('ADAPTER_RECONCILIATION_REQUIRED', 'Adapter result was malformed/unvalidated; generic RPC completion cannot certify it. No probe sent');
    }
    const workerIdentityFile = path.join(directory, 'worker-identity.json');
    if (!active && fs.existsSync(workerIdentityFile)) {
      const workerIdentity = readJson(workerIdentityFile);
      try {
        if (processBirth(workerIdentity.pid) === workerIdentity.birth) fail('WORKER_PENDING', 'Original local worker is still alive; no probe sent');
      } catch (error) { if (!['ENOENT', 'ESRCH'].includes(error.code)) throw error; }
    } else if (!active && optional('worker-start.json')) {
      fail('WORKER_IDENTITY_UNAVAILABLE', 'Worker spawn was prepared without a durable process identity; absence of a live worker is unproven');
    }
    const records = fs.readdirSync(directory).filter(name => /^rpc-.*\.json$/.test(name) && name !== 'rpc-result.json').map(name => readJson(path.join(directory, name)));
    if (records.some(record => record.binding?.jobId !== id || record.binding?.buildHash !== codeHash || !sameInstance(record.instance, instance))) {
      fail('RECEIPT_MISMATCH', 'Dispatch journal belongs to a different job, build, or Fusion instance; no probe sent');
    }
    const count = job.dispatch?.rpcCount || 0;
    const notDispatched = count === 0;
    const receipts = [];
    if (notDispatched) {
      if (records.some(record => record.terminal)) fail('RECEIPT_MISMATCH', 'Terminal RPC journal conflicts with the undispatched state');
      const started = optional('preflight-start.json');
      const completed = optional('preflight.json');
      for (const receipt of [started, completed].filter(Boolean)) {
        if (receipt.jobId !== id || receipt.buildHash !== codeHash || !sameInstance(receipt.instance, instance)) fail('RECEIPT_MISMATCH', 'Preflight evidence is not bound to this job/instance/build');
      }
      let observation = completed?.completed === true ? completed.instance : null;
      if (started && !observation && started.receipt && started.binding) {
        if (started.binding.jobId !== id || started.binding.buildHash !== codeHash ||
            !/^[a-f0-9-]{36}$/.test(started.binding.rpcId || '') ||
            started.binding.requestHash !== hash('preflight:' + id + ':' + started.binding.rpcId) ||
            started.receipt !== path.join(directory, 'preflight-' + started.binding.rpcId + '.receipt.json')) {
          fail('RECEIPT_MISMATCH', 'Preflight probe binding/path mismatch; no new probe sent');
        }
        observation = remoteReceipt({ receipt: started.receipt, binding: started.binding, instance: started.instance }, false).instance;
      }
      if (started && !observation) fail('PREFLIGHT_PENDING', 'Previous preflight started but its completion is unproven; no probe sent');
      const outcome = { state: 'failed', code: observation && !idle(observation) ? 'FUSION_BUSY' : 'NOT_DISPATCHED',
        executionOutcome: 'not_started', userScriptSubmitted: false, mayHaveMutated: false,
        preflightCompleted: !!observation, source: 'durable-preflight-evidence' };
      durable(path.join(directory, 'outcome.json'), outcome);
      const result = state.resolve(id, outcome);
      held = null; active = null;
      diagnostics();
      return result; // No new probe is needed to settle a product request never sent.
    } else {
      if (records.length !== count) fail('RECEIPT_UNAVAILABLE', 'Complete original dispatch journal is unavailable; no probe sent');
      for (const record of records) {
        if (record.nonterminal) fail('WORKFLOW_RECONCILIATION_REQUIRED', 'RPC returned a typed nonterminal workflow outcome; no generic reconciliation or probe');
        if (record.terminal) {
          if (!record.request || record.request.method !== record.method) fail('RECEIPT_MISMATCH', 'Terminal RPC has no original reply identity');
          matching(client, record.response, record.request);
          if (record.receipt) {
            receipts.push(remoteReceipt(record, true, record.remoteReceipt));
            if (record.remoteReceipt && fs.existsSync(record.receipt)) {
              const current = remoteReceipt(record);
              if (current.outcome !== record.remoteReceipt.outcome) fail('RECEIPT_MISMATCH', 'Remote receipt changed after terminal publication');
            }
          }
        } else {
          if (!record.receipt) fail('RECEIPT_UNAVAILABLE', 'Unsettled non-script RPC has no remote completion evidence; no probe sent');
          receipts.push(remoteReceipt(record));
        }
      }
    }
    const context = active;
    active = null;
    try {
      // A reset during the recovery probe must not cause stacked SDK probes.
      // Its filesystem receipt proves completion even if the transport reply was lost.
      let previous = optional('reconcile-probe.json');
      let actual;
      if (previous) {
        if (previous.binding?.jobId !== id || previous.binding?.buildHash !== codeHash || !sameInstance(previous.instance, instance)) fail('RECEIPT_MISMATCH', 'Recovery probe identity mismatch');
        const receipt = remoteReceipt(previous);
        if (receipt.outcome === 'succeeded') actual = receipt.instance;
        else {
          // All original RPCs and this read-only probe have proven completion.
          // Preserve the failed attempt, then permit a fresh *observation*, never
          // a replay of the user's operation. Missing/mismatched/busy receipts
          // still fail above and cannot reach this branch.
          durable(path.join(directory, `reconcile-probe-${previous.binding.rpcId}.json`), previous);
          previous = null;
        }
      }
      if (!previous) {
        const rpcId = randomUUID();
        const record = { binding: { jobId: id, rpcId, requestHash: hash('reconcile:' + id + ':' + rpcId), buildHash: codeHash },
          instance, receipt: path.join(directory, `reconcile-${rpcId}.receipt.json`) };
        durable(path.join(directory, 'reconcile-probe.json'), record);
        actual = await checkInstance({ receiptPath: record.receipt, binding: record.binding,
          diagnosticPath: path.join(directory, `reconcile-${rpcId}.result.json`) });
      }
      durable(path.join(directory, 'reconcile-postflight.json'), actual);
    }
    finally { active = context; }
    const rawFile = path.join(directory, 'rpc-result.json');
    let raw = job.kind === 'rpc' && fs.existsSync(rawFile) ? readJson(rawFile) : null;
    if (!raw && job.kind === 'rpc' && records.length === 1 && records[0].terminal) {
      raw = records[0].response;
      durable(rawFile, raw);
    }
    const rawReply = raw && client._parse(raw.raw);
    const successfulOutput = job.kind === 'rpc' ? rawReply && !rawReply.error && !rawReply.result?.isError : worker?.terminal === true && worker.jobId === id && worker.code === 0;
    const details = { state: !notDispatched && successfulOutput && receipts.every(r => r.outcome === 'succeeded') && !records.some(r => r.failed) ? 'succeeded' : 'failed',
      code: notDispatched ? 'NOT_DISPATCHED' : worker?.terminal || raw ? 'RECONCILED' : 'RESULT_UNAVAILABLE',
      limitations: 'Receipts prove synchronous execution completion and idle identity, not physical validation or native background-command completion.' };
    durable(path.join(directory, 'outcome.json'), details);
    const result = state.resolve(id, details);
    held = null;
    active = null;
    diagnostics();
    return result;
  }

  async function dispatch(message) {
    if (!message || typeof message !== 'object' || Array.isArray(message)) fail('INVALID_MESSAGE', 'Expected a JSON object');
    if (message.action === 'backend') return backend(message);
    if (message.action === 'register') {
      if (!identifier(message.clientId) || !identifier(message.clientToken)) fail('INVALID_CLIENT', 'Nonempty clientId and private clientToken required');
      const tokenHash = hash(message.clientToken);
      if (own(clients, message.clientId) && !equal(clients[message.clientId], tokenHash)) fail('CLIENT_EXISTS', 'Client id already registered with another token');
      const updated = { ...clients, [message.clientId]: tokenHash };
      durable(clientsFile, updated);
      clients = updated;
      return { clientId: message.clientId };
    }
    const clientId = auth(message);
    switch (message.action) {
      case 'submit': {
        if (stopping) fail('BROKER_STOPPING', 'Broker is stopping');
        const r = message.request;
        if (!r || typeof r !== 'object' || Array.isArray(r)) fail('INVALID_REQUEST', 'Request object required');
        const request = { ...r, clientId, ownerToken: clients[clientId] };
        if (!Number.isSafeInteger(request.timeoutMs) || request.timeoutMs <= 0 || request.timeoutMs > 2147483647) fail('INVALID_TIMEOUT', 'Execution timeout must be 1..2147483647 ms');
        if (request.kind === 'command' && Array.isArray(request.argv)) {
          const entry = commandEntry(request.argv);
          if (['keychain', 'queue', 'init'].includes(entry?.key.split(' ')[0])) fail('unsupported_queue_route', 'Keychain and broker/configuration lifecycle commands are not queued workflows');
          if (entry?.target === 'animation.play') fail('unsupported_queue_route', 'Asynchronous animation.play has no supported terminal queue receipt');
        }
        if (request.protocolVersion !== undefined && (typeof request.protocolVersion !== 'string' ||
            !/^\d{4}-\d{2}-\d{2}$/.test(request.protocolVersion) || !Number.isFinite(Date.parse(request.protocolVersion)) ||
            new Date(request.protocolVersion).toISOString().slice(0, 10) !== request.protocolVersion)) fail('INVALID_PROTOCOL_VERSION', 'protocolVersion must be a valid YYYY-MM-DD protocol date');
        if (request.kind === 'rpc') {
          request.payload = r.rpc?.payload || r.payload;
          request.sessionId = r.rpc?.sessionId ?? r.sessionId;
          delete request.rpc;
          if (request.sessionId === undefined) delete request.sessionId;
          validateRaw(request.payload);
        }
        if (request.inputFiles !== undefined && (!Array.isArray(request.inputFiles) || request.inputFiles.some(f =>
          !f || typeof f.path !== 'string' || !/^[a-f0-9]{64}$/.test(f.sha256)))) fail('INVALID_INPUT_FILES', 'Input files require path and lowercase SHA256');
        if ((request.kind === 'command' || request.inputFiles?.length) && (typeof request.cwd !== 'string' || !path.isAbsolute(request.cwd))) fail('INVALID_CWD', 'Commands/input files require an absolute cwd');
        if (request.buildHash !== undefined && request.buildHash !== codeHash) fail('BUILD_CHANGED', 'Submitted buildHash differs from pinned broker build');
        if (request.backend && request.backend !== (pinned.backend || 'mcp')) fail('BACKEND_MISMATCH', 'Job backend differs from the broker; no fallback');
        return state.submit(request);
      }
      case 'status': return message.jobId ? state.status(message.jobId) : { ...state.status(), held, stopping, recovery, buildHash: codeHash };
      case 'result': {
        if (!message.jobId) return { ...state.status(), held, stopping, recovery, buildHash: codeHash };
        return { job: owned(message.jobId, clientId), ...outputs(message.jobId) };
      }
      case 'cancel': return state.cancel(message.jobId, clientId);
      case 'release': return state.release(message.sequenceId, clientId);
      case 'pause': return state.pause(true);
      case 'resume':
        if (held || state.summary().blocked) fail('RECONCILIATION_REQUIRED', 'Resolve the held instance/job before resuming');
        return state.pause(false);
      case 'reconcile':
        if (busy) fail('BROKER_BUSY', 'Original execution has not settled');
        busy = true;
        try { return await reconcile(message.jobId, clientId); } finally { busy = false; if (stopping) setImmediate(drain); }
      case 'stop':
        if (held || state.summary().blocked || active?.unknown) fail('RECONCILIATION_REQUIRED', 'Cannot stop an unknown/blocked queue');
        stopping = true;
        setImmediate(() => close().catch(error => { stopping = false; held ||= error.code || 'CLOSE_FAILED'; }));
        return { stopping: true, draining: !!state.summary().active };
      default: fail('INVALID_ACTION', 'Unknown broker action');
    }
  }

  async function execute(job) {
    const directory = jobDir(job.id);
    privateDirectory(directory);
    let inputFailure;
    if (job.request.buildHash !== undefined && job.request.buildHash !== codeHash) inputFailure = 'BUILD_CHANGED_BEFORE_EXECUTION';
    try {
      for (const input of job.request.inputFiles || []) {
        if (hash(fs.readFileSync(path.resolve(job.request.cwd, input.path))) !== input.sha256) inputFailure = 'INPUT_CHANGED';
      }
    } catch { inputFailure = 'INPUT_UNAVAILABLE'; }
    if (inputFailure) {
      const details = { state: 'failed', code: inputFailure, executionOutcome: 'not_started', userScriptSubmitted: false, mayHaveMutated: false };
      durable(path.join(directory, 'outcome.json'), details);
      state.finish(job.id, details);
      return;
    }
    const entry = job.kind === 'command' ? commandEntry(job.request.argv) : null;
    const protocolOnly = job.kind === 'rpc' ? ['initialize', 'notifications/initialized', 'ping', 'tools/list'].includes(job.request.payload.method)
      : ['tools', 'doctor'].includes(entry?.kind);
    const allowsBusy = protocolOnly || ['ui.inspect', 'ui.respond', 'ui.resolve'].includes(entry?.target);
    const allowsBusyAfter = protocolOnly || entry?.target === 'ui.inspect';
    const guardSelector = job.sequenceMode === 'automatic' ? documentSelector(job) : undefined;
    let observed;
    // Record actual completion before applying the idle policy. Even a lost
    // transport response has a bound remote receipt for later observation.
    const rpcId = randomUUID();
    const binding = { jobId: job.id, rpcId, requestHash: hash('preflight:' + job.id + ':' + rpcId), buildHash: codeHash };
    const receipt = path.join(directory, 'preflight-' + rpcId + '.receipt.json');
    durable(path.join(directory, 'preflight-start.json'), { version: 2, jobId: job.id, buildHash: codeHash, instance, at: Date.now(), binding, receipt }, true);
    try {
      await checkInstance({ receiptPath: receipt, binding, requireIdle: !allowsBusy,
        diagnosticPath: path.join(directory, 'preflight-result.json'),
        documentSelector: guardSelector,
        onObservation: observation => { observed = observation; durable(path.join(directory, 'preflight.json'), {
          version: 2, jobId: job.id, buildHash: codeHash, completed: true, instance: observation,
          idle: idle(observation), requiresIdle: !allowsBusy,
        }, true); } });
    } catch (error) {
      if (error.code !== 'FUSION_BUSY' || error.probeCompleted !== true || !sameInstance(error.observation, instance)) throw error;
      const outcome = { state: 'failed', code: 'FUSION_BUSY', executionOutcome: 'not_started',
        userScriptSubmitted: false, mayHaveMutated: false, preflightCompleted: true,
        activeCommand: error.observation.activeCommand };
      durable(path.join(directory, 'outcome.json'), outcome);
      state.finish(job.id, outcome);
      return;
    }
    if (job.sequenceMode === 'automatic' && job.sequenceParentId) {
      const baselineFile = path.join(jobDir(job.sequenceParentId), 'postflight.json');
      const baseline = fs.existsSync(baselineFile) ? readJson(baselineFile).documentState : null;
      const code = compareDocumentState(baseline, observed?.documentState);
      if (code) {
        const refreshedStatePath = path.join(directory, 'refreshed-document-state.json');
        const refresh = { success: false, status: code === 'DOCUMENT_CHANGED' ? 'document_changed' : 'document_guard_rejected',
          code, operationSubmitted: false, mayHaveMutated: false,
          automaticallyRefreshed: observed?.documentState?.status === 'complete',
          previousFingerprint: baseline?.fingerprint || null, currentState: observed?.documentState || null,
          refreshedStatePath, openDocuments: observed?.documents || [],
          message: observed?.documentState?.status === 'complete'
            ? 'The original operation was not executed. Current document state was collected in this same queue turn; no second queued read is needed to inspect it.'
            : 'The original operation was not executed. The response includes the observed target-state availability and open documents; no unchanged-state claim is made.' };
        durable(refreshedStatePath, refresh);
        durable(path.join(directory, 'outcome.json'), { state: 'failed', code, executionOutcome: 'not_started',
          userScriptSubmitted: false, mayHaveMutated: false, refreshedStatePath });
        fs.writeFileSync(path.join(directory, 'stdout.txt'), JSON.stringify(refresh) + '\n', { flag: 'wx', mode: 0o600 });
        state.finish(job.id, { state: 'failed', code, executionOutcome: 'not_started',
          userScriptSubmitted: false, mayHaveMutated: false, refreshedStatePath });
        return;
      }
    }
    const context = { job, token: randomBytes(32).toString('hex'), pending: new Set(), dispatched: false,
      unknown: false, timedOut: false, workerClosed: false, executionFailed: false, deadline: Date.now() + job.timeoutMs };
    active = context;
    let code, publicationError = false;
    if (job.kind === 'rpc') {
      try {
        const operation = (async () => {
          const previousHeaders = client.server.headers;
          const previousTimeout = client.server.timeoutMs;
          const headers = Object.fromEntries(Object.entries(previousHeaders || {}).filter(([name]) => name.toLowerCase() !== 'mcp-protocol-version'));
          if (job.request.protocolVersion) headers['MCP-Protocol-Version'] = job.request.protocolVersion;
          client.server.headers = headers;
          client.server.timeoutMs = job.timeoutMs;
          try { return await client._post(job.request.payload, job.request.sessionId); }
          finally { client.server.headers = previousHeaders; client.server.timeoutMs = previousTimeout; }
        })();
        context.pending.add(operation);
        operation.then(() => context.pending.delete(operation), () => context.pending.delete(operation));
        let timeout;
        const deadline = new Promise((resolve, reject) => { timeout = setTimeout(() => {
          context.timedOut = true;
          hold(job, 'Raw RPC exceeded its local deadline; remote completion remains unknown');
          reject(Object.assign(new Error('Raw RPC deadline expired'), { code: 'RUN_TIMEOUT' }));
        }, job.timeoutMs); });
        let result;
        try { result = await Promise.race([operation, deadline]); }
        finally { clearTimeout(timeout); }
        const reply = matching(client, result, job.request.payload);
        code = reply?.error || reply?.result?.isError || context.executionFailed ? 1 : 0;
        durable(path.join(directory, 'rpc-result.json'), result);
      } catch (error) { code = 1; if (!context.unknown && !context.timedOut) publicationError = true; }
      context.workerClosed = true;
    } else {
      const safeCfg = { backend: pinned.backend || 'mcp', tool: pinned.tool, transport: pinned.transport,
        timeoutMs: job.timeoutMs, protocolVersion: pinned.protocolVersion, url: 'http://queue.invalid', headers: {} };
      durable(path.join(directory, 'request.json'), { id: job.id, request: job.request, buildHash: codeHash,
        properties: clientProperties(), deadline: context.deadline }, true);
      const out = fs.openSync(path.join(directory, 'stdout.txt'), 'wx', 0o600);
      const err = fs.openSync(path.join(directory, 'stderr.txt'), 'wx', 0o600);
      try {
        // A fixed Node entry point invokes cli.main with fixed dependencies; no shell/argv interpreter.
        const env = {};
        for (const key of ['PATH', 'HOME', 'USER', 'LOGNAME', 'LANG', 'LC_ALL', 'XDG_CONFIG_HOME', 'WSL_DISTRO_NAME', 'TMPDIR', 'SYSTEMROOT']) {
          if (process.env[key] !== undefined) env[key] = process.env[key];
        }
        Object.assign(env, { FMCAD_QUEUE_WORKER_JOB: job.id, FMCAD_QUEUE_WORKER_TOKEN: context.token,
          FMCAD_QUEUE_DIR: dir, FMCAD_QUEUE_WORKER_CONFIG: JSON.stringify(safeCfg), FMCAD_QUEUE: 'worker' });
        durable(path.join(directory, 'worker-start.json'), { jobId: job.id, buildHash: codeHash, at: Date.now() }, true);
        const child = spawn(process.execPath, [path.join(__dirname, 'queue-worker.js'), path.join(directory, 'request.json')],
          { cwd: job.request.cwd, shell: false, env, stdio: ['ignore', out, err] });
        context.child = child;
        let spawnError;
        child.once('spawn', () => {
          try { durable(path.join(directory, 'worker-identity.json'), { pid: child.pid, birth: processBirth(child.pid) }, true); }
          catch (error) {
            publicationError = true;
            if (!['ENOENT', 'ESRCH'].includes(error.code)) {
              if (context.dispatched) hold(job, 'Local worker identity could not be persisted');
              child.kill('SIGKILL');
            }
          }
        });
        const timeout = setTimeout(() => {
          context.timedOut = true;
          if (context.dispatched) hold(job, 'Worker deadline expired after possible physical dispatch; remote operation is not cancelled');
          child.kill('SIGKILL'); // Only our local child, never Fusion or a remote RPC.
        }, Math.max(1, context.deadline - Date.now()));
        code = await new Promise(resolve => {
          child.once('error', error => { spawnError = error; });
          child.once('close', exitCode => resolve(exitCode ?? 1));
        });
        clearTimeout(timeout);
        context.workerClosed = true;
        if (spawnError) code = 1;
        fs.fsyncSync(out); fs.fsyncSync(err);
      } catch (error) { code = 1; publicationError = true; }
      finally { fs.closeSync(out); fs.closeSync(err); }
    }
    if (context.pending.size) {
      hold(job, 'Worker exited while a broker RPC is still pending; no postflight sent');
      return;
    }
    const workerFile = path.join(directory, 'worker-result.json');
    const worker = fs.existsSync(workerFile) ? readJson(workerFile) : null;
    if (context.workflowUnknown || worker?.nonterminal || workflowNonterminal(worker?.workflowOutcome)) {
      durable(path.join(directory, 'outcome.json'), { state: 'needs_reconciliation', code: 'WORKFLOW_NONTERMINAL',
        workflowOutcome: worker?.workflowOutcome || null, nonterminal: true });
      hold(job, 'Typed workflow result is unknown/nonterminal; a synchronous script receipt is insufficient');
      return;
    }
    if (context.unknown || context.timedOut && context.dispatched || state.summary().blocked) return;
    if (job.kind === 'command' && context.dispatched && (!worker?.terminal || worker.jobId !== job.id)) {
      hold(job, 'Worker exited after dispatch without its own durable terminal result');
      return;
    }
    if (job.kind === 'command' && code === 0 && (!worker?.terminal || worker.jobId !== job.id)) publicationError = true;
    active = null;
    try { durable(path.join(directory, 'postflight.json'), await checkInstance({ requireIdle: !allowsBusyAfter,
      diagnosticPath: path.join(directory, 'postflight-result.json'), documentSelector: guardSelector }), true); }
    catch (error) { active = context; hold(job, error.code || 'POSTFLIGHT_FAILED'); return; }
    const details = { state: code === 0 && !context.executionFailed && !publicationError && !context.publicationError ? 'succeeded' : 'failed',
      code: publicationError || context.publicationError ? 'OUTPUT_PUBLICATION_FAILED' : context.timedOut ? 'RUN_TIMEOUT' : 'EXECUTION_COMPLETE', exitCode: code };
    durable(path.join(directory, 'outcome.json'), details);
    state.finish(job.id, details);
    active = null;
  }

  async function tick() {
    if (busy || closed || stopping) return;
    if (held) {
      // Queue deadlines continue to expire while a blocked job holds the physical instance.
      if (state.summary().blocked) {
        try { state.next(); } catch { /* The held storage fault is already visible to callers. */ }
        if (options.autoReconcile === true && Date.now() - lastRecoveryCheck >= 30000) {
          lastRecoveryCheck = Date.now();
          busy = true;
          const id = state.summary().blocked.id;
          try {
            await reconcile(id, state.status(id).clientId);
            recovery = { jobId: id, status: 'resolved', at: Date.now() };
          } catch (error) {
            recovery = { jobId: id, status: 'waiting_for_evidence', code: error.code || 'RECOVERY_ERROR', at: Date.now() };
          } finally { busy = false; }
          diagnostics();
        }
      }
      return;
    }
    busy = true;
    let job;
    try {
      job = state.next();
      if (job) await execute(job);
    } catch (error) {
      if (job) hold(job, error.code || 'BROKER_EXECUTION_FAILED');
      else held = error.code || 'BROKER_STORAGE_FAILED';
      diagnostics();
    } finally { busy = false; if (stopping) setImmediate(drain); }
  }

  const sockets = new Set();
  const server = net.createServer(socket => {
    sockets.add(socket);
    socket.on('close', () => sockets.delete(socket));
    socket.on('error', () => {});
    socket.setTimeout(30000, () => socket.destroy());
    let buffer = Buffer.alloc(0), consumed = false;
    function respond(value) {
      if (socket.destroyed) return;
      let text = JSON.stringify(value);
      if (Buffer.byteLength(text) > MAX) text = JSON.stringify({ ok: false, error: { code: 'RESPONSE_TOO_LARGE', message: 'Response exceeds 16 MiB; use output file metadata' } });
      socket.end(text + '\n');
    }
    socket.on('data', chunk => {
      if (consumed) return;
      if (buffer.length + chunk.length > MAX) { consumed = true; respond({ ok: false, error: { code: 'MESSAGE_TOO_LARGE', message: 'Request exceeds 16 MiB' } }); return; }
      buffer = Buffer.concat([buffer, chunk]);
      const newline = buffer.indexOf(10);
      if (newline < 0) return;
      consumed = true;
      socket.setTimeout(0); // Client disconnects never cancel accepted jobs or backend operations.
      let message;
      try { message = JSON.parse(buffer.subarray(0, newline).toString('utf8')); }
      catch { respond({ ok: false, error: { code: 'INVALID_JSON', message: 'Invalid JSON request' } }); return; }
      Promise.resolve().then(() => dispatch(message)).then(result => respond({ ok: true, result }), error =>
        respond({ ok: false, error: { code: error.code || 'BROKER_ERROR', message: error.code ? error.message : 'Broker operation failed; inspect private durable records' } }));
    });
  });
  const socket = queueSocket(dir);
  // A stale Unix socket may be removed only after exclusive lock ownership was acquired.
  if (process.platform !== 'win32' && fs.existsSync(socket)) fs.unlinkSync(socket);
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(socket, resolve); });
  if (process.platform !== 'win32') fs.chmodSync(socket, 0o600);
  try { durable(lifecycleFile, { ...lifecycle, stage: 'ready' }); }
  catch (error) { server.close(); client.reqOpts?.agent?.destroy(); throw error; }
  server.on('error', () => { held = 'IPC_SERVER_ERROR'; });
  diagnostics();
  timer = setInterval(tick, options.pollMs || 100);

  async function close() {
    if (closed) return;
    if (held || state.summary().blocked || active?.unknown) fail('RECONCILIATION_REQUIRED', 'Cannot release broker ownership with an unknown/blocked job');
    stopping = true;
    if (!closeTask) closeTask = new Promise((resolve, reject) => { closeResolve = resolve; closeReject = reject; });
    setImmediate(drain);
    return closeTask;
  }
  async function drain() {
    if (!stopping || closed || closing || !closeTask) return;
    if (held || state.summary().blocked || active?.unknown) {
      stopping = false;
      closeReject(Object.assign(new Error('Drain became unknown/blocked; broker ownership is retained'), { code: 'RECONCILIATION_REQUIRED' }));
      closeTask = null;
      return;
    }
    if (busy || active || state.summary().active) return;
    closing = true;
    try {
      const lease = state.summary().lease;
      if (lease) {
        try { state.release(lease.id, lease.clientId); }
        catch (error) { if (error.code !== 'SEQUENCE_MISMATCH' || state.summary().lease) throw error; }
      }
      clearInterval(timer);
      for (const connection of sockets) connection.end();
      await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
      if (readJson(lock).nonce !== marker.nonce) fail('LOCK_CHANGED', 'Broker ownership marker changed');
      fs.unlinkSync(lock);
      const fd = fs.openSync(dir, 'r');
      try { fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
      client.reqOpts?.agent?.destroy();
      closed = true;
      closeResolve();
    } catch (error) { held = error.code || 'CLOSE_FAILED'; closeReject(error); }
  }
  return { close, dir, socket, buildHash: codeHash, status: () => ({ ...state.status(), held, stopping, buildHash: codeHash }) };
}

module.exports = { serve, reclaim };
