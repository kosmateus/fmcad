'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const { createHash, randomUUID } = require('node:crypto');

const fail = (code, message) => { throw Object.assign(new Error(message), { code }); };
const hash = value => createHash('sha256').update(value).digest('hex');

function durable(file, value, exclusive = false) {
  const temp = exclusive ? file : `${file}.${randomUUID()}.tmp`;
  const fd = fs.openSync(temp, 'wx', 0o600);
  try { fs.writeFileSync(fd, JSON.stringify(value)); fs.fsyncSync(fd); }
  finally { fs.closeSync(fd); }
  if (!exclusive) fs.renameSync(temp, file);
  const directory = fs.openSync(path.dirname(file), 'r');
  try { fs.fsyncSync(directory); } finally { fs.closeSync(directory); }
}

function readJson(file) {
  const fd = fs.openSync(file, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
  try {
    if (fs.fstatSync(fd).size > 16 * 1024 * 1024) fail('CORRUPT_STATE', 'Queue record exceeds 16 MiB');
    return JSON.parse(fs.readFileSync(fd, 'utf8'));
  } finally { fs.closeSync(fd); }
}

function processBirth(pid = process.pid) {
  // Linux start ticks plus boot id distinguish reused PIDs and machine boots.
  if (process.platform !== 'linux') fail('UNSUPPORTED_HOST', 'Broker ownership currently requires Linux /proc birth identity');
  const stat = fs.readFileSync(`/proc/${pid}/stat`, 'utf8');
  const fields = stat.slice(stat.lastIndexOf(')') + 2).split(' ');
  if (['Z', 'X'].includes(fields[0])) fail('ESRCH', 'Process has exited');
  const ticks = fields[19];
  if (!/^\d+$/.test(ticks)) fail('INVALID_PROCESS_IDENTITY', 'Process birth ticks are unavailable');
  return `${fs.readFileSync('/proc/sys/kernel/random/boot_id', 'utf8').trim()}:${ticks}`;
}

function priorProcessAlive(identity) {
  if (!identity || !Number.isSafeInteger(identity.pid) || identity.pid <= 0 || typeof identity.birth !== 'string') return null;
  if (identity.birth.includes(':')) {
    try { return processBirth(identity.pid) === identity.birth; }
    catch (error) { return ['ENOENT', 'ESRCH'].includes(error.code) ? false : null; }
  }
  // Fusion's Windows birth value is a FILETIME. In WSL, PID-only checks are
  // meaningless; compare the exact Windows process creation time instead.
  try {
    const script = `$p=Get-CimInstance -ClassName Win32_Process -Filter 'ProcessId = ${identity.pid}' -ErrorAction SilentlyContinue; if ($null -eq $p) { 'absent' } else { $p.CreationDate.ToFileTimeUtc().ToString() }`;
    const value = execFileSync('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-Command', script],
      { encoding: 'utf8', timeout: 3000, windowsHide: true }).trim();
    if (value === 'absent') return false;
    return /^\d+$/.test(value) ? value === identity.birth : null;
  } catch { return null; }
}

function reclaim(dir) {
  const file = path.join(dir, 'broker.lock');
  const marker = readJson(file);
  if (!Number.isSafeInteger(marker.pid) || marker.pid <= 0 || typeof marker.birth !== 'string') fail('INVALID_LOCK', 'Invalid broker ownership marker');
  let dead = false;
  try { dead = processBirth(marker.pid) !== marker.birth; }
  catch (error) { if (error.code === 'ENOENT' || error.code === 'ESRCH') dead = true; else throw error; }
  if (!dead) fail('BROKER_ALIVE', 'The original broker PID and birth identity are still alive');
  // An exclusive recovery claim prevents two recovery commands removing a new lock.
  const claim = path.join(dir, 'recovery.lock');
  durable(claim, { pid: process.pid, birth: processBirth() }, true);
  try {
    // A graceful close must not race with a new serve while recovery owns the directory.
    const current = readJson(file);
    if (JSON.stringify(current) !== JSON.stringify(marker)) fail('LOCK_CHANGED', 'Broker ownership changed during recovery');
    durable(path.join(dir, `reclaimed-${randomUUID()}.json`), marker, true);
    fs.unlinkSync(file);
    const fd = fs.openSync(dir, 'r');
    try { fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
    return { reclaimed: true, previous: { pid: marker.pid, birth: marker.birth }, reconciliationRequired: true };
  } finally { fs.unlinkSync(claim); }
}

function buildHash(root = path.resolve(__dirname, '..')) {
  const digest = createHash('sha256');
  function visit(relative) {
    const full = path.join(root, relative);
    const stat = fs.lstatSync(full);
    if (stat.isSymbolicLink()) fail('UNPINNED_BUILD', `Symlink in executable build: ${relative}`);
    if (stat.isDirectory()) {
      for (const name of fs.readdirSync(full).sort()) visit(path.join(relative, name));
    } else if (stat.isFile()) digest.update(relative + '\0').update(fs.readFileSync(full)).update('\0');
  }
  for (const name of ['package.json', 'bin', 'src', 'assets']) visit(name);
  return digest.digest('hex');
}

function fusionPath(file) {
  if (process.platform !== 'linux') return file;
  const drive = file.match(/^\/mnt\/([a-zA-Z])\/(.*)$/);
  if (drive) return drive[1].toUpperCase() + ':\\' + drive[2].replaceAll('/', '\\');
  return '\\\\wsl$\\' + (process.env.WSL_DISTRO_NAME || 'Ubuntu') + file.replaceAll('/', '\\');
}

// Shared by the read-only probe and remote terminal receipts. Never substitute PID alone.
const identityPython = `import os as _qi_os, sys as _qi_sys, adsk.core as _qi_core
def _qi_identity():
    _app = _qi_core.Application.get()
    if _qi_os.name == 'nt':
        import ctypes as _ct
        from ctypes import wintypes as _wt
        _kernel = _ct.WinDLL('kernel32', use_last_error=True)
        _kernel.GetCurrentProcess.restype = _wt.HANDLE
        _kernel.GetProcessTimes.argtypes = [_wt.HANDLE] + [_ct.POINTER(_wt.FILETIME)] * 4
        _times = [_wt.FILETIME() for _ in range(4)]
        if not _kernel.GetProcessTimes(_kernel.GetCurrentProcess(), *[_ct.byref(_t) for _t in _times]):
            raise OSError(_ct.get_last_error(), 'GetProcessTimes')
        _birth = str((_times[0].dwHighDateTime << 32) | _times[0].dwLowDateTime)
    elif _qi_sys.platform.startswith('linux'):
        with open('/proc/self/stat') as _f: _stat = _f.read()
        with open('/proc/sys/kernel/random/boot_id') as _f: _boot = _f.read().strip()
        _birth = _boot + ':' + _stat[_stat.rfind(')') + 2:].split()[19]
    else:
        raise RuntimeError('Actual process birth identity unavailable on this Fusion host')
    return {'pid':_qi_os.getpid(), 'birth':_birth, 'version':_app.version,
            'activeCommand':_app.userInterface.activeCommand}
`;

const probeScript = `${identityPython}
import json as _qi_json
def run(_context):
    _value = _qi_identity()
    _app = _qi_core.Application.get()
    _value['documents'] = []
    for _i in range(_app.documents.count):
        _doc = _app.documents.item(_i)
        _data = _doc.dataFile
        _value['documents'].append({'id':_doc.creationId, 'fileId':_data.id if _data else None,
            'isSaved':_doc.isSaved, 'isModified':_doc.isModified})
    print('FMCAD_QUEUE_INSTANCE ' + _qi_json.dumps(_value))
`;

const sameInstance = (a, b) => !!(a && b && a.pid === b.pid && a.birth === b.birth && a.version === b.version);
const idle = identity => !!identity && ['', 'SelectCommand'].includes(identity.activeCommand);
const workflowNonterminal = value => !!(value && typeof value === 'object' &&
  (value.outcome === 'unknown' || value.executionOutcome === 'unknown' ||
    ['started', 'running', 'pending'].includes(value.status) || value.completed === false ||
    value.status === 'unknown' && /^(batch\.|ui\.|references\.refresh$|document\.save_as$|review$)/.test(value.operation || '')));

async function probe(client, { receiptPath, binding, requireIdle = true, onObservation, diagnosticPath, documentSelector } = {}) {
  const previousTimeout = client.server.timeoutMs;
  client.server.timeoutMs = Math.min(previousTimeout, 15000);
  let output;
  try {
    const documentCode = documentSelector !== undefined
      ? fs.readFileSync(path.join(__dirname, '..', 'assets', 'queue_document.py'), 'utf8') : '';
    const code = documentCode ? documentCode + '\n' + probeScript.replace(
      "    print('FMCAD_QUEUE_INSTANCE '",
      `    _value['documentState'] = _qd_capture(_app, _qi_json.loads(${JSON.stringify(JSON.stringify(documentSelector))}))\n    print('FMCAD_QUEUE_INSTANCE '`) : probeScript;
    const script = receiptPath ? wrapScript(code, true, receiptPath, binding) : code;
    output = await client.callTool({ featureType: 'script', object: { script, readOnly: true } }, 'fusion_mcp_execute');
  } catch (error) {
    if (diagnosticPath) durable(diagnosticPath, { stage: 'instance_probe', at: new Date().toISOString(),
      code: error.code || 'PROBE_TRANSPORT_ERROR', message: error.message });
    throw error;
  } finally { client.server.timeoutMs = previousTimeout; }
  if (diagnosticPath) durable(diagnosticPath, { stage: 'instance_probe', at: new Date().toISOString(),
    failed: output.failed, text: String(output.text || '').slice(-16384) });
  if (output.failed) fail('INSTANCE_UNAVAILABLE', 'Read-only Fusion instance probe failed');
  const text = output.text || '';
  const line = text.split(/\r?\n/).find(line => line.startsWith('FMCAD_QUEUE_INSTANCE '));
  if (!line) fail('INSTANCE_UNAVAILABLE', 'Fusion instance probe returned no identity');
  const result = JSON.parse(line.slice('FMCAD_QUEUE_INSTANCE '.length));
  if (!Number.isSafeInteger(result.pid) || !result.birth || !result.version || !Array.isArray(result.documents)) fail('INSTANCE_UNAVAILABLE', 'Incomplete Fusion identity');
  if (onObservation) await onObservation(result);
  if (requireIdle && !idle(result)) throw Object.assign(new Error('An interactive Fusion command is open'), {
    code: 'FUSION_BUSY', probeCompleted: true, observation: result,
  });
  return result;
}

function wrapScript(code, official, receiptPath, binding) {
  const body = `${identityPython}
import json as _qr_json, uuid as _qr_uuid, traceback as _qr_traceback
_qr_binding = _qr_json.loads(${JSON.stringify(JSON.stringify(binding))})
_qr_path = ${JSON.stringify(fusionPath(receiptPath))}
_qr_outcome = 'failed'
_qr_error = None
try:
    _qr_namespace = {'__name__':'__main__', '__file__':'<fmcad-queue>'}
    exec(compile(${JSON.stringify(code)}, '<fmcad-queue>', 'exec'), _qr_namespace, _qr_namespace)
${official ? "    _qr_namespace['run'](_context)\n" : ''}    _qr_outcome = 'succeeded'
except BaseException as _qr_exception:
    _qr_error = {'type':type(_qr_exception).__name__, 'message':str(_qr_exception),
                 'traceback':_qr_traceback.format_exc()[-16384:]}
    raise
finally:
    _qr_record = dict(_qr_binding)
    _qr_record.update({'terminal':True, 'outcome':_qr_outcome, 'instance':_qi_identity()})
    if _qr_error is not None: _qr_record['error'] = _qr_error
    _qr_temp = _qr_path + '.' + str(_qr_uuid.uuid4()) + '.tmp'
    with open(_qr_temp, 'x', encoding='utf-8') as _qr_file:
        _qr_json.dump(_qr_record, _qr_file)
        _qr_file.flush()
        _qi_os.fsync(_qr_file.fileno())
    _qi_os.replace(_qr_temp, _qr_path)
    if _qi_os.name != 'nt':
        _qr_fd = _qi_os.open(_qi_os.path.dirname(_qr_path), _qi_os.O_RDONLY)
        try: _qi_os.fsync(_qr_fd)
        finally: _qi_os.close(_qr_fd)
`;
  return official ? 'def run(_context):\n' + body.split('\n').map(line => '    ' + line).join('\n') + '\n' : body;
}

module.exports = { durable, readJson, processBirth, priorProcessAlive, reclaim, buildHash, fusionPath, probe, sameInstance, idle, workflowNonterminal, wrapScript, hash, fail };
