const { performance } = require('node:perf_hooks');
const { stripVTControlCharacters } = require('node:util');

function progressMode(mode, stream, env = process.env) {
  if (!['auto', 'bar', 'plain', 'off'].includes(mode)) throw new Error('--progress requires auto, bar, plain or off');
  if (mode === 'auto' || mode === 'bar') {
    return stream.isTTY === true && env.TERM !== 'dumb' ? 'bar' : 'plain';
  }
  return mode;
}

function createProgress(stream, { mode = 'auto', operation, timeout = 0, clock = () => performance.now(), animate = true,
  heartbeatMs = 10000, env = process.env } = {}) {
  mode = progressMode(mode, stream, env);
  if (!Number.isFinite(heartbeatMs) || heartbeatMs <= 0) throw new Error('heartbeatMs must be positive');
  const clean = text => stripVTControlCharacters(String(text)).replace(/[\x00-\x1f\x7f-\x9f]/g, ' ');
  operation = clean(operation);
  const start = clock();
  let stage = operation, status = 'started', completed, total, frame = 0, width = 0, previous, last = 0, stopped = false;
  const elapsed = () => Math.max(0, clock() - start);
  const duration = ms => `${Math.floor(ms / 60000)}:${String(Math.floor(ms / 1000) % 60).padStart(2, '0')}`;
  function draw() {
    if (stopped || mode === 'off') return;
    const time = elapsed();
    const stateKey = JSON.stringify([stage, status, completed, total]);
    const changed = stateKey !== previous;
    const count = completed === undefined ? '' : total === undefined ? `${completed} completed` : `${completed}/${total}`;
    const timing = ` | ${duration(time)}${timeout ? ` | limit ${duration(timeout)}` : ''}`;
    if (mode === 'bar') {
      const measured = completed !== undefined && total > 0;
      const filled = measured ? Math.round(Math.min(1, completed / total) * 20) : 0;
      const indicator = measured ? `[${'█'.repeat(filled)}${'░'.repeat(20 - filled)}]` : ['|', '/', '-', '\\'][frame++ % 4];
      const text = `${stage} - ${status} ${indicator}${count ? ' ' + count : ''}${timing}`;
      stream.write('\r' + text.padEnd(width));
      width = text.length;
    } else if (changed || time - last >= heartbeatMs) {
      stream.write(`${new Date().toISOString()} ${stage} - ${changed ? status : 'still running'}${count ? ' | ' + count : ''}${timing}\n`);
      last = time;
    }
    previous = stateKey;
  }
  function update(line) {
    if (stopped || mode === 'off') return;
    let value;
    try {
      value = JSON.parse(line);
    } catch {
      const match = /^image\.optimize: (\d+)\/(\d+)/.exec(line);
      if (!match) return;
      // The legacy optimizer emits this before computing the candidate, not after.
      value = { stage: 'prepare.optimize', status: `candidate ${match[1]}/${match[2]} started`, completed: null, total: null };
    }
    if (!value || typeof value.stage !== 'string' || typeof value.status !== 'string') return;
    // Supervisor liveness must not replace detailed child progress or reset its idle clock.
    if (value.supervisorHeartbeat === true) { draw(); return; }
    const nextStage = clean(value.stage);
    if (nextStage !== stage) { completed = undefined; total = undefined; }
    stage = nextStage;
    status = clean(value.status);
    const validCount = value => Number.isFinite(value) && value >= 0 ? value : undefined;
    if (Object.hasOwn(value, 'completed')) completed = validCount(value.completed);
    if (Object.hasOwn(value, 'total')) total = validCount(value.total);
    draw();
  }
  draw();
  const timer = animate && mode !== 'off' ? setInterval(draw, mode === 'bar' ? 125 : Math.min(heartbeatMs, 1000)) : null;
  timer?.unref();
  return { update, draw, finish(result) {
    if (stopped) return;
    if (timer) clearInterval(timer);
    const text = `${operation} - ${clean(result)} | ${(elapsed() / 1000).toFixed(2)} s`;
    if (mode === 'bar') stream.write('\r' + text.padEnd(width) + '\n');
    else if (mode !== 'off') stream.write(text + '\n');
    stopped = true;
  } };
}

module.exports = { createProgress, progressMode };
