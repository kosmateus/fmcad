'use strict';

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { randomBytes, randomUUID, createHash } = require('node:crypto');
const { queueDirectory, request } = require('./queue-connection');

const hash = value => createHash('sha256').update(value).digest('hex');
const final = state => ['succeeded', 'failed', 'cancelled', 'expired', 'needs_reconciliation'].includes(state);
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

function credentials(clientId = process.env.FMCAD_CLIENT || `cli:${os.hostname()}:${os.userInfo().username}`) {
  if (typeof clientId !== 'string' || !clientId.trim() || clientId.length > 256) throw new Error('client id must contain 1..256 characters');
  const dir = queueDirectory();
  const clients = path.join(dir, 'client-credentials');
  fs.mkdirSync(clients, { recursive: true, mode: 0o700 });
  const file = path.join(clients, hash(clientId) + '.json');
  const temporary = path.join(clients, '.' + randomUUID() + '.tmp');
  try {
    const fd = fs.openSync(temporary, 'wx', 0o600);
    try { fs.writeFileSync(fd, JSON.stringify({ clientId, clientToken: randomBytes(32).toString('hex') })); fs.fsyncSync(fd); }
    finally { fs.closeSync(fd); }
    // Publish a fully written credential without replacing an existing owner.
    try { fs.linkSync(temporary, file); } catch (error) { if (error.code !== 'EEXIST') throw error; }
    const directory = fs.openSync(clients, 'r');
    try { fs.fsyncSync(directory); } finally { fs.closeSync(directory); }
  } finally { if (fs.existsSync(temporary)) fs.unlinkSync(temporary); }
  const fd = fs.openSync(file, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
  let auth;
  try { auth = JSON.parse(fs.readFileSync(fd, 'utf8')); } finally { fs.closeSync(fd); }
  if (auth.clientId !== clientId || !/^[a-f0-9]{64}$/.test(auth.clientToken)) throw new Error('Invalid private queue client credentials; do not replace credentials of an existing sequence');
  return auth;
}

class QueueClient {
  constructor(clientId, options = {}) { this.dir = queueDirectory(); this.auth = credentials(clientId); this.options = options; }
  async register({ autoStart = false } = {}) {
    try { await request(this.dir, { action: 'register', ...this.auth }); }
    catch (error) {
      const { ensureBroker, missing } = require('./queue-autostart');
      if (!autoStart || !missing(error)) throw error;
      const selected = this.options.cfg;
      if (!selected || selected.routing !== 'queue') throw error;
      if (selected.queue?.autoStart === false) {
        throw Object.assign(new Error('Queue broker is not running and queue.autoStart is false; no direct fallback'), { code: 'QUEUE_NOT_RUNNING' });
      }
      // Startup uses the configured physical backend, not this job's execution
      // --timeout or per-job connection overrides. Other callers share it.
      const base = require('./config').loadConfig({ config: this.options.configPath, routing: 'queue' }).cfg;
      if (selected.backend !== base.backend) {
        throw Object.assign(new Error(`Queue broker is configured for ${base.backend}; this client requests ${selected.backend}. Select the configured backend; no broker was launched.`), { code: 'BACKEND_MISMATCH' });
      }
      await ensureBroker(base, this.auth);
    }
    return this;
  }
  call(action, values = {}) { return request(this.dir, { ...values, action, auth: this.auth }); }
  async submit(input) {
    if (input.kind === 'command' && Array.isArray(input.argv)) {
      const entry = require('./commands').findCommand(require('./cli').parseFlags(input.argv).rest);
      if (['keychain', 'queue', 'init'].includes(entry?.key.split(' ')[0]) || entry?.target === 'animation.play') {
        throw Object.assign(new Error('This command is unsupported in the queue; no broker startup or direct fallback was attempted'), { code: 'unsupported_queue_route' });
      }
    }
    await this.register({ autoStart: true });
    return this.call('submit', { request: { ...input, requestId: input.requestId || randomUUID() } });
  }
  async wait(jobId, { signal, progress } = {}) {
    let previous;
    for (;;) {
      if (signal?.aborted) throw Object.assign(new Error(`Stopped waiting; job ${jobId} is NOT cancelled`), { code: 'WAIT_ABORTED', jobId });
      const value = await this.call('result', { jobId });
      const state = value.job.state;
      if (state !== previous) { progress?.(value.job); previous = state; }
      if (final(state)) return value;
      await delay(250);
    }
  }
}

function inputFiles(argv, cwd) {
  const names = new Set();
  for (let i = 0; i < argv.length; i++) {
    if (['--file', '--args-file'].includes(argv[i]) && argv[i + 1]) names.add(path.resolve(cwd, argv[++i]));
  }
  const position = runArgumentPosition(argv);
  if (position !== undefined) names.add(require('./run').resolveScript(argv[position]));
  return [...names].map(file => ({ path: file, sha256: hash(fs.readFileSync(file)) }));
}

function runArgumentPosition(argv) {
  const { globalFlags, findCommand } = require('./commands');
  const positions = [];
  for (let i = 0; i < argv.length; i++) { if (Object.hasOwn(globalFlags, argv[i])) i++; else positions.push(i); }
  const words = positions.map(i => argv[i]);
  const entry = findCommand(words);
  if (entry?.kind !== 'run' || words.includes('--list') || words.includes('-l')) return undefined;
  for (let i = 1; i < words.length; i++) {
    if (Object.hasOwn(entry.flags, words[i])) { if (entry.flags[words[i]] === 'value') i++; continue; }
    if (words[i].startsWith('-')) continue;
    return positions[i];
  }
}

function pinCommand(argv) {
  const pinned = [...argv];
  const index = runArgumentPosition(argv);
  if (index !== undefined) pinned[index] = require('./run').resolveScript(argv[index]);
  return pinned;
}

function verifyInputBytes(file, bytes) {
  if (!process.env.FMCAD_QUEUE_WORKER_JOB) return;
  const entries = JSON.parse(process.env.FMCAD_QUEUE_INPUT_FILES || '[]');
  const entry = entries.find(item => path.resolve(item.path) === path.resolve(file));
  if (!entry || entry.sha256 !== hash(bytes)) throw Object.assign(new Error('Queued input bytes changed: ' + file), { code: 'INPUT_CHANGED' });
}

function sequenceOptions(opts) {
  if (!opts['sequence-action'] && !opts['sequence-id'] && !opts['sequence-mode']) return undefined;
  const value = { action: opts['sequence-action'], ...(opts['sequence-id'] ? { id: opts['sequence-id'] } : {}),
    ...(opts['sequence-mode'] ? { mode: opts['sequence-mode'] } : {}) };
  if (!['begin', 'continue', 'end'].includes(value.action) || (value.action === 'begin' ? value.id !== undefined : !value.id)) throw new Error('Use --sequence-action begin, or continue/end with --sequence-id');
  if (value.mode !== undefined && !['automatic', 'exclusive'].includes(value.mode)) throw new Error('sequence mode must be automatic or exclusive');
  return value;
}

async function runQueued(argv, cfg, opts, streams) {
  const client = new QueueClient(opts.client ?? process.env.FMCAD_CLIENT ?? cfg.queue?.client, { cfg, configPath: opts.config });
  const requestId = opts['request-id'] || randomUUID();
  const pinned = pinCommand(argv);
  const input = { requestId, kind: 'command', argv: pinned, cwd: process.cwd(), timeoutMs: cfg.timeoutMs, backend: cfg.backend,
    inputFiles: inputFiles(pinned, process.cwd()), buildHash: require('./queue-instance').buildHash() };
  const sequence = sequenceOptions(opts);
  if (sequence) input.sequence = sequence;
  if (opts['queue-timeout'] !== undefined || cfg.queue?.waitTimeoutMs !== undefined) input.queueTimeoutMs = Number(opts['queue-timeout'] ?? cfg.queue.waitTimeoutMs);
  if (opts['expected-revision'] !== undefined) input.expectedRevision = Number(opts['expected-revision']);
  // Persist client-side intent before submission, so loss of the admission reply has a stable lookup key.
  const intent = path.join(client.dir, 'client-credentials', hash(client.auth.clientId) + '-' + hash(requestId) + '.json');
  if (!fs.existsSync(intent)) {
    const fd = fs.openSync(intent, 'wx', 0o600);
    try { fs.writeFileSync(fd, JSON.stringify({ requestId, clientId: client.auth.clientId, input })); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
  }
  streams.stderr.write('FMCAD_QUEUE_REQUEST ' + JSON.stringify({ requestId, clientId: client.auth.clientId }) + '\n');
  const job = await client.submit(input);
  streams.stderr.write('FMCAD_QUEUE_JOB ' + JSON.stringify({ jobId: job.id, requestId }) + '\n');
  const result = await client.wait(job.id, { progress: value => streams.stderr.write(`QUEUE ${value.id} ${value.state}\n`) });
  if (result.stdout) streams.stdout.write(result.stdout);
  if (result.stderr) streams.stderr.write(result.stderr);
  if (result.outputs) streams.stderr.write('FMCAD_QUEUE_OUTPUTS ' + JSON.stringify(result.outputs) + '\n');
  streams.stderr.write('FMCAD_QUEUE_RESULT ' + JSON.stringify(result.job) + '\n');
  return result.job.state === 'succeeded' ? 0 : 1;
}

function assertDirectAccess() {
  if (process.env.FMCAD_QUEUE_WORKER_JOB) return;
  if (fs.existsSync(path.join(queueDirectory(), 'broker.lock'))) throw Object.assign(new Error('Fusion is reserved by the fmcad broker (or has an unresolved broker marker). Use routing=queue or reconcile/drain the broker; no direct access was attempted.'), { code: 'FUSION_QUEUE_OWNED' });
}

function invocationRouting(argv, cwd = process.cwd()) {
  argv = [...argv];
  for (let i = 0; i < argv.length; i++) if (['--file', '--config', '--args-file'].includes(argv[i]) && argv[i + 1]) argv[++i] = path.resolve(cwd, argv[i]);
  if (argv.includes('--help') || argv.includes('-h') || argv[0] === 'help') return false;
  if (argv[0] === 'queue') return ['exec', 'submit'].includes(argv[1]);
  if (['keychain', 'image'].includes(argv[0])) return false;
  const { opts, rest } = require('./cli').parseFlags(argv);
  const entry = require('./commands').findCommand(rest);
  if (!entry || ['local', 'help', 'family', 'init'].includes(entry.kind) || (entry.kind === 'run' && (rest.includes('--list') || rest.includes('-l')))) return false;
  if (entry.kind === 'cad') {
    const { catalog } = require('./cad');
    const spec = catalog[entry.target];
    const spelling = [entry.key, ...(entry.aliases || [])].sort((a,b) => b.length - a.length).find(s => rest.slice(0, s.split(' ').length).join(' ') === s);
    const input = require('./cad-input').parseCadInput(rest.slice(spelling.split(' ').length), spec.inputs, spec);
    if (spec.offline || input.preview || ['batch.validate', 'batch.preview'].includes(entry.target) ||
      require('./data-import').isOffline(entry.target, input.data) ||
      entry.target === 'references.refresh' && input.data.phase === 'inspect' ||
      entry.target === 'definition.instantiate' && input.data.mode && input.data.mode !== 'run') return false;
  }
  return require('./config').loadConfig(opts).cfg.routing === 'queue';
}

module.exports = { QueueClient, runQueued, sequenceOptions, inputFiles, pinCommand, verifyInputBytes, assertDirectAccess, credentials, final, invocationRouting };
