const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');
const readline = require('node:readline/promises');
const { commandTimeout, commandLifecycle, monotonicMs } = require('./keychain-timeout');
const { createProgress, progressMode } = require('./keychain-progress');
const { redactDiagnostic } = require('./diagnostics');
const { randomUUID } = require('node:crypto');

const prepareFields = ['input', 'out', 'name', 'project', 'projectMode', 'projectId', 'documentFileId', 'colors', 'thicknessMm', 'imageSide',
  'widthMm', 'frontMm', 'trials', 'seed', 'palette', 'outlineColor', 'search', 'regions', 'backing', 'debug'];
const approvalFields = ['candidate', 'approve', 'svg'];
const backendFlags = ['backend', 'config', 'transport', 'url', 'curl-path'];
const numericFields = ['colors', 'thicknessMm', 'widthMm', 'frontMm', 'trials', 'seed'];
const fields = {
  prepare: prepareFields, status: ['run'], approve: ['run', 'debug', ...approvalFields],
  build: ['run', 'debug', ...approvalFields],
  verify: ['directory', 'colors', 'widthMm', 'thicknessMm', 'frontMm', 'imageSide'],
};
const sharedHelp = `All options require values except --json and help. --file PATH supplies a JSON object;
--progress auto|bar|plain|off (auto): single-line bar only when stderr.isTTY is true and TERM is not dumb.
Explicit bar also falls back to plain in captured/non-TTY output (including OpenCode Bash).
Plain prints stage/status/count changes and a heartbeat after 10 seconds without a new state; no cursor controls.
Unknown work uses a spinner only on a terminal, never invented percentages. Progress uses stderr;
--json retains machine-readable stdout. off suppresses progress, including the final progress line.
Without --json, print concise results. Detailed diagnostics are saved only on failure, as *-error.log.
status and verify are always read-only: diagnostics use stderr only, including failure and cancellation.
flags may supplement it, but duplicate fields/options and unknown fields are errors.
Python precedence: --python EXE > FMCAD_PYTHON > existing repo .venv-keychain/bin/python3
(Windows: .venv-keychain/Scripts/python.exe) > python3. Selection is CLI-only.
The generic repository environment is not shipped in npm; installation is never implicit.
One-time setup with assets/keychain_requirements.txt is documented in docs/KEYCHAIN.md.
--timeout positive-ms bounds the whole command, including prompts, startup, offline work and backend requests.
Cancellation allows up to 5 additional seconds for local cleanup, reported separately on stderr.
Omitted: no keychain execution timeout, regardless of old timeout environment defaults.
--offline-timeout is a compatibility alias; do not combine it with --timeout. POSIX/WSL required.
prepare/approve/build accept --debug true to retain generated helpers/logs and checkpoint history (default false for new runs).
prepare retains candidate approval inputs; consumed heavy intermediates are pruned by default.
After verified success, the entire run workspace is deleted; the empty .fmcad-keychain parent is removed too.
Original inputs and public F3D/STL/ZIP remain. Failed/unfinished or debug runs keep recovery state.
Use --debug true if you need later status/replay by --run; a purged run is no longer addressable.
No public verification report or instructions file is generated. cleanupBytesFreed is stdout JSON only.
Cleanup uses an owned-file allowlist, never sources, symlinks, unknown files or unrelated old runs.
Timeout terminates and checks owned offline groups before cleanup; unconfirmed workers retain files.
Unknown Fusion operations retain safety context and live inputs; no automatic retry or Fusion reset.
Timeout stops waiting, not the Fusion engine; uncertain outcomes require inspection, never automatic retry.
--json suppresses TTY questions.
Paths (including paths in --file) resolve against invocation cwd, not the JSON file directory.
No host path conversion. Worker JSON {success, operation:"keychain.<op>", result} passes through
unchanged; diagnostics and English prompts use stderr. No automatic selection, reset or retry.
Owned messages are English; raw SDK diagnostics and user names retain their original language.
Generated project prefix "Brelok " and fallback slug "brelok" remain stable identifiers for compatibility;
this language policy does not rename existing projects.
prepare/status include candidate metadata; approve/build return candidates:[] with candidateCount.
Use actual IDs from the first prepare response, never an assumed best. status retrieves candidates again.
Relay warnings and approval/signature errors; status is inspection, not fresh geometry approval.
See docs/KEYCHAIN.md and docs/ASSISTANT_KEYCHAIN_WORKFLOW.md.`;
const descriptors = {
  verify: {
    usage: 'keychain verify --directory PRINT --colors N --width-mm W --thickness-mm T --front-mm F --image-side bottom|top [--json] [--timeout MS] [--progress plain]',
    desc: 'LOCAL read-only final F3D/STL/ZIP file checks. No run, config or Fusion.',
    example: 'fmcad keychain verify --directory print --colors 3 --width-mm 50 --thickness-mm 3 --front-mm 0.8 --image-side bottom --json',
    extra: `All six inputs are required. Coordinates use the explicit keychain-mm convention; STL units are not inferred.
Colors must be an integer [1,16]; dimensions must be finite and positive, with front < thickness.
Checks exact layout, archive CRC/ZIP member bytes, STL topology, union X width and Z thickness (0.01 mm tolerance).
One backing-color STL spans Z=0..thickness; others span bottom 0..front or top thickness-front..thickness.
JSON includes fileChecksPassed, nativeComparison:notEvaluated and physicalValidation:notEvaluated.
F3D integrity does not prove native geometry. No manufacturing approval, repairs or generated reports/logs.
${sharedHelp}`,
  },
  prepare: {
    usage: 'keychain prepare --input PATH [--colors N] [--thickness-mm N] [options] [--json]',
    desc: 'LOCAL image preparation, no config or Fusion. Stops for explicit manual candidate selection.',
    example: 'fmcad keychain prepare --input image.png --colors 3 --thickness-mm 3 --json',
    extra: `Minimal TTY: fmcad keychain prepare --input photo.png
--out PATH defaults to cwd; --name TEXT; --project TEXT; --palette PATH; --outline-color #RRGGBB.
--project-mode new|existing defaults to new: name/project are prefixes with run ID suffixes.
existing requires exactly one of --project exact-name or --project-id exact-ID (preferred).
The existing project root is verified at build; no project is created. New documents get a run ID suffix.
--document-file-id exact-cloud-ID requires existing project mode and freezes a reusable target for build.
Build requires exactly one open target, complete, writable, unmodified and empty by document.clear dryRun audit.
Its current display name must also be unique among open documents: core CAD resolves names before ID guards.
Duplicate names fail during discovery; resolve the name conflict before building. No automatic rename or close.
It discovers the current name by ID, never clears automatically, and saves one next version of the same file.
Omitting this option preserves new-document/saveAs behavior. Build cannot override the prepared target.
--colors integer [1,16] and --thickness-mm positive number are required, never guessed.
TTY asks only missing values (two English questions at most, repeated for invalid answers).
TTY thickness accepts a decimal dot or comma; blank answers are never guessed.
Non-TTY or --json returns worker needs_input with NO side effects when either is missing.
--image-side bottom|top (bottom); --width-mm positive number (50); --front-mm positive number
(worker default min(0.8,thickness/2)); --trials integer [2,128] (24); --seed integer (17).
--backing silhouette|convex-hull (silhouette). Convex-hull explicitly adds outline-color material
to support disconnected artwork; review the amber dashed backing boundary. Never selected automatically.
--search JSON object; --regions JSON array. Input must be an existing local file before prompting.
--palette uses colors[].color as fixed RGB swatches with weighted Lab assignment, NOT image.trace
threshold/range rules. Exactly N distinct foreground swatches are required; no automatic reduction.
ImageOps normalizes EXIF orientation on frame 0; original source bytes remain frozen.
Canvas/display PNG helpers are created only when format, EXIF or animation requires conversion;
ordinary unrotated, nonanimated PNG/JPEG bytes are embedded unchanged.
Hidden work: .fmcad-keychain/<runId>; public <name>-<shortId>/overlays contains SVG overlays only.
Windows hiding sets and reads back H (WSL attrib); hiddenWorkspace records evidence, not global config.
Review up to 3 eligible suggestions and available overlays from 24 default trials; rankings are not approval.
Eligible overlays show canonical planned geometry over the original image, with a fixed-reference
semantic feature audit. Weighted CIELAB [0.35,1,1] palette and perimeter RGB adaptation are heuristics,
not original-photo fidelity guarantees. No eligible candidate is possible; never bypass gates.
Inspect geometryPlanReady, semanticAuditPassed, overlayOrigin, failures and warnings.
Prepared canonical candidates store planSignature and overlaySha256 in hidden state/report.
${sharedHelp}`,
  },
  status: {
    usage: 'keychain status --run PATH [--python EXE] [--json]',
    desc: 'LOCAL read-only run status. No config, model access or state mutation.',
    example: 'fmcad keychain status --run .fmcad-keychain/RUN_ID --json',
    extra: sharedHelp,
  },
  approve: {
    usage: 'keychain approve --run PATH --candidate ID --approve true [--svg PATH] [--json]',
    desc: 'LOCAL record of explicit user selection, optionally using a manually corrected SVG. No Fusion or config.',
    example: 'fmcad keychain approve --run .fmcad-keychain/RUN_ID --candidate candidate_007 --approve true',
    extra: `--approve accepts literal true only. Candidate must be the exact user-chosen ID, never an automatic best.
Corrected --svg is frozen and locally preplanned; its public canonical overlay preserves original RGB input.
Normal canonical approval verifies cached planSignature and overlaySha256; corrected SVG approval
stores a fresh planSignature after local planning. Editing a preview SVG is not geometry approval.
Same-ID/same-SVG approval is idempotent, not permission to accept changed planner output.
Exact palette colors and geometry gates still apply. Approval is not native CAD validation.
${sharedHelp}`,
  },
  build: {
    usage: 'keychain build --run PATH [--candidate ID --approve true] [--svg PATH] [--backend mcp|addin] [--json]',
    desc: 'Build an approved run in Fusion using the frozen project and optional reusable file, save and export verified print artifacts.',
    example: 'fmcad keychain build --run .fmcad-keychain/RUN_ID --candidate candidate_007 --approve true --backend addin',
    extra: `Without selection flags the worker requires existing approved state. Selection flags require BOTH
--candidate ID and --approve true; --svg is only valid with that explicit selection.
Build-only backend options: --backend mcp|addin, --config PATH,
--transport node|windows-curl, --url URL, --curl-path EXE. Forwarded as backendOptions;
config path remains encoded as supplied for existing backend commands. No global config changes.
--header and credential-bearing URLs are rejected; use existing backend configuration for credentials.
Retained completed debug/legacy builds recheck approved SVG and artifact hashes without rebuilding.
Successful non-debug runs are purged after final artifact hash and cloud-save checks.
For signed approvals, build regenerates and verifies planSignature BEFORE CAD; raw SVG equality alone
does not authorize geometry changed by software. Review/reapprove a fresh preview where allowed,
or prepare a new run; do not edit stored signatures. Legacy completed runs remain replay-compatible.
Frozen canvasPath/canvasSha256 are checked before new build/resume alongside original source bytes.
Explicit subsequent build may resume only guarded save/export phases: frozen hashes, native fingerprint,
persisted run marker and verified project/file identity are checked. Unknown geometry remains blocked.
Partition prisms use public no-input Command transactions: start once, then finalize observes completion
and deletes the owned definition only after destroy. Finalize is mutating-capable, never marked readonly;
pending calls do not create geometry or clean definitions. Separate readonly status remains available.
Accepted launch is not completion; saves/exports wait for successful destruction and confirmed cleanup.
Both backends require a compatible idle/non-command script host. Known nested host commands are rejected,
without fallback. On timeout, inspect build.prismOperation and retained journals/model; never replay.
creationId may change on first save; it is NOT the stable run identity. No duplicate geometry or saveAs.
Bottom color layer Z=0..frontMm; top Z=thickness-frontMm..thickness. Camera faces the colored side.
The original source canvas is calibrated and hidden; the top source construction plane is hidden.
F3D ZIP method 93 (Zstandard) uses bounded decompression and CRC checks, not a reimport test.
Only verified STLs, F3D and ZIP enter public print/. No physical print certification.
${sharedHelp}`,
  },
};
const manuals = Object.fromEntries(Object.entries(descriptors).map(([operation, descriptor]) => [
  `keychain ${operation}`, {
    sections: [{ title: 'Local Return Contract', text: descriptor.desc }],
    examples: [{ label: `Keychain ${operation}`, requires: operation === 'verify' ? 'Existing final print directory and explicit dimensions, color count and image side; no run or Fusion.' : 'Existing local image/run and explicit user selection before approval/build; see docs/KEYCHAIN.md.',
      argv: descriptor.example.slice('fmcad '.length).split(' '), output: 'Unchanged worker envelope; inspect result status. No automatic approval.' }],
    audit: {
      sources: operation === 'verify' ? ['src/keychain.js', 'src/cli.js', 'assets/keychain.py', 'assets/keychain_verify.py', 'assets/keychain_build.py:inspect_stl,mesh_report,verify_f3d_archive', 'docs/KEYCHAIN.md'] : ['src/keychain.js', 'src/cli.js', 'assets/keychain.py', 'assets/keychain_state.py', 'assets/keychain_prepare.py', 'assets/keychain_partition.py', 'assets/keychain_preview.py', 'assets/keychain_signature.py', 'assets/keychain_build.py', 'assets/keychain_fusion.py', 'docs/KEYCHAIN.md', 'docs/KEYCHAIN_PARTITION_CONTRACT.md'],
      verified: operation === 'verify' ? ['local read-only dispatch and error policy', 'explicit dimensions and layer convention', 'archive CRC and exact ZIP member bytes', 'shared STL topology checks without fictitious native comparison'] : ['local routing and JSON stdin', 'strict flags and explicit approval syntax', 'TTY missing-only prompts and numeric ranges', 'portable interpreter precedence and dependency guidance', 'stdout passthrough and backend forwarding', 'real dispatcher needs_input without site packages or output directories', 'pure worker compact candidate summaries', 'current worker workflow documentation'],
      tests: [], testRetirement: 'removed-by-user-2026-10-17',
      testRetirementReason: 'Keychain-specific automated tests were removed by explicit user request on 2026-10-17; source-audit notes do not claim remaining automated coverage.',
      gaps: [],
      bugs: ['Keychain-specific automated tests were removed by explicit user request on 2026-10-17; no current automated keychain coverage.', ...(operation === 'verify' ? ['File checks are not native, visual or physical acceptance; raw STL units rely on explicit caller convention. Concurrent external edits are not a transactionally locked snapshot.'] : ['Canonical plan and semantic gates are not photo-fidelity or physical-manufacturability proof. Save/export recovery requires verified evidence; unknown geometry blocks.'])],
    },
  },
]));

async function keychain(operation, args, deps) {
  const started = monotonicMs();
  const allowed = fields[operation];
  if (!allowed) throw new Error(`Unknown keychain operation: ${operation}`);
  const allowedFlags = [...allowed.map(key => key.replace(/[A-Z]/g, c => '-' + c.toLowerCase())), 'file', 'python', 'json', 'timeout', 'offline-timeout', 'progress'];
  const flags = {};
  for (let i = 0; i < args.length; i++) {
    const flag = args[i];
    const key = flag.slice(2);
    if (!flag.startsWith('--') || !allowedFlags.includes(key) &&
        !(operation === 'build' && backendFlags.includes(key))) throw new Error(`Unknown keychain ${operation} option: ${flag}`);
    if (Object.hasOwn(flags, key)) throw new Error(`Duplicate keychain option: ${flag}`);
    if (key === 'json') flags[key] = true;
    else {
      const value = args[++i];
      if (!value || /^--|^-[A-Za-z]/.test(value)) throw new Error(`${flag} requires a value`);
      flags[key] = value;
    }
  }
  const timeout = commandTimeout(flags);
  const lifecycle = commandLifecycle(timeout, started);
  let cancellationReported = false;
  let cancellationLog = () => {};
  function reportCancellation(report) {
    if (cancellationReported) return;
    cancellationReported = true;
    const record = { stage: 'keychain.lifecycle',
      status: report.reason === 'timeout' ? 'timed_out' : report.reason.startsWith('SIG') ? 'interrupted' : 'failed',
      signal: report.reason.startsWith('SIG') ? report.reason : null, cleanup: report.cleanup,
      cleanupError: report.cleanupError || null, cleanupBudgetMs: 5000, cleanupMs: report.cleanupMs,
      remoteMutation: operation === 'build' ? 'unknown; inspect journal and Fusion before retry' : 'not_applicable' };
    deps.stderr.write(redactDiagnostic(JSON.stringify(record)) + '\n');
    cancellationLog(record);
  }
  try {
  const request = flags.file ? JSON.parse(fs.readFileSync(path.resolve(flags.file), 'utf8')) : {};
  if (!request || typeof request !== 'object' || Array.isArray(request)) throw new Error('Keychain request must be a JSON object');
  for (const key of Object.keys(request)) if (!allowed.includes(key)) throw new Error(`Unknown keychain request field: ${key}`);
  const backendOptions = [];
  for (const [key, value] of Object.entries(flags)) {
    if (['file', 'python', 'json', 'timeout', 'offline-timeout', 'progress'].includes(key)) continue;
    if (operation === 'build' && backendFlags.includes(key)) {
      if (key === 'backend' && !['mcp', 'addin'].includes(value)) throw new Error('--backend requires mcp or addin');
      if (key === 'transport' && !['node', 'windows-curl'].includes(value)) throw new Error('--transport requires node or windows-curl');
      if (key === 'url') {
        const url = new URL(value);
        if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) throw new Error('--url must be HTTP(S) without credentials, query or fragment');
      }
      backendOptions.push('--' + key, value);
      continue;
    }
    const field = key.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
    if (Object.hasOwn(request, field)) throw new Error(`Duplicate keychain input: ${field}`);
    request[field] = [...numericFields, 'search', 'regions', 'approve', 'debug'].includes(field) ? JSON.parse(value) : value;
  }
  for (const key of numericFields) {
    if (!Object.hasOwn(request, key)) continue;
    const value = request[key];
    if (typeof value !== 'number' || !Number.isFinite(value) || (key !== 'seed' && value <= 0) ||
        (['colors', 'trials', 'seed'].includes(key) && !Number.isSafeInteger(value))) throw new Error(`${key} requires a ${['colors', 'trials', 'seed'].includes(key) ? 'safe integer' : 'finite number'}${key === 'seed' ? '' : ' greater than zero'}`);
  }
  if (request.colors > 16) throw new Error('colors must be an integer in [1,16]');
  if (Object.hasOwn(request, 'trials') && (request.trials < 2 || request.trials > 128)) throw new Error('trials must be an integer in [2,128]');
  for (const key of ['name', 'project', 'projectId', 'documentFileId', 'candidate']) {
    if (Object.hasOwn(request, key) && (typeof request[key] !== 'string' || !request[key].trim())) throw new Error(`${key} must be nonempty text`);
  }
  if (Object.hasOwn(request, 'approve') && request.approve !== true) throw new Error('--approve requires literal true');
  if (Object.hasOwn(request, 'debug') && typeof request.debug !== 'boolean') throw new Error('--debug requires true or false');
  if (operation === 'approve' || operation === 'build' && approvalFields.some(key => Object.hasOwn(request, key))) {
    if (!request.candidate || request.approve !== true) throw new Error('Explicit selection requires --candidate ID and --approve true');
  }
  if (operation === 'prepare') {
    const mode = request.projectMode ?? 'new';
    if (!['new', 'existing'].includes(mode)) throw new Error('--project-mode requires new or existing');
    if (mode === 'existing' && Number(Object.hasOwn(request, 'project')) + Number(Object.hasOwn(request, 'projectId')) !== 1) throw new Error('existing requires exactly one of --project or --project-id');
    if (mode === 'new' && Object.hasOwn(request, 'projectId')) throw new Error('--project-id requires --project-mode existing');
    if (Object.hasOwn(request, 'documentFileId')) {
      if (mode !== 'existing') throw new Error('--document-file-id requires --project-mode existing');
      if (/\s/.test(request.documentFileId) || request.documentFileId.startsWith('-')) throw new Error('documentFileId must be an exact cloud ID without whitespace');
    }
    for (const [key, value] of Object.entries({ out: process.cwd(), imageSide: 'bottom', widthMm: 50, trials: 24, seed: 17, backing: 'silhouette' })) {
      if (!Object.hasOwn(request, key)) request[key] = value;
    }
    if (!['bottom', 'top'].includes(request.imageSide)) throw new Error('--image-side requires bottom or top');
    if (!['silhouette', 'convex-hull'].includes(request.backing)) throw new Error('--backing requires silhouette or convex-hull');
    if (Object.hasOwn(request, 'outlineColor') && (typeof request.outlineColor !== 'string' || !/^#[\da-f]{6}$/i.test(request.outlineColor))) throw new Error('--outline-color requires #RRGGBB');
    if (Object.hasOwn(request, 'search') && (!request.search || typeof request.search !== 'object' || Array.isArray(request.search))) throw new Error('--search requires a JSON object');
    if (Object.hasOwn(request, 'regions') && !Array.isArray(request.regions)) throw new Error('--regions requires a JSON array');
  }
  if (operation === 'verify') {
    for (const key of fields.verify) if (!Object.hasOwn(request, key)) throw new Error(`keychain verify requires ${key}`);
    if (!['bottom', 'top'].includes(request.imageSide)) throw new Error('--image-side requires bottom or top');
    if (request.frontMm >= request.thicknessMm) throw new Error('frontMm must be less than thicknessMm');
  }
  for (const key of operation === 'prepare' ? ['input', 'out', 'palette'] : operation === 'verify' ? ['directory'] : ['run', 'svg']) {
    if (['palette', 'svg'].includes(key) && !Object.hasOwn(request, key)) continue;
    if (typeof request[key] !== 'string' || !request[key].trim()) throw new Error(`keychain ${operation} requires ${key} as a nonempty path`);
    request[key] = path.resolve(request[key]);
  }
  if (operation === 'prepare') {
    if (!fs.statSync(request.input).isFile()) throw new Error('keychain prepare input must be a file');
    const input = deps.stdin || process.stdin;
    const tty = deps.isTTY ?? Boolean(input.isTTY && deps.stdout.isTTY);
    const missing = ['colors', 'thicknessMm'].filter(key => !Object.hasOwn(request, key));
    if (tty && !flags.json && missing.length) {
      const rl = deps.ask ? null : readline.createInterface({ input, output: deps.stderr });
      const ask = deps.ask || (async question => {
        if (rl.closed) throw new Error('Input cancelled');
        let onClose;
        try {
          return await new Promise((resolve, reject) => {
            onClose = () => reject(new Error('Input cancelled'));
            rl.once('close', onClose);
            rl.question(question, { signal: lifecycle.signal }).then(resolve, reject);
          });
        } finally {
          rl.removeListener('close', onClose);
        }
      });
      try {
        for (const key of missing) {
          const question = key === 'colors' ? 'How many colors should the keychain have (1-16)? ' : 'How thick should the keychain be (mm, decimal dot or comma)? ';
          while (true) {
            lifecycle.check();
            const answer = await Promise.race([ask(question), lifecycle.cancelled.then(() => { lifecycle.check(); })]);
            if (answer === undefined || answer === null) throw new Error('Input cancelled');
            const text = key === 'thicknessMm' ? String(answer).trim().replace(',', '.') : String(answer).trim();
            const value = Number(text);
            if (/^(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(text) && Number.isFinite(value) && value > 0 &&
                (key !== 'colors' || Number.isSafeInteger(value) && value <= 16)) {
              request[key] = value;
              break;
            }
            deps.stderr.write(key === 'colors' ? 'Enter an integer from 1 to 16.\n' : 'Enter a positive number (mm, decimal dot or comma).\n');
          }
        }
      } finally {
        rl?.close();
      }
    }
  }
  request.operation = operation;
  lifecycle.check();
  const progressEnv = { ...process.env, ...(deps.env || {}) };
  const mode = progressMode(flags.progress ?? 'auto', deps.stderr, progressEnv);
  if (operation === 'build') request.backendOptions = backendOptions;
  const repoPython = path.resolve(__dirname, '../.venv-keychain',
    (deps.platform || process.platform) === 'win32' ? 'Scripts/python.exe' : 'bin/python3');
  const python = flags.python || (deps.env || process.env).FMCAD_PYTHON ||
    ((deps.existsSync || fs.existsSync)(repoPython) ? repoPython : 'python3');
  const setup = `If Python dependencies are missing, run ${JSON.stringify(python)} -m pip install -r ${JSON.stringify(path.resolve(__dirname, '../assets/keychain_requirements.txt'))} in your user-owned environment. See docs/KEYCHAIN.md for one-time setup. Nothing was installed automatically.\n`;
  return await new Promise((resolve, reject) => {
    const progress = createProgress(deps.stderr, { mode, operation: `keychain ${operation}`, timeout, env: progressEnv });
    let output = '', diagnostic = '', pending = '';
    function writeFailure(record, result) {
      if (operation === 'status' || operation === 'verify') return;
      try {
        const folder = result?.run || request.run || request.out;
        if (!folder || !fs.existsSync(folder)) return;
        const log = path.join(folder, `${operation}-${randomUUID()}-error.log`);
        fs.writeFileSync(log, redactDiagnostic(JSON.stringify(record) + '\n' + diagnostic + '\n' + output), { flag: 'wx', mode: 0o600 });
        deps.stderr.write(`Diagnostics: ${log}\n`);
      } catch (error) { deps.stderr.write(redactDiagnostic(`Diagnostic log write failed: ${error.message}\n`)); }
    }
    cancellationLog = record => {
      let result;
      try { result = JSON.parse(output).result; } catch { /* Retain partial output with diagnostic redaction. */ }
      writeFailure(record, result);
    };
    const env = { ...process.env, ...(deps.env || {}), FMCAD_OFFLINE_TIMEOUT_MS: '0',
      FMCAD_KEYCHAIN_DEADLINE_MS: timeout ? String(Date.now() + Math.max(0, lifecycle.deadline - monotonicMs())) : '0',
      FMCAD_PROGRESS_EVENTS: '1', PYTHONUNBUFFERED: '1' };
    if (operation === 'verify') env.PYTHONDONTWRITEBYTECODE = '1';
    // Only Linux/WSL has the verified shared CLOCK_MONOTONIC epoch.
    delete env.FMCAD_KEYCHAIN_DEADLINE_MONOTONIC_MS;
    if (process.platform === 'linux') env.FMCAD_KEYCHAIN_DEADLINE_MONOTONIC_MS = String(lifecycle.deadline);
    delete env.FMCAD_OFFLINE_DEADLINE_MONOTONIC;
    const child = (deps.spawnKeychain || spawn)(python, [path.resolve(__dirname, '../assets/keychain.py')],
      { shell: false, stdio: ['pipe', 'pipe', 'pipe'],
        env });
    lifecycle.attach(child);
    lifecycle.cancelled.then(report => {
      progress.finish(report.reason === 'timeout' ? 'TIMEOUT' : report.reason.startsWith('SIG') ? 'INTERRUPTED' : 'FAILED');
      reportCancellation(report);
      // A descendant may hold inherited pipes after its leader exits. Never wait
      // for EOF beyond the cleanup bound; retained worker checkpoints are untouched.
      child.stdin.destroy?.(); child.stdout.destroy?.(); child.stderr.destroy?.();
      child.unref?.();
      resolve(1);
    });
    child.stdout.on('data', chunk => { output += chunk; if (flags.json) deps.stdout.write(chunk); });
    child.stderr.on('data', chunk => {
      diagnostic += chunk;
      pending += chunk;
      const lines = pending.split('\n');
      pending = lines.pop().slice(-65536);
      for (const line of lines) progress.update(redactDiagnostic(line));
    });
    child.on('error', error => {
      progress.finish('STARTUP ERROR');
      reject(new Error(`Cannot start local Python ${JSON.stringify(python)}: ${error.message}. Select an installed interpreter with --python EXE or FMCAD_PYTHON.\n${setup}`));
    });
    child.stdin.on('error', error => {
      if (error.code !== 'EPIPE') {
        deps.stderr.write(redactDiagnostic(`Keychain input transport failed: ${error.message}\n`));
        lifecycle.cancel('execution_failure');
      }
    });
    child.on('close', (code, signal) => {
      if (lifecycle.deadline && monotonicMs() >= lifecycle.deadline) lifecycle.cancel('timeout');
      if (lifecycle.reason) return;
      let result;
      try { result = JSON.parse(output).result; } catch { /* Failure text remains available for diagnostics. */ }
      const storedStatus = operation === 'status' && result?.status;
      progress.finish(redactDiagnostic(storedStatus ? `Stored status: ${storedStatus}` : code === 0 ? (result?.status || 'OK') : `ERROR (${signal || code})`));
      if (code !== 0) {
        writeFailure({ stage: 'keychain.lifecycle', status: 'failed', code, signal,
          cleanup: 'unknown', remoteMutation: operation === 'build' ? 'unknown; inspect journal and Fusion before retry' : 'not_applicable' }, result);
        deps.stderr.write(redactDiagnostic(`${result?.error?.message || diagnostic.trim().split('\n').at(-1) || (storedStatus ? `Stored run status: ${storedStatus}.` : 'The command did not complete successfully.')}\n`));
      }
      if (!flags.json && result) {
        if (operation === 'verify') deps.stdout.write(`File checks: ${result.fileChecksPassed ? 'PASS' : 'FAIL'}. Native comparison: not evaluated. Physical validation: not evaluated.\n`);
        if (result.workspaceRemoved) deps.stdout.write('Removed the entire run workspace.\n');
        else if (result.run) deps.stdout.write(`Run: ${result.run}\n`);
        if (result.status === 'needs_input') deps.stdout.write(`Required input: ${JSON.stringify(result.missing || result)}\n`);
        if (result.candidates?.length) deps.stdout.write(`Candidates: ${result.candidates.map(c => `${c.id} (${c.eligible ? 'OK' : 'rejected'})`).join(', ')}\n`);
        for (const warning of result.warnings || []) deps.stderr.write(redactDiagnostic(`Warning: ${typeof warning === 'string' ? warning : JSON.stringify(warning)}\n`));
        for (const candidate of result.candidates || []) {
          for (const key of ['failures', 'planningFailure', 'semanticFailure', 'warnings']) {
            if (candidate[key] && (!Array.isArray(candidate[key]) || candidate[key].length)) {
              deps.stderr.write(redactDiagnostic(`${candidate.id} ${key}: ${JSON.stringify(candidate[key])}\n`));
            }
          }
        }
        if (result.recommendations?.length) deps.stdout.write(`Recommended: ${result.recommendations.join(', ')}\n`);
        if (result.artifacts?.length) deps.stdout.write(`Files: ${result.artifacts.length}, directory: ${path.dirname(result.artifacts[0].path)}\n`);
        if (result.cleanupBytesFreed) deps.stdout.write(`Removed helper data: ${(result.cleanupBytesFreed / 1000000).toFixed(2)} MB\n`);
      }
      resolve(code === 0 ? 0 : 1);
    });
    child.stdin.end(JSON.stringify(request));
  });
  } catch (error) {
    if (!lifecycle.reason) throw error;
    reportCancellation(await lifecycle.cancelled);
    return 1;
  } finally {
    lifecycle.dispose();
  }
}

module.exports = { keychain, descriptors, manuals };
