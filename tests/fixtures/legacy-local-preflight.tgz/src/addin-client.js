const { McpClient } = require('./client');
const { buildBridgeScript } = require('./addin-bridge');
const { randomUUID } = require('node:crypto');

const ADDIN_CAPABILITIES = {
  backend: 'addin', implementation: 'frankhommers/autodesk-fusion-mcp',
  readOnlyEnforced: false, automaticFallback: false, automaticMutationRetry: false,
  atomicBatch: true,
  unsupported: ['licensing', 'document recent', 'undo', 'redo', 'electronics'],
};

function parsed(text) {
  try { return JSON.parse(text); } catch (_) { return null; }
}

class AddinClient extends McpClient {
  constructor(server) {
    super({ ...server, protocolVersion: server.protocolVersion || '2025-06-18' });
    this.capabilities = ADDIN_CAPABILITIES;
    this.session = null;
  }

  _openSession() {
    // Reuse within a CLI/batch invocation. A failed mutation is never retried.
    if (!this.session) this.session = super._openSession();
    return this.session;
  }

  async _script(script, readOnly = false, bridge = false, guardedUiRoute = false) {
    if (typeof script !== 'string' || !script.trim()) throw new Error('A nonempty Python script is required');
    const guardToken = guardedUiRoute ? null : randomUUID();
    const guard = readOnly || guardedUiRoute ? '' : `import adsk.core as _fmcad_guard_core
import json as _fmcad_guard_json
_fmcad_guard_token = ${JSON.stringify(guardToken)}
_fmcad_guard_ui = _fmcad_guard_core.Application.get().userInterface
try:
    _fmcad_guard_command = _fmcad_guard_ui.activeCommand
except Exception as _fmcad_guard_error:
    print('FMCAD_UI_GUARD ' + _fmcad_guard_token + ' ' + _fmcad_guard_json.dumps({'status':'rejected-before-mutation','notStarted':True,'activeCommand':None,'identityAvailable':False,'error':type(_fmcad_guard_error).__name__}))
    raise RuntimeError('Interactive-command identity unavailable; user script not started. Inspect UI state; no retry is automatic.')
if _fmcad_guard_command not in ('', 'SelectCommand'):
    print('FMCAD_UI_GUARD ' + _fmcad_guard_token + ' ' + _fmcad_guard_json.dumps({'status':'rejected-before-mutation','notStarted':True,'activeCommand':_fmcad_guard_command,'identityAvailable':True}))
    raise RuntimeError('An interactive Fusion command is open (' + _fmcad_guard_command + '); user script not started. Use ui.inspect then authorized ui.resolve; no retry is automatic.')
`;
    const output = await super.callTool({ code: guard + script + '\n\nrun("")\n', persistent: false }, 'execute_python');
    const payload = output.data || parsed(output.text);
    if (!payload || typeof payload.success !== 'boolean' || typeof payload.stdout !== 'string') {
      throw new Error('Malformed add-in execution response; operation may have run. Inspect before retrying.');
    }
    const failed = output.failed || !payload.success || /^ERROR /m.test(payload.stdout);
    const text = failed
      ? [payload.stdout, payload.error, payload.traceback, payload.stderr].filter(Boolean).join('\n')
      : payload.stdout;
    let uiGuard = null;
    if (guardToken) {
      const guardLine = String(payload.stdout || '').split(/\r?\n/).find(value => value.startsWith('FMCAD_UI_GUARD ' + guardToken + ' '));
      if (guardLine) {
        try { uiGuard = JSON.parse(guardLine.slice(('FMCAD_UI_GUARD ' + guardToken + ' ').length)); }
        catch (_) { uiGuard = { status: 'unknown', notStarted: false, identityAvailable: false }; }
      }
    }
    const line = bridge && text.split(/\r?\n/).find(value => value.startsWith('FMCAD_BRIDGE_RESULT '));
    if (bridge && !failed && !line) throw new Error('Missing add-in bridge result; inspect before retrying.');
    const data = line ? JSON.parse(line.slice('FMCAD_BRIDGE_RESULT '.length)) : null;
    return { text: data ? JSON.stringify(data) : text, data, failed: failed || data?.success === false,
      ...(uiGuard ? { uiGuard } : {}),
      stderr: payload.stderr, backend: 'addin', readOnlyRequested: readOnly, readOnlyEnforced: false };
  }

  // Dedicated UI route: exact identity/profile/lease guards are owned by ui.js.
  async executeUiGuardedScript(script) {
    return this._script(script, false, false, true);
  }

  async callTool(request, toolName = 'fusion_mcp_execute') {
    if (!request || typeof request !== 'object' || Array.isArray(request)) {
      throw new TypeError('Tool request must be a non-null object');
    }
    if (toolName === 'fusion_mcp_execute' && request.featureType === 'script') {
      if (!request.object || typeof request.object !== 'object' || Array.isArray(request.object)) {
        throw new TypeError('Script object must be a non-null object');
      }
      if (Object.hasOwn(request.object, 'readOnly') && typeof request.object.readOnly !== 'boolean') {
        throw new TypeError('readOnly must be boolean');
      }
      return this._script(request.object?.script, request.object?.readOnly === true);
    }
    if (toolName === 'fusion_mcp_read' && request.queryType === 'screenshot') {
      const args = {};
      if (request.width !== undefined) args.width = request.width;
      if (request.height !== undefined) args.height = request.height;
      if (request.direction && request.direction !== 'current') {
        const views = ['front', 'back', 'top', 'bottom', 'left', 'right',
          'iso-top-left', 'iso-top-right', 'iso-bottom-left', 'iso-bottom-right'];
        if (!views.includes(request.direction)) throw new Error('Unknown screenshot direction: ' + request.direction);
        args.view = request.direction.replaceAll('-', '_');
      }
      if (request.antiAliasing !== undefined) args.anti_aliasing = request.antiAliasing;
      if (request.transparentBackground !== undefined) args.background = request.transparentBackground ? 'transparent' : 'viewport';
      return super.callTool(args, 'capture_viewport');
    }
    if (toolName === 'fusion_mcp_read' && request.queryType === 'apiDocumentation') {
      if (request.filter) throw new Error('Add-in API documentation does not support the native filter; use fetch_api_documentation or --backend mcp explicitly.');
      const category = { class: 'class_name', member: 'member_name', description: 'description', all: 'all' };
      if (request.apiCategory && !category[request.apiCategory]) throw new Error('Unknown API documentation category');
      return super.callTool({ search_term: request.searchPattern || '', category: category[request.apiCategory] || 'all' }, 'fetch_api_documentation');
    }
    if (toolName === 'fusion_mcp_execute' || toolName === 'fusion_mcp_read') {
      return this._script(buildBridgeScript(toolName, request), toolName === 'fusion_mcp_read', true);
    }
    if (toolName === 'fusion_mcp_update' || toolName === 'fusion_mcp_electronics_read') {
      throw new Error(`${toolName} is unavailable on the addin backend; explicitly select --backend mcp. No fallback was performed.`);
    }
    // Explicit low-level calls can address the selected add-in's own tools.
    return super.callTool(request, toolName);
  }
}

module.exports = { AddinClient, ADDIN_CAPABILITIES };
