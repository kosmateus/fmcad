'use strict';

const net = require('node:net');
const os = require('node:os');
const path = require('node:path');
const { createHash } = require('node:crypto');

const MAX_MESSAGE = 16 * 1024 * 1024;
function queueDirectory() {
  return path.join(process.env.XDG_STATE_HOME || path.join(os.homedir(), '.local', 'state'), 'fmcad', 'queue');
}
function queueSocket(dir = queueDirectory()) {
  if (process.platform === 'win32') return '\\\\.\\pipe\\fmcad-' + createHash('sha256').update(path.resolve(dir)).digest('hex').slice(0, 24);
  const socket = path.join(dir, 'broker.sock');
  if (Buffer.byteLength(socket) > 103) throw new Error('Queue state path is too long for a Unix socket; use a shorter XDG_STATE_HOME');
  return socket;
}
function request(dir, message, { timeoutMs = 30000 } = {}) {
  const payload = Buffer.from(JSON.stringify(message) + '\n');
  if (payload.length > MAX_MESSAGE) return Promise.reject(new Error('Queue request exceeds 16 MiB'));
  return new Promise((resolve, reject) => {
    const socket = net.createConnection(queueSocket(dir));
    let data = Buffer.alloc(0), settled = false;
    const finish = (error, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer); socket.destroy();
      error ? reject(error) : resolve(value);
    };
    const timer = setTimeout(() => finish(Object.assign(new Error('Queue IPC timeout; an accepted job is not cancelled. Inspect its requestId/jobId before resubmitting.'), { code: 'QUEUE_IPC_TIMEOUT' })), timeoutMs);
    socket.once('connect', () => socket.write(payload));
    socket.on('error', error => finish(error));
    socket.on('data', chunk => {
      if (data.length + chunk.length > MAX_MESSAGE) return finish(new Error('Queue response exceeds 16 MiB'));
      data = Buffer.concat([data, chunk]);
      const newline = data.indexOf(10);
      if (newline < 0) return;
      try {
        const response = JSON.parse(data.subarray(0, newline).toString('utf8'));
        if (response.ok !== true) return finish(Object.assign(new Error(response.error?.message || 'Queue request failed'), { code: response.error?.code || 'QUEUE_ERROR' }));
        finish(null, response.result);
      } catch (error) { finish(error); }
    });
    socket.once('end', () => { if (!settled) finish(new Error('Queue response ended without a receipt; inspect the existing job before retry')); });
  });
}

module.exports = { queueDirectory, queueSocket, request };
