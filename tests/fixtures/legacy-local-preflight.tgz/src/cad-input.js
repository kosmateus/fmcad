const fs = require('node:fs');

function parseCadInput(args, inputs = {}, formatting = {}) {
  const options = { doc: null, component: null, projectId: null, json: false, preview: false };
  let payload = null;
  const direct = {};
  const values = { '--doc': 'doc', '--component': 'component', '--project-id': 'projectId',
    '--doc-id': 'docId', '--doc-file-id': 'docFileId' };
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (Object.hasOwn(values, arg)) {
      if (['--doc-id', '--doc-file-id'].includes(arg)) {
        if (Object.hasOwn(options, values[arg])) throw new Error(`Duplicate CAD option: ${arg}`);
        if (typeof args[i + 1] !== 'string' || !args[i + 1] || /\s/.test(args[i + 1]) || args[i + 1].startsWith('-')) {
          throw new Error(`${arg} requires a nonempty identity without whitespace`);
        }
      }
      if (!args[i + 1] || args[i + 1].startsWith('--')) throw new Error(`${arg} requires a value`);
      options[values[arg]] = args[++i];
    } else if (arg === '--json') {
      options.json = true;
    } else if (arg === '--summary' && formatting.summaryFlag) {
      options.summary = true;
    } else if (arg === '--preview') {
      options.preview = true;
    } else if (arg === '--data' || arg === '--file') {
      if (payload !== null) throw new Error('Provide only one of --data or --file');
      if (!args[i + 1] || args[i + 1].startsWith('--')) throw new Error(`${arg} requires a value`);
      const value = args[++i];
      if (arg === '--file') {
        const bytes = fs.readFileSync(value);
        if (process.env.FMCAD_QUEUE_WORKER_JOB) require('./queue-client').verifyInputBytes(value, bytes);
        payload = bytes.toString('utf8');
      } else payload = value;
    } else if (arg.startsWith('--')) {
      const key = (arg === '--input-component' ? 'component' : arg.slice(2)).replace(/-([a-z])/g, (_, c) => c.toUpperCase());
      if (!Object.hasOwn(inputs, key)) throw new Error(`Unknown CAD option: ${arg}`);
      if (args[i + 1] === undefined || args[i + 1].startsWith('--')) throw new Error(`${arg} requires a value`);
      const value = args[++i];
      try { direct[key] = JSON.parse(value); } catch (_) { direct[key] = value; }
    } else {
      throw new Error(`Unknown CAD option: ${arg}`);
    }
  }
  const data = payload === null ? {} : (formatting.observeShortcut && payload.trim() === 'observe'
    ? { operations: [] } : JSON.parse(payload));
  if (data === null || typeof data !== 'object' || Array.isArray(data)) {
    throw new Error('CAD command data must be a JSON object');
  }
  for (const [key, value] of Object.entries(direct)) {
    if (Object.hasOwn(data, key)) throw new Error(`Duplicate CAD input: ${key}`);
    data[key] = value;
  }
  return { ...options, data };
}

module.exports = { parseCadInput };
