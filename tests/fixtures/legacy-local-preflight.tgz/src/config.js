const fs = require('fs');
const os = require('os');
const path = require('path');
const { formatJsonError } = require('./diagnostics');

const DEFAULTS = {
  url: 'http://192.168.1.223:27183/mcp',
  headers: { Host: '127.0.0.1:27182' },
  timeoutMs: 180000,
  tool: 'fusion_mcp_execute',
  transport: 'node',
  protocolVersion: '2024-11-05',
};

function backendDefaults(backend) {
  if (!['mcp', 'addin'].includes(backend)) {
    throw new Error(`Invalid backend: ${backend} (expected mcp or addin)`);
  }
  if (backend === 'mcp') return DEFAULTS;
  const wsl = process.platform === 'linux' && !!process.env.WSL_DISTRO_NAME;
  return {
    url: 'http://127.0.0.1:8765/mcp',
    headers: {},
    timeoutMs: DEFAULTS.timeoutMs,
    tool: 'execute_python',
    transport: wsl ? 'windows-curl' : 'node',
    curlPath: wsl ? '/mnt/c/Windows/System32/curl.exe' : undefined,
    protocolVersion: '2025-06-18',
  };
}

function defaultConfigPath() {
  const base = process.env.XDG_CONFIG_HOME || path.join(os.homedir(), '.config');
  return path.join(base, 'fmcad', 'config.json');
}

function stripJsonc(text) {
  return text
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/(^|[^:"'])\/\/.*$/gm, '$1')
    .replace(/,\s*([}\]])/g, '$1');
}

function parseJsoncFile(file) {
  if (!fs.existsSync(file)) return null;
  try {
    return JSON.parse(stripJsonc(fs.readFileSync(file, 'utf8')));
  } catch (e) {
    throw new Error(`Cannot parse ${file}: ${e instanceof SyntaxError ? formatJsonError(e) : e.message}`);
  }
}

function loadConfig(opts = {}) {
  const cfgPath = opts.config || process.env.FMCAD_CONFIG || defaultConfigPath();
  let cfg = {};
  if (fs.existsSync(cfgPath)) {
    try {
      cfg = JSON.parse(stripJsonc(fs.readFileSync(cfgPath, 'utf8')));
    } catch (e) {
      throw new Error(`Cannot parse config ${cfgPath}: ${e instanceof SyntaxError ? formatJsonError(e) : e.message}`);
    }
  }
  const backend = opts.backend ?? process.env.FMCAD_BACKEND ?? cfg.backend ?? 'mcp';
  const defaults = backendDefaults(backend);
  const legacy = backend === 'mcp' ? cfg : {};
  const selected = cfg.backends?.[backend] || {};
  const routing = opts.routing ?? process.env.FMCAD_ROUTING ?? cfg.routing ?? 'direct';
  if (!['direct', 'queue'].includes(routing)) throw new Error('routing must be direct or queue');
  if (cfg.queue !== undefined && (!cfg.queue || typeof cfg.queue !== 'object' || Array.isArray(cfg.queue))) throw new Error('queue must be an object');
  if (cfg.queue?.autoStart !== undefined && typeof cfg.queue.autoStart !== 'boolean') throw new Error('queue.autoStart must be boolean');
  if (cfg.queue?.autoRecover !== undefined && typeof cfg.queue.autoRecover !== 'boolean') throw new Error('queue.autoRecover must be boolean');
  if (cfg.queue?.startupTimeoutMs !== undefined && (!Number.isSafeInteger(cfg.queue.startupTimeoutMs) || cfg.queue.startupTimeoutMs <= 0 || cfg.queue.startupTimeoutMs > 600000)) throw new Error('queue.startupTimeoutMs must be 1..600000');
  const resolved = {
    backend,
    url: opts.url ?? selected.url ?? legacy.url ?? defaults.url,
    headers: { ...defaults.headers, ...legacy.headers, ...selected.headers, ...opts.headers },
    timeoutMs: Number(opts.timeoutMs ?? opts.timeout ?? selected.timeoutMs ?? legacy.timeoutMs ?? defaults.timeoutMs),
    tool: opts.tool ?? selected.tool ?? legacy.tool ?? defaults.tool,
    transport: opts.transport ?? selected.transport ?? legacy.transport ?? defaults.transport,
    curlPath: opts.curlPath ?? opts['curl-path'] ?? selected.curlPath ?? legacy.curlPath ?? defaults.curlPath,
    protocolVersion: selected.protocolVersion ?? legacy.protocolVersion ?? defaults.protocolVersion,
    routing,
    queue: cfg.queue || {},
  };
  if (!['node', 'windows-curl'].includes(resolved.transport)) {
    throw new Error(`Invalid transport: ${resolved.transport} (expected node or windows-curl)`);
  }
  if (!Number.isFinite(resolved.timeoutMs) || resolved.timeoutMs <= 0) {
    throw new Error('timeoutMs must be a finite number greater than zero');
  }
  return { path: cfgPath, cfg: resolved };
}

function opencodeFusionBlock() {
  const candidates = [
    path.join(os.homedir(), '.opencode', 'opencode.jsonc'),
    path.join(os.homedir(), '.opencode', 'opencode.json'),
    path.join(os.homedir(), '.config', 'opencode', 'opencode.jsonc'),
    path.join(os.homedir(), '.config', 'opencode', 'opencode.json'),
  ];
  for (const file of candidates) {
    const doc = parseJsoncFile(file);
    if (doc && doc.mcp && doc.mcp.fusion) return { file, fusion: doc.mcp.fusion };
  }
  return null;
}

function initConfig({ fromOpencode = false, force = false, config, backend = 'mcp' } = {}) {
  const defaults = backendDefaults(backend);
  if (fromOpencode && backend === 'addin') {
    throw new Error('--from-opencode is only compatible with the mcp backend');
  }
  const cfgPath = config || defaultConfigPath();
  if (fs.existsSync(cfgPath) && !force) {
    throw new Error(`config already exists: ${cfgPath} (use --force to overwrite)`);
  }
  let out = {
    backend,
    url: DEFAULTS.url,
    headers: { ...DEFAULTS.headers },
    timeoutMs: DEFAULTS.timeoutMs,
    tool: DEFAULTS.tool,
  };
  if (backend === 'addin') out = { backend, backends: { addin: { ...defaults } } };
  let note = 'defaults written';
  if (fromOpencode) {
    const found = opencodeFusionBlock();
    if (!found) throw new Error('no opencode config with mcp.fusion found');
    const f = found.fusion;
    out = {
      backend,
      url: f.url || DEFAULTS.url,
      headers: { ...DEFAULTS.headers, ...(f.headers || {}) },
      timeoutMs: Number(f.timeout || DEFAULTS.timeoutMs),
      tool: DEFAULTS.tool,
    };
    note = `imported from ${found.file}`;
  }
  fs.mkdirSync(path.dirname(cfgPath), { recursive: true });
  fs.writeFileSync(cfgPath, JSON.stringify(out, null, 2) + '\n');
  const scriptsDir = path.join(path.dirname(cfgPath), 'scripts');
  fs.mkdirSync(scriptsDir, { recursive: true });
  return { path: cfgPath, note: `${note}; scripts dir: ${scriptsDir}` };
}

module.exports = { loadConfig, initConfig, defaultConfigPath, DEFAULTS };
