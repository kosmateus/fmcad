'use strict';

const { randomUUID } = require('node:crypto');
const { QueueClient, inputFiles, pinCommand, sequenceOptions } = require('./queue-client');
const { queueDirectory } = require('./queue-connection');

const summaries = {
  serve: 'Run one local multi-agent Fusion broker. Requires explicit ownership handoff and an idle Fusion. Does not start/restart Fusion.',
  exec: 'Autostart/connect to the shared broker, submit one whole fmcad command and wait. Startup/queue waiting do not consume execution timeout.',
  submit: 'Autostart/connect to the shared broker and durably submit one whole fmcad command; return jobId immediately. No automatic replay.',
  status: 'Inspect local broker/job status without Fusion traffic.',
  result: 'Read the submitting client\'s durable job output without Fusion traffic.',
  cancel: 'Cancel a queued job only. Started Fusion work is never cancelled.',
  release: 'End an owned idle sequence without another Fusion command.',
  pause: 'Stop granting new jobs; current execution may finish.',
  resume: 'Resume grants only if no unresolved operation holds Fusion.',
  stop: 'Drain the current job and stop the broker. Unknown execution prevents ownership release.',
  reclaim: 'Recover a dead broker or interrupted startup marker after PID/birth verification. Preserves unknown jobs; never retries.',
  reconcile: 'Reconcile an owned unknown job using matching durable remote receipts, then an idle identity probe. Never reruns the command.',
};
const optionsHelp = `
Options: --client LABEL, --request-id ID, --timeout MS (active command execution), --queue-timeout MS (waiting only), --sequence-action begin|continue|end, --sequence-id ID, --sequence-mode automatic|exclusive, --expected-revision N.
serve: --backend mcp|addin, --config PATH, --confirm-ownership true; optional --idle-ms MS, --lease-ms MS, --max-queued N, --max-per-client N.
status/result/cancel/reconcile: --job ID. release: --sequence-id ID.
Separate child fmcad argv with -- for exec/submit. CLI stdout remains child stdout; job/sequence receipts use FMCAD_QUEUE_RESULT on stderr.
Default sequence mode is automatic: each complete Fusion command is exclusive, then the slot is yielded immediately, including before offline analysis or image review. A continuation compares the live pinned document and its references, not the global queue counter. DOCUMENT_CHANGED returns refreshed state in the same turn without executing the stale operation. Existing --doc/--doc-id/--doc-file-id flags pin the target; unscoped/unreadable targets fail closed. Explicit --expected-revision still requests a separate global revision fence.
Explicit --sequence-mode exclusive keeps an uninterrupted reservation across calls, for workflows that cannot be split. Never use it around offline work. The MCP queue_begin tool retains explicit exclusive semantics. No sequence mode releases active/unknown work. Neither mode is a rollback transaction.
No direct fallback, remote cancellation or automatic replay. keychain build is unsupported in managed mode. See docs/QUEUE.md.
`;
const descriptors = Object.fromEntries(Object.entries(summaries).map(([name, desc]) => [name, {
  usage: `queue ${name}${['exec', 'submit'].includes(name) ? ' [options] -- <fmcad argv...>' : ' [options]'}`,
  desc, example: name === 'serve' ? 'fmcad queue serve --backend addin --confirm-ownership true' : name === 'release' ? 'fmcad queue release --sequence-id SEQUENCE_ID' :
    ['exec', 'submit'].includes(name) ? `fmcad queue ${name} --client agent-a -- doc list` : `fmcad queue ${name}${['result', 'cancel', 'reconcile'].includes(name) ? ' --job JOB_ID' : ''}`,
  extra: optionsHelp,
}]));

function parse(argv) {
  const delimiter = argv.indexOf('--');
  const own = delimiter < 0 ? argv : argv.slice(0, delimiter);
  const rest = delimiter < 0 ? [] : argv.slice(delimiter + 1);
  const allowed = new Set(['client', 'request-id', 'timeout', 'queue-timeout', 'sequence-action', 'sequence-id', 'expected-revision',
    'backend', 'config', 'confirm-ownership', 'idle-ms', 'lease-ms', 'max-queued', 'max-per-client', 'job', 'sequence-mode']);
  const opts = {};
  for (let i = 0; i < own.length; i++) {
    const key = own[i].slice(2), value = own[++i];
    if (!own[i - 1].startsWith('--') || !allowed.has(key) || Object.hasOwn(opts, key) || value === undefined || value.startsWith('--')) throw new Error('Invalid or duplicate queue option: ' + own[i - 1]);
    opts[key] = value;
  }
  return { opts, rest };
}

async function queueCommand(argv, deps) {
  const name = argv[0];
  if (!Object.hasOwn(descriptors, name)) throw new Error('Unknown queue command');
  const { opts, rest } = parse(argv.slice(1));
  const write = value => deps.stdout.write(JSON.stringify(value, null, 2) + '\n');
  if (name === 'reclaim') {
    const fs = require('node:fs'), path = require('node:path'), dir = queueDirectory();
    if (fs.existsSync(path.join(dir, 'broker.lock'))) write(require('./queue-broker').reclaim(dir));
    else write(require('./queue-autostart').reclaimStart(dir));
    return 0;
  }
  if (name === 'serve') {
    const { cfg } = deps.loadConfig(opts);
    const stateOptions = {};
    for (const [flag, field] of [['idle-ms', 'idleMs'], ['lease-ms', 'leaseMs'], ['max-queued', 'maxQueued'], ['max-per-client', 'maxPerClient']]) {
      if (opts[flag] !== undefined) {
        const value = Number(opts[flag]);
        if (!Number.isSafeInteger(value) || value <= 0) throw new Error('--' + flag + ' must be a positive integer');
        stateOptions[field] = value;
      }
    }
    const handle = await require('./queue-broker').serve({ ...cfg, routing: 'direct', queue: {} }, {
      confirmOwnership: opts['confirm-ownership'] === 'true', stateOptions, autoReconcile: cfg.queue?.autoRecover !== false,
    });
    write({ state: 'listening', socket: handle.socket, buildHash: handle.buildHash, limitations: 'Cooperative single-host ownership. No keychain integration, replay or physical qualification.' });
    for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, () => {
      handle.close().catch(error => deps.stderr.write(`Broker remains reserved: ${error.message}. Resolve/drain before stopping.\n`));
    });
    return 0;
  }
  const { cfg } = deps.loadConfig(opts);
  const client = new QueueClient(opts.client ?? process.env.FMCAD_CLIENT ?? cfg.queue?.client,
    { cfg: { ...cfg, routing: 'queue' }, configPath: opts.config });
  if (['exec', 'submit'].includes(name)) {
    if (!rest.length) throw new Error(`queue ${name} requires -- followed by fmcad argv`);
    const commandGlobals = require('./cli').parseFlags(rest).opts;
    const sequence = sequenceOptions({ ...commandGlobals, ...opts });
    const pinned = pinCommand(rest);
    const input = { requestId: opts['request-id'] || commandGlobals['request-id'] || randomUUID(), kind: 'command', argv: pinned, cwd: process.cwd(),
      backend: commandGlobals.backend || cfg.backend,
      timeoutMs: Number(opts.timeout ?? commandGlobals.timeoutMs ?? cfg.timeoutMs), inputFiles: inputFiles(pinned, process.cwd()),
      buildHash: require('./queue-instance').buildHash(), ...(sequence ? { sequence } : {}) };
    const queueTimeout = opts['queue-timeout'] ?? commandGlobals['queue-timeout'] ?? cfg.queue?.waitTimeoutMs;
    const revision = opts['expected-revision'] ?? commandGlobals['expected-revision'];
    if (queueTimeout !== undefined) input.queueTimeoutMs = Number(queueTimeout);
    if (revision !== undefined) input.expectedRevision = Number(revision);
    deps.stderr.write('FMCAD_QUEUE_REQUEST ' + JSON.stringify({ requestId: input.requestId, clientId: client.auth.clientId }) + '\n');
    const job = await client.submit(input);
    if (name === 'submit') { write(job); return 0; }
    deps.stderr.write('FMCAD_QUEUE_JOB ' + JSON.stringify({ jobId: job.id, requestId: input.requestId }) + '\n');
    const value = await client.wait(job.id);
    if (value.stdout) deps.stdout.write(value.stdout);
    if (value.stderr) deps.stderr.write(value.stderr);
    if (value.outputs) deps.stderr.write('FMCAD_QUEUE_OUTPUTS ' + JSON.stringify(value.outputs) + '\n');
    deps.stderr.write('FMCAD_QUEUE_RESULT ' + JSON.stringify(value.job) + '\n');
    return value.job.state === 'succeeded' ? 0 : 1;
  }
  if (rest.length) throw new Error('Unexpected child argv');
  await client.register(); // Metadata/control commands must not start Fusion access.
  if (['result', 'cancel', 'reconcile'].includes(name) && !opts.job) throw new Error(`${name} requires --job`);
  if (name === 'release' && !opts['sequence-id']) throw new Error('release requires --sequence-id');
  const value = await client.call(name, { ...(opts.job ? { jobId: opts.job } : {}), ...(opts['sequence-id'] ? { sequenceId: opts['sequence-id'] } : {}) });
  write(value);
  return 0;
}

module.exports = { queueCommand, descriptors };
