const fs = require('node:fs/promises');
const path = require('node:path');
const { hash } = require('./batch');
const { readOperationJournal, writeOperationRecord } = require('./batch-atomic');

const OPERATIONS = ['document.save.once', 'document.save.observe'];
const FIELDS = {
  'document.save.once': ['requestId', 'operationId', 'projectId', 'fileId', 'creationId',
    'expectedVersion', 'reportPath', 'confirm', 'description', 'timeBudgetMs'],
  'document.save.observe': ['requestId', 'operationId', 'projectId', 'fileId', 'creationId',
    'expectedVersion', 'reportPath', 'timeBudgetMs'],
};
const REQUIRED = {
  'document.save.once': ['requestId', 'operationId', 'projectId', 'fileId', 'creationId',
    'expectedVersion', 'reportPath', 'confirm'],
  'document.save.observe': ['requestId', 'operationId', 'projectId', 'fileId', 'creationId',
    'expectedVersion', 'reportPath'],
};
const integer = value => Number.isSafeInteger(value) && value > 0;
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);

function validate(operation, data) {
  if (!OPERATIONS.includes(operation)) return;
  if (!object(data)) throw new Error(operation + ' data must be an object');
  for (const key of Object.keys(data)) if (!FIELDS[operation].includes(key)) throw new Error('Unknown ' + operation + ' input: ' + key);
  for (const key of REQUIRED[operation]) if (!Object.hasOwn(data, key)) throw new Error(operation + ' requires ' + key);
  for (const key of ['requestId', 'operationId']) {
    if (typeof data[key] !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(data[key])) {
      throw new Error(key + ' must contain 1..128 letters, digits, underscores or hyphens');
    }
  }
  for (const key of ['projectId', 'fileId', 'creationId', 'reportPath']) {
    if (typeof data[key] !== 'string' || !data[key].trim()) throw new Error(key + ' must be a nonempty exact value');
  }
  if (!integer(data.expectedVersion)) throw new Error('expectedVersion must be a positive safe integer');
  if (operation === 'document.save.once' && data.confirm !== true) throw new Error('confirm must be boolean true');
  if (data.description !== undefined && typeof data.description !== 'string') throw new Error('description must be a string');
  if (data.timeBudgetMs !== undefined && (!Number.isSafeInteger(data.timeBudgetMs) || data.timeBudgetMs < 1 || data.timeBudgetMs > 120000)) {
    throw new Error('timeBudgetMs must be an integer in 1..120000');
  }
}

function targetFor(data, context) {
  if (!context?.doc || context.docId !== data.creationId || context.docFileId !== data.fileId ||
      context.projectId !== data.projectId) {
    throw new Error('document save target requires matching --doc, --doc-id, --doc-file-id and --project-id context');
  }
  return { name: context.doc, creationId: data.creationId, fileId: data.fileId,
    projectId: data.projectId, version: data.expectedVersion };
}

function journalBinding(data, target) {
  const pinnedTarget = { creationId: target.creationId, fileId: target.fileId,
    projectId: target.projectId, version: target.version };
  const request = { requestId: data.requestId, operationId: data.operationId, target: pinnedTarget };
  return { operation: 'document.save.once', requestId: data.requestId, operationId: data.operationId,
    requestHash: hash(request), target: pinnedTarget };
}

function directoryFor(data, binding) {
  return path.join(path.resolve(data.reportPath), 'document-save', hash([binding.requestId, binding.operationId]));
}

async function ensureReceiptDirectory(directory) {
  await fs.mkdir(directory, { recursive: true, mode: 0o700 });
  const stat = await fs.lstat(directory);
  if (!stat.isDirectory() || stat.isSymbolicLink()) throw new Error('document save receipt directory must be a real directory');
}

async function loadRecords(directory, binding) {
  try { return { records: await readOperationJournal(directory, binding), binding }; }
  catch (error) {
    if (error.code === 'ENOENT') return { records: [], binding };
    if (!String(error.message).includes('Operation journal identity mismatch')) throw error;
    const first = JSON.parse(await fs.readFile(path.join(directory, '00000000.json'), 'utf8'));
    const legacy = first.binding, target = legacy?.target;
    if (legacy?.operation !== 'document.save.once' || legacy.requestId !== binding.requestId ||
        legacy.operationId !== binding.operationId || typeof target?.name !== 'string' ||
        target.creationId !== binding.target.creationId || target.fileId !== binding.target.fileId ||
        target.projectId !== binding.target.projectId || target.version !== binding.target.version ||
        legacy.requestHash !== hash({ requestId: legacy.requestId, operationId: legacy.operationId, target })) throw error;
    return { records: await readOperationJournal(directory, legacy), binding: legacy };
  }
}

function validateRecords(records) {
  const states = new Set(['submit_uncertain', 'accepted', 'pending', 'complete', 'failed',
    'blocked', 'unknown', 'noop']);
  if (records.some(record => record.operation !== 'document.save.once' ||
      !states.has(record.result?.status) || !object(record.result))) {
    throw new Error('document save receipt state is corrupt or belongs to another operation');
  }
  return records;
}

async function appendRecord(directory, binding, records, value) {
  const lockPath = path.join(directory, 'journal.lock');
  let lock;
  try { lock = await fs.open(lockPath, 'wx', 0o600); }
  catch (error) {
    if (error.code === 'EEXIST') throw new Error('document save receipt writer is active; observe the original request');
    throw error;
  }
  try {
    const current = await loadRecords(directory, binding);
    if (current.records.length !== records.length) throw new Error('document save receipt changed concurrently; do not resubmit');
    const record = await writeOperationRecord(directory, binding, records.length,
      { operation: 'document.save.once', ...value });
    records.push(record);
    return record;
  } finally {
    await lock.close();
    await fs.unlink(lockPath).catch(() => {});
  }
}

function receiptResult(operation, binding, status, fields = {}) {
  return { success: ['complete', 'noop'].includes(status), operation, status,
    requestId: binding.requestId, operationId: binding.operationId,
    requestHash: binding.requestHash, target: binding.target,
    accepted: fields.accepted ?? null, changed: fields.changed ?? null,
    baselineVersion: fields.baselineVersion ?? binding.target.version,
    resultingVersion: fields.resultingVersion ?? null,
    cloudComplete: fields.cloudComplete ?? null,
    receipt: fields.receipt ?? null,
    replayedReceipt: fields.replayedReceipt === true,
    unavailableEvidence: fields.unavailableEvidence ?? [] };
}

function recordValue(record) {
  return record?.result ?? record;
}

function resultFromRecord(operation, binding, record, replayed = false) {
  const value = recordValue(record);
  return receiptResult(operation, binding, value.status ?? 'unknown', {
    ...value, receipt: value, replayedReceipt: replayed });
}

async function currentStatus(executeCad, client, context) {
  const response = await executeCad(client, 'document.status', {}, context);
  if (!response?.success || !object(response.result)) throw new Error('document.status readback did not return a scoped snapshot');
  return response.result;
}

function exactBaseline(snapshot, target) {
  return snapshot.name === target.name && snapshot.creationId === target.creationId &&
    snapshot.fileId === target.fileId && snapshot.projectId === target.projectId &&
    snapshot.version === target.version;
}

function observedPublication(snapshot, binding, accepted) {
  const target = binding.target;
  if (snapshot.creationId !== target.creationId || snapshot.fileId !== target.fileId || snapshot.projectId !== target.projectId) {
    return { status: 'unknown', accepted, changed: true,
      unavailableEvidence: ['current document identity no longer matches the original save target'] };
  }
  if (!Number.isSafeInteger(snapshot.version) || snapshot.version < target.version) {
    return { status: 'unknown', accepted, changed: true,
      unavailableEvidence: ['current version is unavailable or precedes the saved baseline'] };
  }
  if (snapshot.version > target.version && snapshot.saved === true && snapshot.modified === false && snapshot.isComplete === true) {
    return { status: 'complete', accepted, changed: true, resultingVersion: snapshot.version, cloudComplete: true };
  }
  if (snapshot.modified === true && snapshot.version > target.version) {
    return { status: 'unknown', accepted, changed: true,
      unavailableEvidence: ['target became modified after the submitted save; publication attribution is ambiguous'] };
  }
  return { status: 'pending', accepted, changed: true, resultingVersion: snapshot.version,
    cloudComplete: snapshot.isComplete === true ? true : null };
}

async function observeUntil(executeCad, client, context, data, binding, directory, records, accepted, deadline, dependencies = {}) {
  const now = dependencies.now ?? (() => performance.now());
  const sleep = dependencies.sleep ?? (ms => new Promise(resolve => setTimeout(resolve, ms)));
  const recordBinding = dependencies.recordBinding ?? binding;
  const resultBinding = dependencies.resultBinding ?? binding;
  let last;
  while (now() < deadline) {
    let snapshot;
    try { snapshot = await currentStatus(executeCad, client, context); }
    catch (error) {
      last = { status: 'unknown', accepted, changed: true,
        unavailableEvidence: ['document.status readback failed: ' + String(error.message ?? error)] };
      break;
    }
    last = observedPublication(snapshot, binding, accepted);
    if (last.status !== 'pending') break;
    if (now() >= deadline) break;
    await sleep(Math.min(100, Math.max(1, deadline - now())));
  }
  if (!last) last = { status: accepted === true ? 'accepted' : 'unknown', accepted, changed: true,
    unavailableEvidence: ['observation budget expired before a publication status read'] };
  if (last.status === 'pending' && now() >= deadline) {
    last.unavailableEvidence = ['publication remains pending at the bounded observation deadline'];
  }
  await appendRecord(directory, recordBinding, records, { state: last.status, result: last });
  return receiptResult('document.save.once', resultBinding, last.status, { ...last, receipt: last });
}

async function saveOnce(client, data, context, executeCad, dependencies = {}) {
  const target = targetFor(data, context);
  const binding = journalBinding(data, target);
  const directory = directoryFor(data, binding);
  await ensureReceiptDirectory(directory);
  let loaded = await loadRecords(directory, binding);
  let records = validateRecords(loaded.records);
  if (records.length) return resultFromRecord('document.save.once', binding, records.at(-1), true);
  const submitLock = path.join(directory, 'submit.lock');
  let lock;
  try { lock = await fs.open(submitLock, 'wx', 0o600); }
  catch (error) {
    if (error.code === 'EEXIST') return receiptResult('document.save.once', binding, 'unknown', {
      unavailableEvidence: ['another submission owns this request identity; no second save was sent'] });
    throw error;
  }
  try {
    loaded = await loadRecords(directory, binding);
    records = validateRecords(loaded.records);
    if (records.length) return resultFromRecord('document.save.once', binding, records.at(-1), true);
    let before;
    try { before = await currentStatus(executeCad, client, context); }
    catch (error) { return receiptResult('document.save.once', binding, 'blocked', {
      accepted: false, changed: false,
      unavailableEvidence: ['exact target preflight status unavailable: ' + String(error.message ?? error)] }); }
    if (!exactBaseline(before, target)) return receiptResult('document.save.once', binding, 'blocked', {
      accepted: false, changed: false, unavailableEvidence: ['name/creationId/fileId/projectId/version differs from requested target'] });
    if (before.saved !== true) return receiptResult('document.save.once', binding, 'blocked', {
      accepted: false, changed: false, unavailableEvidence: ['target must already be saved'] });
    if (before.modified === false) {
      const noop = { status: 'noop', accepted: false, changed: false,
        resultingVersion: before.version, cloudComplete: before.isComplete === true ? true :
          before.isComplete === false ? false : null };
      await appendRecord(directory, loaded.binding, records, { state: 'noop', result: noop });
      return receiptResult('document.save.once', binding, 'noop', { ...noop, receipt: noop });
    }
    if (before.isComplete !== true || before.isReadOnly !== false) {
      return receiptResult('document.save.once', binding, 'blocked', { accepted: false, changed: false,
        unavailableEvidence: ['changed target must be cloud complete and writable before saving'] });
    }
    const submitIntent = { status: 'submit_uncertain', accepted: null, changed: true,
      baselineVersion: target.version };
    await appendRecord(directory, loaded.binding, records, { state: 'submit_uncertain', result: submitIntent });
    let submitted;
    try {
      submitted = await executeCad(client, 'document.save_native', { requestId: data.requestId,
        operationId: data.operationId, projectId: target.projectId, fileId: target.fileId,
        creationId: target.creationId, version: target.version,
        description: data.description ?? ('Authorized fmcad save ' + data.operationId) }, context);
    } catch (error) {
      const unknown = { status: 'unknown', accepted: null, changed: true,
        unavailableEvidence: ['save RPC outcome is unknown: ' + String(error.message ?? error)] };
      await appendRecord(directory, loaded.binding, records, { state: 'unknown', result: unknown });
      return receiptResult('document.save.once', binding, 'unknown', { ...unknown, receipt: unknown });
    }
    const outcome = submitted?.result;
    if (!object(outcome)) {
      const unknown = { status: 'unknown', accepted: null, changed: true,
        unavailableEvidence: ['save RPC returned no structured native result'] };
      await appendRecord(directory, loaded.binding, records, { state: 'unknown', result: unknown });
      return receiptResult('document.save.once', binding, 'unknown', { ...unknown, receipt: unknown });
    }
    if (outcome.status === 'noop') {
      const noop = { status: 'noop', accepted: false, changed: false,
        resultingVersion: target.version, cloudComplete: outcome.cloudComplete ?? null };
      await appendRecord(directory, loaded.binding, records, { state: 'noop', result: noop });
      return receiptResult('document.save.once', binding, 'noop', { ...noop, receipt: noop });
    }
    if (outcome.status === 'blocked') {
      const blocked = { status: 'blocked', accepted: false, changed: false,
        unavailableEvidence: [outcome.reason ?? 'native pre-save guard refused the target'] };
      await appendRecord(directory, loaded.binding, records, { state: 'blocked', result: blocked });
      return receiptResult('document.save.once', binding, blocked.status, { ...blocked, receipt: blocked });
    }
    if (outcome.status === 'failed' && outcome.accepted === false) {
      const failed = { status: 'failed', accepted: false, changed: true,
        unavailableEvidence: [outcome.reason ?? 'Fusion did not accept the save'] };
      await appendRecord(directory, loaded.binding, records, { state: 'failed', result: failed });
      return receiptResult('document.save.once', binding, failed.status, { ...failed, receipt: failed });
    }
    if (outcome.status !== 'accepted' || outcome.accepted !== true) {
      const unknown = { status: 'unknown', accepted: outcome.accepted ?? null, changed: true,
        unavailableEvidence: [outcome.reason ?? 'native save result is not a known accepted/no-op/failed result'] };
      await appendRecord(directory, loaded.binding, records, { state: 'unknown', result: unknown });
      return receiptResult('document.save.once', binding, unknown.status, { ...unknown, receipt: unknown });
    }
    const accepted = { status: 'accepted', accepted: true, changed: true,
      baselineVersion: target.version };
    await appendRecord(directory, loaded.binding, records, { state: 'accepted', result: accepted });
    const now = dependencies.now ?? (() => performance.now());
    const deadline = now() + (data.timeBudgetMs ?? 30000);
    return observeUntil(executeCad, client, context, data, binding, directory, records,
      true, deadline, { ...dependencies, recordBinding: loaded.binding });
  } finally {
    await lock.close();
    await fs.unlink(submitLock).catch(() => {});
  }
}

async function saveObserve(client, data, context, executeCad, dependencies = {}) {
  const target = targetFor(data, context);
  const binding = journalBinding(data, target);
  const directory = directoryFor(data, binding);
  let loaded;
  let records;
  try {
    loaded = await loadRecords(directory, binding);
    records = validateRecords(loaded.records);
  }
  catch (error) { return receiptResult('document.save.observe', binding, 'blocked', {
    unavailableEvidence: ['receipt identity or journal is invalid: ' + String(error.message ?? error)] }); }
  if (!records.length) {
    try { await fs.lstat(path.join(directory, 'submit.lock')); return receiptResult('document.save.observe', binding, 'unknown', {
      unavailableEvidence: ['an interrupted submission lock exists without a complete receipt; save is not replayed'] }); }
    catch (error) { if (error.code !== 'ENOENT') return receiptResult('document.save.observe', binding, 'unknown', {
      unavailableEvidence: ['submission lock status is unavailable: ' + String(error.message ?? error)] }); }
    return receiptResult('document.save.observe', binding, 'unknown', {
      accepted: null, changed: null, unavailableEvidence: ['original save receipt is missing; no submission outcome can be inferred and no save is issued'] });
  }
  const last = records.at(-1).result ?? {};
  if (['noop', 'complete', 'failed', 'blocked'].includes(last.status)) {
    return resultFromRecord('document.save.observe', loaded.binding, records.at(-1), true);
  }
  const now = dependencies.now ?? (() => performance.now());
  const deadline = now() + (data.timeBudgetMs ?? 30000);
  return observeUntil(executeCad, client, context, data, binding, directory, records,
    last.accepted ?? null, deadline, { ...dependencies, recordBinding: loaded.binding,
      resultBinding: loaded.binding })
    .then(result => ({ ...result, operation: 'document.save.observe' }));
}

async function execute(client, operation, data, context, executeCad, dependencies = {}) {
  validate(operation, data);
  let target;
  try { target = targetFor(data, context); }
  catch (error) {
    const targetHint = { name: context?.doc ?? null, creationId: data?.creationId ?? null,
      fileId: data?.fileId ?? null, projectId: data?.projectId ?? null,
      version: data?.expectedVersion ?? null };
    const binding = journalBinding(data, targetHint);
    return receiptResult(operation, binding, 'blocked', {
      accepted: false, changed: false, unavailableEvidence: [String(error.message ?? error)] });
  }
  const binding = journalBinding(data, target);
  try {
    return operation === 'document.save.once'
      ? await saveOnce(client, data, context, executeCad, dependencies)
      : await saveObserve(client, data, context, executeCad, dependencies);
  } catch (error) {
    return receiptResult(operation, binding, 'unknown', {
      unavailableEvidence: [String(error.message ?? error)] });
  }
}

module.exports = { OPERATIONS, validate, execute };
