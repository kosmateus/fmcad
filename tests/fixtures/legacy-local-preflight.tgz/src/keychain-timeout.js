const fs = require('node:fs');

// Linux/WSL: libuv hrtime and Python clock_gettime(CLOCK_MONOTONIC) share
// the kernel clock, including its epoch. Never use performance.now() here.
const monotonicMs = () => Number(process.hrtime.bigint()) / 1e6;

// Only child processes of keychain receive this command-scoped deadline.
function requestTimeout(server, env = process.env) {
  const timeout = scopedRequestTimeout(server, env);
  // Set only by the owning fmcad_execute invocation. Admission control, not
  // cancellation: refuse the NEXT RPC if its full allowance no longer fits.
  // This also bounds initialization and all steps of a multi-request batch.
  const outer = env.FMCAD_EXECUTION_DEADLINE_MONOTONIC_MS;
  if (outer !== undefined) {
    const remaining = Number(outer) - monotonicMs();
    if (!Number.isFinite(remaining) || !(timeout > 0) || timeout > remaining) {
      const error = new Error('RPC not submitted: insufficient fmcad_execute budget for its full timeout. Earlier calls may have run; inspect reports, split the remaining work, never replay uncertain mutations.');
      error.code = 'FMCAD_RPC_NOT_SUBMITTED_BUDGET';
      throw error;
    }
  }
  return timeout;
}

function scopedRequestTimeout(server, env) {
  const monotonic = env.FMCAD_KEYCHAIN_DEADLINE_MONOTONIC_MS;
  const value = monotonic ?? env.FMCAD_KEYCHAIN_DEADLINE_MS;
  if (value === undefined) return server.timeoutMs;
  if (value === '0') return 0;
  const remaining = Number(value) - (monotonic === undefined ? Date.now() : monotonicMs());
  if (!Number.isFinite(remaining) || remaining <= 0) {
    throw new Error('Keychain command timeout; inspect any pending Fusion operation before retry');
  }
  return Math.max(1, Math.ceil(remaining));
}

function commandTimeout(flags) {
  if (flags.timeout !== undefined && flags['offline-timeout'] !== undefined) {
    throw new Error('Use only --timeout (--offline-timeout is its compatibility alias)');
  }
  const raw = flags.timeout ?? flags['offline-timeout'];
  if (raw === undefined) return 0;
  const value = Number(raw);
  if (!Number.isSafeInteger(value) || value <= 0 || value > 2147483647) {
    throw new Error('--timeout requires positive integer milliseconds, at most 2147483647');
  }
  return value;
}

// Identity checks prevent a recycled PID from becoming a cancellation target.
// No process-name matching or signalling of foreign/shared process groups.
function processInfo(pid) {
  try {
    const text = fs.readFileSync(`/proc/${pid}/stat`, 'utf8');
    const fields = text.slice(text.lastIndexOf(') ') + 2).split(' ');
    return { pid: Number(pid), parent: Number(fields[1]), start: fields[19], state: fields[0] };
  } catch (error) {
    if (error.code === 'ENOENT' || error.code === 'ESRCH') return null;
    throw error;
  }
}

function commandLifecycle(timeout, started = monotonicMs()) {
  const deadline = timeout ? started + timeout : 0;
  const controller = new AbortController();
  const owned = new Map();
  let child, exited = false, reason, timer, poll, escalation, bound;
  let cleanupError, finishCancellation, cleanupStarted;
  const cancelled = new Promise(resolve => { finishCancellation = resolve; });
  const alive = info => {
    const current = processInfo(info.pid);
    return current && current.start === info.start && !['Z', 'X'].includes(current.state);
  };
  function discover() {
    const processes = fs.readdirSync('/proc').filter(name => /^\d+$/.test(name)).map(processInfo).filter(Boolean);
    let changed;
    do {
      changed = false;
      for (const info of processes) {
        const parent = owned.get(info.parent);
        if (!owned.has(info.pid) && parent && alive(parent)) {
          owned.set(info.pid, info);
          changed = true;
        }
      }
    } while (changed);
  }
  function signalOwned(signal) {
    for (const info of owned.values()) {
      try { if (alive(info)) process.kill(info.pid, signal); }
      catch (error) { if (error.code !== 'ESRCH') cleanupError = error.message; }
    }
  }
  function finish() {
    let stopped = !child || exited;
    try { stopped = stopped && [...owned.values()].every(info => !alive(info)); }
    catch (error) { cleanupError = error.message; }
    if (!stopped) return false;
    finishCancellation({ reason, cleanup: stopped && !cleanupError ? 'confirmed' : 'unconfirmed', cleanupError,
      cleanupMs: monotonicMs() - cleanupStarted });
    return true;
  }
  function cancel(value) {
    if (reason) return;
    reason = value;
    cleanupStarted = monotonicMs();
    controller.abort(new Error(`Keychain command ${reason}`));
    if (!child) { finish(); return; }
    try { discover(); } catch (error) { cleanupError = error.message; }
    try {
      if (!exited) child.kill(value === 'SIGINT' ? 'SIGINT' : 'SIGTERM');
    } catch (error) { cleanupError = error.message; }
    // Python has up to 3 seconds for TERM, reaping and descendant verification.
    // One additional second allows scheduling and journal writes.
    escalation = setTimeout(() => {
      // Freeze known local parents before the final ancestry scan/kill. A scan
      // failure must not prevent killing already identified owned processes.
      signalOwned('SIGSTOP');
      try { discover(); } catch (error) { cleanupError = error.message; }
      signalOwned('SIGKILL');
      try { if (!exited) child.kill('SIGKILL'); } catch (error) { cleanupError = error.message; }
    }, 4000);
    bound = setTimeout(() => {
      if (!finish()) finishCancellation({ reason, cleanup: 'unconfirmed', cleanupError: cleanupError || 'Owned processes did not stop within 5 seconds',
        cleanupMs: monotonicMs() - cleanupStarted });
    }, 5000);
  }
  const handlers = Object.fromEntries(['SIGINT', 'SIGTERM'].map(signal => [signal, () => cancel(signal)]));
  for (const [signal, handler] of Object.entries(handlers)) process.on(signal, handler);
  if (deadline) timer = setTimeout(() => cancel('timeout'), Math.max(0, deadline - monotonicMs()));
  return {
    deadline, signal: controller.signal, cancelled, cancel,
    get reason() { return reason; },
    check() {
      if (!reason && deadline && monotonicMs() >= deadline) cancel('timeout');
      if (reason) throw controller.signal.reason;
    },
    attach(value) {
      child = value;
      // Successful fake transports need neither a PID nor kill().
      if (child.pid && process.platform === 'linux') {
        try {
          const info = processInfo(child.pid);
          if (info) owned.set(info.pid, info);
        } catch (error) { cleanupError = error.message; }
      }
      child.once('exit', () => { exited = true; });
      child.once('close', () => { exited = true; });
      poll = setInterval(() => {
        try { if (owned.size) discover(); } catch (error) { cleanupError = error.message; }
        if (reason) finish();
      }, 50);
    },
    dispose() {
      for (const handle of [timer, poll, escalation, bound]) clearTimeout(handle);
      for (const [signal, handler] of Object.entries(handlers)) process.removeListener(signal, handler);
    },
  };
}

module.exports = { requestTimeout, commandTimeout, commandLifecycle, monotonicMs };
