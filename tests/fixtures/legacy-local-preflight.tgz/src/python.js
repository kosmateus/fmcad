// Decode JSON at runtime: JSON booleans and null are not Python literals.
function pythonValue(value) {
  const json = JSON.stringify(value).replace(/[^\x00-\x7f]/g,
    character => '\\u' + character.charCodeAt(0).toString(16).padStart(4, '0'));
  return `__import__('json').loads(${JSON.stringify(json)})`;
}

module.exports = { pythonValue };
