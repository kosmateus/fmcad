// Only explicit execution/evidence fields determine failure, never user metadata.
function failedOutcome(output) {
  if (!output || output.success === false || ['fail', 'failed', 'blocked', 'unknown', 'missing', 'stale'].includes(output.status)) return true;
  const evidence = output.result;
  return !!(evidence && (evidence.passed === false ||
    (evidence.restored === false && evidence.leftRequestedState !== true && evidence.status !== 'pass') ||
    evidence.sampledPassed === false || evidence.checkOutcome === 'fail' ||
    ['fail', 'failed', 'blocked', 'unknown', 'missing', 'stale'].includes(evidence.status)));
}

module.exports = { failedOutcome };
