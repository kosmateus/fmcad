'use strict';
const termkit = require('terminal-kit');
const path = require('node:path');
const { text } = require('./safe');
const { duration, bytes, cpu, clock, count, doc, stateNames } = require('./format');
const { filtered } = require('./logs');

function fit(value, width, right = false) {
  if (width <= 0) return '';
  let valueText = text(value, 6000);
  if (termkit.stringWidth(valueText) > width) valueText = termkit.truncateString(valueText, Math.max(0, width - 1)) + '…';
  const padding = ' '.repeat(Math.max(0, width - termkit.stringWidth(valueText)));
  return right ? padding + valueText : valueText + padding;
}
function columns(spec, width) {
  let chosen = spec.map(column => ({ ...column }));
  const required = () => chosen.reduce((sum, column) => sum + column.min, 0) + Math.max(0, chosen.length - 1) * 3;
  while (chosen.length > 1 && required() > width) {
    const least = chosen.reduce((a, b) => a.priority <= b.priority ? a : b);
    chosen = chosen.filter(column => column !== least);
  }
  if (required() > width) chosen[0].min = Math.max(0, width);
  for (const column of chosen) column.width = column.min;
  let remaining = Math.max(0, width - required());
  const growing = chosen.filter(column => column.grow) || [];
  const recipients = growing.length ? growing : chosen;
  while (remaining > 0) for (const column of recipients) {
    const amount = Math.min(remaining, column.grow || 1);
    column.width += amount; remaining -= amount;
    if (!remaining) break;
  }
  return chosen;
}
function line(cells, cols) { return cols.map(column => fit(cells[column.key], column.width, column.right)).join(' │ '); }
const col = (key, title, min, priority, grow = 0, right = false) => ({ key, title, min, priority, grow, right });
function specs(kind, width) {
  const narrow = width < 100;
  if (kind === 'jobs') return [col('id', 'ID', 8, 10), col('state', 'Stan', narrow ? 10 : 12, 100),
    col('agent', 'Agent / klient', narrow ? 12 : 18, 40, 1), col('document', 'Dokument', narrow ? 16 : 22, 100, 2),
    col('command', 'Polecenie', narrow ? 13 : 18, 90, 3), col('wait', 'Czekanie', narrow ? 8 : 11, 50, 0, true),
    col('elapsed', 'Wykonanie', narrow ? 8 : 11, 70, 0, true)];
  if (kind === 'logs') return [col('time', 'Czas', 8, 80), col('level', 'Typ', 5, 100),
    col('agent', 'Agent / klient', 16, 30, 1), col('document', 'Dokument', narrow ? 14 : 20, 50, 1), col('message', 'Zdarzenie', narrow ? 16 : 24, 100, 4)];
  if (kind === 'agents') return [col('state', 'Stan', narrow ? 9 : 12, 100), col('agent', 'Agent / klient', narrow ? 14 : 24, 100, 3),
    col('project', 'Projekt', 16, 30, 1), col('type', 'Typ', 7, 40), col('age', 'Kontakt', 9, 60, 0, true), col('pid', 'PID', 7, 20, 0, true)];
  if (kind === 'resources') return [col('name', 'Proces', 9, 100, 1), col('cpu', 'CPU', 6, 90, 0, true), col('ram', 'RAM', 10, 100, 1, true)];
  if (kind === 'alerts') return [col('level', 'Typ', 5, 60), col('message', 'Komunikat', 12, 100, 4)];
  return [col('name', 'Pole', Math.min(24, Math.max(8, Math.floor(width * 0.3))), 80), col('value', 'Wartość', 8, 100, 4)];
}
function table(kind, records, width, query = '', wrapValues = false) {
  const cols = columns(specs(kind, width), width);
  const search = query.toLocaleLowerCase('pl');
  const selected = records.filter(record => !search || (record.search || Object.values(record.cells).join(' ')).toLocaleLowerCase('pl').includes(search));
  return { columns: cols, header: line(Object.fromEntries(cols.map(column => [column.key, column.title])), cols),
    rows: selected.flatMap(record => {
      const valueColumn = wrapValues && cols.find(column => column.key === 'value');
      if (!valueColumn || valueColumn.width < 2) return [{ ...record, line: line(record.cells, cols) }];
      let value = text(record.cells.value, 6000), index = 0;
      const result = [];
      do {
        const part = termkit.truncateString(value, valueColumn.width);
        result.push({ ...record, key: record.key + ':' + index, line: line({ ...record.cells, name: index ? '' : record.cells.name, value: part }, cols) });
        value = value.slice(part.length); index++;
      } while (value.length && index < 300);
      return result;
    }) };
}
function shortAgent(value) {
  if (typeof value !== 'string') return 'nieznany';
  if (value.startsWith('opencode:')) return 'OpenCode #' + value.slice(-8);
  if (value.startsWith('mcp-stdio:')) return 'MCP #' + value.slice(-8);
  return value;
}
const briefTime = ms => !Number.isFinite(ms) ? '—' : ms < 60000 ? duration(ms) : ms < 3600000 ? `${Math.floor(ms / 60000)} min` : `${(ms / 3600000).toFixed(1)} h`;
const age = (now, at) => Number.isFinite(at) ? briefTime(Math.max(0, now - at)) : '—';
const pending = job => ['queued', 'running', 'sending', 'needs_reconciliation'].includes(job.state);
function jobRecords(snapshot, overview, width) {
  const jobs = [...snapshot.jobs].sort((a, b) => Number(!pending(a)) - Number(!pending(b)) || b.order - a.order);
  const visible = overview ? [...jobs.filter(pending), ...jobs.filter(job => !pending(job)).slice(0, 3)] : jobs;
  return visible.map(job => ({ key: 'job:' + job.id, detail: { type: 'job', id: job.id },
    style: job.state === 'needs_reconciliation' ? 'error' : ['failed', 'expired'].includes(job.state) ? 'warn' : job.state === 'succeeded' ? 'success' : 'normal',
    search: JSON.stringify(job), cells: { id: job.id.slice(0, 8), state: stateNames[job.state] || job.state,
      agent: shortAgent(job.clientLabel || job.clientId), document: doc(job), command: job.command,
      wait: width < 100 ? briefTime(job.waitMs) : duration(job.waitMs), elapsed: width < 100 ? briefTime(job.elapsedMs) : duration(job.elapsedMs) } }));
}
function logRecords(snapshot, ui) {
  return filtered(snapshot.logs.lines, { ...ui, query: ui.query || '' }).map(event => ({
    key: `log:${event.source}:${event.sequence ?? event.timestamp}:${event.fields.job || event.event}`,
    detail: { type: 'value', value: event }, style: ['ERROR', 'FATAL'].includes(event.level) ? 'error' : event.level === 'WARN' ? 'warn' : 'normal',
    search: JSON.stringify(event), cells: { time: clock(event.timestamp), level: event.level,
      agent: shortAgent(event.clientLabel), document: event.document || '—',
      message: event.message + (event.command ? ' · ' + event.command : '') } }));
}
function agentRecords(snapshot, overview) {
  const result = [], mapped = new Set();
  for (const session of snapshot.agents.sessions) {
    if (overview && ['ended', 'stale'].includes(session.status)) continue;
    if (session.clientId) mapped.add(session.clientId);
    result.push({ key: 'session:' + session.id, detail: { type: 'value', value: session },
      style: ['stopped', 'stale'].includes(session.status) ? 'warn' : 'normal', search: JSON.stringify(session),
      cells: { state: stateNames[session.status] || session.status, agent: session.title,
        project: path.basename(session.project || ''), type: 'sesja', age: age(snapshot.observedAt, session.observedAt), pid: session.pid } });
  }
  const active = new Map(snapshot.jobs.filter(pending).map(job => [job.clientId, job]));
  for (const client of snapshot.agents.clients) {
    if (mapped.has(client.id)) continue;
    if (overview && !active.has(client.id) && snapshot.observedAt - client.lastActivityAt > 300000) continue;
    const job = active.get(client.id);
    result.push({ key: 'client:' + client.id, detail: { type: 'value', value: client }, style: 'muted', search: JSON.stringify(client),
      cells: { state: job ? stateNames[job.state] || job.state : 'nieznany', agent: shortAgent(client.title || client.id),
        project: path.basename(client.project || ''), type: 'klient', age: age(snapshot.observedAt, client.lastActivityAt), pid: '—' } });
  }
  if (!overview) for (const host of snapshot.system.hosts) result.push({ key: 'host:' + host.pid,
    detail: { type: 'value', value: host }, style: host.stopped ? 'warn' : 'muted', search: JSON.stringify(host),
    cells: { state: host.stopped ? 'wstrzymany' : 'proces żywy', agent: host.role === 'mcp' ? 'Mostek MCP' : 'Host OpenCode',
      project: path.basename(host.project || ''), type: host.role === 'mcp' ? 'MCP' : 'host', age: '—', pid: host.pid } });
  return result;
}
function resourceRecords(snapshot) {
  const list = [['Broker', snapshot.system.broker], ['Worker', snapshot.system.worker], ['Panel', snapshot.system.panel],
    ['Linux/WSL', { cpuPercent: snapshot.system.host.cpuPercent, rssBytes: snapshot.system.host.memoryUsedBytes }]];
  return list.map(([name, value]) => ({ key: 'resource:' + name, style: 'normal', detail: { type: 'value', value: value || { state: 'niedostępny' } },
    cells: { name, cpu: cpu(value?.cpuPercent), ram: bytes(value?.rssBytes) } }));
}
function alertRecords(snapshot) {
  const alerts = snapshot.alerts.map((alert, i) => ({ key: 'alert:' + i + ':' + alert.message,
    style: alert.level === 'ERROR' ? 'error' : 'warn', detail: { type: 'value', value: alert }, cells: { level: alert.level, message: alert.message } }));
  if (!alerts.length) alerts.push({ key: 'alert:ok', style: 'success', cells: { level: 'OK', message: 'Brak bieżących alarmów' } });
  return alerts;
}
function fieldRecords(object) {
  const result = [];
  function visit(value, name) {
    if (value && typeof value === 'object') {
      for (const [key, child] of Object.entries(value)) visit(child, name ? name + '.' + key : key);
    } else result.push({ key: 'field:' + name, cells: { name, value: value === null || value === undefined ? '—' : String(value) }, style: 'normal' });
  }
  visit(object, ''); return result;
}
function geometry(width, height, view, overlay) {
  const y = 4, h = Math.max(0, height - 7), w = Math.max(1, width);
  if (!h) return [];
  if (view !== 0 || overlay) return [{ id: overlay || ['overview', 'agents', 'jobs', 'logs', 'system'][view], x: 0, y, w, h }];
  if (width < 72 || h < 12) {
    if (h < 9) return [{ id: 'jobs', x: 0, y, w, h }];
    const top = Math.max(4, Math.floor((h - 1) / 2));
    return [{ id: 'jobs', x: 0, y, w, h: Math.min(top, h) }, { id: 'logs', x: 0, y: y + top + 1, w, h: Math.max(1, h - top - 1) }];
  }
  const left = Math.floor((w - 1) * (w >= 110 ? 0.66 : 0.55)), right = w - left - 1;
  const top = Math.floor((h - 1) * 0.45);
  const result = [{ id: 'jobs', x: 0, y, w: left, h: top }, { id: 'logs', x: 0, y: y + top + 1, w: left, h: h - top - 1 }];
  if (h >= 24) {
    const agents = Math.max(7, Math.floor(h * 0.3)), resources = Math.max(9, Math.floor(h * 0.4));
    result.push({ id: 'agents', x: left + 1, y, w: right, h: agents },
      { id: 'resources', x: left + 1, y: y + agents + 1, w: right, h: resources },
      { id: 'alerts', x: left + 1, y: y + agents + resources + 2, w: right, h: h - agents - resources - 2 });
  } else {
    const agents = Math.floor((h - 1) / 2);
    result.push({ id: 'agents', x: left + 1, y, w: right, h: agents },
      { id: 'resources', x: left + 1, y: y + agents + 1, w: right, h: h - agents - 1 });
  }
  return result;
}
function makePanels(snapshot, view, ui, width, height) {
  const overlay = ui.help ? 'help' : ui.detail ? 'details' : null;
  return geometry(width, height, view, overlay).map(rect => {
    const contentWidth = Math.max(1, rect.w - 4);
    let kind = rect.id, records, title, subtitle = '';
    if (kind === 'jobs') {
      title = 'ZADANIA'; records = jobRecords(snapshot, view === 0, contentWidth);
      subtitle = `Kolejka: ${count(snapshot.queue.projectWaiting)} · Enter: szczegóły`;
    } else if (kind === 'logs') {
      title = 'LOGI — PLIK: ' + (snapshot.logs.file ? path.basename(snapshot.logs.file) : 'wszystkie projekty');
      records = logRecords(snapshot, ui); subtitle = `${ui.hideInfo ? 'bez INFO' : 'INFO'} · ${ui.errorsOnly ? 'WARN/ERROR' : 'wszystkie poziomy'} · ${ui.hideHeartbeat ? 'bez heartbeat' : 'heartbeat'}`;
    } else if (kind === 'agents') {
      title = 'SESJE / AGENCI / KLIENCI'; records = agentRecords(snapshot, view === 0);
      subtitle = `Sesje: ${count(snapshot.agents.liveSessions)} · aktywne: ${count(snapshot.agents.busySessions)} · hosty: ${snapshot.agents.hostCount}`;
    } else if (kind === 'resources') { title = 'ZASOBY SYSTEMU'; records = resourceRecords(snapshot); subtitle = 'CPU / pamięć · odczyt OS'; }
    else if (kind === 'alerts') { title = 'ALARMY'; records = alertRecords(snapshot); subtitle = `${snapshot.alerts.length} bieżących · bez działań automatycznych`; }
    else if (kind === 'help') {
      title = 'KLAWISZE'; subtitle = 'Dashboard nie przewija całej strony. Tab zmienia panel.';
      records = [ ['1–5', 'Widoki; 1 = pełny dashboard'], ['Tab / Shift+Tab', 'Następny / poprzedni panel'], ['↑↓ / PgUp PgDn', 'Wybór i przewijanie tylko aktywnego panelu'],
        ['Kółko myszy', 'Przewijanie panelu pod wskaźnikiem'], ['Pasek przewijania', 'Kliknij lub przeciągnij suwak'], ['Enter / Esc', 'Szczegóły / powrót'],
        ['/', 'Wyszukiwanie; Enter kończy wpisywanie'], ['c', 'Wyczyść wyszukiwanie'], ['i / e / h', 'Filtry logów: INFO / WARN+ERROR / heartbeat'],
        ['p / a', 'Projekt / archiwum godzinne'], ['g / G', 'Początek / koniec panelu; G w logach włącza follow'], ['Spacja', 'Zamroź tylko widok, nigdy kolejkę'], ['q / Ctrl+C', 'Wyjście'] ]
        .map(([name, value]) => ({ key: 'help:' + name, cells: { name, value }, style: 'normal' }));
      kind = 'fields';
    } else if (kind === 'details') { title = 'SZCZEGÓŁY'; subtitle = 'Esc: powrót · pełne wartości w stałych kolumnach'; records = fieldRecords(ui.detail); kind = 'fields'; }
    else {
      title = 'ZASOBY SYSTEMU'; subtitle = 'Odczyt lokalny, bez SDK i SQL'; kind = 'fields';
      records = fieldRecords({ 'Broker CPU': cpu(snapshot.system.broker?.cpuPercent), 'Broker RAM': bytes(snapshot.system.broker?.rssBytes),
        'Worker CPU': cpu(snapshot.system.worker?.cpuPercent), 'Worker RAM': bytes(snapshot.system.worker?.rssBytes),
        'Panel CPU': cpu(snapshot.system.panel?.cpuPercent), 'Panel RAM': bytes(snapshot.system.panel?.rssBytes),
        'Linux/WSL CPU': cpu(snapshot.system.host.cpuPercent), 'RAM hosta': `${bytes(snapshot.system.host.memoryUsedBytes)} / ${bytes(snapshot.system.host.memoryTotalBytes)}`,
        'Fusion PID': snapshot.fusion.pid, 'Fusion build': snapshot.fusion.version, 'Kontakt Fusion (zapis)': age(snapshot.observedAt, snapshot.fusion.observedAt),
        'Fusion CPU Windows': 'N/A — bez zapytania SDK', 'Kolejka': snapshot.queue.reason,
        'Build brokera': snapshot.queue.buildHash, 'Źródło danych': snapshot.source,
        'Stan danych': snapshot.data.stale ? 'Nieaktualne: ' + snapshot.data.error : 'Odczytane',
        'Blokady Beads': snapshot.beads.available ? snapshot.beads.holders.map(h => `PID ${h.pid} ${h.command}${h.stopped ? ' WSTRZYMANY' : ''}`).join('; ') || 'brak w chwili próbkowania' : snapshot.beads.reason,
      });
    }
    const result = table(kind, records, contentWidth, ui.help ? '' : ui.query, kind === 'fields');
    if (!result.rows.length) result.rows.push({ key: 'empty:' + rect.id, style: 'muted', line: fit(rect.id === 'agents' ? 'Brak telemetrii / bieżących klientów' : 'Brak pasujących wpisów', contentWidth) });
    return { ...rect, ...result, title, subtitle, contentWidth, bodyY: rect.y + 3, bodyHeight: Math.max(0, rect.h - 4) };
  });
}
function metrics(snapshot, width) {
  const specs = [col('broker', 'Broker', 18, 100, 1), col('waiting', 'Czeka', 10, 90, 1),
    col('sessions', 'Sesje', 14, 50, 1), col('cpu', 'CPU', 12, 80, 1), col('ram', 'RAM', 15, 40, 1)];
  return line({ broker: 'BROKER: ' + (stateNames[snapshot.queue.brokerState] || snapshot.queue.brokerState),
    waiting: 'CZEKA: ' + count(snapshot.queue.waiting), sessions: 'SESJE: ' + count(snapshot.agents.liveSessions),
    cpu: 'CPU: ' + cpu(snapshot.system.broker?.cpuPercent), ram: 'RAM: ' + bytes(snapshot.system.broker?.rssBytes) }, columns(specs, width));
}
function statistics(snapshot, width) {
  const stats = snapshot.statistics;
  return line({ wait: `Czekanie p50/p95: ${briefTime(stats.waitMedianMs)} / ${briefTime(stats.waitP95Ms)}`,
    run: `Wykonanie p50/p95: ${briefTime(stats.runMedianMs)} / ${briefTime(stats.runP95Ms)}`,
    contact: 'Kontakt Fusion: ' + age(snapshot.observedAt, snapshot.fusion.observedAt), failures: 'Błędy: ' + count(stats.executionFailures) },
  columns([col('wait', '', 24, 100, 1), col('run', '', 24, 90, 1), col('contact', '', 19, 60, 1), col('failures', '', 9, 40, 1)], width));
}
module.exports = { fit, columns, line, table, geometry, makePanels, metrics, statistics, shortAgent };
