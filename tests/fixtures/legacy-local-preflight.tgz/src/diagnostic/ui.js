'use strict';
const { rows, cpu, bytes, count } = require('./format');
const { text } = require('./safe');
const path = require('node:path');

const views = ['Przegląd', 'Agenci', 'Zadania', 'Logi', 'System'];
async function runTUI(provider, { refresh = 1000, termkit = require('terminal-kit') } = {}) {
  const term = termkit.terminal;
  const ui = { view: 0, cursor: 0, top: 0, query: '', search: false, hideInfo: false, hideHeartbeat: true,
    errorsOnly: false, frozen: false, follow: true, help: false, detail: null, notice: '' };
  let snapshot = null, latest = null, buffer, content = [], closed = false, pending = false, generation = 0;
  let resolve, reject;
  const ended = new Promise((a, b) => { resolve = a; reject = b; });
  const styles = { normal: { color: 'white', bgColor: 'black' }, muted: { color: 'gray', bgColor: 'black' },
    heading: { color: 'cyan', bgColor: 'black', bold: true }, warn: { color: 'yellow', bgColor: 'black' },
    error: { color: 'red', bgColor: 'black', bold: true }, success: { color: 'green', bgColor: 'black' } };
  function put(y, value, style = 'normal') {
    if (y < 0 || y >= term.height) return;
    buffer.put({ x: 0, y, attr: styles[style] || styles.normal, markup: false, wrap: false }, '%s', termkit.truncateString(text(value, 6000), Math.max(1, term.width - 1)));
  }
  function draw() {
    if (closed || !snapshot) return;
    if (!buffer || buffer.width !== term.width || buffer.height !== term.height) buffer = new termkit.ScreenBuffer({ dst: term, width: term.width, height: term.height });
    buffer.fill({ char: ' ', attr: styles.normal });
    put(0, ` fmcad diagnostic  |  ${snapshot.project ? path.basename(snapshot.project) : 'wszystkie projekty'}  ${ui.frozen ? ' [WIDOK ZAMROŻONY]' : ''}`, 'heading');
    put(1, ` ${snapshot.queue.brokerState === 'alive' ? 'Broker działa' : 'Broker: ' + snapshot.queue.brokerState}  ·  Czeka ${count(snapshot.queue.waiting)}  ·  Sesje ${count(snapshot.agents.liveSessions)}  ·  CPU ${cpu(snapshot.system.broker?.cpuPercent)}  RAM ${bytes(snapshot.system.broker?.rssBytes)}`,
      snapshot.queue.blocked ? 'error' : 'normal');
    put(2, views.map((v, i) => `${i === ui.view ? '▶' : ' '}[${i + 1}] ${v}`).join('   '), 'heading');
    const height = Math.max(1, term.height - 6);
    if (ui.help) {
      content = [
        'KLAWISZE', '1–5 / Tab: widok     ↑↓ / PgUp PgDn: przewijanie     Enter: szczegóły',
        '/: wyszukiwanie     i: ukryj/pokaż INFO     e: tylko WARN/ERROR     h: heartbeat',
        'p: następny projekt / wszystkie     a: następne archiwum godzinne',
        'G: koniec i śledzenie     g: początek     Spacja: zamroź tylko widok',
        'Esc: zamknij szczegóły / wyszukiwanie     q / Ctrl+C: wyjście', '',
        'Panel jest pasywny. Nie uruchamia Fusion ani brokera i nie rezerwuje kolejki.',
        'Sesje raportujące, klienci z zadaniami i hosty OpenCode to różne liczniki.',
        'Stare sesje bez pluginu telemetrii mają obecność nieznaną.',
        'Archiwa wybiera się dla konkretnego projektu. Czasy zdarzeń są lokalne.',
      ].map(line => ({ line, style: 'normal' }));
    } else if (ui.detail) {
      content = ['SZCZEGÓŁY — Esc: powrót', ...JSON.stringify(ui.detail, null, 2).split('\n')].map(line => ({ line: text(line, 4000), style: 'normal' }));
    } else content = rows(snapshot, ui.view, ui);
    ui.cursor = Math.max(0, Math.min(ui.cursor, content.length - 1));
    if (ui.follow && ui.view === 3 && !ui.help && !ui.detail) { ui.top = Math.max(0, content.length - height); ui.cursor = Math.max(0, content.length - 1); }
    else { if (ui.cursor < ui.top) ui.top = ui.cursor; if (ui.cursor >= ui.top + height) ui.top = ui.cursor - height + 1; }
    ui.top = Math.max(0, Math.min(ui.top, Math.max(0, content.length - height)));
    for (let i = 0; i < height; i++) {
      if (4 + i >= term.height - 2) break;
      const row = content[ui.top + i];
      if (!row) continue;
      if (ui.top + i === ui.cursor && row.detail) {
        const value = termkit.truncateString(text(row.line, 6000), Math.max(1, term.width - 1));
        buffer.put({ x: 0, y: 4 + i, attr: { color: 'white', bgColor: 'blue', bold: true }, wrap: false, markup: false }, '%s', value + ' '.repeat(Math.max(0, term.width - termkit.stringWidth(value) - 1)));
      } else put(4 + i, row.line, row.style);
    }
    put(term.height - 2, ui.search ? 'Szukaj: ' + ui.query + '▏' : ui.notice || `Filtr: ${ui.query || 'brak'}  ·  ${ui.hideInfo ? 'bez INFO' : 'INFO'}  ·  ${ui.hideHeartbeat ? 'bez heartbeat' : 'heartbeat'}  ·  ${ui.errorsOnly ? 'WARN/ERROR' : 'wszystkie poziomy'}`, 'muted');
    put(term.height - 1, ' [?] Pomoc  [/] Szukaj  [i] INFO  [e] Błędy  [p] Projekt  [a] Archiwum  [Spacja] Zamroź  [q] Wyjdź', 'heading');
    buffer.draw({ delta: true });
  }
  async function tick() {
    if (pending || closed) return;
    pending = true; const current = generation;
    try {
      const value = await provider.get();
      if (closed || generation !== current) return;
      latest = value;
      if (!ui.frozen || !snapshot) snapshot = value;
      draw();
    } catch (error) {
      ui.notice = 'Odczyt: ' + text(error.message);
      if (snapshot) draw();
      else finish(error);
    } finally { pending = false; }
  }
  function finish(error) {
    if (closed) return; closed = true; clearInterval(interval);
    term.removeListener('key', key); term.removeListener('resize', resize);
    process.removeListener('SIGINT', interrupt); process.removeListener('SIGTERM', interrupt);
    provider.close();
    try { term.grabInput(false); term.hideCursor(false); term.styleReset(); term.fullscreen(false); } catch { /* Best effort terminal restoration after terminal failure. */ }
    error ? reject(error) : resolve(0);
  }
  function key(name, matches, data) {
    if (name === 'CTRL_C') return finish();
    if (ui.search) {
      if (name === 'ENTER' || name === 'ESCAPE') ui.search = false;
      else if (name === 'BACKSPACE') ui.query = [...ui.query].slice(0, -1).join('');
      else if (data?.isCharacter && ui.query.length < 200) ui.query += text(name, 4);
      ui.cursor = 0; ui.top = 0; ui.follow = false; return draw();
    }
    if (name === 'q') return finish();
    if (name === 'ESCAPE') { ui.detail = null; ui.help = false; ui.notice = ''; ui.cursor = 0; ui.top = 0; }
    else if (name === '?') { ui.help = !ui.help; ui.detail = null; ui.cursor = 0; ui.top = 0; }
    else if (/^[1-5]$/.test(name) || name === 'TAB') { ui.view = name === 'TAB' ? (ui.view + 1) % 5 : Number(name) - 1; ui.detail = null; ui.help = false; ui.cursor = 0; ui.top = 0; }
    else if (name === '/') { ui.search = true; ui.detail = null; }
    else if (name === 'i') ui.hideInfo = !ui.hideInfo;
    else if (name === 'e') ui.errorsOnly = !ui.errorsOnly;
    else if (name === 'h') ui.hideHeartbeat = !ui.hideHeartbeat;
    else if (name === 'UP' || name === 'DOWN') { ui.cursor += name === 'UP' ? -1 : 1; ui.follow = false; }
    else if (name === 'PAGE_UP' || name === 'PAGE_DOWN') { ui.cursor += (name === 'PAGE_UP' ? -1 : 1) * Math.max(1, term.height - 8); ui.follow = false; }
    else if (name === 'g') { ui.cursor = 0; ui.top = 0; ui.follow = false; }
    else if (['G', 'SHIFT_G', 'END'].includes(name)) { ui.cursor = Math.max(0, content.length - 1); ui.follow = true; }
    else if (name === ' ') { ui.frozen = !ui.frozen; if (!ui.frozen && latest) snapshot = latest; }
    else if (name === 'ENTER') {
      const detail = content[ui.cursor]?.detail;
      if (detail) { ui.detail = detail.type === 'job' ? provider.details(detail.id) : detail.value; ui.cursor = 0; ui.top = 0; }
    } else if (name === 'p' && snapshot) {
      const choices = [null, ...snapshot.projects.map(project => project.path)];
      provider.setProject(choices[(choices.indexOf(snapshot.project) + 1) % choices.length]);
      generation++; ui.detail = null; ui.cursor = 0; ui.top = 0; ui.notice = ''; void tick();
    } else if (name === 'a' && snapshot) {
      if (!snapshot.project) ui.notice = 'Najpierw wybierz projekt klawiszem p.';
      else {
        const choices = snapshot.logs.archives;
        if (choices.length) {
          const index = choices.indexOf(path.basename(snapshot.logs.file || 'fmcad.log'));
          provider.setArchive(choices[(index + 1) % choices.length]); generation++; ui.cursor = 0; ui.top = 0; ui.follow = true; void tick();
        }
      }
    }
    draw();
  }
  const resize = () => { buffer = null; draw(); };
  const interrupt = () => finish();
  let interval;
  try {
    term.fullscreen(true); term.hideCursor(true); term.grabInput({ mouse: false });
    term.on('key', key); term.on('resize', resize);
    process.once('SIGINT', interrupt); process.once('SIGTERM', interrupt);
    interval = setInterval(() => { void tick(); }, refresh);
    await tick();
  } catch (error) { finish(error); }
  return ended;
}
module.exports = { runTUI };
