'use strict';
const path = require('node:path');
const { text } = require('./safe');
const { fit, columns, line, makePanels, metrics, statistics } = require('./layout');
const viewport = require('./viewport');

const views = ['Przegląd', 'Agenci', 'Zadania', 'Logi', 'System'];
async function runTUI(provider, { refresh = 1000, termkit = require('terminal-kit') } = {}) {
  const term = termkit.terminal;
  const ui = { view: 0, query: '', search: false, hideInfo: false, hideHeartbeat: true,
    errorsOnly: false, frozen: false, help: false, detail: null, notice: '' };
  const states = new Map();
  let snapshot, latest, buffer, panels = [], focused = 'jobs', drag = null;
  let closed = false, pending = false, generation = 0, interval;
  let resolve, reject;
  const ended = new Promise((a, b) => { resolve = a; reject = b; });
  const styles = {
    normal: { color: 252, bgColor: 234 }, muted: { color: 244, bgColor: 234 },
    heading: { color: 81, bgColor: 234, bold: true }, header: { color: 117, bgColor: 237, bold: true },
    warn: { color: 221, bgColor: 234 }, error: { color: 203, bgColor: 234, bold: true },
    success: { color: 114, bgColor: 234 }, border: { color: 240, bgColor: 234 },
    focus: { color: 81, bgColor: 234 }, selected: { color: 255, bgColor: 24, bold: true },
  };
  function stateFor(panel) {
    const key = `${snapshot?.project || '*'}:${ui.view}:${panel.id}`;
    if (!states.has(key)) states.set(key, { cursor: 0, top: 0, follow: panel.id === 'logs', interacted: false });
    return states.get(key);
  }
  function put(x, y, value, width, style = 'normal', alternate = false) {
    if (y < 0 || y >= term.height || x < 0 || x >= term.width || width <= 0) return;
    const attr = { ...(styles[style] || styles.normal) };
    if (alternate && style !== 'selected') attr.bgColor = 235;
    buffer.put({ x, y, attr, markup: false, wrap: false }, '%s', fit(value, Math.min(width, term.width - x)));
  }
  function drawPanel(panel) {
    const { x, y, w, h } = panel, state = stateFor(panel), isFocused = focused === panel.id;
    const border = isFocused ? 'focus' : 'border';
    if (w < 3 || h < 2) { put(x, y, panel.title, w, border); return; }
    put(x, y, '┌' + '─'.repeat(Math.max(0, w - 2)) + '┐', w, border);
    const caption = `${isFocused ? '▶ ' : ''}${panel.title}`;
    put(x + 2, y, ' ' + caption + ' ', Math.max(0, Math.min(w - 4, termkit.stringWidth(caption) + 2)), border);
    for (let row = 1; row < h - 1; row++) { put(x, y + row, '│', 1, border); put(x + w - 1, y + row, '│', 1, border); }
    if (h >= 3) put(x + 1, y + 1, panel.subtitle, w - 2, 'muted');
    if (h >= 4) put(x + 1, y + 2, panel.header, panel.contentWidth, 'header');
    const bar = viewport.scrollbar(panel.rows.length, panel.bodyHeight, state.top);
    for (let row = 0; row < panel.bodyHeight; row++) {
      const index = state.top + row, value = panel.rows[index];
      if (value) put(x + 1, panel.bodyY + row, value.line, panel.contentWidth,
        isFocused && index === state.cursor && value.detail ? 'selected' : value.style, index % 2 === 1);
      put(x + w - 2, panel.bodyY + row, bar.overflow && row >= bar.start && row < bar.start + bar.size ? '█' : '│', 1,
        bar.overflow ? isFocused ? 'focus' : 'border' : 'muted');
    }
    put(x, y + h - 1, '└' + '─'.repeat(Math.max(0, w - 2)) + '┘', w, border);
    const range = panel.rows.length && panel.bodyHeight ? `${state.top + 1}–${Math.min(panel.rows.length, state.top + panel.bodyHeight)} / ${panel.rows.length}` : '0 / ' + panel.rows.length;
    const label = ' ' + range + (panel.id === 'logs' && state.follow ? ' LIVE' : '') + ' ';
    const labelWidth = Math.min(w - 4, termkit.stringWidth(label));
    if (labelWidth > 0) put(x + w - labelWidth - 2, y + h - 1, label, labelWidth, 'muted');
  }
  function draw(preserve = false) {
    if (closed || !snapshot) return;
    const previous = new Map(panels.map(panel => [panel.id, panel.rows]));
    panels = makePanels(snapshot, ui.view, ui, term.width, term.height);
    if (!panels.some(panel => panel.id === focused)) focused = panels[0]?.id || null;
    for (const panel of panels) {
      const state = stateFor(panel);
      if (preserve) viewport.preserve(state, previous.get(panel.id) || [], panel.rows, panel.bodyHeight);
      else {
        if (state.follow) { state.top = Math.max(0, panel.rows.length - panel.bodyHeight); state.cursor = Math.max(0, panel.rows.length - 1); }
        viewport.clamp(state, panel.rows.length, panel.bodyHeight);
      }
    }
    if (!buffer || buffer.width !== term.width || buffer.height !== term.height) buffer = new termkit.ScreenBuffer({ dst: term, width: term.width, height: term.height });
    buffer.fill({ char: ' ', attr: styles.normal });
    const width = Math.max(1, term.width);
    const brand = ui.frozen ? 'fmcad · WIDOK ZAMROŻONY' : 'fmcad diagnostic';
    const head = columns([{ key: 'brand', min: Math.min(26, width), priority: 100 },
      { key: 'project', min: 12, priority: 50, grow: 1 }], width);
    put(0, 0, line({ brand, project: snapshot.project || 'wszystkie projekty' }, head), width, 'heading');
    put(0, 1, metrics(snapshot, width), width, snapshot.queue.blocked ? 'error' : 'header');
    const narrow = width < 100;
    put(0, 2, views.map((view, i) => `${i === ui.view ? '▶' : ' '}[${i + 1}]${narrow ? '' : ' '}${view}`).join(narrow ? ' ' : '   '), width, 'heading');
    const alert = snapshot.alerts.find(value => value.level === 'ERROR') || snapshot.alerts[0];
    put(0, 3, alert ? `${alert.level} (${snapshot.alerts.length}): ${alert.message}` : snapshot.queue.reason, width,
      alert?.level === 'ERROR' ? 'error' : alert ? 'warn' : 'muted');
    for (const panel of panels) drawPanel(panel);
    put(0, term.height - 3, statistics(snapshot, width), width, 'muted');
    const active = panels.find(panel => panel.id === focused);
    const filter = ui.search ? 'Szukaj: ' + ui.query + '▏' : ui.notice || `Panel: ${active?.title || '—'} · ${ui.hideInfo ? 'bez INFO' : 'INFO'} · ${ui.errorsOnly ? 'WARN/ERROR' : 'wszystkie poziomy'} · filtr: ${ui.query || 'brak'}`;
    put(0, term.height - 2, filter, width, 'muted');
    put(0, term.height - 1, width >= 110
      ? '[1–5] Widoki  [Tab] Panel  [↕/kółko] Przewiń panel  [Enter] Szczegóły  [/] Szukaj  [i] INFO  [?] Pomoc  [q] Wyjdź'
      : '[1–5] Widok [Tab] Panel [↕] Scroll [/] Szukaj [?] Pomoc [q] Wyjdź', width, 'heading');
    buffer.draw({ delta: true });
  }
  async function tick() {
    if (pending || closed) return;
    pending = true; const current = generation;
    try {
      const value = await provider.get();
      if (closed || current !== generation) return;
      latest = value;
      if (!ui.frozen || !snapshot) snapshot = value;
      draw(true);
    } catch (error) {
      ui.notice = 'Odczyt: ' + text(error.message);
      if (snapshot) draw(); else finish(error);
    } finally { pending = false; }
  }
  function finish(error) {
    if (closed) return;
    closed = true; clearInterval(interval);
    term.removeListener('key', key); term.removeListener('resize', resize); term.removeListener('mouse', mouse);
    process.removeListener('SIGINT', interrupt); process.removeListener('SIGTERM', interrupt);
    provider.close();
    try { term.grabInput(false); term.hideCursor(false); term.styleReset(); term.fullscreen(false); } catch { /* Restore what remains available. */ }
    error ? reject(error) : resolve(0);
  }
  function resetPositions() {
    for (const state of states.values()) Object.assign(state, { cursor: 0, top: 0, follow: false, interacted: false });
  }
  function key(name, matches, data) {
    if (name === 'CTRL_C') return finish();
    if (ui.search) {
      if (['ENTER', 'ESCAPE'].includes(name)) ui.search = false;
      else if (name === 'BACKSPACE') ui.query = [...ui.query].slice(0, -1).join('');
      else if (name === 'CTRL_U') ui.query = '';
      else if (data?.isCharacter && ui.query.length < 200) ui.query += text(name, 4);
      resetPositions(); return draw();
    }
    if (name === 'q') return finish();
    const panel = panels.find(value => value.id === focused), state = panel && stateFor(panel);
    if (name === 'ESCAPE') { ui.detail = null; ui.help = false; ui.notice = ''; }
    else if (name === '?') { ui.help = !ui.help; ui.detail = null; }
    else if (/^[1-5]$/.test(name)) { ui.view = Number(name) - 1; ui.detail = null; ui.help = false; }
    else if (name === 'TAB' || name === 'SHIFT_TAB') {
      const index = panels.findIndex(value => value.id === focused);
      focused = panels[(index + (name === 'TAB' ? 1 : -1) + panels.length) % panels.length]?.id;
    } else if (name === '/') { ui.search = true; ui.detail = null; }
    else if (name === 'c') { ui.query = ''; resetPositions(); }
    else if (name === 'i') ui.hideInfo = !ui.hideInfo;
    else if (name === 'e') ui.errorsOnly = !ui.errorsOnly;
    else if (name === 'h') ui.hideHeartbeat = !ui.hideHeartbeat;
    else if (state && ['UP', 'DOWN', 'PAGE_UP', 'PAGE_DOWN'].includes(name)) {
      viewport.move(state, (name.includes('UP') ? -1 : 1) * (name.startsWith('PAGE') ? Math.max(1, panel.bodyHeight - 1) : 1), panel.rows.length, panel.bodyHeight);
    } else if (state && name === 'g') { Object.assign(state, { cursor: 0, top: 0, follow: false, interacted: false }); }
    else if (state && ['G', 'SHIFT_G', 'END'].includes(name)) {
      Object.assign(state, { cursor: Math.max(0, panel.rows.length - 1), top: Math.max(0, panel.rows.length - panel.bodyHeight), follow: panel.id === 'logs', interacted: true });
    } else if (name === ' ') { ui.frozen = !ui.frozen; if (!ui.frozen && latest) snapshot = latest; return draw(true); }
    else if (name === 'ENTER' && panel) {
      const detail = panel.rows[state.cursor]?.detail;
      if (detail) ui.detail = detail.type === 'job'
        ? { ...snapshot.jobs.find(job => job.id === detail.id), ...provider.details(detail.id) } : detail.value;
    } else if (name === 'p' && snapshot) {
      const choices = [null, ...snapshot.projects.map(value => value.path)];
      provider.setProject(choices[(choices.indexOf(snapshot.project) + 1) % choices.length]);
      generation++; ui.detail = null; ui.frozen = false; ui.notice = 'Wczytywanie projektu…'; void tick();
    } else if (name === 'a' && snapshot) {
      if (!snapshot.project) ui.notice = 'Najpierw wybierz projekt klawiszem p.';
      else if (snapshot.logs.archives.length) {
        const choices = snapshot.logs.archives, index = choices.indexOf(path.basename(snapshot.logs.file || 'fmcad.log'));
        provider.setArchive(choices[(index + 1) % choices.length]); generation++; ui.frozen = false; resetPositions(); void tick();
      }
    }
    draw();
  }
  function mouse(name, data) {
    if (ui.search || !snapshot) return;
    const x = data.x - 1, y = data.y - 1;
    if (name === 'MOUSE_LEFT_BUTTON_RELEASED') { drag = null; return; }
    const panel = drag && name === 'MOUSE_DRAG' ? panels.find(value => value.id === drag)
      : panels.find(value => x >= value.x && x < value.x + value.w && y >= value.y && y < value.y + value.h);
    if (!panel) return;
    const state = stateFor(panel);
    if (['MOUSE_WHEEL_UP', 'MOUSE_WHEEL_DOWN'].includes(name)) {
      focused = panel.id; viewport.scroll(state, name === 'MOUSE_WHEEL_UP' ? -3 : 3, panel.rows.length, panel.bodyHeight);
    } else if (name === 'MOUSE_LEFT_BUTTON_PRESSED' || name === 'MOUSE_DRAG' && drag) {
      focused = panel.id;
      if (drag || x === panel.x + panel.w - 2 && y >= panel.bodyY && y < panel.bodyY + panel.bodyHeight) {
        drag = panel.id; viewport.seek(state, y - panel.bodyY, panel.rows.length, panel.bodyHeight);
      } else if (y >= panel.bodyY && y < panel.bodyY + panel.bodyHeight) {
        Object.assign(state, { cursor: Math.min(panel.rows.length - 1, state.top + y - panel.bodyY), follow: false, interacted: true });
      }
    } else return;
    draw();
  }
  const resize = () => { buffer = null; draw(true); };
  const interrupt = () => finish();
  try {
    term.fullscreen(true); term.hideCursor(true); term.grabInput({ mouse: 'drag' });
    term.on('key', key); term.on('resize', resize); term.on('mouse', mouse);
    process.once('SIGINT', interrupt); process.once('SIGTERM', interrupt);
    interval = setInterval(() => { void tick(); }, refresh);
    await tick();
  } catch (error) { finish(error); }
  return ended;
}
module.exports = { runTUI };
