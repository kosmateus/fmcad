'use strict';
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { execFile } = require('node:child_process');
const { text } = require('./safe');

function processInfo(pid, proc = '/proc') {
  if (!Number.isSafeInteger(pid) || pid <= 0) return null;
  try {
    const raw = fs.readFileSync(path.join(proc, String(pid), 'stat'), 'utf8');
    const fields = raw.slice(raw.lastIndexOf(')') + 2).trim().split(/\s+/);
    const boot = fs.readFileSync(path.join(proc, 'sys/kernel/random/boot_id'), 'utf8').trim();
    const status = fs.readFileSync(path.join(proc, String(pid), 'status'), 'utf8');
    return { pid, parentPid: Number(fields[1]), state: fields[0], birth: boot + ':' + fields[19],
      ticks: Number(fields[11]) + Number(fields[12]), rssBytes: Number(status.match(/^VmRSS:\s+(\d+)/m)?.[1] || 0) * 1024,
      alive: !['Z', 'X'].includes(fields[0]), stopped: ['T', 't'].includes(fields[0]) };
  } catch { return null; }
}
class SystemSampler {
  constructor({ proc = '/proc', now = Date.now } = {}) { this.proc = proc; this.now = now; this.previous = new Map(); this.hostPrevious = null; this.hosts = []; this.scanAt = -Infinity; }
  cpuTotals() {
    try {
      const values = fs.readFileSync(path.join(this.proc, 'stat'), 'utf8').split('\n')[0].trim().split(/\s+/).slice(1).map(Number);
      // guest/guest_nice are already included in user/nice.
      return { total: values.slice(0, 8).reduce((a, b) => a + b, 0), idle: values[3] + (values[4] || 0) };
    } catch { return null; }
  }
  sampleProcess(pid, expectedBirth, totals) {
    const value = processInfo(pid, this.proc);
    if (!value || expectedBirth && value.birth !== expectedBirth) return { pid, available: false, state: 'unavailable', cpuPercent: null, rssBytes: null };
    const previous = this.previous.get(pid), now = this.now();
    let cpuPercent = null;
    if (previous && previous.birth === value.birth && totals && totals.total > previous.total) {
      cpuPercent = Math.max(0, (value.ticks - previous.ticks) / (totals.total - previous.total) * os.cpus().length * 100);
    }
    this.previous.set(pid, { birth: value.birth, ticks: value.ticks, total: totals?.total, at: now });
    return { pid, birth: value.birth, available: value.alive, state: value.stopped ? 'stopped' : value.alive ? 'alive' : 'exited',
      cpuPercent, rssBytes: value.rssBytes, stopped: value.stopped };
  }
  scanHosts() {
    if (this.now() - this.scanAt < 5000) return this.hosts;
    this.scanAt = this.now(); const hosts = [];
    try {
      for (const name of fs.readdirSync(this.proc)) {
        if (!/^\d+$/.test(name)) continue;
        try {
          const argv = fs.readFileSync(path.join(this.proc, name, 'cmdline'), 'utf8').split('\0').filter(Boolean);
          const executable = path.basename(argv[0] || '');
          const role = executable === 'opencode' ? 'opencode' : argv.some(arg => path.basename(arg) === 'fmcad-mcp.js') ? 'mcp' : null;
          if (!role) continue;
          const info = processInfo(Number(name), this.proc);
          if (!info?.alive) continue;
          let cwd = null;
          try { cwd = fs.readlinkSync(path.join(this.proc, name, 'cwd')); } catch { /* Unknown, not the current cwd. */ }
          hosts.push({ pid: info.pid, parentPid: info.parentPid, birth: info.birth, stopped: info.stopped, role, project: cwd ? text(cwd) : null });
        } catch { /* Other users' processes may not be readable. */ }
      }
    } catch { /* /proc is optional on other hosts. */ }
    this.hosts = hosts; return hosts;
  }
  sample(owner, worker, presencePids = []) {
    const totals = this.cpuTotals(), hostPrevious = this.hostPrevious;
    const hostCpu = hostPrevious && totals && totals.total > hostPrevious.total
      ? Math.max(0, 100 * (1 - (totals.idle - hostPrevious.idle) / (totals.total - hostPrevious.total))) : null;
    this.hostPrevious = totals;
    const identities = new Map([[process.pid, { pid: process.pid }]]);
    for (const identity of [owner, worker, ...presencePids].filter(Boolean)) identities.set(identity.pid, identity);
    const processes = [...identities.values()].map(identity => this.sampleProcess(identity.pid, identity.birth, totals));
    for (const [pid, item] of this.previous) if (this.now() - item.at > 60000) this.previous.delete(pid);
    return { host: { cpuPercent: hostCpu, memoryUsedBytes: os.totalmem() - os.freemem(), memoryTotalBytes: os.totalmem(), loadAverage: os.loadavg(), uptimeSeconds: os.uptime() },
      panel: processes.find(p => p.pid === process.pid), broker: processes.find(p => p.pid === owner?.pid) || null,
      worker: processes.find(p => p.pid === worker?.pid) || null, processes, hosts: this.scanHosts() };
  }
}
class LockSampler {
  constructor({ now = Date.now, run = execFile, proc = '/proc' } = {}) { this.now = now; this.run = run; this.proc = proc; this.cache = { at: 0, available: false, holders: [] }; this.pending = false; this.project = null; }
  sample(project) {
    if (!project) return Promise.resolve({ available: false, reason: 'Nie wybrano projektu', holders: [] });
    if (this.pending || this.project === project && this.now() - this.cache.at < 5000) return Promise.resolve(this.cache);
    this.pending = true; this.project = project;
    return new Promise(resolve => this.run('lslocks', ['--json', '-o', 'PID,COMMAND,TYPE,MODE,PATH'], { timeout: 1000, maxBuffer: 512 * 1024, encoding: 'utf8' }, (error, stdout) => {
      try {
        if (error) throw error;
        const rows = JSON.parse(stdout).locks || [];
        const holders = rows.filter(row => typeof row.path === 'string' && row.path.startsWith(path.join(project, '.beads') + path.sep)).map(row => {
          const info = processInfo(Number(row.pid), this.proc);
          return { pid: Number(row.pid), command: text(row.command), path: text(row.path), mode: text(row.mode), stopped: info?.stopped ?? null };
        });
        this.cache = { at: this.now(), available: true, holders };
      } catch { this.cache = { at: this.now(), available: false, reason: 'Odczyt blokad systemowych niedostępny', holders: [] }; }
      this.pending = false; resolve(this.cache);
    }));
  }
}
module.exports = { processInfo, SystemSampler, LockSampler };
