'use strict';
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

const stateRoot = () => path.join(process.env.XDG_STATE_HOME || path.join(os.homedir(), '.local', 'state'), 'fmcad');
function readJson(file, limit = 64 * 1024 * 1024) {
  const fd = fs.openSync(file, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW | fs.constants.O_NONBLOCK);
  try {
    const stat = fs.fstatSync(fd);
    if (!stat.isFile() || stat.size > limit) throw Object.assign(Error('Invalid diagnostic input'), { code: 'INVALID_SNAPSHOT' });
    return JSON.parse(fs.readFileSync(fd, 'utf8'));
  } finally { fs.closeSync(fd); }
}
class JsonCache {
  constructor(capacity = 2048) { this.entries = new Map(); this.reads = 0; this.capacity = capacity; }
  get(file, limit) {
    try {
      const stat = fs.statSync(file), stamp = `${stat.ino}:${stat.size}:${stat.mtimeMs}`;
      const previous = this.entries.get(file);
      if (previous?.stamp === stamp) { this.entries.delete(file); this.entries.set(file, previous); return previous; }
      const value = readJson(file, limit);
      this.reads++;
      const result = { value, stamp, modifiedAt: stat.mtimeMs, error: null };
      this.entries.set(file, result);
      if (this.entries.size > this.capacity) this.entries.delete(this.entries.keys().next().value);
      return result;
    } catch (error) {
      const previous = this.entries.get(file);
      return { value: previous?.value || null, stamp: previous?.stamp, modifiedAt: previous?.modifiedAt || null, error: error.code || 'INVALID_JSON' };
    }
  }
}
module.exports = { stateRoot, readJson, JsonCache };
