'use strict';
const { stripVTControlCharacters } = require('node:util');
const path = require('node:path');

function text(value, limit = 500) {
  return stripVTControlCharacters(String(value ?? '')).replace(/[\x00-\x1f\x7f-\x9f]/g, ' ')
    .replace(/\bBearer\s+\S+/gi, 'Bearer [REDACTED]')
    .replace(/\b(clientToken|ownerToken|authorization|api[_-]?key|access[_-]?token|refresh[_-]?token)["']?\s*[=:]\s*["']?[^\s,;"']+/gi, '$1=[REDACTED]')
    .slice(0, limit);
}
const short = value => text(value, 120);
const finite = value => Number.isFinite(value) ? value : null;
const within = (file, directory) => file === directory || file.startsWith(directory + path.sep);
function target(argv = []) {
  if (!Array.isArray(argv)) argv = [];
  const value = flag => { const i = argv.indexOf(flag); return i >= 0 ? short(argv[i + 1]) : null; };
  return { name: value('--doc'), creationId: value('--doc-id'), fileId: value('--doc-file-id') };
}
function command(job) {
  if (job.kind === 'rpc') {
    const payload = job.request?.payload || job.request?.rpc?.payload;
    return short(payload?.method === 'tools/call' ? payload.params?.name || 'tools/call' : payload?.method || 'RPC');
  }
  const argv = Array.isArray(job.request?.argv) ? job.request.argv : [];
  const name = short(argv[0] || 'polecenie');
  if (name === 'run') return 'run ' + short(path.basename(argv[1] || 'skrypt'));
  // Never display arbitrary positional JSON, arguments, script bodies or headers.
  return name;
}
module.exports = { text, short, finite, within, target, command };
