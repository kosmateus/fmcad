'use strict';
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const os = require('node:os');
const { createHash } = require('node:crypto');
const { stateRoot, JsonCache } = require('./files');
const { text, short, within, target, command } = require('./safe');
const { processInfo, SystemSampler, LockSampler } = require('./system');
const { LogTail, archives } = require('./logs');

const terminal = new Set(['succeeded', 'failed', 'expired', 'cancelled']);
const statuses = new Set(['queued', 'running', 'sending', 'needs_reconciliation', ...terminal]);
function workspace(cwd) {
  if (typeof cwd !== 'string' || !path.isAbsolute(cwd)) return null;
  const parts = path.resolve(cwd).split(path.sep), index = parts.findIndex(p => ['.cad', '.fmcad-batch'].includes(p));
  return index >= 0 ? parts.slice(0, index).join(path.sep) || path.sep : path.resolve(cwd);
}
function percentile(values, p) {
  if (!values.length) return null;
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.min(sorted.length - 1, Math.ceil(sorted.length * p) - 1)];
}
function safeJob(job) {
  return { id: short(job.id), clientId: short(job.clientId), kind: short(job.kind), command: command(job),
    project: workspace(job.request?.cwd), document: target(job.request?.argv),
    state: statuses.has(job.state) ? job.state : 'unknown', code: short(job.code) || null,
    submittedAt: Number.isFinite(job.submittedAt) ? job.submittedAt : null,
    startedAt: Number.isFinite(job.startedAt) ? job.startedAt : null,
    finishedAt: Number.isFinite(job.finishedAt) ? job.finishedAt : null,
    queueDeadline: Number.isFinite(job.queueDeadline) ? job.queueDeadline : null,
    timeoutMs: Number.isFinite(job.timeoutMs) ? job.timeoutMs : null,
    order: Number.isFinite(job.order) ? job.order : 0, sequenceId: short(job.sequenceId) || null,
    sequenceMode: short(job.sequenceMode) || null, sequenceState: short(job.sequenceState) || null,
    executionOutcome: short(job.details?.executionOutcome) || null,
    rpc: Number.isFinite(job.dispatch?.rpcCount) ? job.dispatch.rpcCount : null,
    ack: Number.isFinite(job.dispatch?.completedCount) ? job.dispatch.completedCount : null,
    stageAt: Number.isFinite(job.dispatch?.updatedAt) ? job.dispatch.updatedAt : null };
}

class ObserverReader {
  constructor(root, queueDir, cache, now) { Object.assign(this, { root, queueDir, cache, now }); this.retryAt = 0; }
  async get(project, archive) {
    if (this.now() < this.retryAt) return null;
    const key = createHash('sha256').update((process.getuid?.() ?? 'user') + ':' + this.queueDir).digest('hex').slice(0, 28);
    const control = this.cache.get(path.join(this.root, 'project-logs-' + key, 'observer.json'), 8192).value;
    if (!control?.token) { this.retryAt = this.now() + 30000; return null; }
    try {
      return await new Promise((resolve, reject) => {
        const socket = net.createConnection({ path: '\0fmcad-project-logs-' + key });
        let buffer = '', finished = false;
        const done = (error, value) => { if (finished) return; finished = true; clearTimeout(timer); socket.destroy(); error ? reject(error) : resolve(value); };
        const timer = setTimeout(() => done(Error('observer timeout')), 250);
        socket.on('connect', () => socket.write(JSON.stringify({ method: 'diagnostic', token: control.token, project, archive }) + '\n'));
        socket.on('error', error => done(error));
        socket.on('end', () => { if (!finished) done(Error('observer disconnected')); });
        socket.on('data', bytes => {
          buffer += bytes.toString('utf8');
          if (Buffer.byteLength(buffer) > 4 * 1024 * 1024) return done(Error('observer result too large'));
          if (!buffer.includes('\n')) return;
          try {
            const value = JSON.parse(buffer.slice(0, buffer.indexOf('\n')));
            if (!value.ok || value.snapshot?.schemaVersion !== 1) return done(Error('older observer'));
            done(null, value.snapshot);
          } catch (error) { done(error); }
        });
      });
    } catch { this.retryAt = this.now() + 30000; return null; }
  }
}

class DiagnosticProvider {
  constructor({ root = stateRoot(), project = null, now = Date.now, useObserver = true,
    system, locks, presenceDirectory } = {}) {
    Object.assign(this, { root, now, project: project ? path.resolve(project) : null });
    this.queueDir = path.join(root, 'queue'); this.cache = new JsonCache();
    this.observations = new JsonCache(8);
    this.system = system || new SystemSampler({ now }); this.locks = locks || new LockSampler({ now });
    this.presenceDirectory = presenceDirectory || path.join(root, 'diagnostic-presence');
    this.observer = useObserver ? new ObserverReader(root, this.queueDir, this.cache, now) : null;
    this.queueStamp = null; this.jobs = []; this.byId = new Map(); this.lastQueue = null;
    this.tails = new Map(); this.archive = null; this.lastSnapshot = null;
  }
  resetTails() { for (const tail of this.tails.values()) tail.close(); this.tails.clear(); }
  setProject(project) { this.project = project ? path.resolve(project) : null; this.archive = null; this.resetTails(); }
  setArchive(name) { this.archive = name && /^fmcad(?:-\d{4}-\d\d-\d\d_\d\d)?\.log$/.test(name) ? name : null; this.resetTails(); }
  presence() {
    const sessions = new Map(); let sourceAvailable = false, limited = false;
    try {
      const files = fs.readdirSync(this.presenceDirectory).filter(name => /^\d+-[a-f0-9-]+\.json$/.test(name));
      sourceAvailable = true; limited = files.length > 1000;
      for (const file of files.slice(-1000)) {
        const value = this.cache.get(path.join(this.presenceDirectory, file), 1024 * 1024).value;
        if (value?.schemaVersion !== 1 || !Number.isFinite(value.updatedAt) || !Array.isArray(value.sessions)) continue;
        const info = processInfo(value.pid);
        const sameProcess = !!(info && info.birth === value.birth && info.alive);
        for (const item of value.sessions.slice(0, 200)) {
          if (typeof item.id !== 'string') continue;
          const status = item.status === 'ended' ? 'ended' : !sameProcess ? 'ended' : info.stopped ? 'stopped'
            : this.now() - value.updatedAt > 30000 ? 'stale' : ['busy', 'idle', 'retry'].includes(item.status) ? item.status : 'unknown';
          const session = { id: short(item.id), clientId: short(item.clientId) || null,
            title: text(item.title || item.agent || 'Sesja', 180), agent: short(item.agent) || null,
            project: workspace(item.project), status, pid: value.pid, birth: short(value.birth),
            lastActivityAt: Number.isFinite(item.lastActivityAt) ? item.lastActivityAt : null,
            observedAt: value.updatedAt, lastTool: short(item.lastTool) || null, telemetry: 'reported',
            connected: sameProcess && !info.stopped && this.now() - value.updatedAt <= 30000 && item.status !== 'ended' };
          const key = session.project + ':' + session.id;
          if (!sessions.has(key) || sessions.get(key).observedAt < session.observedAt) sessions.set(key, session);
        }
      }
    } catch { /* Existing sessions without the plugin are unknown, not disconnected. */ }
    return { available: sourceAvailable, limited, sessions: [...sessions.values()] };
  }
  knownProjects(presence) {
    const values = new Set(this.jobs.map(j => j.project).filter(Boolean));
    for (const session of presence.sessions) if (session.project) values.add(session.project);
    try {
      for (const name of fs.readdirSync(this.root).filter(n => n.startsWith('project-logs-'))) {
        const cursor = this.cache.get(path.join(this.root, name, 'cursor.json'), 1024 * 1024).value;
        for (const file of cursor?.projects || []) {
          if (typeof file !== 'string') continue;
          const suffix = path.join('.cad', 'logs', 'fmcad.log');
          if (file.endsWith(path.sep + suffix)) values.add(file.slice(0, -suffix.length - 1));
          else if (path.basename(file) === 'fmcad.log') values.add(path.dirname(file));
        }
      }
    } catch { /* No observer has run yet. */ }
    if (this.project) values.add(this.project);
    return [...values].sort().map(value => ({ path: text(value), name: text(path.basename(value)) }));
  }
  async get({ queueData } = {}) {
    if (this.observer && queueData === undefined) {
      const shared = await this.observer.get(this.project, this.archive);
      if (shared) {
        const local = this.system.sample(null, null);
        shared.system = { ...shared.system, collector: shared.system.panel, panel: local.panel };
        this.byId = new Map(shared.jobs.map(job => [job.id, job]));
        this.lastSnapshot = shared; return shared;
      }
    }
    const now = this.now();
    const record = queueData ? { value: queueData, stamp: queueData, modifiedAt: now, error: null }
      : this.cache.get(path.join(this.queueDir, 'queue-state.json'));
    let queueError = record.error;
    if (record.value && (record.value.version !== 1 || !record.value.jobs || Array.isArray(record.value.jobs))) queueError = 'UNSUPPORTED_SNAPSHOT';
    if (!queueError && record.stamp !== this.queueStamp) {
      this.lastQueue = record.value; this.queueStamp = record.stamp;
      this.jobs = Object.values(record.value.jobs).filter(job => job && typeof job.id === 'string').map(safeJob).sort((a, b) => b.order - a.order);
      this.byId = new Map(this.jobs.map(job => [job.id, job]));
    }
    const data = this.lastQueue, presence = this.presence();
    const ownerRecord = this.cache.get(path.join(this.queueDir, 'broker.lock'), 8192);
    const owner = ownerRecord.error ? null : ownerRecord.value;
    const diagnostic = this.cache.get(path.join(this.queueDir, 'queue-diagnostics.json'), 65536).value;
    const instanceRecord = this.cache.get(path.join(this.queueDir, 'instance.json'));
    const active = this.jobs.find(job => job.id === data?.active) || null;
    let fusionObservation = { instance: instanceRecord.value?.instance, at: instanceRecord.modifiedAt };
    const observedJobs = new Map([active, ...this.jobs.filter(job => job.startedAt !== null).slice(0, 3)].filter(Boolean).map(job => [job.id, job]));
    for (const job of observedJobs.values()) {
      if (!/^[A-Za-z0-9_-]{1,120}$/.test(job.id)) continue;
      for (const name of ['postflight.json', 'preflight.json']) {
        const record = this.observations.get(path.join(this.queueDir, 'jobs', job.id, name));
        const candidate = name === 'preflight.json' ? record.value?.instance : record.value;
        if (Number.isSafeInteger(candidate?.pid) && typeof candidate.birth === 'string' && typeof candidate.version === 'string' &&
            record.modifiedAt > (fusionObservation.at || 0)) fusionObservation = { instance: candidate, at: record.modifiedAt };
      }
    }
    const instance = fusionObservation.instance;
    const worker = active && /^[A-Za-z0-9_-]{1,120}$/.test(active.id) ? this.cache.get(path.join(this.queueDir, 'jobs', active.id, 'worker-identity.json'), 8192).value : null;
    const sessionRows = presence.sessions.filter(item => !this.project || item.project && within(item.project, this.project));
    const system = this.system.sample(owner, worker, sessionRows.map(s => ({ pid: s.pid, birth: s.birth })));
    const aliveBroker = !!(owner && system.broker?.available && !system.broker?.stopped);
    const allPending = this.jobs.filter(job => !terminal.has(job.state));
    const jobs = this.jobs.filter(job => !this.project || job.project && within(job.project, this.project));
    const ownPending = jobs.filter(job => !terminal.has(job.state));
    const lease = data?.lease ? { id: short(data.lease.id), clientId: short(data.lease.clientId), idleUntil: data.lease.idleUntil, holdUntil: data.lease.holdUntil } : null;
    const blocked = data?.blocked ? { id: short(data.blocked.id), reason: text(data.blocked.reason || 'Wymaga uzgodnienia'), at: data.blocked.at } : null;
    const leaseOwner = lease ? presence.sessions.find(session => session.clientId === lease.clientId)?.title || lease.clientId : null;
    const reason = !data ? 'Brak danych kolejki' : system.broker?.stopped ? 'Proces brokera jest wstrzymany (STOP)'
      : !aliveBroker ? 'Broker nie działa lub jego tożsamość jest niedostępna'
      : blocked ? 'Wynik poprzedniej operacji wymaga uzgodnienia' : data.paused ? 'Przyznawanie zadań jest wstrzymane'
        : active ? `Trwa ${active.command}${active.document.name ? ' · ' + active.document.name : ''}`
          : data.active ? 'Trwa zadanie — brak czytelnych szczegółów'
            : lease ? 'Wyłączna rezerwacja między poleceniami · ' + leaseOwner : 'Kolejka jest wolna';
    const sessionsByClient = new Map(sessionRows.filter(s => s.clientId).map(s => [s.clientId, s]));
    const clients = new Map();
    for (const job of jobs) {
      if (clients.has(job.clientId)) continue;
      const reported = sessionsByClient.get(job.clientId);
      clients.set(job.clientId, { id: job.clientId, title: reported?.title || short(job.clientId),
        project: job.project, status: reported?.status || 'unknown', telemetry: reported ? 'reported' : 'legacy',
        lastJobId: job.id, lastActivityAt: job.finishedAt || job.startedAt || job.submittedAt });
    }
    const visible = [...ownPending, ...jobs.filter(job => terminal.has(job.state))].slice(0, 200);
    const decorated = visible.map(job => ({ ...job,
      clientLabel: sessionsByClient.get(job.clientId)?.title || short(job.clientId),
      waitMs: job.submittedAt === null ? null : Math.max(0, (job.startedAt || job.finishedAt || now) - job.submittedAt),
      elapsedMs: job.startedAt === null ? null : Math.max(0, (job.finishedAt || now) - job.startedAt),
      waitingReason: job.state === 'queued' ? reason : null }));
    const windowStart = now - 3600000;
    const measured = jobs.filter(job => job.code === 'EXECUTION_COMPLETE' && terminal.has(job.state) && job.finishedAt >= windowStart && job.startedAt !== null && job.submittedAt !== null);
    const recentFailures = jobs.filter(job => job.state === 'failed' && job.finishedAt >= windowStart && job.executionOutcome !== 'not_started');
    const documentRefreshes = jobs.filter(job => job.code === 'DOCUMENT_CHANGED' && job.finishedAt >= windowStart);
    const waits = measured.map(job => job.startedAt - job.submittedAt), runs = measured.map(job => job.finishedAt - job.startedAt);
    const pendingWaits = ownPending.filter(job => job.state === 'queued' && job.submittedAt !== null).sort((a, b) => a.submittedAt - b.submittedAt);
    const projects = this.knownProjects(presence), files = archives(this.project);
    const logProjects = this.project ? [this.project] : [...new Set([active?.project, ...jobs.map(j => j.project), ...projects.map(p => p.path)].filter(Boolean))].slice(0, 8);
    const logFiles = logProjects.map(project => path.join(project, '.cad', 'logs', this.project ? this.archive || 'fmcad.log' : 'fmcad.log'));
    for (const [file, tail] of this.tails) if (!logFiles.includes(file)) { tail.close(); this.tails.delete(file); }
    const logStates = logFiles.map(file => {
      if (!this.tails.has(file)) this.tails.set(file, new LogTail(file));
      return this.tails.get(file).poll();
    });
    const log = { lines: logStates.flatMap(state => state.lines).sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0)).slice(-2000),
      dropped: logStates.reduce((sum, state) => sum + state.dropped, 0), error: this.project ? logStates[0]?.error || null : null,
      caughtUp: logStates.every(state => state.caughtUp) };
    const enriched = log.lines.map(row => {
      const job = this.byId.get(row.fields.job);
      return { ...row, document: job?.document.name || row.fields.document || row.fields.doc || null,
        command: job?.command || row.fields.kind || null,
        clientLabel: job ? sessionsByClient.get(job.clientId)?.title || job.clientId : row.fields.client || null,
        project: job?.project || workspace(row.source) };
    });
    const locks = await this.locks.sample(this.project);
    const alerts = [];
    if (queueError) alerts.push({ level: 'WARN', message: `Odczyt kolejki: ${queueError}; zachowano ostatni dostępny stan` });
    if (blocked) alerts.push({ level: 'ERROR', message: `Kolejka wymaga uzgodnienia: ${blocked.reason}` });
    if (owner && !aliveBroker) alerts.push({ level: 'WARN', message: 'Pozostał marker niedostępnego brokera — panel nie usuwa go ani nie uruchamia brokera' });
    for (const holder of locks.holders) if (holder.stopped) alerts.push({ level: 'ERROR', message: `Zatrzymany proces ${holder.command} (PID ${holder.pid}) trzyma blokadę bazy Beads` });
    if (log.error && this.project) alerts.push({ level: 'WARN', message: 'Log projektu: ' + log.error });
    const registry = this.cache.get(path.join(this.queueDir, 'clients.json'));
    const result = {
      schemaVersion: 1, observedAt: now, source: 'local-files', project: this.project,
      data: { available: !!data, stale: !!queueError, error: queueError, modifiedAt: record.modifiedAt },
      projects,
      queue: { brokerState: !owner ? 'absent' : system.broker?.state || 'unavailable', paused: data?.paused ?? null,
        active, blocked, lease, waiting: data ? allPending.filter(j => j.state === 'queued').length : null,
        projectWaiting: data ? ownPending.filter(j => j.state === 'queued').length : null,
        reason, buildHash: short(diagnostic?.buildHash || instanceRecord.value?.buildHash) || null,
        recovery: diagnostic?.recovery ? { status: short(diagnostic.recovery.status), code: short(diagnostic.recovery.code) } : null },
      agents: { telemetryAvailable: presence.available && sessionRows.length > 0, limited: presence.limited,
        liveSessions: presence.available && sessionRows.length > 0 ? sessionRows.filter(s => s.connected).length : null,
        busySessions: presence.available && sessionRows.length > 0 ? sessionRows.filter(s => s.connected && ['busy', 'retry'].includes(s.status)).length : null,
        idleSessions: presence.available && sessionRows.length > 0 ? sessionRows.filter(s => s.connected && s.status === 'idle').length : null,
        stoppedSessions: sessionRows.filter(s => s.status === 'stopped').length,
        activeClients: data ? new Set(ownPending.map(j => j.clientId)).size : null,
        registeredClients: registry.error || !registry.value ? null : Object.keys(registry.value).length,
        sessions: sessionRows.sort((a, b) => b.observedAt - a.observedAt).slice(0, 200),
        clients: [...clients.values()].slice(0, 100),
        hostCount: new Set(system.hosts.filter(h => h.role === 'opencode' && (!this.project || h.project && within(h.project, this.project))).map(h => h.pid)).size },
      jobs: decorated, jobsTruncated: jobs.length > 200, statistics: { window: 'ostatnia godzina', samples: measured.length,
        executionFailures: recentFailures.length, documentRefreshes: documentRefreshes.length,
        lastFailures: recentFailures.slice(0, 3),
        waitMedianMs: percentile(waits, 0.5), waitP95Ms: percentile(waits, 0.95), runMedianMs: percentile(runs, 0.5), runP95Ms: percentile(runs, 0.95),
        longestWaiting: pendingWaits[0] ? { id: pendingWaits[0].id, waitMs: now - pendingWaits[0].submittedAt, reason } : null },
      system, beads: locks, fusion: { pid: instance?.pid || null, version: short(instance?.version) || null,
        observedAt: fusionObservation.at, activeCommandAtObservation: short(instance?.activeCommand) || null,
        cpuPercent: null, note: 'Ostatnia zapisana obserwacja; CPU Windows Fusion: N/A (bez odpytywania SDK)' },
      logs: { file: this.project ? logFiles[0] : null, files: logFiles, archives: files.map(f => path.basename(f)), lines: enriched, error: log.error, dropped: log.dropped, caughtUp: log.caughtUp },
      alerts,
    };
    this.lastSnapshot = result; return result;
  }
  details(id) {
    const job = this.byId.get(id);
    if (!job || !/^[A-Za-z0-9_-]{1,120}$/.test(id)) return null;
    const directory = path.join(this.queueDir, 'jobs', id);
    const after = this.cache.get(path.join(directory, 'postflight.json')).value;
    const before = this.cache.get(path.join(directory, 'preflight.json')).value;
    const identity = after?.documentState?.state?.identity || before?.instance?.documentState?.state?.identity;
    return { ...job, documentIdentity: identity ? { name: short(identity.name), creationId: short(identity.creationId), fileId: short(identity.fileId), version: Number.isFinite(identity.version) ? identity.version : null } : null,
      evidenceDirectory: directory, note: 'Panel pokazuje metadane. Nie pobiera prywatnych wyników jako inny klient.' };
  }
  close() { this.resetTails(); }
}
module.exports = { DiagnosticProvider, safeJob, workspace, percentile, ObserverReader };
