'use strict';
const { text } = require('./safe');
const path = require('node:path');
const { filtered } = require('./logs');

const stateNames = { queued: 'czeka', running: 'uruchomione', sending: 'backend', succeeded: 'sukces', failed: 'bez sukcesu',
  expired: 'czas minął', cancelled: 'anulowane', needs_reconciliation: 'uzgodnienie', busy: 'aktywny', idle: 'bezczynny',
  retry: 'ponawia', stopped: 'wstrzymany', ended: 'zakończony', stale: 'stara telemetria', unknown: 'nieznany', alive: 'działa', exited: 'zakończony', absent: 'wyłączony', unavailable: 'niedostępny' };
const duration = ms => !Number.isFinite(ms) ? '—' : ms < 1000 ? `${Math.round(ms)} ms` : ms < 60000 ? `${(ms / 1000).toFixed(1)} s` : ms < 3600000 ? `${Math.floor(ms / 60000)} min ${Math.floor(ms / 1000) % 60} s` : `${(ms / 3600000).toFixed(1)} h`;
const bytes = value => !Number.isFinite(value) ? 'N/A' : value >= 1024 ** 3 ? `${(value / 1024 ** 3).toFixed(1)} GiB` : `${(value / 1024 ** 2).toFixed(1)} MiB`;
const cpu = value => Number.isFinite(value) ? `${value.toFixed(1)}%` : 'N/A';
const clock = value => value ? new Date(value).toLocaleTimeString('pl-PL', { hour12: false }) : '—';
const count = value => value === null || value === undefined ? 'nieznane' : String(value);
const age = (now, value) => duration(Number.isFinite(value) ? now - value : null);
const doc = job => job.document?.name || job.document?.creationId || job.document?.fileId || 'cel nieprzypięty';
const compact = value => text(value, 200);
function eventLine(event, global = false) {
  const context = [global && event.project ? path.basename(event.project) : null,
    event.clientLabel ? compact(event.clientLabel).slice(0, 28) : null].filter(Boolean).join(' · ');
  return `${clock(event.timestamp)} ${event.level.padEnd(5)} ${context ? '[' + context + '] ' : ''}${event.message}` +
    `${event.command ? ' · ' + event.command : ''}${event.document ? ' · ' + event.document : ''}` +
    `${event.fields.active_ms ? ' · ' + duration(Number(event.fields.active_ms)) : ''}` +
    `${event.fields.job ? '  [' + event.fields.job.slice(0, 8) + ']' : ''}`;
}

function rows(snapshot, view, ui = {}) {
  const result = [], add = (line, style = 'normal', detail = null) => result.push({ line: text(line, 4000), style, detail });
  const jobs = snapshot.jobs || [], query = (ui.query || '').toLocaleLowerCase('pl');
  const matching = job => !query || [job.id, job.clientId, job.clientLabel, job.command, doc(job), job.project, job.state, job.code].join(' ').toLocaleLowerCase('pl').includes(query);
  const jobRows = (limit = 200) => {
    const sorted = [...jobs].sort((a, b) => Number(!['queued', 'running', 'sending', 'needs_reconciliation'].includes(a.state)) - Number(!['queued', 'running', 'sending', 'needs_reconciliation'].includes(b.state)) || b.order - a.order);
    for (const job of sorted.filter(matching).slice(0, limit)) {
      add(`${(stateNames[job.state] || job.state).padEnd(13)} ${compact(job.clientLabel || job.clientId).slice(0, 23).padEnd(24)} ${compact(doc(job)).slice(0, 28).padEnd(29)} ${job.command}  ·  czekał ${duration(job.waitMs)}  ·  od startu ${duration(job.elapsedMs)}`,
        job.state === 'needs_reconciliation' ? 'error' : job.state === 'failed' || job.state === 'expired' ? 'warn' : job.state === 'succeeded' ? 'success' : 'normal', { type: 'job', id: job.id });
      if (job.waitingReason) add('   ↳ ' + job.waitingReason, 'muted');
    }
    if (!sorted.filter(matching).length) add('Brak zadań pasujących do widoku.', 'muted');
  };
  if (view === 0) {
    add('BIEŻĄCY STAN', 'heading');
    add(snapshot.queue.reason, snapshot.queue.blocked ? 'error' : 'normal');
    if (snapshot.queue.lease && !snapshot.queue.active && !snapshot.queue.blocked) {
      const until = Math.min(snapshot.queue.lease.idleUntil, snapshot.queue.lease.holdUntil);
      add('Pozostały limit bezczynnej rezerwacji: ' + duration(Number.isFinite(until) ? Math.max(0, until - snapshot.observedAt) : null), 'muted');
    }
    add(`Oczekuje globalnie: ${count(snapshot.queue.waiting)}  |  W projekcie: ${count(snapshot.queue.projectWaiting)}  |  Żywe raportujące sesje: ${count(snapshot.agents.liveSessions)}`);
    add(`Zgłoszone jako aktywne: ${count(snapshot.agents.busySessions)}  ·  bezczynne: ${count(snapshot.agents.idleSessions)}`, 'muted');
    add(`Broker CPU ${cpu(snapshot.system.broker?.cpuPercent)}  RAM ${bytes(snapshot.system.broker?.rssBytes)}  |  Panel CPU ${cpu(snapshot.system.panel?.cpuPercent)}`);
    add(`Klienci z zadaniami: ${count(snapshot.agents.activeClients)}  |  Hosty OpenCode: ${snapshot.agents.hostCount}  |  Rejestr historyczny: ${count(snapshot.agents.registeredClients)}`, 'muted');
    if (!snapshot.agents.telemetryAvailable) add('Liczba żywych sesji jest nieznana: istniejące hosty nie raportują jeszcze telemetrii sesji.', 'warn');
    for (const alert of snapshot.alerts) add(alert.message, alert.level === 'ERROR' ? 'error' : 'warn');
    add(''); add('ZADANIA — Enter: szczegóły', 'heading'); jobRows(12);
    add(''); add('OCZEKIWANIE / WYKONANIE — ostatnia godzina', 'heading');
    const stats = snapshot.statistics;
    add(`Próbek: ${stats.samples}  ·  czekanie mediana ${duration(stats.waitMedianMs)}, p95 ${duration(stats.waitP95Ms)}  ·  wykonanie mediana ${duration(stats.runMedianMs)}, p95 ${duration(stats.runP95Ms)}`);
    add('Czas wykonania oznacza całe wywołanie, nie czas obliczeń ani CPU Fusion.', 'muted');
    add(`Nieudane wykonania: ${stats.executionFailures}  ·  Automatyczne odświeżenia zmienionego dokumentu: ${stats.documentRefreshes}`);
    for (const job of stats.lastFailures || []) add(`Ostatnio: ${job.command} · ${job.code || 'bez kodu'} · ${doc(job)}`, 'warn', { type: 'job', id: job.id });
    if (stats.longestWaiting) add(`Najdłużej czeka ${stats.longestWaiting.id}: ${duration(stats.longestWaiting.waitMs)} · ${stats.longestWaiting.reason}`, 'warn');
    add(''); add('OSTATNIE ZDARZENIA', 'heading');
    for (const event of filtered(snapshot.logs.lines, ui).slice(-8)) add(eventLine(event, !snapshot.project), event.level === 'ERROR' ? 'error' : event.level === 'WARN' ? 'warn' : 'normal', { type: 'log', value: event });
  } else if (view === 1) {
    add('SESJE — obecność potwierdzona heartbeatem i tożsamością procesu', 'heading');
    for (const session of snapshot.agents.sessions.filter(s => !query || [s.title, s.agent, s.id, s.project].join(' ').toLocaleLowerCase('pl').includes(query))) {
      add(`${(stateNames[session.status] || session.status).padEnd(17)} ${session.title}  ·  ${path.basename(session.project || '')}  ·  PID ${session.pid}  ·  kontakt ${duration(snapshot.observedAt - session.observedAt)} temu`,
        ['stopped', 'stale'].includes(session.status) ? 'warn' : 'normal', { type: 'value', value: session });
    }
    if (!snapshot.agents.sessions.length) add('Brak telemetrii sesji. Nie oznacza to braku pracujących agentów.', 'warn');
    add(''); add('KLIENCI — ostatnia zaobserwowana aktywność, nie licznik połączonych agentów', 'heading');
    for (const client of snapshot.agents.clients.filter(c => !query || [c.id, c.title, c.project].join(' ').toLocaleLowerCase('pl').includes(query))) {
      add(`${client.title}  ·  ${path.basename(client.project || '')}  ·  ${client.telemetry === 'legacy' ? 'obecność nieznana' : stateNames[client.status]}  ·  aktywność ${age(snapshot.observedAt, client.lastActivityAt)} temu`, 'muted', { type: 'value', value: client });
    }
    add(''); add('HOSTY / MOSTKI MCP — nie są równoważne liczbie sesji', 'heading');
    for (const host of snapshot.system.hosts) add(`${host.role}  PID ${host.pid}  rodzic ${host.parentPid}  ${host.stopped ? 'WSTRZYMANY' : 'proces żywy'}  ${host.project || 'katalog nieznany'}`, host.stopped ? 'warn' : 'muted', { type: 'value', value: host });
  } else if (view === 2) {
    add('STAN         KLIENT                   DOKUMENT                      POLECENIE / CZASY', 'heading');
    jobRows();
    if (snapshot.jobsTruncated) add('Widok ograniczony do 200 zadań; zadania niezakończone mają pierwszeństwo.', 'muted');
  } else if (view === 3) {
    add(`PLIK: ${snapshot.logs.file || 'wybierz projekt, aby przeglądać archiwa'}`, 'heading');
    add(`Filtry: ${ui.hideInfo ? 'bez INFO' : 'INFO widoczne'} · ${ui.errorsOnly ? 'WARN/ERROR' : 'wszystkie poziomy'} · ${ui.hideHeartbeat ? 'bez heartbeat' : 'heartbeat widoczny'} · bufor pominiętych wpisów ${snapshot.logs.dropped}`, 'muted');
    for (const event of filtered(snapshot.logs.lines, ui)) {
      add(eventLine(event, !snapshot.project),
        ['ERROR', 'FATAL'].includes(event.level) ? 'error' : event.level === 'WARN' ? 'warn' : event.level === 'DEBUG' ? 'muted' : 'normal', { type: 'log', value: event });
    }
    if (snapshot.logs.error) add('Odczyt logu: ' + snapshot.logs.error, 'warn');
    if (!snapshot.logs.caughtUp) add('Wczytywanie kolejnej ograniczonej porcji logu…', 'muted');
  } else {
    add('ZASOBY SYSTEMU', 'heading');
    add(`Linux/WSL CPU ${cpu(snapshot.system.host.cpuPercent)}  ·  RAM ${bytes(snapshot.system.host.memoryUsedBytes)} / ${bytes(snapshot.system.host.memoryTotalBytes)}`);
    add(`Uptime hosta ${duration(snapshot.system.host.uptimeSeconds * 1000)}  ·  load ${snapshot.system.host.loadAverage.map(v => v.toFixed(2)).join(' / ')}`);
    for (const [name, process] of [['Broker', snapshot.system.broker], ['Worker', snapshot.system.worker], ['Panel', snapshot.system.panel]]) {
      add(`${name.padEnd(8)} ${process ? `PID ${process.pid}  ${stateNames[process.state] || process.state}  CPU ${cpu(process.cpuPercent)}  RAM ${bytes(process.rssBytes)}` : 'niedostępny / nie działa'}`);
    }
    add(''); add('FUSION — ostatnia zapisana obserwacja, bez nowego wywołania SDK', 'heading');
    add(`PID ${snapshot.fusion.pid || 'nieznany'}  ·  build ${snapshot.fusion.version || 'nieznany'}  ·  obserwacja ${age(snapshot.observedAt, snapshot.fusion.observedAt)} temu`);
    add(snapshot.fusion.note, 'muted');
    add(''); add('BEADS / DOLT — odczyt blokad systemowych, bez otwierania bazy', 'heading');
    if (!snapshot.beads.available) add(snapshot.beads.reason || 'Dane niedostępne', 'muted');
    else if (!snapshot.beads.holders.length) add('W chwili próbkowania nie znaleziono blokad bazy wybranego projektu.', 'success');
    for (const lock of snapshot.beads.holders) add(`PID ${lock.pid} ${lock.command}: ${lock.stopped ? 'WSTRZYMANY proces trzyma blokadę' : 'proces trzyma blokadę'} · ${lock.path}`, lock.stopped ? 'error' : 'normal');
    add(''); add('TELEMETRIA', 'heading');
    add(`Źródło: ${snapshot.source}  ·  ostatnia zmiana stanu kolejki: ${clock(snapshot.data.modifiedAt)}  ·  dane ${snapshot.data.stale ? 'nieaktualne / odczyt nieudany' : 'odczytane'}`);
    add(`Build brokera: ${snapshot.queue.buildHash || 'nieznany'}`, 'muted');
    add('Brak danych = N/A, nie zero. Panel nie pauzuje ani nie odblokowuje kolejki.', 'muted');
  }
  return result;
}
function plain(snapshot) {
  return [`fmcad diagnostic · ${snapshot.project || 'wszystkie projekty'}`, ...rows(snapshot, 0).map(r => r.line), '',
    'Widoki interaktywne wymagają terminala. --json zwraca pojedynczy snapshot.'].join('\n') + '\n';
}
module.exports = { rows, plain, duration, bytes, cpu, clock, count, doc, stateNames };
