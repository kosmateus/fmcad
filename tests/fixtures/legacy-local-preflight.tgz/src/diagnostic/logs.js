'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { StringDecoder } = require('node:string_decoder');
const { text } = require('./safe');

const descriptions = {
  job_queued: 'Dodano zadanie do kolejki', job_running: 'Rozpoczęto zadanie', job_sending: 'Trwa wywołanie backendu',
  job_succeeded: 'Zadanie zakończone', job_failed: 'Zadanie zakończone bez sukcesu', job_expired: 'Upłynął limit oczekiwania',
  job_cancelled: 'Anulowano oczekujące zadanie', job_needs_reconciliation: 'Wynik wymaga uzgodnienia',
  job_attached: 'Zaobserwowano zadanie', client_requested: 'Agent wywołał fmcad', client_finished: 'Wywołanie fmcad zakończone',
  client_failed: 'Wywołanie fmcad nie powiodło się', broker_observed: 'Zmiana stanu brokera',
  queue_diagnostics: 'Zmiana stanu kolejki', snapshot_unavailable: 'Dane kolejki niedostępne',
  snapshot_read_recovered: 'Przywrócono odczyt kolejki', observer_attached: 'Dołączono podgląd projektu',
};
const fieldsAllowed = new Set(['job', 'client', 'kind', 'state', 'code', 'execution', 'wait_ms', 'active_ms', 'rpc', 'ack',
  'sequence', 'rpc_id', 'timeout_ms', 'reason', 'held', 'blocked_reason', 'blocked_job', 'recovery_code', 'recovery_status',
  'probe_outcome', 'probe_error_type', 'broker_process', 'broker_pid', 'document', 'doc', 'document_id', 'project']);
function parseLine(line, source) {
  const match = line.match(/^(\S+)\s+(INFO|WARN|ERROR|DEBUG|TRACE|FATAL)\s+(\S+)\s*(.*)$/);
  if (!match) return { timestamp: null, level: 'INFO', event: 'unstructured', message: 'Wpis nierozpoznanego formatu (surowa treść pominięta)', source, fields: {} };
  const fields = {};
  for (const token of match[4].matchAll(/([a-zA-Z_][\w]*)=([^\s]+)/g)) if (fieldsAllowed.has(token[1])) fields[token[1]] = text(token[2], 180);
  const event = text(match[3], 100);
  let message = descriptions[event] || event.replaceAll('_', ' ');
  if (fields.code === 'DOCUMENT_CHANGED') message = 'Dokument zmieniony — zwrócono świeży stan, bez wykonania starej operacji';
  else if (fields.code) message += ' · ' + fields.code;
  if (fields.reason || fields.blocked_reason) message += ' · ' + (fields.reason || fields.blocked_reason);
  return { timestamp: Number.isFinite(Date.parse(match[1])) ? Date.parse(match[1]) : null,
    level: match[2], event, message, source, fields };
}

class LogTail {
  constructor(file, { capacity = 2000, initialBytes = 65536, maxBytesPerPoll = 262144 } = {}) {
    Object.assign(this, { file, capacity, initialBytes, maxBytesPerPoll });
    this.lines = []; this.fd = null; this.offset = 0; this.inode = null;
    this.decoder = new StringDecoder('utf8'); this.partial = ''; this.dropped = 0; this.skipping = false;
    this.error = null; this.sequence = 0;
  }
  open(initial) {
    const fd = fs.openSync(this.file, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW | fs.constants.O_NONBLOCK);
    const stat = fs.fstatSync(fd);
    if (!stat.isFile()) { fs.closeSync(fd); throw Object.assign(Error('Not a regular log'), { code: 'INVALID_LOG' }); }
    this.fd = fd; this.inode = `${stat.dev}:${stat.ino}`; this.offset = initial ? Math.max(0, stat.size - this.initialBytes) : 0;
    this.decoder = new StringDecoder('utf8'); this.partial = ''; this.skipping = this.offset > 0;
  }
  append(chunk) {
    const decoded = this.decoder.write(chunk);
    for (const part of decoded.split(/(?<=\n)/)) {
      const terminated = part.endsWith('\n');
      if (!this.skipping) {
        this.partial += part;
        if (this.partial.length > 16384) { this.partial = ''; this.skipping = true; this.dropped++; }
      }
      if (terminated) {
        if (!this.skipping && this.partial.trim()) {
          this.lines.push({ sequence: ++this.sequence, ...parseLine(this.partial.replace(/\r?\n$/, ''), this.file) });
          if (this.lines.length > this.capacity) { this.lines.shift(); this.dropped++; }
        }
        this.partial = ''; this.skipping = false;
      }
    }
  }
  poll() {
    let caughtUp = false;
    try {
      if (this.fd === null) this.open(true);
      let stat = fs.fstatSync(this.fd);
      if (stat.size < this.offset) {
        this.offset = 0; this.decoder = new StringDecoder('utf8'); this.partial = ''; this.skipping = false;
      }
      const size = Math.min(this.maxBytesPerPoll, Math.max(0, stat.size - this.offset));
      if (size) {
        const buffer = Buffer.alloc(size), count = fs.readSync(this.fd, buffer, 0, size, this.offset);
        this.offset += count; this.append(buffer.subarray(0, count));
      }
      // Finish the old inode before following the hourly replacement by name.
      let named;
      try { named = fs.lstatSync(this.file); } catch (error) { if (error.code !== 'ENOENT') throw error; }
      if (named?.isSymbolicLink()) throw Object.assign(Error('Symlink log refused'), { code: 'UNSAFE_LOG' });
      if (named && `${named.dev}:${named.ino}` !== this.inode && this.offset >= stat.size) {
        fs.closeSync(this.fd); this.fd = null; this.open(false);
      }
      this.error = named ? null : 'ENOENT';
      caughtUp = this.fd !== null && fs.fstatSync(this.fd).size <= this.offset;
    } catch (error) { this.error = error.code || 'LOG_READ_FAILED'; }
    return { file: this.file, lines: this.lines, dropped: this.dropped, error: this.error, caughtUp };
  }
  close() { if (this.fd !== null) fs.closeSync(this.fd); this.fd = null; }
}
function archives(project) {
  if (!project) return [];
  const directory = path.join(project, '.cad', 'logs');
  try { return fs.readdirSync(directory).filter(name => /^fmcad(?:-\d{4}-\d\d-\d\d_\d\d)?\.log$/.test(name))
    .sort((a, b) => a === 'fmcad.log' ? -1 : b === 'fmcad.log' ? 1 : b.localeCompare(a)).map(name => path.join(directory, name)); }
  catch { return []; }
}
function filtered(lines, { query = '', hideInfo = false, hideHeartbeat = true, errorsOnly = false } = {}) {
  const search = query.toLocaleLowerCase('pl');
  return lines.filter(row => !(hideHeartbeat && ['heartbeat', 'job_progress'].includes(row.event)) &&
    !(hideInfo && ['INFO', 'DEBUG', 'TRACE'].includes(row.level)) &&
    !(errorsOnly && !['WARN', 'ERROR', 'FATAL'].includes(row.level)) &&
    (!search || [row.message, row.level, row.document, row.clientLabel, row.project, row.command,
      ...Object.values(row.fields)].join(' ').toLocaleLowerCase('pl').includes(search)));
}
module.exports = { LogTail, parseLine, archives, filtered };
