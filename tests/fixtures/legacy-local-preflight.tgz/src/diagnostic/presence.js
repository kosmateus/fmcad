'use strict';
const fs = require('node:fs/promises');
const path = require('node:path');
const { createHash, randomUUID } = require('node:crypto');
const { stateRoot } = require('./files');
const { processInfo } = require('./system');
const { text } = require('./safe');

const hash = value => createHash('sha256').update(value).digest('hex');
function createReporter({ project, directory = path.join(stateRoot(), 'diagnostic-presence'), intervalMs = 10000, now = Date.now } = {}) {
  const owner = processInfo(process.pid), nonce = randomUUID();
  const file = path.join(directory, `${process.pid}-${nonce}.json`);
  const sessions = new Map(); let writing = false, closed = false, scheduled = false, inFlight;
  async function flush() {
    if (closed || writing || !sessions.size || !owner) return;
    writing = true;
    const temp = file + '.tmp';
    inFlight = (async () => {
      try {
        await fs.mkdir(directory, { recursive: true, mode: 0o700 });
        await fs.writeFile(temp, JSON.stringify({ schemaVersion: 1, nonce, pid: owner.pid, birth: owner.birth,
          updatedAt: now(), sessions: [...sessions.values()] }), { mode: 0o600 });
        if (!closed) await fs.rename(temp, file);
        else await fs.unlink(temp).catch(() => {});
      } catch { /* Presence is best-effort and never gates execution. */ }
      finally { writing = false; }
    })();
    await inFlight;
  }
  function touch(id, data = {}) {
    if (closed || typeof id !== 'string' || !id) return;
    const key = hash(id).slice(0, 24), old = sessions.get(key) || { id: key, project: text(project), status: 'unknown' };
    const agent = data.agent ? text(data.agent, 100) : old.agent;
    const session = { ...old, id: key, agent, lastActivityAt: now() };
    for (const field of ['title', 'project', 'lastTool', 'status']) if (data[field] !== undefined) session[field] = data[field];
    for (const field of ['title', 'project', 'lastTool']) if (session[field]) session[field] = text(session[field], 250);
    if (agent) session.clientId = 'opencode:' + hash(id + ':' + agent).slice(0, 40);
    sessions.set(key, session);
    if (sessions.size > 200) sessions.delete(sessions.keys().next().value);
    if (!scheduled) {
      scheduled = true;
      const timer = setTimeout(() => { scheduled = false; void flush(); }, 100);
      timer.unref?.();
    }
  }
  function event(event) {
    const properties = event.properties || {}, info = properties.info;
    if (['session.created', 'session.updated', 'session.deleted'].includes(event.type) && info?.id) {
      touch(info.id, { title: info.title, project: info.directory || project,
        ...(event.type === 'session.deleted' ? { status: 'ended' } : {}) });
    } else if (event.type === 'session.status') touch(properties.sessionID, { status: properties.status?.type || 'unknown' });
    else if (event.type === 'session.idle') touch(properties.sessionID, { status: 'idle' });
  }
  const timer = setInterval(() => { void flush(); }, intervalMs); timer.unref?.();
  return { touch, event, flush, async close() {
    closed = true; clearInterval(timer);
    await inFlight;
    // Each reporter owns its nonce-specific file; never removes another reporter.
    await fs.unlink(file).catch(() => {});
  }, file };
}
module.exports = { createReporter };
