'use strict';

function clamp(state, count, height) {
  state.cursor = Math.max(0, Math.min(state.cursor, Math.max(0, count - 1)));
  state.top = Math.max(0, Math.min(state.top, Math.max(0, count - height)));
  if (height > 0 && state.cursor < state.top) state.cursor = state.top;
  if (height > 0 && state.cursor >= state.top + height) state.cursor = state.top + height - 1;
}
function move(state, delta, count, height) {
  state.follow = false; state.interacted = true;
  state.cursor = Math.max(0, Math.min(state.cursor + delta, Math.max(0, count - 1)));
  if (state.cursor < state.top) state.top = state.cursor;
  if (height > 0 && state.cursor >= state.top + height) state.top = state.cursor - height + 1;
  clamp(state, count, height);
}
function scroll(state, delta, count, height) {
  state.follow = false; state.interacted = true; state.top += delta;
  clamp(state, count, height);
}
function preserve(state, oldRows, newRows, height) {
  if (state.follow) { state.top = Math.max(0, newRows.length - height); state.cursor = Math.max(0, newRows.length - 1); }
  else if (state.interacted) {
    const selected = oldRows[state.cursor]?.key, first = oldRows[state.top]?.key;
    const selectedIndex = selected ? newRows.findIndex(row => row.key === selected) : -1;
    const firstIndex = first ? newRows.findIndex(row => row.key === first) : -1;
    if (selectedIndex >= 0) state.cursor = selectedIndex;
    if (firstIndex >= 0) state.top = firstIndex;
  } else { state.cursor = 0; state.top = 0; }
  clamp(state, newRows.length, height);
}
function scrollbar(count, height, top) {
  if (height <= 0) return { start: 0, size: 0, overflow: false };
  if (count <= height) return { start: 0, size: height, overflow: false };
  const size = Math.max(1, Math.floor(height * height / count));
  return { start: Math.round(top / Math.max(1, count - height) * (height - size)), size, overflow: true };
}
function seek(state, position, count, height) {
  const bar = scrollbar(count, height, state.top);
  state.follow = false; state.interacted = true;
  state.top = Math.round(Math.max(0, Math.min(1, (position - bar.size / 2) / Math.max(1, height - bar.size))) * Math.max(0, count - height));
  state.cursor = state.top; clamp(state, count, height);
}
module.exports = { clamp, move, scroll, preserve, scrollbar, seek };
