'use strict';
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const descriptor = {
  usage: 'diagnostic [--project PATH] [--refresh MS] [--json]',
  desc: 'Pasywny panel terminalowy: agenci, kolejka, zadania, logi i zasoby. Nie uruchamia Fusion ani brokera.',
  example: 'fmcad diagnostic --project "/home/kamil/CadProjects/Cat Water Gun"',
  extra: 'Odświeżanie domyślnie 1000 ms (250..60000). --json zwraca jeden odczyt bez TUI. Poza TTY zwracany jest pojedynczy tekstowy raport. Sesje raportujące obecność nie są liczbą historycznych klientów. CPU Windows Fusion może być N/A. 1–5/Tab: widok, /: szukaj, i: INFO, e: błędy, h: heartbeat, p: projekt, a: archiwum, Spacja: zamroź widok, q/Ctrl+C: wyjście. Brak działań administracyjnych i zapytań SDK/SQL.',
};
const help = () => `fmcad ${descriptor.usage}\n\n${descriptor.desc}\n\n${descriptor.extra}\n\n${descriptor.example}\n`;
function defaultProject(cwd) {
  let directory = path.resolve(cwd);
  while (directory !== path.parse(directory).root && directory !== os.homedir()) {
    if (fs.existsSync(path.join(directory, '.cad', 'logs')) || fs.existsSync(path.join(directory, '.beads', 'metadata.json'))) return directory;
    directory = path.dirname(directory);
  }
  return null;
}
function parse(args, cwd = process.cwd()) {
  const options = { refresh: 1000, project: defaultProject(cwd), json: false };
  const seen = new Set();
  for (let i = 0; i < args.length; i++) {
    const flag = args[i];
    if (seen.has(flag)) throw Error('Powtórzona opcja: ' + flag);
    seen.add(flag);
    if (flag === '--json') options.json = true;
    else if (flag === '--project') {
      if (!args[i + 1] || args[i + 1].startsWith('--')) throw Error('--project wymaga katalogu');
      options.project = fs.realpathSync(path.resolve(cwd, args[++i]));
      if (!fs.statSync(options.project).isDirectory()) throw Error('--project wymaga istniejącego katalogu');
    } else if (flag === '--refresh') {
      const value = args[++i];
      if (!/^\d+$/.test(value || '') || Number(value) < 250 || Number(value) > 60000) throw Error('--refresh musi wynosić 250..60000 ms');
      options.refresh = Number(value);
    } else throw Error('Nieznana opcja diagnostic: ' + flag);
  }
  return options;
}
async function main(args, deps = {}) {
  const stdout = deps.stdout || process.stdout, stderr = deps.stderr || process.stderr, stdin = deps.stdin || process.stdin;
  try {
    if (args.includes('--help') || args.includes('-h')) { stdout.write(help()); return 0; }
    const options = parse(args, deps.cwd || process.cwd());
    const provider = deps.providerFactory ? deps.providerFactory(options) : new (require('./provider').DiagnosticProvider)(options);
    try {
      if (options.json) { stdout.write(JSON.stringify(await provider.get(), null, 2) + '\n'); return 0; }
      if (!stdout.isTTY || !stdin.isTTY || process.env.TERM === 'dumb') { stdout.write(require('./format').plain(await provider.get())); return 0; }
      return await (deps.runTUI || require('./ui').runTUI)(provider, options);
    } finally { provider.close(); }
  } catch (error) { stderr.write('diagnostic: ' + require('./safe').text(error.message) + '\n'); return 1; }
}
module.exports = { main, descriptor, help, parse, defaultProject };
