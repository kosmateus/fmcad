const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');

const tunables = {
  'reference-mode': 'source|labels; default source',
  mode: 'inspect|repair; default inspect',
  scale: 'integer [1, 4]; default 2',
  'max-gap-width-px': 'finite positive source pixels; default 2',
  'max-overlap-width-px': 'finite positive source pixels; default 2',
  'max-changed-area-px': 'finite positive source pixel area; default 500',
  'fit-error-px': 'finite positive source pixels <= 2; default 0.35',
  'corner-angle': 'finite degrees [0, 180]; default 55',
  'width-mm': 'finite positive millimeters; default 50',
  'mirror-x': 'boolean true|false; default false',
};
const camelCase = key => key.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
const worker = path.resolve(__dirname, '../assets/image_boundaries.py');
const requirements = path.resolve(__dirname, '../assets/image_boundaries_requirements.txt');
const descriptor = {
  usage: 'image boundaries --svg PATH --reference PATH --palette JSON --out NEWDIR [--python EXE] [options] [--json]',
  desc: 'LOCAL reference-guided boundary inspection/repair and artifacts only. No Fusion document, backend, config or connection.',
  example: 'fmcad image boundaries --svg traced.svg --reference image.png --palette palette.json --out boundary-audit',
  extra: `Alternative: fmcad image boundaries --file request.json [additional input flags] [--python EXE] [--json]
Required paths: svg, reference, palette, out. --palette is a JSON FILE path.
Request keys: svg, reference, palette, out, ${Object.keys(tunables).map(camelCase).join(', ')}.
--file must contain a JSON object with camelCase fields. Duplicate fields, repeated flags,
unknown fields/options, positional arguments and --doc/backend/global flags are rejected.
Flags supplement --file; they never override its fields. All flags need values except help and --json.
All paths are CLI-host local and resolve against invocation cwd, including request-file values,
NOT the request file directory. No Fusion/Windows path conversion.
--python is CLI-only, defaults to python3, and selects one local executable without a shell.
Worker JSON stdin/stdout passthrough; --json is an optional no-op. Diagnostics use stderr.
Worker stdout is a compact summary with areas, warnings, files and unresolvedReasonCounts
(counts of unresolved components by reason). Full component records, parameters and fitValidation
remain in report.json, located via result.files["report.json"], not in stdout.
Interpreter/worker errors return nonzero. Worker types, ranges and source validation run before output creation.
out must be NEW with an existing parent. No overwrite or cleanup; partial failures are retained.

Options (defaults and strict semantic validation owned by the worker):
${Object.entries(tunables).map(([key, spec]) => `  --${key}: ${spec}`).join('\n')}

inspect maps gaps/overlaps without publishing geometry. repair uses reference-guided width and
total changed-area caps, only nearby expected-class ownership, never global dilation.
Intentional reference holes are protected; pre-existing narrow contour offsets remain
protected_unchanged with a report, not forced to match the reference silhouette.
Significant hole topology checks use 4-connected background and EDT diameter > maxGapWidthPx.
Shared Bezier chains are reused exactly in reverse by adjacent colors, not independently fitted.
Ambiguous ownership, wide defects, area-budget failures or failed integrity checks block publication.
result.status: inspected (audit only), blocked (no repaired geometry published), ready (geometry published).
All three are successful worker envelopes, not process errors. Inspect result.status and warnings.
geometryValidated remains false even for ready; sampledMaskValidated is true only on publication.
These are raster working-resolution and sampled curve checks, NOT analytic/CAD/manufacturing validation.
Original curves are refit within tolerance against the proposed label partition, not original SVG curves;
contours can change globally rather than only near repaired pixels. ready is NOT production-ready certification.
Outputs: report.json, original copies, reference/before/after images and gap/overlap/protected/unresolved maps.
Only when published: repaired.svg, preview/overlay images, sketches/*.json and import_sketches.json.
No sketch batch is executed and no Fusion project is written.

Dependencies: use a user-owned venv; nothing is installed automatically.
  python3 -m venv "$HOME/.venvs/fmcad-image"
  "$HOME/.venvs/fmcad-image/bin/python" -m pip install -r ${JSON.stringify(requirements)}
Select it with --python "$HOME/.venvs/fmcad-image/bin/python".
See docs/IMAGE_BOUNDARIES.md for input restrictions, artifacts and limitations.`,
};

async function boundariesImage(args, deps) {
  const flags = {};
  for (let i = 0; i < args.length; i++) {
    const flag = args[i];
    const key = flag.slice(2);
    if (!flag.startsWith('--') || !['svg', 'reference', 'palette', 'out', 'file', 'python', 'json'].includes(key) && !Object.hasOwn(tunables, key)) {
      throw new Error(`unknown option for image boundaries: ${flag}`);
    }
    if (Object.hasOwn(flags, key)) throw new Error(`Duplicate image boundaries option: ${flag}`);
    if (key === 'json') flags[key] = true;
    else {
      const value = args[++i];
      if (!value || /^--|^-[A-Za-z]/.test(value)) throw new Error(`${flag} requires a value`);
      flags[key] = value;
    }
  }
  const text = flags.file ? fs.readFileSync(path.resolve(flags.file), 'utf8') : '{}';
  const request = JSON.parse(text);
  if (!request || typeof request !== 'object' || Array.isArray(request)) throw new Error('Image boundaries request must be a JSON object');
  // JSON.parse loses duplicate keys. Scan validated JSON tokens for top-level fields first.
  const fields = new Set();
  let depth = 0;
  for (const match of text.matchAll(/"(?:\\.|[^"\\])*"|[{}\[\]]/g)) {
    const token = match[0];
    if (token === '{' || token === '[') depth++;
    else if (token === '}' || token === ']') depth--;
    else if (depth === 1 && /^\s*:/.test(text.slice(match.index + token.length))) {
      const field = JSON.parse(token);
      if (fields.has(field)) throw new Error(`Duplicate image boundaries input: ${field}`);
      fields.add(field);
    }
  }
  const allowed = ['svg', 'reference', 'palette', 'out', ...Object.keys(tunables).map(camelCase)];
  for (const key of Object.keys(request)) {
    if (!allowed.includes(key)) throw new Error(`Unknown image boundaries request field: ${key}`);
  }
  for (const [key, value] of Object.entries(flags)) {
    if (['file', 'python', 'json'].includes(key)) continue;
    const field = camelCase(key);
    if (Object.hasOwn(request, field)) throw new Error(`Duplicate image boundaries input: ${field}`);
    if (key === 'mirror-x') request[field] = JSON.parse(value);
    else if (Object.hasOwn(tunables, key) && !['mode', 'reference-mode'].includes(key)) {
      if (!/^-?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(value)) throw new Error(`${key} requires a number`);
      request[field] = Number(value);
      if (!Number.isFinite(request[field])) throw new Error(`${key} requires a finite number`);
    } else request[field] = value;
  }
  for (const key of ['svg', 'reference', 'palette', 'out']) {
    if (typeof request[key] !== 'string' || !request[key].trim()) throw new Error(`image boundaries requires ${key} as a nonempty path`);
    request[key] = path.resolve(request[key]);
  }
  const python = flags.python || 'python3';
  const setup = `Image boundary dependencies: run ${JSON.stringify(python)} -m pip install -r ${JSON.stringify(requirements)} in your user-owned environment. Nothing was installed automatically.\n`;
  return new Promise((resolve, reject) => {
    const child = (deps.spawnImageBoundaries || spawn)(python, [worker], { shell: false, stdio: ['pipe', 'pipe', 'pipe'] });
    child.stdout.on('data', chunk => deps.stdout.write(chunk));
    child.stderr.on('data', chunk => deps.stderr.write(chunk));
    child.on('error', error => reject(new Error(`Cannot start local Python ${JSON.stringify(python)}: ${error.message}. Select an installed interpreter with --python EXE.\n${setup}`)));
    child.stdin.on('error', error => {
      if (error.code !== 'EPIPE') reject(error);
    });
    child.on('close', (code, signal) => {
      if (code !== 0) deps.stderr.write(`image boundaries worker failed (${signal || code}). ${setup}`);
      resolve(code === 0 ? 0 : 1);
    });
    child.stdin.end(JSON.stringify(request));
  });
}

const manual = {
  sections: [{ title: 'Local Return Contract', text: descriptor.desc }],
  examples: [{ label: 'Local boundary audit', requires: 'Existing traced.svg, reference image.png and palette.json; new output directory and local Python dependencies.',
    argv: ['image', 'boundaries', '--svg', 'traced.svg', '--reference', 'image.png', '--palette', 'palette.json', '--out', 'boundary-audit'],
    output: 'Unchanged image.boundaries worker JSON envelope with result.status inspected, blocked or ready. No CAD mutation; ready is sampled validation only.' }],
  audit: {
    sources: ['src/image-boundaries.js', 'assets/image_boundaries.py', 'assets/image_shared_boundaries.py', 'docs/IMAGE_BOUNDARIES.md'],
    verified: ['local routing without configuration', 'all flags and camelCase JSON stdin', 'duplicates, unknown fields and required paths', 'real-worker type/range rejection before output creation', 'stdout/status passthrough and local failure guidance', 'actual worker main compact unresolved reason counts with processing stubbed', 'worker status and publication contract source review'],
    tests: ['tests/image-boundaries.test.js'], gaps: [],
    bugs: ['Fake-interpreter CLI tests do not certify image quality or geometry. Raster working-resolution and sampled curve validation only; original curves can be refit globally. blocked publishes no repaired geometry; partial I/O failures are retained.'],
  },
};

module.exports = { descriptor, boundariesImage, manual };
