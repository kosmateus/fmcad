'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { readJson, hash, sameInstance } = require('./queue-instance');

// In this attested build, FUSION_BUSY can leave preflight only after a valid
// synchronous identity response was parsed. No worker or product RPC exists yet.
// This compatibility classifier is not a synthetic SDK completion receipt.
const LEGACY_BUSY_BUILD = '762241f5fc33c6e4d4b22755bb10b0cb35cf461db1942af9afe444498986fcf0';

function legacyBusyEvidence(data, expectedInstance, previousBuild, directory) {
  if (previousBuild !== LEGACY_BUSY_BUILD || !data.active || data.blocked?.id !== data.active || data.blocked.reason !== 'FUSION_BUSY') return null;
  const job = data.jobs?.[data.active];
  if (!job || job.id !== data.active || job.state !== 'needs_reconciliation' || job.details?.reason !== 'FUSION_BUSY' ||
      (job.dispatch?.rpcCount || 0) !== 0 || (job.dispatch?.completedCount || 0) !== 0) return null;
  const files = fs.readdirSync(directory);
  if (!files.includes('preflight-start.json') || files.some(name => !['preflight-start.json', 'legacy-preflight-busy-evidence.json'].includes(name))) return null;
  const file = path.join(directory, 'preflight-start.json');
  const started = readJson(file);
  if (started.jobId !== job.id || started.buildHash !== previousBuild || !sameInstance(started.instance, expectedInstance)) return null;
  return { version: 1, method: 'attested-legacy-control-flow', jobId: job.id, requestId: job.requestId,
    originalClientId: job.clientId, originalRequestHash: job.hash, buildHash: previousBuild,
    preflightStartSHA256: hash(fs.readFileSync(file)), probeCompleted: true, observedIdle: false,
    observedCommandId: null, userScriptSubmitted: false, rpcCount: 0,
    limitation: 'Completion is derived from the attested typed rejection path; the original command id/identity response was not persisted. This is not an original SDK receipt.' };
}

module.exports = { legacyBusyEvidence, LEGACY_BUSY_BUILD };
