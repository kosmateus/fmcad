const fs = require('node:fs');
const path = require('node:path');
const { pythonValue } = require('./python');

function buildBridgeScript(toolName, request) {
  const unsupported = detail => {
    throw new Error(`${detail} is unsupported by the addin bridge; use --backend mcp explicitly. No automatic fallback is performed.`);
  };
  if (!request || typeof request !== 'object' || Array.isArray(request)) {
    throw new TypeError('Bridge request must be an object');
  }
  if (toolName === 'fusion_mcp_read') {
    if (!['document', 'projects', 'activeCommand'].includes(request.queryType)) {
      unsupported(`Read ${request.queryType}`);
    }
    if (request.queryType === 'document') {
      if (!['open', 'search'].includes(request.operation)) unsupported(`Document read ${request.operation}`);
      if (request.operation === 'search') {
        if (typeof request.name !== 'string' || !request.name.trim()) throw new TypeError('Search requires a nonempty name');
        if (request.project != null && (typeof request.project !== 'string' || !request.project.trim())) {
          throw new TypeError('Project must be a nonempty name or id');
        }
      }
    }
  } else if (toolName === 'fusion_mcp_execute') {
    if (request.featureType !== 'document') unsupported(`Execute ${request.featureType}`);
    const object = request.object;
    if (!object || typeof object !== 'object' || Array.isArray(object)) throw new TypeError('Document operation requires an object');
    if (!['open', 'save', 'close'].includes(object.operation)) unsupported(`Document execute ${object.operation}`);
    if (object.operation === 'open' && (typeof object.fileId !== 'string' || !object.fileId.trim())) {
      throw new TypeError('Document open requires fileId');
    }
    if (object.operation === 'close') {
      for (const flag of ['userConfirmedSaveAndClose', 'userConfirmedCloseWithoutSave']) {
        if (Object.hasOwn(object, flag) && typeof object[flag] !== 'boolean') throw new TypeError(`${flag} must be boolean`);
      }
      if ((object.userConfirmedSaveAndClose === true) === (object.userConfirmedCloseWithoutSave === true)) {
        throw new Error('Document close requires exactly one save or discard confirmation');
      }
    }
  } else {
    unsupported(`Tool ${toolName}`);
  }
  const source = fs.readFileSync(path.join(__dirname, '../assets/addin-bridge.py'), 'utf8');
  return source.replace('_BRIDGE_REQUEST = {}', () => `_BRIDGE_REQUEST = ${pythonValue({ toolName, request })}`);
}

module.exports = { buildBridgeScript };
