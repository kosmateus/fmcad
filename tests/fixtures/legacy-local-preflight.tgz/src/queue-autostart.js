'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');
const { randomUUID } = require('node:crypto');
const { request, queueDirectory } = require('./queue-connection');
const { durable, readJson, processBirth, reclaim, fail } = require('./queue-instance');

const missing = error => ['ENOENT', 'ECONNREFUSED'].includes(error.code);
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

function record(file) {
  try { return readJson(file); }
  catch (error) { if (error.code === 'ENOENT' || error instanceof SyntaxError) return null; throw error; }
}

function startupOwner(dir, claim) {
  const child = record(path.join(dir, 'autostart', claim.nonce + '.process.json'));
  return child?.nonce === claim.nonce && Number.isSafeInteger(child.pid) && typeof child.birth === 'string' ? child : claim;
}

function claimStart(file, value) {
  const temp = file + '.' + value.nonce + '.tmp';
  durable(temp, value, true);
  try {
    fs.linkSync(temp, file); // Atomic, fully written publication; never replaces a claimant.
    const fd = fs.openSync(path.dirname(file), 'r');
    try { fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
  } finally { fs.unlinkSync(temp); }
}

function recoverableBroker(dir, owner) {
  if (!/^[a-f0-9-]{36}$/.test(owner.nonce || '')) return false;
  const file = path.join(dir, `broker-lifecycle-${owner.nonce}.json`);
  const lifecycle = record(file);
  // Protocol 2 durably creates lifecycle before any startup SDK probe. A death
  // before that file exists can restore the supervisor without issuing work.
  if (!lifecycle && owner.protocol === 2 && !fs.existsSync(file)) return true;
  if (!lifecycle || lifecycle.owner?.pid !== owner.pid || lifecycle.owner?.birth !== owner.birth || lifecycle.owner?.nonce !== owner.nonce) return false;
  if (['ready', 'recovery'].includes(lifecycle.stage) || lifecycle.stage === 'rejected' && lifecycle.safeToRecover === true) return true;
  if (lifecycle.stage !== 'starting') return false;
  const expected = path.join(dir, `broker-startup-${owner.nonce}.receipt.json`);
  if (lifecycle.receipt !== expected) return false;
  const receipt = record(expected), binding = lifecycle.binding;
  return !!(receipt?.terminal === true && ['succeeded', 'failed'].includes(receipt.outcome) && binding &&
    ['brokerNonce', 'ownerPid', 'ownerBirth', 'buildHash', 'stage'].every(key => receipt[key] === binding[key]) &&
    binding.brokerNonce === owner.nonce && binding.ownerPid === owner.pid && binding.ownerBirth === owner.birth);
}

const recoveryRace = error => ['EEXIST', 'ENOENT', 'BROKER_ALIVE', 'STARTER_ALIVE', 'LOCK_CHANGED', 'RECOVERY_IN_PROGRESS', 'BROKER_MARKER_PRESENT'].includes(error.code);

function releaseStart(dir, nonce) {
  const file = path.join(dir, 'autostart.lock');
  if (fs.existsSync(file) && readJson(file).nonce === nonce) fs.unlinkSync(file);
}

function startupResult(dir, nonce, result) {
  durable(path.join(dir, 'autostart', nonce + '.json'), { nonce, ...result });
}

function launch(dir, cfg, nonce) {
  const stdout = fs.openSync(path.join(dir, 'autostart', nonce + '.stdout.log'), 'wx', 0o600);
  let stderr;
  try { stderr = fs.openSync(path.join(dir, 'autostart', nonce + '.stderr.log'), 'wx', 0o600); }
  catch (error) { fs.closeSync(stdout); throw error; }
  try {
    const env = {};
    for (const key of ['PATH', 'HOME', 'USER', 'LOGNAME', 'LANG', 'LC_ALL', 'XDG_STATE_HOME', 'XDG_CONFIG_HOME', 'WSL_DISTRO_NAME', 'TMPDIR', 'SYSTEMROOT']) {
      if (process.env[key] !== undefined) env[key] = process.env[key];
    }
    const child = spawn(process.execPath, [path.join(__dirname, 'queue-autostart-worker.js'), nonce], {
      cwd: path.resolve(__dirname, '..'), env, detached: true, shell: false, stdio: ['pipe', stdout, stderr],
    });
    child.once('error', error => {
      startupResult(dir, nonce, { state: 'failed', code: 'BROKER_SPAWN_FAILED', message: error.message });
      releaseStart(dir, nonce);
    });
    // Configuration/credentials travel over an owned pipe, never argv or a log.
    child.stdin.on('error', () => {});
    child.stdin.end(JSON.stringify(cfg));
    child.unref();
  } finally { fs.closeSync(stdout); fs.closeSync(stderr); }
}

async function ensureBroker(cfg, auth) {
  if (cfg.routing !== 'queue' || cfg.queue?.autoStart === false) {
    fail('QUEUE_NOT_RUNNING', 'Queue broker is not running; automatic startup is disabled. Start fmcad queue serve separately. No direct fallback.');
  }
  const dir = queueDirectory();
  const timeout = cfg.queue?.startupTimeoutMs ?? 60000;
  if (!Number.isSafeInteger(timeout) || timeout <= 0 || timeout > 600000) fail('INVALID_STARTUP_TIMEOUT', 'queue.startupTimeoutMs must be 1..600000 ms');
  const started = performance.now();
  let launched = false, observedNonce;
  fs.mkdirSync(path.join(dir, 'autostart'), { recursive: true, mode: 0o700 });
  const stat = fs.lstatSync(dir);
  if (!stat.isDirectory() || stat.isSymbolicLink() || process.getuid && stat.uid !== process.getuid()) fail('UNSAFE_DIRECTORY', 'Unsafe broker state directory');
  for (;;) {
    try { return await request(dir, { action: 'register', ...auth }, { timeoutMs: Math.max(1, Math.min(3000, timeout - (performance.now() - started))) }); }
    catch (error) { if (!missing(error)) throw error; }

    const marker = path.join(dir, 'broker.lock');
    const startup = path.join(dir, 'autostart.lock');
    if (observedNonce) {
      const result = record(path.join(dir, 'autostart', observedNonce + '.json'));
      if (result?.state === 'failed' && result.code !== 'EEXIST') fail(result.code || 'BROKER_START_FAILED', result.message || 'Broker startup failed; inspect private startup logs');
    }
    const brokerOwner = record(marker);
    if (brokerOwner) {
      const owner = brokerOwner;
      let alive;
      try { alive = processBirth(owner.pid) === owner.birth; }
      catch (error) { if (['ENOENT', 'ESRCH'].includes(error.code)) alive = false; else throw error; }
      if (!alive) {
        if (cfg.queue?.autoRecover === false) fail('BROKER_STALE', 'Previous broker marker remains and queue.autoRecover is false; explicit recovery required.');
        if (recoverableBroker(dir, owner)) {
          try {
            // Recover only the dead supervisor. The original job/lease owner and
            // any unknown outcome remain durable and block normal dispatch.
            reclaim(dir);
            launched = false; observedNonce = undefined;
            continue;
          } catch (error) { if (!recoveryRace(error)) throw error; }
        } else if (!fs.existsSync(path.join(dir, `broker-lifecycle-${owner.nonce}.json`))) {
          fail('BROKER_STALE', 'Legacy broker marker has no bound lifecycle proof; one-time explicit reconciliation is required.');
        }
      }
    } else if (!fs.existsSync(marker) && !fs.existsSync(startup) && !launched) {
      const nonce = randomUUID();
      try {
        claimStart(startup, { nonce, pid: process.pid, birth: processBirth() });
        launched = true;
        observedNonce = nonce;
        try { launch(dir, cfg, nonce); }
        catch (error) { releaseStart(dir, nonce); throw error; }
      } catch (error) { if (error.code !== 'EEXIST') throw error; }
    }
    const startupClaim = record(startup);
    if (startupClaim) {
      const owner = startupClaim;
      const processOwner = startupOwner(dir, owner);
      observedNonce = owner.nonce;
      const resultFile = path.join(dir, 'autostart', owner.nonce + '.json');
      if (fs.existsSync(resultFile)) {
        const result = readJson(resultFile);
        if (result.state === 'failed' && result.code !== 'EEXIST') fail(result.code || 'BROKER_START_FAILED', result.message || 'Broker startup failed; inspect private startup logs');
      }
      let alive;
      try { alive = processBirth(processOwner.pid) === processOwner.birth; }
      catch (error) { if (['ENOENT', 'ESRCH'].includes(error.code)) alive = false; else throw error; }
      if (!alive && !fs.existsSync(marker)) {
        if (cfg.queue?.autoRecover === false) fail('STARTUP_STALE', 'Interrupted startup claim remains and queue.autoRecover is false');
        try {
          reclaimStart(dir);
          launched = false; observedNonce = undefined;
          continue;
        } catch (error) { if (!recoveryRace(error)) throw error; }
      }
    }
    if (performance.now() - started >= timeout) fail('BROKER_START_TIMEOUT', 'Timed out waiting for broker startup; no command was submitted. The broker may still start; inspect status before retrying.');
    await sleep(100);
  }
}

function reclaimStart(dir = queueDirectory()) {
  if (fs.existsSync(path.join(dir, 'broker.lock'))) fail('BROKER_MARKER_PRESENT', 'Reclaim/reconcile the broker marker first');
  const file = path.join(dir, 'autostart.lock');
  const owner = readJson(file);
  const processOwner = startupOwner(dir, owner);
  let alive;
  try { alive = processBirth(processOwner.pid) === processOwner.birth; }
  catch (error) { if (['ENOENT', 'ESRCH'].includes(error.code)) alive = false; else throw error; }
  if (alive) fail('STARTER_ALIVE', 'The startup claimant is still alive');
  // Serialize reclaim; never remove a claim that has changed since inspection.
  const claim = path.join(dir, 'recovery.lock');
  durable(claim, { pid: process.pid, birth: processBirth() }, true);
  try {
    if (JSON.stringify(readJson(file)) !== JSON.stringify(owner) || fs.existsSync(path.join(dir, 'broker.lock'))) fail('LOCK_CHANGED', 'Startup ownership changed during recovery');
    const latest = startupOwner(dir, owner);
    try { if (processBirth(latest.pid) === latest.birth) fail('STARTER_ALIVE', 'The startup daemon is still alive'); }
    catch (error) { if (!['ENOENT', 'ESRCH'].includes(error.code)) throw error; }
    durable(path.join(dir, 'autostart', owner.nonce + '.reclaimed.json'), owner, true);
    fs.unlinkSync(file);
    return { reclaimedStartup: true, previousPid: processOwner.pid, noFusionRequestSent: true };
  } finally { fs.unlinkSync(claim); }
}

module.exports = { ensureBroker, releaseStart, startupResult, reclaimStart, missing };
