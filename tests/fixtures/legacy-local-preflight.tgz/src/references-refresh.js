const fs = require('node:fs/promises');
const path = require('node:path');
const { randomBytes } = require('node:crypto');
const { hash } = require('./engineering-common');
const { publishComplete } = require('./publish');

const phases = new Set(['audit', 'plan', 'apply', 'inspect']);
const policies = new Set(['preserve', 'latest']);
const lifecycles = new Set(['existingOnly', 'openOwned']);
const fallbackModes = new Set(['never', 'qualifiedOnce']);
const durabilities = new Set(['cloud', 'cold']);
// Match the shipped .11 watcher cap; native timeBudgetMs covers the complete
// Python operation from function entry (including preflight and final report).
const NATIVE_WATCHER_MAX_MS = 120000;
const NATIVE_RPC_RETURN_RESERVE_MS = 1000;
const NATIVE_WATCHER_RECEIPT_RESERVE_MS = 5000;
const own = (value, key) => Object.hasOwn(value, key);
const isObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const nonempty = value => typeof value === 'string' && value.trim() === value && value.length > 0;
const boundedInteger = (value, min, max) => Number.isSafeInteger(value) && value >= min && value <= max;
const nowIso = () => new Date().toISOString();

function nativeUpdateAllocation(remainingMs) {
  if (!Number.isFinite(remainingMs)) return null;
  const remaining = Math.floor(remainingMs);
  const reserve = NATIVE_RPC_RETURN_RESERVE_MS + NATIVE_WATCHER_RECEIPT_RESERVE_MS;
  const nativeUpdateMs = Math.min(NATIVE_WATCHER_MAX_MS - reserve, remaining - reserve);
  if (nativeUpdateMs <= 0) return null;
  return { nativeUpdateMs, nativeRpcTimeoutMs: nativeUpdateMs + NATIVE_RPC_RETURN_RESERVE_MS,
    watcherMs: Math.min(NATIVE_WATCHER_MAX_MS, remaining) };
}

function validate(data, operation) {
  if (operation !== undefined && operation !== 'references.refresh') return;
  if (!isObject(data)) throw new Error('references.refresh data must be an object');
  const allowed = new Set(['schemaVersion', 'phase', 'root', 'scopeFileId', 'policy', 'pins',
    'allowedProjectIds', 'lifecycle', 'nativeFallback', 'durability', 'parameterBindings',
    'callerNamespaces', 'maxFiles', 'maxUpdates', 'timeBudgetMs', 'requestId', 'planId',
    'reportPath', 'confirm', 'uiLeases']);
  for (const key of Object.keys(data)) if (!allowed.has(key)) throw new Error(`Unknown references.refresh input: ${key}`);
  if (data.schemaVersion !== 1) throw new Error('references.refresh schemaVersion must be 1');
  const phase = data.phase ?? 'audit';
  if (!phases.has(phase)) throw new Error('phase must be audit, plan, apply or inspect');
  if (!isObject(data.root) || Object.keys(data.root).some(k => !['projectId', 'fileId', 'version'].includes(k)) ||
      !nonempty(data.root.projectId) || !nonempty(data.root.fileId) || !boundedInteger(data.root.version, 1, 1000000)) {
    throw new Error('root must be the exact saved {projectId,fileId,version} baseline');
  }
  if (data.scopeFileId !== undefined && !nonempty(data.scopeFileId)) throw new Error('scopeFileId must be an exact nonempty file ID');
  if (data.policy !== undefined && !policies.has(data.policy)) throw new Error('policy must be preserve or latest');
  if (phase !== 'apply' && phase !== 'inspect' && own(data, 'confirm')) throw new Error('confirm is accepted only by apply');
  if (phase === 'apply' && data.confirm !== true) throw new Error('apply requires confirm:true');
  if (phase === 'plan' && !policies.has(data.policy)) throw new Error('plan requires an explicit policy: preserve or latest');
  if (data.lifecycle !== undefined && !lifecycles.has(data.lifecycle)) throw new Error('lifecycle must be existingOnly or openOwned');
  if (data.nativeFallback !== undefined && !fallbackModes.has(data.nativeFallback)) throw new Error('nativeFallback must be never or qualifiedOnce');
  if (data.durability !== undefined && !durabilities.has(data.durability)) throw new Error('durability must be cloud or cold');
  if (!nonempty(data.requestId) || !/^[A-Za-z0-9_-]{1,128}$/.test(data.requestId)) {
    throw new Error('requestId must contain 1..128 letters, digits, underscores or hyphens');
  }
  if (!nonempty(data.reportPath)) throw new Error('reportPath must be a nonempty local journal directory');
  if ((phase === 'apply' || phase === 'inspect') && !nonempty(data.planId)) {
    if (phase === 'apply') throw new Error('apply requires planId');
  }
  if (data.planId !== undefined && !/^[0-9a-f]{64}$/.test(data.planId)) throw new Error('planId must be an exact SHA-256 plan identifier');
  for (const [key, value, max] of [['maxFiles', data.maxFiles, 1000], ['maxUpdates', data.maxUpdates, 1000],
    ['timeBudgetMs', data.timeBudgetMs, 1200000]]) {
    if (value !== undefined && !boundedInteger(value, 1, max)) throw new Error(`${key} must be an integer in 1..${max}`);
  }
  if (data.maxUpdates !== undefined && data.maxFiles !== undefined && data.maxUpdates > data.maxFiles) {
    throw new Error('maxUpdates cannot exceed maxFiles');
  }
  if (data.allowedProjectIds !== undefined && (!Array.isArray(data.allowedProjectIds) ||
      data.allowedProjectIds.some(id => !nonempty(id)) || new Set(data.allowedProjectIds).size !== data.allowedProjectIds.length)) {
    throw new Error('allowedProjectIds must contain unique exact project IDs');
  }
  if (data.allowedProjectIds && !data.allowedProjectIds.includes(data.root.projectId)) {
    throw new Error('allowedProjectIds must include the pinned root projectId');
  }
  if (data.pins !== undefined && (!Array.isArray(data.pins) || data.pins.some(pin => !isObject(pin) ||
      Object.keys(pin).some(k => !['edgeId', 'sourceFileId', 'version'].includes(k)) ||
      !nonempty(pin.edgeId) || !nonempty(pin.sourceFileId) || !boundedInteger(pin.version, 1, 1000000)))) {
    throw new Error('pins must be [{edgeId,sourceFileId,version}] with exact IDs and positive versions');
  }
  if (data.pins && new Set(data.pins.map(pin => pin.edgeId)).size !== data.pins.length) {
    throw new Error('pins must contain at most one version per edgeId');
  }
  if (data.parameterBindings !== undefined && (!Array.isArray(data.parameterBindings) ||
      data.parameterBindings.some(binding => !isObject(binding) ||
        Object.keys(binding).some(k => !['edgeId', 'sourceParameter', 'consumerAlias', 'nativeDerivedParameter'].includes(k)) ||
        !nonempty(binding.edgeId) || !nonempty(binding.sourceParameter) ||
        (!nonempty(binding.consumerAlias) && !nonempty(binding.nativeDerivedParameter))))) {
    throw new Error('parameterBindings require edgeId, sourceParameter and a caller-named consumerAlias or nativeDerivedParameter');
  }
  if (data.callerNamespaces !== undefined && !isObject(data.callerNamespaces)) {
    throw new Error('callerNamespaces must be an object of opaque caller-supplied context namespaces');
  }
  if (data.uiLeases !== undefined && (!isObject(data.uiLeases) || Object.entries(data.uiLeases).some(([fileId, entry]) =>
      !nonempty(fileId) || !isObject(entry) || !isObject(entry.target) || !isObject(entry.lease) ||
      entry.target.fileId !== fileId || !nonempty(entry.target.name) ||
      (entry.target.creationId !== undefined && !nonempty(entry.target.creationId)) ||
      (entry.target.commandId !== undefined && entry.target.commandId !== null) ||
      entry.lease.requestId !== data.requestId || !nonempty(entry.lease.id) || !nonempty(entry.lease.operationId) ||
      !Number.isSafeInteger(entry.lease.expiresAt) || !isObject(entry.lease.target) ||
      hash(entry.lease.target) !== hash(entry.target)))) {
    throw new Error('uiLeases must map exact file IDs to .11 leases bound to this requestId and exact target identity');
  }
  if (phase === 'apply' && inputNativeFallback(data) && data.uiLeases !== undefined &&
      Object.keys(data.uiLeases).some(fileId => !nonempty(fileId))) throw new Error('uiLeases keys must be exact file IDs');
  return { ...data, phase, lifecycle: data.lifecycle ?? 'existingOnly', nativeFallback: data.nativeFallback ?? 'never',
    policy: data.policy ?? 'preserve',
    durability: data.durability ?? (phase === 'apply' ? 'cold' : 'cold'),
    allowedProjectIds: data.allowedProjectIds ?? [data.root.projectId],
    maxFiles: data.maxFiles ?? 100, maxUpdates: data.maxUpdates ?? data.maxFiles ?? 100,
    timeBudgetMs: data.timeBudgetMs ?? 180000, pins: data.pins ?? [],
    parameterBindings: data.parameterBindings ?? [], callerNamespaces: data.callerNamespaces ?? {} };
}

function configure(catalog) {
  if (!catalog['references.refresh']) throw new Error('references.refresh catalog entry is required');
  const entry = catalog['references.refresh'];
  entry.nodeOnly = true;
  entry.batchAllowed = false;
  entry.requiresDoc = false;
}

function inputNativeFallback(data) { return (data.nativeFallback ?? 'never') === 'qualifiedOnce'; }

function edgeKey(edge) {
  if (!isObject(edge) || !nonempty(edge.edgeId)) throw new Error('Reference edge is missing its stable edgeId');
  return edge.edgeId;
}

function dependencyOrder(nodes, edges) {
  const state = new Map(), result = [], cycle = [];
  const outgoing = new Map(nodes.map(node => [node.fileId, []]));
  for (const edge of edges) {
    if (edge.selfReference === true) continue;
    if (outgoing.has(edge.ownerFileId) && nodes.some(node => node.fileId === edge.sourceFileId)) {
      outgoing.get(edge.ownerFileId).push(edge.sourceFileId);
    }
  }
  function visit(fileId, pathStack) {
    const mark = state.get(fileId);
    if (mark === 'done') return;
    if (mark === 'visiting') { cycle.push([...pathStack, fileId]); return; }
    state.set(fileId, 'visiting');
    for (const child of outgoing.get(fileId) ?? []) visit(child, [...pathStack, fileId]);
    state.set(fileId, 'done');
    result.push(fileId);
  }
  for (const node of nodes) visit(node.fileId, []);
  return { order: result, cycles: cycle };
}

function explicitBindingCoverage(edge, document, bindings) {
  const derived = Array.isArray(edge.derivedParameters) ? edge.derivedParameters : [];
  if (!derived.length) return { complete: true, expected: [], mapped: [], valuesMatch: true, valueMismatches: [] };
  const sourceNames = new Set((edge.sourceParameters ?? []).map(row => row.name));
  const aliases = new Map((document.parameters ?? []).filter(row => row?.name).map(row => [row.name, row]));
  const candidates = bindings.filter(binding => binding.edgeId === edge.edgeId);
  const mapped = [];
  for (const binding of candidates) {
    if (!sourceNames.has(binding.sourceParameter)) continue;
    let nativeName = binding.nativeDerivedParameter;
    if (nativeName && !derived.some(row => row.name === nativeName)) continue;
    if (!nativeName && binding.consumerAlias) {
      const alias = aliases.get(binding.consumerAlias);
      if (!alias) continue;
      const matches = derived.filter(row => alias.expression === row.name ||
        Array.isArray(alias.dependsOn) && alias.dependsOn.includes(row.name));
      if (matches.length !== 1) continue;
      nativeName = matches[0].name;
    }
    if (!nativeName) continue;
    if (binding.consumerAlias) {
      const alias = aliases.get(binding.consumerAlias);
      if (!alias || !(alias.expression === nativeName || Array.isArray(alias.dependsOn) && alias.dependsOn.includes(nativeName))) continue;
    }
    mapped.push({ sourceParameter: binding.sourceParameter, nativeDerivedParameter: nativeName,
      consumerAlias: binding.consumerAlias ?? null });
  }
  const mappedNames = new Set(mapped.map(row => row.nativeDerivedParameter));
  const complete = mapped.length === candidates.length && derived.every(row => mappedNames.has(row.name)) &&
    mapped.length === derived.length;
  const valueMismatches = [];
  let valuesUnknown = false;
  for (const binding of mapped) {
    const source = (edge.sourceParameters ?? []).find(row => row.name === binding.sourceParameter);
    const target = derived.find(row => row.name === binding.nativeDerivedParameter);
    if (!source || !target || source.internal_unit !== target.internal_unit ||
        source.internal_value === undefined || target.internal_value === undefined) {
      valuesUnknown = true;
      continue;
    }
    const matches = typeof source.internal_value === 'number' && typeof target.internal_value === 'number' ?
      Math.abs(source.internal_value - target.internal_value) <= 1e-9 * Math.max(1, Math.abs(source.internal_value)) :
      source.internal_value === target.internal_value;
    if (!matches) valueMismatches.push({ sourceParameter: source.name,
      nativeDerivedParameter: target.name, sourceValue: source.internal_value,
      derivedValue: target.internal_value, unit: source.internal_unit });
  }
  return { complete, expected: derived.map(row => row.name), mapped,
    valuesMatch: !complete || valuesUnknown ? null : valueMismatches.length === 0, valueMismatches };
}

function makePlan(snapshot, input) {
  if (!isObject(snapshot) || !Array.isArray(snapshot.documents) || !Array.isArray(snapshot.edges)) {
    const shape = !isObject(snapshot) ? `type=${snapshot === null ? 'null' : typeof snapshot}` :
      `object keys=${Object.keys(snapshot).sort().join(',') || '(none)'}`;
    const error = new Error(`Graph audit did not return documents and forward edges (${shape})`);
    error.fmcadReadOnlyFailure = 'references.refresh graph result shape';
    throw error;
  }
  const documents = snapshot.documents;
  const byId = new Map();
  for (const doc of documents) {
    if (!nonempty(doc.fileId) || !nonempty(doc.projectId) || !boundedInteger(doc.version, 1, 1000000)) {
      throw new Error('Audited document is missing exact project/file/version identity');
    }
    if (byId.has(doc.fileId)) throw new Error('Duplicate document identity in reference graph: ' + doc.fileId);
    byId.set(doc.fileId, doc);
  }
  const root = byId.get(input.root.fileId);
  if (!root || root.projectId !== input.root.projectId || root.version !== input.root.version) {
    throw new Error('Root audit does not match the exact requested project/file/version baseline');
  }
  const edgeIds = new Set();
  const edges = snapshot.edges.map((edge, edgeIndex) => {
    if (!isObject(edge) || !byId.has(edge.ownerFileId) || !nonempty(edge.sourceFileId) ||
        !nonempty(byId.get(edge.ownerFileId).projectId)) {
      throw new Error('Audited forward edge has incomplete owner/source file identity');
    }
    const id = edgeKey(edge);
    const duplicateId = edgeIds.has(id);
    const resolvedEdgeId = duplicateId || edge.edgeIdentityUnique === false ?
      `${id}:unresolved:${edgeIndex}` : id;
    edgeIds.add(resolvedEdgeId);
    const explicitPin = input.pins.find(pin => pin.edgeId === resolvedEdgeId || pin.edgeId === id);
    if (explicitPin && explicitPin.sourceFileId !== edge.sourceFileId) throw new Error('Pin sourceFileId differs from its audited edge');
    const source = byId.get(edge.sourceFileId);
    const sourceProjectId = edge.sourceProjectId ?? source?.projectId ?? null;
    const projectAllowed = nonempty(sourceProjectId) && input.allowedProjectIds.includes(sourceProjectId);
    const pinVersion = explicitPin?.version;
    const baselineVersion = edge.baselineVersion;
    const resolved = Number.isSafeInteger(baselineVersion) && baselineVersion > 0;
    const latestVersion = edge.latestVersion;
    const latestKnown = Number.isSafeInteger(latestVersion) && latestVersion > 0;
    let targetVersion = null, targetVersionSource = null, status = edge.status ?? 'current';
    if (duplicateId || edge.edgeIdentityUnique === false) status = 'blocked';
    else if (!nonempty(sourceProjectId)) status = 'unresolved';
    else if (!projectAllowed) status = 'blocked';
    else if (status === 'blocked') { /* keep edge identity ambiguity explicit */ }
    else if (!resolved || edge.getterError && edge.versionSource === 'unresolved') status = 'unresolved';
    else if (pinVersion !== undefined) {
      targetVersion = pinVersion; targetVersionSource = 'explicitPin';
      status = pinVersion < baselineVersion || latestKnown && pinVersion > latestVersion ? 'blocked' :
        pinVersion === baselineVersion ? 'pinned' : 'outdated';
    }
    else if (edge.selfReference === true) { targetVersion = baselineVersion; targetVersionSource = 'historicalSelfReference'; status = 'pinned'; }
    else if (input.policy === 'latest') {
      if (!latestKnown) status = 'unresolved';
      else { targetVersion = latestVersion; targetVersionSource = 'planLatest'; status = baselineVersion === latestVersion ? 'current' : 'outdated'; }
    } else {
      targetVersion = baselineVersion; targetVersionSource = 'preservedBaseline';
      status = latestKnown && baselineVersion < latestVersion ? 'pinned' : 'current';
    }
    if (source && sourceProjectId !== source.projectId) throw new Error('Edge source project differs from audited source document');
    if (!source && edge.selfReference !== true && status !== 'pinned' &&
        targetVersion !== null && targetVersion !== baselineVersion) status = 'unresolved';
    return { ...edge, edgeId: resolvedEdgeId, sourceProjectId,
      ownerProjectId: edge.ownerProjectId ?? byId.get(edge.ownerFileId).projectId,
      edgeIdentityUnique: !duplicateId && edge.edgeIdentityUnique !== false,
      explicitPin: pinVersion !== undefined, projectAllowed,
      ...(resolved ? { baselineVersion } : {}), ...(latestKnown ? { latestVersion } : {}),
      targetVersion, targetVersionSource, status,
      sourceAvailable: !!source };
  });
  for (const pin of input.pins) if (!edgeIds.has(pin.edgeId)) throw new Error('Pin does not match a proven reachable forward edge: ' + pin.edgeId);
  for (const edge of edges) if (edge.kind === 'derive') {
    const coverage = explicitBindingCoverage(edge, byId.get(edge.ownerFileId), input.parameterBindings);
    edge.bindingCoverage = coverage;
    edge.bindingValuesMatch = coverage.valuesMatch;
    if (coverage.complete && coverage.valuesMatch === false && !edge.explicitPin && !edge.selfReference &&
        edge.targetVersion !== null && !['blocked', 'unresolved'].includes(edge.status)) {
      edge.bindingValueMismatch = true;
      // A value mismatch without a version advance is not an update request.
      // Repeating Update All on an already-current Derive is not a repair.
      if (edge.baselineVersion === edge.targetVersion) {
        edge.status = 'blocked';
        edge.blockedReason = 'currentVersionBindingMismatch';
      } else edge.status = 'outdated';
    }
  }
  const reachableFromRoot = new Set([input.root.fileId]);
  let reachChanged = true;
  while (reachChanged) {
    reachChanged = false;
    for (const edge of edges) if (!edge.selfReference && reachableFromRoot.has(edge.ownerFileId) &&
        byId.has(edge.sourceFileId) && !reachableFromRoot.has(edge.sourceFileId)) {
      reachableFromRoot.add(edge.sourceFileId); reachChanged = true;
    }
  }
  const rootScope = input.scopeFileId ?? input.root.fileId;
  if (!reachableFromRoot.has(rootScope)) throw new Error('scopeFileId is not proven reachable from the pinned root');
  const selected = new Set([rootScope]);
  let changed = true;
  while (changed) {
    changed = false;
    for (const edge of edges) if (!edge.selfReference && selected.has(edge.ownerFileId) && byId.has(edge.sourceFileId) && !selected.has(edge.sourceFileId)) {
      selected.add(edge.sourceFileId); changed = true;
    }
  }
  const selectedDocs = documents.filter(doc => selected.has(doc.fileId));
  const limitedIds = new Set(selectedDocs.slice(0, input.maxFiles).map(doc => doc.fileId));
  const scopedDocs = selectedDocs.filter(doc => limitedIds.has(doc.fileId));
  const scopedEdges = edges.filter(edge => limitedIds.has(edge.ownerFileId));
  const ordered = dependencyOrder(scopedDocs, scopedEdges);
  for (const cycle of ordered.cycles) {
    const cycleNodes = new Set(cycle);
    for (const doc of scopedDocs) if (cycleNodes.has(doc.fileId)) doc.referenceCycle = true;
    for (const edge of scopedEdges) if (cycleNodes.has(edge.ownerFileId) && cycleNodes.has(edge.sourceFileId)) edge.status = 'blocked';
  }
  const updates = [], blocked = [], skipped = [];
  for (const fileId of ordered.order) {
    const doc = byId.get(fileId);
    const outgoing = scopedEdges.filter(edge => edge.ownerFileId === fileId);
    const unknownEdge = outgoing.some(edge => ['unresolved', 'blocked'].includes(edge.status));
    const health = doc.health ?? doc.history ?? {};
    const incoming = scopedEdges.filter(edge => !edge.selfReference && edge.sourceFileId === fileId);
    const pinnedDependency = fileId !== rootScope && incoming.length > 0 && incoming.every(edge =>
      edge.status === 'pinned' && edge.targetVersion === doc.version) &&
      outgoing.every(edge => ['current', 'pinned'].includes(edge.status) && !edge.bindingValueMismatch);
    const repairRequired = doc.repairRequired === true || health.repairRequired === true ||
      health.healthy !== true || doc.consumedBodiesVerified === false || doc.historySnapshotSupported === false;
    let blocker = null;
    if (!input.allowedProjectIds.includes(doc.projectId)) blocker = 'projectNotAllowed';
    else if (doc.referenceCycle === true) blocker = 'referenceCycle';
    else if (doc.available !== true) blocker = 'documentUnavailable';
    else if (!Number.isSafeInteger(doc.version) || !Number.isSafeInteger(doc.latestVersion)) blocker = 'cloudVersionUnresolved';
    else if (doc.dirty !== false && doc.modified !== false) blocker = 'dirtyOrModifiedStatusUnknown';
    else if (Number.isSafeInteger(doc.latestVersion) && doc.version !== doc.latestVersion && !pinnedDependency) blocker = 'olderRevisionOpen';
    else if (doc.isComplete !== true) blocker = 'cloudIncompleteOrUnknown';
    else if (doc.readOnly !== false) blocker = 'uneditableOrUnknown';
    else if (doc.timelineAtEnd !== true || doc.pendingSnapshot !== false) blocker = 'historyPositionNotReadyOrUnknown';
    else if (repairRequired) blocker = 'repairRequired';
    else if (outgoing.some(edge => edge.blockedReason === 'currentVersionBindingMismatch')) blocker = 'repairRequired';
    else if (unknownEdge) blocker = outgoing.some(edge => edge.status === 'blocked') ? 'edgeConflictOrOutOfScope' : 'unresolvedReferenceVersion';
    const bySourceTargets = new Map();
    for (const edge of outgoing.filter(edge => !edge.selfReference && edge.targetVersion !== null)) {
      if (!bySourceTargets.has(edge.sourceFileId)) bySourceTargets.set(edge.sourceFileId, new Set());
      bySourceTargets.get(edge.sourceFileId).add(edge.targetVersion);
    }
    if ([...bySourceTargets.values()].some(versions => versions.size > 1) && outgoing.some(edge => edge.kind === 'derive')) {
      doc.blocked = true; doc.blockedReason = 'multipleVersionsOfOneDeriveSource';
      blocked.push({ fileId, reason: doc.blockedReason }); continue;
    }
    const stale = outgoing.filter(edge => !edge.selfReference && edge.status !== 'pinned' &&
      edge.targetVersion !== null && (edge.baselineVersion !== edge.targetVersion || edge.bindingValueMismatch === true));
    const blockedDependency = outgoing.some(edge => edge.sourceAvailable && byId.get(edge.sourceFileId)?.blocked === true);
    if (!blocker && blockedDependency) blocker = 'blockedDependency';
    if (blocker) { doc.blocked = true; doc.blockedReason = blocker; blocked.push({ fileId, reason: blocker }); continue; }
    if (!stale.length) { skipped.push({ fileId, reason: 'alreadyAtIntendedTargets' }); continue; }
    const linked = outgoing.filter(edge => edge.kind === 'linked' && edge.status !== 'pinned' && edge.isOccurrenceReference !== false);
    const derives = outgoing.filter(edge => edge.kind === 'derive' && edge.status !== 'pinned');
    const staleDerives = stale.filter(edge => edge.kind === 'derive');
    const incompleteBinding = staleDerives.find(edge => !explicitBindingCoverage(edge, doc, input.parameterBindings).complete);
    if (incompleteBinding) {
      doc.blocked = true; doc.blockedReason = 'explicitParameterBindingsRequired';
      blocked.push({ fileId, edgeId: incompleteBinding.edgeId, reason: doc.blockedReason,
        bindingCoverage: explicitBindingCoverage(incompleteBinding, doc, input.parameterBindings) });
      continue;
    }
    const unknownKinds = outgoing.filter(edge => !['linked', 'derive'].includes(edge.kind));
    if (unknownKinds.length) { doc.blocked = true; doc.blockedReason = 'unsupportedReferenceKind'; blocked.push({ fileId, reason: 'unsupportedReferenceKind' }); continue; }
    const conflictingPins = outgoing.some(edge => edge.explicitPin || edge.status === 'pinned');
    const massUpdateSafe = !conflictingPins && !outgoing.some(edge => edge.selfReference) && outgoing.every(edge =>
      edge.projectAllowed && edge.targetVersion === edge.latestVersion);
    if (derives.length && linked.length) {
      if (!massUpdateSafe) { doc.blocked = true; doc.blockedReason = 'mixedParentCouldAdvancePinnedOrOutOfScopeEdge'; blocked.push({ fileId, reason: doc.blockedReason }); continue; }
      const method = input.nativeFallback === 'qualifiedOnce' ? 'UpdateAllLatestCmd' : 'document.updateAllReferences';
      updates.push({ fileId, method, fallback: null,
        reason: 'mixedOwnedDeriveAndLinkedReferences', edgeIds: stale.map(edge => edge.edgeId) });
    } else if (derives.length) {
      if (!massUpdateSafe) { doc.blocked = true; doc.blockedReason = 'deriveUpdateCouldAdvancePinnedOrOutOfScopeEdge'; blocked.push({ fileId, reason: doc.blockedReason }); continue; }
      updates.push({ fileId, method: 'document.updateAllReferences', fallback: null,
        reason: 'ownedDeriveReferences', edgeIds: stale.map(edge => edge.edgeId) });
    } else {
      updates.push({ fileId, method: 'DocumentReference.getLatestVersion', fallback: null,
        reason: 'edgeScopedLinkedReferences', edgeIds: stale.map(edge => edge.edgeId) });
    }
  }
  const truncatedFiles = selectedDocs.filter(doc => !limitedIds.has(doc.fileId)).map(doc => doc.fileId);
  const limitedUpdates = updates.slice(0, input.maxUpdates);
  const updateLimited = updates.length > limitedUpdates.length;
  const notPlanned = [...truncatedFiles, ...(updateLimited ? updates.slice(limitedUpdates.length).map(row => row.fileId) : [])];
  const updateById = new Map(limitedUpdates.map(update => [update.fileId, update]));
  const blockedById = new Map(blocked.map(row => [row.fileId, row]));
  const skippedById = new Map(skipped.map(row => [row.fileId, row]));
  const plannedDocuments = scopedDocs.map(doc => ({ ...doc,
    baselineVersion: doc.version, resultingVersion: null,
    identityBefore: { projectId: doc.projectId, fileId: doc.fileId, version: doc.version,
      creationId: doc.creationId ?? null }, identityAfter: null,
    method: updateById.get(doc.fileId)?.method ?? null,
    status: blockedById.has(doc.fileId) ? 'blocked' : skippedById.has(doc.fileId) ? 'up_to_date' :
      updateById.has(doc.fileId) ? 'planned' : 'notProcessed',
    saveStatus: 'notStarted', coldVerified: null, commandReceipt: null }));
  return { schemaVersion: 1, root: { ...input.root }, scopeFileId: rootScope,
    policy: input.policy, lifecycle: input.lifecycle, nativeFallback: input.nativeFallback,
    durability: input.durability, requestId: input.requestId,
    options: { pins: clone(input.pins), allowedProjectIds: [...input.allowedProjectIds],
      parameterBindings: clone(input.parameterBindings), callerNamespaces: clone(input.callerNamespaces),
      maxFiles: input.maxFiles, maxUpdates: input.maxUpdates, timeBudgetMs: input.timeBudgetMs },
    documents: plannedDocuments, edges: scopedEdges,
    order: ordered.order, cycles: ordered.cycles, updates: limitedUpdates, blocked, skipped,
    notPlanned, limits: { maxFiles: input.maxFiles, maxUpdates: input.maxUpdates,
      totalReachableFiles: selectedDocs.length, plannedFiles: scopedDocs.length,
      requestedUpdates: updates.length, plannedUpdates: limitedUpdates.length },
    graphComplete: snapshot.graphComplete === true && scopedDocs.every(doc => doc.available !== false) && !truncatedFiles.length,
    allIntendedReferencesCurrent: scopedEdges.some(edge => edge.status === 'unresolved' ||
      edge.kind === 'derive' && (edge.bindingCoverage?.valuesMatch === null || edge.bindingReadError)) ? null :
      updates.length || blocked.length || scopedEdges.some(edge => edge.status === 'outdated') ? false : true,
    allReferencesLatest: scopedEdges.some(edge => edge.status === 'unresolved' || !Number.isSafeInteger(edge.latestVersion)) ? null :
      scopedEdges.every(edge => edge.selfReference || edge.baselineVersion === edge.latestVersion),
    getterErrors: snapshot.getterErrors ?? [], lifecycleEffects: snapshot.lifecycleEffects ?? [],
    coverage: snapshot.coverage ?? {},
    environment: snapshot.environment ?? { backend: null, fusionVersion: null, osBuild: null, locale: null, adapterQualification: null } };
}

function clone(value) { return JSON.parse(JSON.stringify(value)); }

function requestIdentity(input, requestHash, backend) {
  return { runId: input.requestId, requestHash, commandId: 'fmcad_references_' + randomBytes(16).toString('hex'),
    backend: backend ?? 'unknown', sessionNonce: randomBytes(16).toString('hex'),
    documentIdentity: { expected: { projectId: input.root.projectId, fileId: input.root.fileId, version: input.root.version }, resolved: null } };
}

async function writeRequestRecord(root, requestId, identity, sequence, value, io = fs) {
  const directory = path.join(root, 'requests', requestId);
  await io.mkdir(directory, { recursive: true, mode: 0o700 });
  const target = path.join(directory, String(sequence).padStart(8, '0') + '.json');
  const record = { version: 1, operation: 'references.refresh', sequence,
    requestId, runId: identity.runId, requestHash: identity.requestHash,
    commandId: identity.commandId, backend: identity.backend, sessionNonce: identity.sessionNonce,
    documentIdentity: clone(identity.documentIdentity), at: nowIso(), ...clone(value) };
  await publishComplete(target, JSON.stringify(record, null, 2) + '\n', io);
  return record;
}

async function loadJournal(root, requestId, io = fs) {
  const dir = path.join(root, 'requests', requestId);
  let names;
  try { names = (await io.readdir(dir)).filter(name => /^\d{8}\.json$/.test(name)).sort(); }
  catch (error) { if (error.code === 'ENOENT') return { dir, records: [] }; throw error; }
  const records = [];
  for (let i = 0; i < names.length; i++) {
    const expected = String(i).padStart(8, '0') + '.json';
    if (names[i] !== expected) throw new Error('Reference request journal has a sequence gap; inspect, do not replay');
    const record = JSON.parse(await io.readFile(path.join(dir, expected), 'utf8'));
    if (record.version !== 1 || record.operation !== 'references.refresh' || record.requestId !== requestId || record.sequence !== i) {
      throw new Error('Reference request journal identity/sequence mismatch; outcome unknown');
    }
    if (i && (record.requestHash !== records[0].requestHash || record.commandId !== records[0].commandId ||
        record.sessionNonce !== records[0].sessionNonce || hash(record.documentIdentity) !== hash(records[0].documentIdentity))) {
      throw new Error('Reference journal identity changed; outcome unknown');
    }
    records.push(record);
  }
  let writerActive = false;
  try { await io.lstat(path.join(dir, 'run.lock')); writerActive = true; }
  catch (error) { if (error.code !== 'ENOENT') throw error; }
  return { dir, records, report: records.at(-1), writerActive };
}

async function writePlan(root, plan, io = fs) {
  const planId = hash(plan);
  const directory = path.join(root, 'plans');
  await io.mkdir(directory, { recursive: true, mode: 0o700 });
  const target = path.join(directory, `${planId}.json`);
  try { await publishComplete(target, JSON.stringify({ ...plan, planId }, null, 2) + '\n', io); }
  catch (error) {
    if (error.code !== 'EEXIST') throw error;
    const existing = JSON.parse(await io.readFile(target, 'utf8'));
    if (existing.planId !== planId || hash(Object.fromEntries(Object.entries(existing).filter(([k]) => k !== 'planId'))) !== planId) {
      throw new Error('Immutable planId collision or corrupted existing plan');
    }
  }
  return planId;
}

async function readPlan(root, planId, io = fs) {
  const target = path.join(root, 'plans', `${planId}.json`);
  const plan = JSON.parse(await io.readFile(target, 'utf8'));
  const { planId: stored, ...content } = plan;
  if (stored !== planId || hash(content) !== planId) throw new Error('Immutable reference plan checksum mismatch');
  return content;
}

function reportStatus(result) {
  const unknown = result.unknown === true || result.invocationStatus === 'unknown';
  if (unknown) return 'unknown';
  if (result.invocationStatus === 'failed' || result.failed?.length) return 'failed';
  if (result.invocationStatus === 'blocked' || result.blocked?.length) return 'blocked';
  return result.invocationStatus ?? 'complete';
}

function bindingEvidenceMatches(edge, currentEdge, baseline, current, bindings) {
  const binding = explicitBindingCoverage(currentEdge, current, bindings);
  if (binding.complete !== edge.bindingCoverage?.complete) return false;
  if (binding.valuesMatch === edge.bindingValuesMatch) return true;
  // sourceDesign can expose either the saved baseline or the newly published
  // source while a stale consumer is cold-opened. Accept only that proved
  // version change, never changed consumer bindings/values or same-version drift.
  const versions = [edge.baselineVersion, edge.targetVersion];
  if (!(versions[1] > versions[0]) || edge.sourceParameterVersion === currentEdge.sourceParameterVersion ||
      !versions.includes(edge.sourceParameterVersion) || !versions.includes(currentEdge.sourceParameterVersion) ||
      edge.sourceParameterFileId !== edge.sourceFileId || currentEdge.sourceParameterFileId !== edge.sourceFileId ||
      edge.sourceDocumentModified !== false || currentEdge.sourceDocumentModified !== false) return false;
  const rows = values => (values ?? []).map(row => ({ name: row.name, expression: row.expression,
    internal_value: row.internal_value, internal_unit: row.internal_unit, dependsOn: row.dependsOn ?? [] }))
    .sort((a,b) => a.name.localeCompare(b.name));
  const aliases = new Set(bindings.filter(row => row.edgeId === edge.edgeId).map(row => row.consumerAlias).filter(Boolean));
  const schema = values => rows(values).map(({name,internal_unit}) => ({name,internal_unit}));
  return hash(rows(edge.derivedParameters)) === hash(rows(currentEdge.derivedParameters)) &&
    hash(rows((baseline.parameters ?? []).filter(row => aliases.has(row.name)))) ===
      hash(rows((current.parameters ?? []).filter(row => aliases.has(row.name)))) &&
    hash(schema(edge.sourceParameters)) === hash(schema(currentEdge.sourceParameters));
}

function staleBeforeStep(plan, freshSnapshot, fileId, effectiveTargets = {}) {
  const baseline = plan.documents.find(doc => doc.fileId === fileId);
  const current = freshSnapshot.documents?.find(doc => doc.fileId === fileId) ??
    (freshSnapshot.document?.fileId === fileId ? freshSnapshot.document : null);
  if (!baseline || !current) return { reason: 'documentUnavailable',
    preflight: { status: freshSnapshot?.status ?? null, reason: freshSnapshot?.reason ?? null,
      error: freshSnapshot?.error ?? null, identity: freshSnapshot?.identity ?? null } };
  const currentHealth = current.health ?? current.history ?? {};
  for (const key of ['projectId', 'fileId', 'version']) if (baseline[key] !== current[key]) return 'identityOrVersionDrift';
  if (Number.isSafeInteger(baseline.latestVersion) && Number.isSafeInteger(current.latestVersion) &&
      baseline.latestVersion !== current.latestVersion) return 'unrelatedRevisionDrift';
  if (current.modified !== false || current.isComplete !== true || current.readOnly !== false ||
      current.timelineAtEnd !== true || current.pendingSnapshot !== false || currentHealth.healthy !== true) return 'documentPreconditionChanged';
  const plannedEdges = plan.edges.filter(edge => edge.ownerFileId === fileId);
  const currentEdges = new Map((freshSnapshot.edges ?? []).filter(edge => edge.ownerFileId === fileId).map(edge => [edge.edgeId, edge]));
  for (const edge of plannedEdges) {
    const now = currentEdges.get(edge.edgeId);
    if (!now || now.sourceFileId !== edge.sourceFileId || now.kind !== edge.kind) return {
      reason: 'edgeSetDrift', expectedEdgeId: edge.edgeId,
      observedEdges: [...currentEdges.values()].map(row => ({ edgeId: row.edgeId, kind: row.kind, sourceFileId: row.sourceFileId })) };
    if (edge.kind === 'derive') {
      if (!bindingEvidenceMatches(edge, now, baseline, current, plan.options?.parameterBindings ?? [])) {
        return 'derivedBindingEvidenceDrift';
      }
    }
    const expected = effectiveTargets[edge.edgeId] ?? edge.targetVersion;
    if (now.baselineVersion !== edge.baselineVersion && now.baselineVersion !== expected) return 'edgeVersionDrift';
    const latestNow = now.latestVersion ?? now.sourceLatestVersion;
    const targetNow = effectiveTargets[edge.edgeId];
    if (latestNow !== undefined && edge.latestVersion !== undefined &&
        latestNow !== (targetNow ?? edge.latestVersion)) return 'unrelatedSourceVersionDrift';
  }
  return null;
}

function planFreshness(plan, snapshot) {
  const blockers = [];
  if (!isObject(snapshot) || !Array.isArray(snapshot.documents) || !Array.isArray(snapshot.edges)) {
    blockers.push({ reason: 'auditGraphUnavailable' });
    return blockers;
  }
  const root = snapshot.documents?.find(doc => doc.fileId === plan.root.fileId);
  if (!root || root.projectId !== plan.root.projectId || root.version !== plan.root.version) {
    blockers.push({ fileId: plan.root.fileId, reason: 'rootIdentityOrVersionDrift' });
    return blockers;
  }
  for (const update of plan.updates) {
    const baseline = plan.documents.find(doc => doc.fileId === update.fileId);
    const current = snapshot.documents?.find(doc => doc.fileId === update.fileId);
    if (!baseline || !current) { blockers.push({ fileId: update.fileId, reason: 'documentUnavailable' }); continue; }
    const currentHealth = current.health ?? current.history ?? {};
    for (const key of ['projectId', 'fileId', 'version', 'latestVersion']) {
      if (baseline[key] !== current[key]) blockers.push({ fileId: update.fileId, reason: 'documentVersionDrift', field: key,
        expected: baseline[key], actual: current[key] });
    }
    if (current.modified !== false || current.readOnly !== false || current.isComplete !== true ||
        current.timelineAtEnd !== true || current.pendingSnapshot === true || currentHealth.healthy !== true) {
      blockers.push({ fileId: update.fileId, reason: currentHealth.repairRequired ? 'repairRequired' : 'documentPreconditionChanged' });
    }
    const plannedEdges = plan.edges.filter(edge => edge.ownerFileId === update.fileId);
    const currentEdges = snapshot.edges?.filter(edge => edge.ownerFileId === update.fileId) ?? [];
    if (plannedEdges.length !== currentEdges.length) blockers.push({ fileId: update.fileId, reason: 'forwardEdgeSetDrift' });
    const observedById = new Map(currentEdges.map(edge => [edge.edgeId, edge]));
    for (const edge of plannedEdges) {
      const now = observedById.get(edge.edgeId);
      if (!now || now.sourceFileId !== edge.sourceFileId || now.kind !== edge.kind ||
          now.baselineVersion !== edge.baselineVersion || now.latestVersion !== edge.latestVersion) {
        blockers.push({ fileId: update.fileId, edgeId: edge.edgeId, reason: 'forwardEdgeVersionDrift' });
        continue;
      }
      if (edge.kind === 'derive') {
        if (!bindingEvidenceMatches(edge, now, baseline, current, plan.options?.parameterBindings ?? [])) {
          blockers.push({ fileId: update.fileId, edgeId: edge.edgeId, reason: 'derivedBindingEvidenceDrift' });
        }
      }
    }
  }
  return blockers;
}

async function inspect(client, input, deps) {
  const root = path.resolve(input.reportPath);
  const result = { operation: 'references.refresh', schemaVersion: 1, phase: 'inspect',
    requestId: input.requestId, planId: input.planId, root: input.root,
    invocationStatus: 'complete', success: true, modelValidated: false, lifecycleEffects: [], errors: [] };
  if (input.planId) {
    try { result.plan = await readPlan(root, input.planId, deps.fs ?? fs); }
    catch (error) { result.planStatus = 'unavailable'; result.errors.push({ stage: 'planRead', message: error.message }); }
  }
  const journal = await loadJournal(root, input.requestId, deps.fs ?? fs);
  result.receipts = journal.records;
  result.latestReceipt = journal.report ?? null;
  result.writerActive = journal.writerActive;
  if (journal.writerActive) { result.invocationStatus = 'unknown'; result.success = false; }
  return result;
}

async function finishReadPhase(input, result, deps) {
  const root = path.resolve(input.reportPath);
  const io = deps.fs ?? fs;
  const journal = await loadJournal(root, input.requestId, io);
  const requestHash = hash({ operation: 'references.refresh', request: { ...input, phase: result.phase } });
  if (journal.report) {
    if (journal.report.requestHash !== requestHash) throw new Error('requestId already belongs to a different immutable request');
    return { ...journal.report.result, replayedReceipt: true };
  }
  const directory = path.join(root, 'requests', input.requestId);
  await io.mkdir(directory, { recursive: true, mode: 0o700 });
  const lockPath = path.join(directory, 'run.lock');
  let lock;
  try { lock = await io.open(lockPath, 'wx', 0o600); }
  catch (error) { if (error.code === 'EEXIST') throw new Error('request journal writer exists; inspect before retrying'); throw error; }
  try {
    const identity = requestIdentity(input, requestHash, deps.backend ?? null);
    const rootDocument = result.documents?.find(doc => doc.fileId === input.root.fileId);
    if (rootDocument) identity.documentIdentity.resolved = { projectId: rootDocument.projectId,
      fileId: rootDocument.fileId, version: rootDocument.version, creationId: rootDocument.creationId ?? null };
    await writeRequestRecord(root, input.requestId, identity, 0,
      { event: result.phase + '_settled', phase: result.phase, invocationStatus: result.invocationStatus,
        planId: result.planId ?? null, result }, io);
  } finally {
    await lock.close();
    await io.unlink(lockPath).catch(() => {});
  }
  return result;
}

async function apply(client, input, plan, deps) {
  const started = (deps.now ?? Date.now)();
  const deadline = started + input.timeBudgetMs;
  const result = { operation: 'references.refresh', schemaVersion: 1, requestId: input.requestId,
    planId: input.planId, root: plan.root, scope: plan.scopeFileId,
    invocationStatus: 'complete', success: false, modelValidated: false, graphComplete: plan.graphComplete,
    allIntendedReferencesCurrent: plan.allIntendedReferencesCurrent,
    allReferencesLatest: plan.allReferencesLatest, documents: clone(plan.documents), edges: clone(plan.edges),
    order: [...plan.order], completed: [], skipped: [...plan.skipped], blocked: [...plan.blocked], failed: [],
    notProcessed: [...(plan.notPlanned ?? [])], inProgress: null, budgetExceeded: false, continuation: null,
    lifecycleEffects: [...plan.lifecycleEffects, ...(deps.initialSnapshot?.lifecycleEffects ?? [])],
    environment: plan.environment, errors: [] };
  const resultDocument = fileId => result.documents.find(doc => doc.fileId === fileId);
  const markDocument = (fileId, values) => Object.assign(resultDocument(fileId) ?? {}, values);
  const rootPath = path.resolve(input.reportPath);
  const requestHash = hash({ request: { ...input, phase: 'apply', confirm: true }, planId: input.planId });
  const journal = await loadJournal(rootPath, input.requestId, deps.fs ?? fs);
  if (journal.writerActive) return { ...result, invocationStatus: 'unknown',
    errors: [{ stage: 'journal', message: 'existing request writer is active; no replay or lock theft' }] };
  if (journal.report) {
    if (journal.report.requestHash !== requestHash) throw new Error('requestId already belongs to another immutable apply request');
    result.invocationStatus = journal.report.invocationStatus === 'unknown' ? 'unknown' : 'blocked';
    result.replayedReceipt = true;
    result.priorReceipt = journal.report;
    return result;
  }
  if (input.requestId === plan.requestId) throw new Error('apply needs a new requestId distinct from the immutable plan request');
  const identity = requestIdentity(input, requestHash, client?.capabilities?.backend);
  const rootDoc = plan.documents.find(doc => doc.fileId === plan.root.fileId);
  identity.documentIdentity.resolved = rootDoc ? { projectId: rootDoc.projectId, fileId: rootDoc.fileId,
    version: rootDoc.version, creationId: rootDoc.creationId ?? null } : null;
  const requestDir = path.join(rootPath, 'requests', input.requestId);
  const lockPath = path.join(requestDir, 'run.lock');
  await (deps.fs ?? fs).mkdir(requestDir, { recursive: true, mode: 0o700 });
  let lock;
  try { lock = await (deps.fs ?? fs).open(lockPath, 'wx', 0o600); }
  catch (error) {
    if (error.code === 'EEXIST') return { ...result, invocationStatus: 'unknown',
      errors: [{ stage: 'journal', message: 'request writer is active or outcome is unresolved; no replay' }] };
    throw error;
  }
  let sequence = 0;
  const persist = async (event, fields = {}) => {
    const observedNow = (deps.now ?? Date.now)();
    result.actualElapsedMs = Math.max(0, observedNow - started);
    result.budgetExceeded = result.budgetExceeded || observedNow > deadline;
    return writeRequestRecord(rootPath, input.requestId, identity, sequence++,
      { event, invocationStatus: result.invocationStatus, planId: input.planId,
        inProgress: result.inProgress, result: clone(result), ...fields }, deps.fs ?? fs);
  };
  try {
    await persist('apply_authorized');
    if (deps.initialBlockers?.length) {
      result.invocationStatus = 'blocked';
      result.blocked.push(...deps.initialBlockers);
      for (const blocker of deps.initialBlockers) markDocument(blocker.fileId, { status: 'blocked', blockedReason: blocker.reason });
      await persist('preflight_blocked', { blockers: deps.initialBlockers });
      return result;
    }
    // Cold close/reopen is permitted only when the caller selected the
    // openOwned lifecycle. That authorizes this request to manage only each
    // exact clean editor it preflights and captures; existingOnly never closes
    // a pre-existing editor, even when the plan happened to open it earlier.
    if (input.durability === 'cold' && input.lifecycle !== 'openOwned' && plan.updates.length) {
      result.invocationStatus = 'blocked';
      for (const update of plan.updates) {
        result.blocked.push({ fileId: update.fileId, reason: 'coldRequiresOpenOwnedLifecycle' });
        markDocument(update.fileId, { status: 'blocked', blockedReason: 'coldRequiresOpenOwnedLifecycle' });
      }
      await persist('preflight_blocked');
      return result;
    }
    const effectiveTargets = {};
    const saved = {};
    for (const doc of result.documents) {
      // Ownership from the immutable planning audit does not transfer. A new
      // open in this apply invocation is recorded by its own preflight receipt.
      doc.openedByRequest = false;
      doc.ownedCreationId = null;
    }
    for (const fileId of plan.order) {
      const update = plan.updates.find(row => row.fileId === fileId);
      if (!update) continue;
      if (result.blocked.some(row => row.fileId === fileId)) continue;
      const unsettledFiles = new Set([...result.blocked, ...result.failed].map(row => row.fileId).filter(Boolean));
      const unsettledDependencies = plan.edges.filter(edge => edge.ownerFileId === fileId &&
        !edge.selfReference && unsettledFiles.has(edge.sourceFileId));
      if (unsettledDependencies.length) {
        const diagnostic = { fileId, reason: 'blockedDependencyAfterUnsettledChild',
          dependencies: unsettledDependencies.map(edge => ({ edgeId: edge.edgeId, sourceFileId: edge.sourceFileId })) };
        result.blocked.push(diagnostic);
        markDocument(fileId, { status: 'blocked', blockedReason: diagnostic.reason });
        result.invocationStatus = 'blocked';
        await persist('dependent_blocked', diagnostic);
        continue;
      }
      const beforeFileNow = (deps.now ?? Date.now)();
      if (beforeFileNow >= deadline) {
        result.budgetExceeded = result.budgetExceeded || beforeFileNow > deadline;
        result.invocationStatus = 'partial';
        result.inProgress = null;
        result.notProcessed.push(...plan.order.slice(plan.order.indexOf(fileId)).filter(id => !result.skipped.some(row => row.fileId === id)));
        result.continuation = { reason: 'budgetExhausted' };
        await persist('budget_exhausted');
        return result;
      }
      const node = resultDocument(fileId);
      const before = await deps.step('preflight', { fileId, projectId: node.projectId, version: node.version,
        allowedProjectIds: plan.options?.allowedProjectIds ?? [plan.root.projectId],
        lifecycle: input.lifecycle, openedByRequest: false,
        requestId: input.requestId, root: plan.root }, input, contextFor(plan, fileId));
      result.lifecycleEffects.push(...(before.lifecycleEffects ?? []));
      const drift = staleBeforeStep(plan, before, fileId, effectiveTargets);
      if (drift) {
        const blocker = typeof drift === 'string' ? { reason: drift } : drift;
        result.blocked.push({ fileId, ...blocker });
        markDocument(fileId, { status: 'blocked', blockedReason: blocker.reason });
        result.invocationStatus = 'blocked';
        await persist('step_blocked', { fileId, ...blocker, preflight: before });
        continue;
      }
      const afterPreflightNow = (deps.now ?? Date.now)();
      if (afterPreflightNow >= deadline) {
        result.budgetExceeded = result.budgetExceeded || afterPreflightNow > deadline;
        result.invocationStatus = 'partial';
        result.inProgress = null;
        result.notProcessed.push(...plan.order.slice(plan.order.indexOf(fileId)).filter(id => plan.updates.some(row => row.fileId === id)));
        result.continuation = { reason: 'budgetExhausted' };
        await persist('budget_exhausted_after_preflight');
        return result;
      }
      if (before.identity?.creationId ?? before.document?.creationId) {
        node.ownedCreationId = before.identity?.creationId ?? before.document?.creationId;
      }
      if (before.openedByRequest === true) node.openedByRequest = true;
      const directNativeRoute = update.method === 'UpdateAllLatestCmd';
      if (directNativeRoute && (input.nativeFallback !== 'qualifiedOnce' || update.fallback)) {
        result.invocationStatus = 'blocked';
        result.blocked.push({ fileId, stage: 'nativeUpdate', reason: 'directNativeMethodNotAuthorizedByPlan' });
        markDocument(fileId, { status: 'blocked', blockedReason: 'directNativeMethodNotAuthorizedByPlan' });
        result.inProgress = null;
        await persist('native_direct_blocked', { fileId });
        continue;
      }
      const stepData = { plan, update, fileId, projectId: node.projectId, version: node.version,
        latestVersion: node.latestVersion,
        allowedProjectIds: plan.options?.allowedProjectIds ?? [plan.root.projectId],
        nativeFallback: plan.nativeFallback,
        method: update.method,
        lifecycle: input.lifecycle, ownedCreationId: node.ownedCreationId, openedByRequest: node.openedByRequest === true,
        edgeIds: update.edgeIds, planEdges: plan.edges, effectiveTargets, parameterBindings: input.parameterBindings,
        expectedSourceParameters: Object.fromEntries(plan.documents.map(doc => [doc.fileId, saved[doc.fileId + ':parameters'] ?? doc.parameters ?? []])),
        baselineMetadata: node.metadata ?? {},
        baselineUserParameters: node.userParameters ?? [],
        confirm: true, requestId: input.requestId, timeBudgetMs: input.timeBudgetMs };
      let stepResult = null;
      if (!directNativeRoute) {
        markDocument(fileId, { status: 'updating' });
        result.inProgress = { fileId, stage: 'sdkUpdate', method: update.method };
        await persist('sdk_update_uncertain', { fileId, method: update.method });
        try { stepResult = await deps.step('sdkUpdate', stepData, input, contextFor(plan, fileId)); }
        catch (error) {
          result.invocationStatus = 'unknown';
          markDocument(fileId, { status: 'unknown' });
          result.inProgress = { fileId, stage: 'sdkUpdate', outcome: 'unknown' };
          result.errors.push({ fileId, stage: 'sdkUpdate', message: String(error.message || error) });
          await persist('sdk_update_unknown', { fileId, message: String(error.message || error) });
          return result;
        }
        result.environment = { ...result.environment, ...(stepResult.environment ?? {}) };
        result.lifecycleEffects.push(...(stepResult.lifecycleEffects ?? []));
        if (stepResult.identity?.creationId) node.ownedCreationId = stepResult.identity.creationId;
        if (stepResult.openedByRequest === true) node.openedByRequest = true;
        if (stepResult.notStarted === true || stepResult.status === 'notStarted') {
          result.invocationStatus = 'blocked';
          result.blocked.push({ fileId, stage: 'sdkUpdate', reason: 'requestNotSubmitted', error: stepResult.error ?? null });
          markDocument(fileId, { status: 'blocked', blockedReason: 'requestNotSubmitted' });
          result.inProgress = null;
          await persist('sdk_update_not_started', { fileId, stepResult });
          continue;
        }
        if (stepResult.status === 'unknown' || stepResult.outcome === 'unknown') {
          result.invocationStatus = 'unknown';
          markDocument(fileId, { status: 'unknown' });
          result.inProgress = { fileId, stage: 'sdkUpdate', outcome: 'unknown' };
          result.errors.push({ fileId, stage: 'sdkUpdate', message: stepResult.error ?? 'SDK update outcome unknown' });
          await persist('sdk_update_unknown', { fileId, stepResult });
          return result;
        }
      }
      let check = stepResult?.checks;
      let usedNativeUpdate = false;
      let nativeDocumentModified = false;
      let settledEdges = stepResult?.after?.edges;
      const sdkFallbackRoute = !directNativeRoute && stepResult?.status === 'knownStale' &&
        update.fallback === 'UpdateAllLatestCmd' && input.nativeFallback === 'qualifiedOnce';
      if (directNativeRoute || sdkFallbackRoute) {
        const priorSdkEffect = directNativeRoute ? 'notAttemptedPlannedDirect' : 'knownSettledStale';
        const mayBeModified = directNativeRoute ? before.document?.modified === true : stepResult.modified === true;
        const beforeNativeNow = (deps.now ?? Date.now)();
        if (beforeNativeNow >= deadline) {
          result.budgetExceeded = result.budgetExceeded || beforeNativeNow > deadline;
          result.invocationStatus = 'partial';
          result.inProgress = { fileId, stage: directNativeRoute ? 'directNative' : 'nativeFallback',
            nativeCommandNotSubmitted: true, priorSdkEffect, documentMayBeModified: mayBeModified };
          result.notProcessed.push(...plan.order.slice(plan.order.indexOf(fileId)).filter(id => plan.updates.some(row => row.fileId === id)));
          result.continuation = { reason: 'budgetExhausted' };
          await persist('budget_exhausted_before_native_fallback', { fileId,
            ...(directNativeRoute ? { plannedMethod: update.method } : { priorSdkResult: stepResult }) });
          return result;
        }
        const uiLease = input.uiLeases?.[fileId];
        if (!uiLease) {
          result.invocationStatus = 'blocked';
          result.failed.push({ fileId, stage: 'nativeFallback', reason: 'authorizedUiLeaseRequired' });
          markDocument(fileId, { status: 'blocked', blockedReason: 'authorizedUiLeaseRequired' });
          result.inProgress = null;
          await persist('native_fallback_blocked', { fileId, reason: 'authorizedUiLeaseRequired',
            ...(directNativeRoute ? { plannedMethod: update.method } : { priorSdkResult: stepResult }) });
          continue;
        }
        const target = uiLease.target;
        if (target.name !== node.name || target.fileId !== fileId ||
            target.creationId !== undefined && target.creationId !== node.ownedCreationId) {
          result.invocationStatus = 'blocked';
          result.blocked.push({ fileId, stage: 'nativeFallback', reason: 'uiLeaseTargetDoesNotMatchResolvedOwnedEditor' });
          markDocument(fileId, { status: 'blocked', blockedReason: 'uiLeaseTargetDoesNotMatchResolvedOwnedEditor' });
          result.inProgress = null;
          await persist('native_fallback_blocked', { fileId, reason: 'uiLeaseTargetDoesNotMatchResolvedOwnedEditor' });
          continue;
        }
        if (typeof deps.inspectUi !== 'function') {
          result.invocationStatus = 'blocked';
          result.blocked.push({ fileId, stage: 'nativeFallback', reason: 'shippedUiInspectUnavailable' });
          markDocument(fileId, { status: 'blocked', blockedReason: 'shippedUiInspectUnavailable' });
          result.inProgress = null;
          await persist('native_fallback_blocked', { fileId, reason: 'shippedUiInspectUnavailable' });
          continue;
        }
        const targetContext = { doc: target.name, ...(target.creationId ? { docId: target.creationId } : {}),
          docFileId: fileId, projectId: node.projectId };
        const uiState = await deps.inspectUi(client, { requestId: input.requestId, lease: uiLease.lease,
          target, intent: 'confirmRequestedUpdate', maxControls: 256 }, targetContext);
        if (uiState.status !== 'nothingToDo' || uiState.identityVerified !== true ||
            !['', 'SelectCommand', null].includes(uiState.activeCommand?.id)) {
          result.invocationStatus = 'blocked';
          result.blocked.push({ fileId, stage: 'nativeFallback', reason: 'UIHostNotIdleOrTargetUnverified',
            uiStatus: uiState.status, activeCommand: uiState.activeCommand, unavailableEvidence: uiState.unavailableEvidence });
          markDocument(fileId, { status: 'blocked', blockedReason: 'UIHostNotIdleOrTargetUnverified' });
          result.inProgress = null;
          result.environment = { ...result.environment, backend: client?.capabilities?.backend ?? null,
            fusionVersion: uiState.process?.fusionVersion ?? null, osBuild: uiState.process?.osBuild ?? null,
            uiLocale: uiState.process?.locale ?? null, adapterQualification: 'update-all-latest:not-qualified' };
          await persist('native_fallback_blocked', { fileId, uiState });
          continue;
        }
        result.environment = { ...result.environment, backend: client?.capabilities?.backend ?? null,
          fusionVersion: uiState.process?.fusionVersion ?? null, osBuild: uiState.process?.osBuild ?? null,
          uiLocale: uiState.process?.locale ?? null, adapterQualification: 'update-all-latest:qualified-by-.11-on-this-host' };
        const initialNativeAllocation = nativeUpdateAllocation(deadline - (deps.now ?? Date.now)());
        if (!initialNativeAllocation) {
          result.budgetExceeded = result.budgetExceeded || (deps.now ?? Date.now)() > deadline;
          result.invocationStatus = 'partial';
          result.inProgress = { fileId, stage: directNativeRoute ? 'directNative' : 'nativeFallback',
            nativeCommandNotSubmitted: true, priorSdkEffect, documentMayBeModified: mayBeModified };
          result.notProcessed.push(...plan.order.slice(plan.order.indexOf(fileId)).filter(id => plan.updates.some(row => row.fileId === id)));
          result.continuation = { reason: 'budgetExhausted' };
          await persist('budget_exhausted_before_native_watcher', { fileId,
            ...(directNativeRoute ? { plannedMethod: update.method } : { priorSdkResult: stepResult }) });
          return result;
        }
        const watcherArmStartedAt = (deps.now ?? Date.now)();
        const watcher = await deps.armWatcher(client, { requestId: input.requestId, lease: uiLease.lease,
          expectedIdentity: { name: target.name, creationId: target.creationId ?? null, fileId,
            commandId: target.commandId },
          intent: 'confirmRequestedUpdate', profileId: 'update-all-latest', timeBudgetMs: initialNativeAllocation.watcherMs });
        if (watcher.status !== 'armed') {
          result.invocationStatus = 'blocked';
          result.blocked.push({ fileId, stage: 'nativeFallback', reason: watcher.status ?? 'watcherNotArmed' });
          markDocument(fileId, { status: 'blocked', blockedReason: watcher.status ?? 'watcherNotArmed' });
          result.inProgress = null;
          await persist('native_fallback_blocked', { fileId, watcher });
          continue;
        }
        const afterArmNow = (deps.now ?? Date.now)();
        // Conservatively charge all arm/setup time against the watcher's
        // requested window as well as the apply deadline. The Python budget
        // then covers its whole RPC-side operation, not just its polling loop.
        const watcherRemainingMs = Math.max(0, initialNativeAllocation.watcherMs - (afterArmNow - watcherArmStartedAt));
        const nativeAllocation = nativeUpdateAllocation(Math.min(deadline - afterArmNow, watcherRemainingMs));
        if (!nativeAllocation) {
          await watcher.disarm().catch(() => {});
          result.budgetExceeded = result.budgetExceeded || afterArmNow > deadline;
          result.invocationStatus = 'partial';
          result.inProgress = { fileId, stage: directNativeRoute ? 'directNative' : 'nativeFallback',
            nativeCommandNotSubmitted: true, priorSdkEffect, documentMayBeModified: mayBeModified };
          result.notProcessed.push(...plan.order.slice(plan.order.indexOf(fileId)).filter(id => plan.updates.some(row => row.fileId === id)));
          result.continuation = { reason: 'budgetExhausted' };
          await persist('budget_exhausted_before_native_submit', { fileId,
            ...(directNativeRoute ? { plannedMethod: update.method } : { priorSdkResult: stepResult }) });
          return result;
        }
        result.inProgress = { fileId, stage: 'UpdateAllLatestCmd', outcome: 'pending' };
        await persist('native_submit_uncertain', { fileId, command: 'UpdateAllLatestCmd',
          route: directNativeRoute ? 'plannedDirect' : 'sdkFallback' });
        let nativeResult;
        let keepWatcher = false;
        try {
          const nativeData = { ...stepData, command: 'UpdateAllLatestCmd', planEdges: plan.edges,
            plannedMethod: update.method, nativeRoute: directNativeRoute ? 'directPlanned' : 'sdkFallback',
            ...(directNativeRoute ? {} : { priorSdkResult: stepResult }),
            lease: uiLease.lease, timeBudgetMs: nativeAllocation.nativeUpdateMs,
            nativeRpcTimeoutMs: nativeAllocation.nativeRpcTimeoutMs };
          nativeResult = await deps.step('nativeUpdate', nativeData, input, contextFor(plan, fileId));
          nativeDocumentModified = nativeResult.modified === true;
          if (nativeResult.status === 'unknown' || nativeResult.outcome === 'unknown') {
            keepWatcher = true;
          } else {
            const uiReceipt = await watcher.complete();
            result.lifecycleEffects.push({ fileId, type: 'nativeUi', command: 'UpdateAllLatestCmd', receipt: uiReceipt });
            if (uiReceipt?.status === 'unknown') {
              result.invocationStatus = 'unknown';
              markDocument(fileId, { status: 'unknown' });
              result.inProgress = { fileId, stage: 'UpdateAllLatestCmd', outcome: 'unknown' };
              await persist('native_ui_receipt_unknown', { fileId, nativeResult, uiReceipt });
              return result;
            }
            if (uiReceipt?.status !== 'actionSubmitted' || uiReceipt?.actionSubmitted !== true) {
              if (nativeResult.actionSubmitted === false || nativeResult.notStarted === true) {
                nativeResult = { ...nativeResult, status: 'blocked', operationOutcome: 'notEvaluated',
                  uiActionObserved: false, uiReceipt,
                  reason: nativeResult.reason ?? 'native command was not submitted or its preflight blocked it' };
              } else {
                result.invocationStatus = 'unknown';
                markDocument(fileId, { status: 'unknown' });
                result.inProgress = { fileId, stage: 'UpdateAllLatestCmd', outcome: 'unknown',
                  reason: 'native command submitted without a qualified one-shot UI action receipt' };
                result.errors.push({ fileId, stage: 'nativeUi', evidence: { nativeResult, uiReceipt } });
                await persist('native_ui_action_unknown', { fileId, nativeResult, uiReceipt });
                return result;
              }
            }
          }
        } catch (error) {
          keepWatcher = true;
          result.invocationStatus = 'unknown';
          markDocument(fileId, { status: 'unknown', nativeCommandStatus: 'unknown' });
          result.inProgress = { fileId, stage: 'UpdateAllLatestCmd', outcome: 'unknown' };
          result.errors.push({ fileId, stage: 'nativeUpdate', message: String(error.message || error) });
          await persist('native_update_unknown', { fileId, message: String(error.message || error) });
          return result;
        } finally {
          if (!keepWatcher) await watcher.disarm().catch(() => {});
        }
        if (nativeResult.reason === 'nativeUpdateBudgetInsufficientBeforeCommand' && nativeResult.notStarted === true) {
          result.invocationStatus = 'partial';
          result.inProgress = { fileId, stage: 'nativeFallback', nativeCommandNotSubmitted: true,
            priorSdkEffect, documentMayBeModified: mayBeModified,
            reason: nativeResult.reason };
          result.notProcessed.push(...plan.order.slice(plan.order.indexOf(fileId)).filter(id => plan.updates.some(row => row.fileId === id)));
          result.continuation = { reason: 'budgetExhausted' };
          markDocument(fileId, { status: 'partial', nativeCommandStatus: 'notSubmitted' });
          await persist('budget_exhausted_before_native_submit', { fileId,
            ...(directNativeRoute ? { plannedMethod: update.method } : { priorSdkResult: stepResult }), nativeResult });
          return result;
        }
        if (nativeResult.status !== 'complete' || nativeResult.operationOutcome !== 'pass') {
          result.invocationStatus = nativeResult.status === 'unknown' ? 'unknown' : 'failed';
          markDocument(fileId, { status: nativeResult.status === 'unknown' ? 'unknown' : 'failed',
            nativeCommandStatus: nativeResult.status });
          result.inProgress = nativeResult.status === 'unknown' ? { fileId, stage: 'UpdateAllLatestCmd', outcome: 'unknown' } : null;
          result.errors.push({ fileId, stage: 'nativeUpdate', evidence: nativeResult });
          await persist(nativeResult.status === 'unknown' ? 'native_update_unknown' : 'native_update_failed',
            { fileId, nativeResult });
          if (nativeResult.status === 'unknown') return result;
          continue;
        }
        check = nativeResult.checks;
        settledEdges = nativeResult.after?.edges;
        usedNativeUpdate = true;
      }
      if (!directNativeRoute && stepResult.status !== 'complete' && !usedNativeUpdate) {
        result.invocationStatus = stepResult.status === 'blocked' ? 'blocked' : 'failed';
        result.failed.push({ fileId, stage: 'sdkUpdate', result: stepResult });
        markDocument(fileId, { status: stepResult.status === 'blocked' ? 'blocked' : 'failed',
          sdkUpdateStatus: stepResult.status });
        result.inProgress = null;
        await persist('sdk_update_failed', { fileId, stepResult });
        continue;
      }
      if (!check?.bindingsPass || !check?.healthPass || !check?.scopePass || !check?.metadataPass ||
          check?.localParametersPreserved !== true || check?.consumedBodiesVerified !== true || check?.getterState === 'unresolved') {
        result.invocationStatus = 'failed';
        result.failed.push({ fileId, stage: 'postUpdateChecks', checks: check });
        markDocument(fileId, { status: 'failed', checks: check });
        result.inProgress = null;
        await persist('postcheck_failed', { fileId, checks: check });
        continue;
      }
      const beforeSaveNow = (deps.now ?? Date.now)();
      if (beforeSaveNow >= deadline) {
        result.budgetExceeded = result.budgetExceeded || beforeSaveNow > deadline;
        result.invocationStatus = 'partial';
        result.inProgress = { fileId, stage: 'saveRequired', modelMutation: 'knownSettled',
          documentMayBeModified: nativeDocumentModified || (!directNativeRoute && stepResult.modified === true) };
        markDocument(fileId, { status: 'partial', checks: check });
        result.notProcessed.push(...plan.order.slice(plan.order.indexOf(fileId) + 1).filter(id => plan.updates.some(row => row.fileId === id)));
        result.continuation = { reason: 'budgetExhausted' };
        await persist('budget_exhausted_before_save', { fileId, checks: check });
        return result;
      }
      result.inProgress = { fileId, stage: 'save', outcome: 'pending' };
      await persist('save_uncertain', { fileId, checks: check });
      let save;
      try { save = await deps.step('save', { ...stepData, ownedCreationId: node.ownedCreationId,
        openedByRequest: node.openedByRequest === true, checks: check, postUpdateEdges: settledEdges }, input, contextFor(plan, fileId)); }
      catch (error) {
        result.invocationStatus = 'unknown';
        result.inProgress = { fileId, stage: 'save', outcome: 'unknown' };
        markDocument(fileId, { status: 'unknown', saveStatus: 'unknown' });
        result.errors.push({ fileId, stage: 'save', message: String(error.message || error) });
        await persist('save_unknown', { fileId, message: String(error.message || error) });
        return result;
      }
      if (save.status === 'unknown' || save.outcome === 'unknown') {
        result.invocationStatus = 'unknown';
        result.inProgress = { fileId, stage: 'save', outcome: 'unknown' };
        markDocument(fileId, { status: 'unknown', saveStatus: 'unknown' });
        await persist('save_unknown', { fileId, save });
        return result;
      }
      if (save.status !== 'complete') {
        result.invocationStatus = 'failed';
        result.failed.push({ fileId, stage: 'save', result: save });
        markDocument(fileId, { status: 'failed', saveStatus: save.status ?? 'failed' });
        result.inProgress = null;
        await persist('save_failed', { fileId, save });
        continue;
      }
      saved[fileId] = save.resultingVersion;
      if (Array.isArray(save.parameters)) saved[fileId + ':parameters'] = save.parameters;
      if (save.changed === true) {
        for (const edge of plan.edges) if (edge.sourceFileId === fileId && !edge.explicitPin) {
          effectiveTargets[edge.edgeId] = save.resultingVersion;
          edge.targetVersionSource = 'dependencyReceipt';
          edge.targetVersion = save.resultingVersion;
          edge.effectiveTargetVersion = save.resultingVersion;
        }
      }
      if (input.durability === 'cold') {
        const beforeColdNow = (deps.now ?? Date.now)();
        if (beforeColdNow >= deadline) {
          result.budgetExceeded = result.budgetExceeded || beforeColdNow > deadline;
          result.invocationStatus = 'partial';
          result.inProgress = null;
          result.notProcessed.push('coldVerification:' + fileId);
          result.continuation = { reason: 'budgetExhausted' };
          node.status = 'partial'; node.saveStatus = 'complete'; node.coldVerified = false;
          await persist('budget_exhausted_before_cold_verify', { fileId, save });
          return result;
        }
        result.inProgress = { fileId, stage: 'coldReopen', outcome: 'pending' };
        await persist('cold_read_uncertain', { fileId, save });
        let cold;
        try { cold = await deps.step('coldVerify', { ...stepData, version: save.resultingVersion, ownedCreationId: node.ownedCreationId,
          openedByRequest: node.openedByRequest === true, plan, update, fileId, save, resultingVersion: save.resultingVersion,
          effectiveTargets }, input, contextFor(plan, fileId)); }
        catch (error) {
          result.invocationStatus = 'unknown';
          result.inProgress = { fileId, stage: 'coldReopen', outcome: 'unknown' };
          markDocument(fileId, { status: 'unknown', saveStatus: 'complete', coldVerified: null });
          result.errors.push({ fileId, stage: 'coldVerify', message: String(error.message || error) });
          await persist('cold_verify_unknown', { fileId, message: String(error.message || error) });
          return result;
        }
        if (cold.status !== 'complete' || cold.coldVerified !== true) {
          result.invocationStatus = cold.status === 'unknown' ? 'unknown' : 'failed';
          result.inProgress = cold.status === 'unknown' ? { fileId, stage: 'coldReopen', outcome: 'unknown' } : null;
          result.failed.push({ fileId, stage: 'coldVerify', result: cold });
          markDocument(fileId, { status: cold.status === 'unknown' ? 'unknown' : 'failed',
            saveStatus: 'complete', coldVerified: cold.coldVerified ?? false });
          await persist(cold.status === 'unknown' ? 'cold_verify_unknown' : 'cold_verify_failed', { fileId, cold });
          if (cold.status === 'unknown') return result;
          continue;
        }
        node.resultingVersion = save.resultingVersion;
        node.coldVerified = true;
        node.identityAfter = cold.identity ?? { projectId: node.projectId, fileId, version: save.resultingVersion };
        if (Array.isArray(cold.parameters)) saved[fileId + ':parameters'] = cold.parameters;
      } else {
        node.resultingVersion = save.resultingVersion;
        node.coldVerified = false;
      }
      node.method = usedNativeUpdate ? 'UpdateAllLatestCmd' : update.method;
      node.saveStatus = 'complete';
      node.status = 'complete';
      if (input.durability !== 'cold') node.coldVerified = false;
      node.identityAfter = save.identityAfter ?? node.identityAfter ??
        { projectId: node.projectId, fileId, version: save.resultingVersion };
      node.checks = check;
      node.metadataCoverage = save.metadataCoverage ?? check.metadataCoverage ?? null;
      result.completed.push({ fileId, baselineVersion: node.version, resultingVersion: save.resultingVersion,
        method: node.method, commandReceipt: usedNativeUpdate ? 'UpdateAllLatestCmd' : null,
        saveStatus: 'complete', coldVerified: node.coldVerified, health: check.health ?? null, checks: check,
        metadataCoverage: node.metadataCoverage });
      result.inProgress = null;
      result.lifecycleEffects.push(...(save.lifecycleEffects ?? []));
      await persist('document_completed', { fileId, resultingVersion: save.resultingVersion });
      if ((deps.now ?? Date.now)() > deadline) {
        result.budgetExceeded = true;
        const remaining = plan.order.slice(plan.order.indexOf(fileId) + 1).filter(id => plan.updates.some(row => row.fileId === id));
        if (remaining.length) {
          result.invocationStatus = 'partial';
          result.notProcessed.push(...remaining);
          result.continuation = { reason: 'budgetExhausted' };
          await persist('budget_overrun_settled', { notProcessed: remaining });
          return result;
        }
      }
    }
    if (result.blocked.length || result.failed.length || result.notProcessed.length) {
      result.invocationStatus = result.notProcessed.length || result.completed.length ? 'partial' : result.blocked.length ? 'blocked' : 'failed';
    }
    const finalRoot = { ...input.root, version: saved[input.root.fileId] ?? input.root.version };
    const finalSnapshot = await deps.step('graph', { ...input, root: finalRoot, policy: plan.policy,
      phase: 'audit', effectiveTargets, savedVersions: saved }, input, contextFor(plan, plan.scopeFileId));
    result.edges = plan.edges.map(edge => {
      const fresh = (finalSnapshot.edges ?? []).find(row => row.edgeId === edge.edgeId);
      const target = effectiveTargets[edge.edgeId] ?? edge.targetVersion;
      return { ...edge, ...(fresh ? { observedAfter: fresh.baselineVersion,
        status: fresh.baselineVersion === target ? (edge.explicitPin ? 'pinned' : 'current') : 'outdated' } : { status: 'unresolved' }) };
    });
    const unresolved = result.edges.some(edge => edge.status === 'unresolved');
    result.allIntendedReferencesCurrent = unresolved ? null : result.edges.every(edge => edge.selfReference || edge.observedAfter === (effectiveTargets[edge.edgeId] ?? edge.targetVersion));
    result.allReferencesLatest = unresolved ? null : result.edges.every(edge => edge.selfReference || edge.observedAfter === edge.latestVersion);
    result.graphComplete = finalSnapshot.graphComplete === true;
    if (!['unknown', 'failed', 'blocked', 'partial'].includes(result.invocationStatus)) {
      result.invocationStatus = result.graphComplete && result.allIntendedReferencesCurrent === true ? 'complete' : 'partial';
    }
    result.success = result.invocationStatus === 'complete';
    result.modelValidated = result.success;
    await persist('apply_settled');
    return result;
  } finally {
    await lock.close();
    await (deps.fs ?? fs).unlink(lockPath).catch(() => {});
  }
}

function contextFor(plan, fileId) {
  const doc = plan.documents.find(row => row.fileId === fileId) ?? plan.documents[0];
  return doc ? { doc: doc.name, docId: doc.creationId, docFileId: doc.fileId, projectId: doc.projectId } : {};
}

async function execute(client, data, context, deps = {}) {
  let input = validate(data);
  if (input.phase === 'inspect') return inspect(client, input, deps);
  if (!deps.step) throw new Error('references.refresh requires the shipped SDK step adapter');
  if (input.phase === 'apply') {
    const rootPath = path.resolve(input.reportPath);
    const plan = await readPlan(rootPath, input.planId, deps.fs ?? fs);
    if (plan.requestId === input.requestId) throw new Error('apply requires a new requestId distinct from its immutable plan request');
    if (plan.root.projectId !== input.root.projectId || plan.root.fileId !== input.root.fileId ||
        plan.root.version !== input.root.version || plan.scopeFileId !== (input.scopeFileId ?? input.root.fileId)) {
      throw new Error('apply root/scope differs from the immutable plan');
    }
    const optionKeys = ['policy', 'pins', 'allowedProjectIds', 'scopeFileId', 'lifecycle', 'nativeFallback',
      'durability', 'parameterBindings', 'callerNamespaces', 'maxFiles', 'maxUpdates'];
    for (const key of optionKeys) {
      if (Object.hasOwn(data, key) && hash(data[key]) !== hash(key === 'scopeFileId' ? plan.scopeFileId :
          (key === 'policy' || key === 'lifecycle' || key === 'nativeFallback' || key === 'durability' ? plan[key] : plan.options?.[key]))) {
        throw new Error(`apply ${key} differs from the immutable plan`);
      }
    }
    if (data.timeBudgetMs !== undefined && data.timeBudgetMs > (plan.options?.timeBudgetMs ?? plan.timeBudgetMs)) {
      throw new Error('apply cannot expand the immutable plan timeBudgetMs');
    }
    const applyData = { ...data, ...clone(plan.options ?? {}), phase: 'apply', root: plan.root,
      policy: plan.policy, scopeFileId: plan.scopeFileId, lifecycle: plan.lifecycle, nativeFallback: plan.nativeFallback,
      durability: plan.durability, planId: input.planId, confirm: true,
      ...(data.timeBudgetMs !== undefined ? { timeBudgetMs: data.timeBudgetMs } : {}),
      ...(data.uiLeases !== undefined ? { uiLeases: data.uiLeases } : {}) };
    input = validate(applyData);
    const requestHash = hash({ request: { ...input, phase: 'apply', confirm: true }, planId: input.planId });
    const prior = await loadJournal(rootPath, input.requestId, deps.fs ?? fs);
    if (prior.writerActive) return { operation: 'references.refresh', schemaVersion: 1,
      requestId: input.requestId, planId: input.planId, invocationStatus: 'unknown', success: false,
      modelValidated: false, inProgress: prior.report?.inProgress ?? null,
      unavailableEvidence: ['existing request writer is active; no replay or lock theft'] };
    if (prior.report) {
      if (prior.report.requestHash !== requestHash) throw new Error('requestId already belongs to a different immutable apply request');
      return prior.report.result ? { ...prior.report.result, replayedReceipt: true } :
        { operation: 'references.refresh', schemaVersion: 1, requestId: input.requestId, planId: input.planId,
          invocationStatus: 'unknown', inProgress: prior.report.inProgress ?? null, replayedReceipt: true,
          unavailableEvidence: ['existing immutable request receipt has no settled result'] };
    }
    if (input.nativeFallback === 'qualifiedOnce') {
      const missing = plan.updates.filter(update =>
        (update.method === 'UpdateAllLatestCmd' || update.fallback === 'UpdateAllLatestCmd') &&
        !input.uiLeases?.[update.fileId]);
      if (missing.length) {
        return apply(client, input, plan, { ...deps, initialBlockers: missing.map(row => ({fileId:row.fileId,
          reason:'authorizedUiLeaseRequired'})) });
      }
    }
    const snapshot = await deps.step('graph', { ...input, phase: 'audit', policy: plan.policy }, input, context);
    const blockers = planFreshness(plan, snapshot);
    return apply(client, input, plan, { ...deps, initialSnapshot: snapshot, initialBlockers: blockers });
  }
  const readRequestHash = hash({ operation: 'references.refresh', request: { ...input, phase: input.phase } });
  const previous = await loadJournal(path.resolve(input.reportPath), input.requestId, deps.fs ?? fs);
  if (previous.writerActive) return { operation: 'references.refresh', schemaVersion: 1,
    requestId: input.requestId, root: input.root, invocationStatus: 'unknown', success: false,
    modelValidated: false, unavailableEvidence: ['existing request writer is active; no replay or lock theft'] };
  if (previous.report) {
    if (previous.report.requestHash !== readRequestHash) throw new Error('requestId already belongs to a different immutable read/plan request');
    return { ...previous.report.result, replayedReceipt: true };
  }
  const snapshot = await deps.step('graph', input, input, context);
  const plan = makePlan(snapshot, input);
  if (input.phase === 'audit') {
    const planned = { ...plan, invocationStatus: plan.blocked.length ? 'blocked' : 'complete',
      completed: [], skipped: plan.skipped, failed: [], notProcessed: [], inProgress: null,
      budgetExceeded: false, continuation: null, errors: [] };
    if ((plan.notPlanned.length || !plan.graphComplete) && planned.invocationStatus === 'complete') planned.invocationStatus = 'partial';
    planned.success = planned.invocationStatus === 'complete'; planned.modelValidated = true;
    return finishReadPhase(input, planned, deps);
  }
  if (input.phase === 'plan') {
    const root = path.resolve(input.reportPath);
    const planId = await writePlan(root, plan, deps.fs ?? fs);
    const result = { ...plan, phase: 'plan', planId,
      invocationStatus: plan.blocked.length ? 'blocked' : plan.notPlanned.length ? 'partial' : 'complete' };
    result.success = result.invocationStatus === 'complete'; result.modelValidated = true;
    return finishReadPhase(input, result, deps);
  }
  throw new Error('Unsupported references.refresh phase');
}

module.exports = { configure, validate, makePlan, dependencyOrder, staleBeforeStep, planFreshness, writePlan,
  readPlan, loadJournal, apply, execute };
