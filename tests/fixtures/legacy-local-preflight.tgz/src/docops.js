const fs = require('fs');

function parseJson(text) {
  try {
    return JSON.parse(text);
  } catch (e) {
    return null;
  }
}

function printResults(results, prefix) {
  for (const r of results || []) {
    const parts = [];
    for (const k of ['name', 'id', 'isActive', 'isModified', 'isSaved']) {
      if (r[k] !== undefined) parts.push(`${k}=${r[k]}`);
    }
    process.stdout.write(`${prefix} ${parts.join(' ')}\n`);
  }
  process.stdout.write('DONE\n');
}

async function docSearchCmd(client, args) {
  let name = null;
  let project = null;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--project') project = args[++i];
    else name = args[i];
  }
  if (!name) {
    process.stderr.write('usage: fmcad doc search <name> [--project <name>]\n');
    return 1;
  }
  const callArgs = { queryType: 'document', operation: 'search', name };
  if (project) callArgs.project = project;
  const out = await client.callTool(callArgs, 'fusion_mcp_read');
  const j = out.data || parseJson(out.text);
  printResults(j && j.results, 'FILE');
  return out.failed ? 1 : 0;
}

async function docListCmd(client) {
  const out = await client.callTool({ queryType: 'document', operation: 'open' }, 'fusion_mcp_read');
  const j = out.data || parseJson(out.text);
  printResults(j && j.results, 'DOC');
  return out.failed ? 1 : 0;
}

async function docRecentCmd(client) {
  const out = await client.callTool({ queryType: 'document', operation: 'recent' }, 'fusion_mcp_read');
  const j = out.data || parseJson(out.text);
  printResults(j && j.results, 'FILE');
  return out.failed ? 1 : 0;
}

async function docOpenCmd(client, args) {
  const name = args[0];
  if (!name) {
    process.stderr.write('usage: fmcad doc open <name>\n');
    return 1;
  }
  const out = await client.callTool({ queryType: 'document', operation: 'search', name }, 'fusion_mcp_read');
  if (out.failed) {
    process.stderr.write('ERROR document search failed: ' + out.text + '\n');
    return 1;
  }
  const j = out.data || parseJson(out.text);
  const results = (j && j.results) || [];
  if (!results.length) {
    process.stderr.write(`ERROR no document matching: ${name}\n`);
    return 1;
  }
  const first = results[0];
  const opened = await client.callTool(
    { featureType: 'document', object: { operation: 'open', fileId: first.id } },
    'fusion_mcp_execute'
  );
  process.stdout.write(`OPENED name=${first.name} id=${first.id}\n`);
  return opened.failed ? 1 : 0;
}

async function docSaveCmd(client) {
  const out = await client.callTool({ featureType: 'document', object: { operation: 'save' } }, 'fusion_mcp_execute');
  const j = parseJson(out.text);
  process.stdout.write((j && (j.message || j.error)) || out.text || '');
  if (!(j && (j.message || j.error))) process.stdout.write(out.text + '\n');
  process.stdout.write('\nDONE\n');
  return out.failed ? 1 : 0;
}

async function docCloseCmd(client, args) {
  const save = args.includes('--save');
  const discard = args.includes('--discard');
  if (!save && !discard) {
    process.stderr.write('ERROR doc close requires --save or --discard\n');
    return 1;
  }
  const object = { operation: 'close' };
  if (save) object.userConfirmedSaveAndClose = true;
  if (discard) object.userConfirmedCloseWithoutSave = true;
  const out = await client.callTool({ featureType: 'document', object }, 'fusion_mcp_execute');
  process.stdout.write(out.text + '\n');
  return out.failed ? 1 : 0;
}

function findBase64(text) {
  const j = parseJson(text);
  if (!j) return null;
  if (j.base64Data) return j.base64Data;
  if (j.data) return j.data;
  if (j.result && j.result.base64Data) return j.result.base64Data;
  const content = j.content || (j.result && j.result.content);
  if (Array.isArray(content)) {
    for (const item of content) {
      if (item.type === 'image' && item.data) return item.data;
      if (item.base64Data) return item.base64Data;
    }
  }
  return null;
}

async function shotCmd(client, args) {
  let outFile = null;
  const callArgs = { queryType: 'screenshot' };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--out') outFile = args[++i];
    else if (a === '--dir') callArgs.direction = args[++i];
    else if (a === '--width') callArgs.width = Number(args[++i]);
    else if (a === '--height') callArgs.height = Number(args[++i]);
    else if (a === '--no-aa') callArgs.antiAliasing = false;
    else if (a === '--transparent') callArgs.transparentBackground = true;
  }
  const out = await client.callTool(callArgs, 'fusion_mcp_read');
  const b64 = findBase64(JSON.stringify(out.data || {})) || findBase64(out.text);
  if (out.failed) {
    process.stderr.write('ERROR screenshot failed: ' + out.text + '\n');
    return 1;
  }
  if (!b64) {
    process.stderr.write('ERROR no image data in screenshot response\n');
    return 1;
  }
  const file = outFile || `shot-${Date.now()}.png`;
  fs.writeFileSync(file, Buffer.from(b64, 'base64'));
  process.stdout.write(`SHOT path=${file} bytes=${Buffer.from(b64, 'base64').length}\n`);
  return 0;
}

async function undoRedoCmd(client, which) {
  const out = await client.callTool({ featureType: which }, 'fusion_mcp_update');
  process.stdout.write(out.text + '\n');
  return out.failed ? 1 : 0;
}

async function licensingCmd(client) {
  const out = await client.callTool({ queryType: 'licensing' }, 'fusion_mcp_read');
  const j = out.data || parseJson(out.text);
  if (j && j.summary) process.stdout.write(JSON.stringify(j.summary, null, 2) + '\n');
  else process.stdout.write(out.text + '\n');
  return out.failed ? 1 : 0;
}

async function activeCmd(client) {
  const out = await client.callTool({ queryType: 'activeCommand' }, 'fusion_mcp_read');
  const j = out.data || parseJson(out.text);
  if (j && j.activeCommand === null) process.stdout.write('NONE\n');
  else process.stdout.write(JSON.stringify(j, null, 2) + '\n');
  return out.failed ? 1 : 0;
}

async function docNewCmd(client, args) {
  let name = '';
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--name') name = args[++i] || '';
  }
  const code =
    'import adsk.core\n\nNAME = ' +
    JSON.stringify(name) +
    '\n\ndef run(_context: str):\n    app = adsk.core.Application.get()\n    doc = app.documents.add(adsk.core.DocumentTypes.FusionDesignDocumentType)\n    if NAME:\n        doc.name = NAME\n    print("CREATED_DOC name=" + doc.name)\n';
  const out = await client.callTool({ featureType: 'script', object: { script: code } }, 'fusion_mcp_execute');
  process.stdout.write(out.text + '\n');
  return out.failed ? 1 : 0;
}

async function fileDownloadCmd(client, args, toWindowsPath) {
  const name = args[0];
  if (!name) {
    process.stderr.write('usage: fmcad file_download <name> [--out <wsl_path|dir>]\n');
    return 1;
  }
  let outPath = null;
  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--out') outPath = args[++i] || '';
  }
  const searched = await client.callTool({ queryType: 'document', operation: 'search', name }, 'fusion_mcp_read');
  if (searched.failed) {
    process.stderr.write('ERROR file search failed: ' + searched.text + '\n');
    return 1;
  }
  const j = searched.data || parseJson(searched.text);
  const results = (j && j.results) || [];
  if (!results.length) {
    process.stderr.write(`ERROR no document matching: ${name}\n`);
    return 1;
  }
  let winPath;
  if (outPath && /\.[A-Za-z0-9]{1,5}$/.test(outPath)) {
    winPath = toWindowsPath(outPath);
  } else {
    const dir = toWindowsPath(outPath || process.cwd());
    const fname = String(results[0].name).replace(/[\\/:*?"<>|]/g, '_');
    winPath = dir + '\\' + fname;
  }
  const code =
    'import adsk.core\n\nFILE_ID = ' +
    JSON.stringify(results[0].id) +
    '\nDIR_PATH = ' +
    JSON.stringify(winPath) +
    '\n\ndef run(_context: str):\n    app = adsk.core.Application.get()\n    f = app.data.findFileById(FILE_ID)\n    if f is None:\n        print("ERROR file not found by id")\n        return\n    if not f.download(DIR_PATH, None):\n        print("ERROR download failed (note: Fusion files like F3D cannot be downloaded)")\n        return\n    print("DOWNLOADED path=" + DIR_PATH)\n';
  const out = await client.callTool({ featureType: 'script', object: { script: code } }, 'fusion_mcp_execute');
  process.stdout.write(out.text + '\n');
  return out.failed ? 1 : 0;
}

module.exports = {
  docSearchCmd,
  docListCmd,
  docRecentCmd,
  docOpenCmd,
  docNewCmd,
  docSaveCmd,
  docCloseCmd,
  shotCmd,
  undoRedoCmd,
  licensingCmd,
  activeCmd,
  fileDownloadCmd,
};
