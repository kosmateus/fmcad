// Diagnostic sinks only: never apply this to execution stdout or CAD payloads.
function redactDiagnostic(value, backend = {}) {
  let text = String(value);
  const secrets = Object.entries(backend.headers || {})
    .filter(([name]) => !/^(host|accept|content-type|content-length)$/i.test(name))
    .flatMap(([, value]) => [String(value), String(value).replace(/^(Bearer|Basic)\s+/i, '')]);
  if (backend.url) {
    text = text.split(String(backend.url)).join('[REDACTED URL]');
    try {
      const url = new URL(backend.url);
      secrets.push(url.username, url.password, decodeURIComponent(url.username), decodeURIComponent(url.password));
      for (const [name, value] of url.searchParams) {
        if (/^(access_token|refresh_token|token|api[_-]?key|key|secret|password|signature|sig|credential)$/i.test(name)) secrets.push(value);
      }
    } catch { /* Pattern redaction still applies to malformed URLs. */ }
  }
  for (const secret of [...new Set(secrets.filter(Boolean))].sort((a, b) => b.length - a.length)) {
    text = text.split(secret).join('[REDACTED]');
  }
  return text
    // Raw line-start headers include comma-separated values and folded lines.
    .replace(/^([ \t]*(?:authorization|proxy-authorization|x-api-key|api-key|cookie|set-cookie|mcp-session-id|access_token|refresh_token|client_secret|password|api_key|secret)[ \t]*[:=][ \t]*)(?:\r?\n)?[^\r\n]*(?:\r?\n[ \t]+[^\r\n]*)*/gim,
      (_, prefix) => prefix + '[REDACTED]')
    .replace(/https?:\/\/[^\s"'<>]+/gi, url => url
      .replace(/(https?:\/\/)[^/]*@/i, '$1[REDACTED]@')
      .replace(/([?&#](?:access_token|refresh_token|token|api[_-]?key|key|secret|password|signature|sig|credential)=)[^&#]*/gi, '$1[REDACTED]'))
    .replace(/((?:["']?)(?:authorization|proxy-authorization|x-api-key|api-key|cookie|set-cookie|mcp-session-id|access_token|refresh_token|client_secret|password|api_key|secret)["']?\s*[:=]\s*)("(?:\\.|[^"\\\r\n])*"?|'(?:\\.|[^'\\\r\n])*'?|[^\r\n,"'}]+)/gi,
      (_, prefix, value) => prefix + (/^"[^"\r\n]+"\s*:/.test(prefix) || value.startsWith('"') ? '"[REDACTED]"' : value.startsWith("'") ? "'[REDACTED]'" : '[REDACTED]'))
    .replace(/\b(Bearer|Basic)\s+[A-Za-z0-9+\/_.=~-]+/gi, '$1 [REDACTED]');
}

// JSON.parse messages may quote input (including partial/escaped credentials).
// Copy only numeric location metadata, never the parser's prose or snippets.
function formatJsonError(error) {
  const location = String(error.message).match(/ at position (\d+)(?: \(line (\d+) column (\d+)\))?$/);
  if (location) {
    return `Invalid JSON at position ${location[1]}` +
      (location[2] ? ` (line ${location[2]} column ${location[3]})` : '');
  }
  const line = String(error.message).match(/(?: at | \()line (\d+) column (\d+)\)?$/);
  return 'Invalid JSON' + (line ? ` (line ${line[1]} column ${line[2]})` : '');
}

module.exports = { redactDiagnostic, formatJsonError };
