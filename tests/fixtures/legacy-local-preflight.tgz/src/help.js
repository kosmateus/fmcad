const { commands, findCommand, OPS_DETAIL, DOC_SUB, SPECIAL: specialDescriptors } = require('./commands');
const { contextualHelp } = require('./help-details');
const { manualHelp } = require('./help-manual');

function detail(cmd, ...sub) {
  const entry = findCommand([cmd, ...sub].filter(Boolean));
  if (!entry) return `No detailed help for "${cmd}". Run "fmcad help" for the full command list.\n`;
  const exampleNote = entry.kind === 'cad'
    ? 'Illustrative input example: existing names/IDs/tokens require discovery; token/library-ID strings shown here are placeholders, not usable IDs. See worked prerequisites below.\n'
    : 'Example:\n';
  const usage = entry.key === 'tools' ? 'tools [--json]' : entry.usage;
  let text = `Help: ${entry.key}\n\nUsage:\n  fmcad ${usage}\n\n${entry.description}\n\n${exampleNote}  ${entry.example}\n`;
  if (entry.extra) text += `\n${entry.extra}\n`;
  if (entry.kind === 'local' || entry.kind === 'queue') return text;
  text += contextualHelp(entry);
  text += manualHelp(entry);
  text += '\nBackend: --backend mcp (default) or --backend addin. Settings can also select the backend.\n' +
    'addin targets AutodeskFusionMCP by Frank Hommers, not the official service. No automatic fallback/retry.\n' +
    'Read-only declarations are sent to the selected server; enforcement depends on that server. addin does not provide a sandbox.\n' +
    'addin limitations: licensing, recent documents, undo/redo and electronics require explicit --backend mcp.\n' +
    'WSL: addin defaults to --transport windows-curl for Windows localhost; override with node when appropriate.\n';
  return text;
}

function globalHelp() {
  return `fmcad - CLI for the Autodesk Fusion MCP

Usage:
  fmcad <command> [args...] [flags...]
  fmcad help <command> [subcommand]
  fmcad <command> [subcommand] --help

Commands:
${commands.filter((c) => c.kind !== 'family').map((c) => `  ${c.usage}`).join('\n')}

Global flags: --config <path>  --url <url>  --header K:V (repeatable)  --timeout <ms>
Backend: --backend <mcp|addin> (default mcp); env FMCAD_BACKEND; config backend/backends.
Transport: --transport <node|windows-curl>  --curl-path <executable>.
Queue (optional): --routing direct|queue; FMCAD_ROUTING or config routing. After enabling queue, ordinary commands wait automatically.
Queue globals: --client LABEL --request-id ID --queue-timeout MS --expected-revision N --sequence-action begin|continue|end --sequence-id ID.
Queue --timeout bounds active whole-command execution, not waiting. Direct --timeout retains its existing per-RPC semantics.
Queued execution autostarts one shared broker by default. Config queue.autoStart:false selects manual startup; queue.startupTimeoutMs defaults to 60000.
Manual start: fmcad queue serve --backend addin --confirm-ownership true. Help: fmcad help queue serve.
addin uses the independent AutodeskFusionMCP add-in on localhost:8765; WSL defaults to Windows curl.
No automatic fallback or mutation retry. addin has no enforced read-only sandbox.
addin does not emulate licensing, recent documents, undo/redo, or electronics; select mcp explicitly for those.
Help aliases: --help, -h. Run script listing aliases: --list, -l.

Scripts for 'run' resolve from:
  1) ~/.config/fmcad/scripts/<name>.py    (user scripts)
  2) <package>/assets/scripts/<name>.py   (built-in scripts)
A script may declare an 'ARGS = [...]' line; --args '<json>' replaces it.
Alternatively, --args-file <path> reads any JSON value from a local UTF-8 file (relative to cwd).
--args and --args-file are mutually exclusive; files are parsed before backend setup.
`;
}

const SPECIAL = Object.fromEntries(Object.keys(specialDescriptors).map((key) => [key, () => detail(key)]));
module.exports = { detail, globalHelp, OPS_DETAIL, DOC_SUB, SPECIAL };
