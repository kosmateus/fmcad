const { spawn } = require('node:child_process');

const WARNING = 'operation MAY HAVE RUN; inspect before retry';

// curl config double quotes recognize backslash escapes, unlike shell quoting.
// JSON.stringify escapes payload controls; URL/header controls are rejected below.
const configQuote = value => '"' + value.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
const controls = /[\x00-\x1f\x7f]/;

// curl --include emits interim headers followed by final headers and decoded body.
// Keep body bytes separate from header parsing, including for JSON and SSE.
function parseCurlResponse(output) {
  const buffer = Buffer.isBuffer(output) ? output : Buffer.from(output);
  let offset = 0;
  while (offset < buffer.length) {
    let end = buffer.indexOf('\r\n\r\n', offset);
    let separator = 4;
    const lfEnd = buffer.indexOf('\n\n', offset);
    if (lfEnd !== -1 && (end === -1 || lfEnd < end)) {
      end = lfEnd;
      separator = 2;
    }
    if (end === -1) break;
    const lines = buffer.subarray(offset, end).toString('latin1').split(/\r?\n/);
    const match = /^HTTP\/\d+(?:\.\d+)?\s+(\d{3})(?:\s|$)/.exec(lines.shift());
    if (!match) break;
    const status = Number(match[1]);
    const headers = {};
    for (const line of lines) {
      const colon = line.indexOf(':');
      if (colon <= 0) throw new Error('invalid curl response header');
      headers[line.slice(0, colon).toLowerCase()] = line.slice(colon + 1).trim();
    }
    offset = end + separator;
    if (status >= 100 && status < 200 && status !== 101) continue;
    if (status < 200 || status > 599) break;
    const body = buffer.subarray(offset);
    if (headers['content-length'] !== undefined && !headers['transfer-encoding']) {
      const length = headers['content-length'];
      if (!/^\d+$/.test(length) || Number(length) !== body.length) {
        throw new Error('curl response Content-Length mismatch');
      }
    }
    return { status, sessionId: headers['mcp-session-id'], raw: body.toString('utf8') };
  }
  throw new Error('missing or invalid final curl HTTP response');
}

// Windows-only loopback bridge (not a LAN exposure mechanism). Native HTTP remains
// available for external servers. No redirects, retries, proxy or backend fallback.
// maxBuffer bounds combined stdout/stderr; 32 MiB accommodates 16 MiB screenshots.
// The optional spawn implementation is a test seam, not a server configuration.
function postWithCurl(server, payload, sessionId, spawnImpl = spawn) {
  return new Promise((resolve, reject) => {
    if (controls.test(server.url)) throw new Error('invalid windows-curl request URL');
    const url = new URL(server.url);
    if (!['http:', 'https:'].includes(url.protocol) ||
        !['localhost', '127.0.0.1', '[::1]'].includes(url.hostname)) {
      throw new Error('windows-curl requires an HTTP(S) loopback URL (localhost, 127.0.0.1 or ::1)');
    }
    const timeoutMs = server.timeoutMs ?? 180000;
    const maxBuffer = server.maxBuffer ?? 32 * 1024 * 1024;
    if (!Number.isFinite(timeoutMs) || timeoutMs < 0 || timeoutMs > 2147483647 ||
        !Number.isSafeInteger(maxBuffer) || maxBuffer <= 0) {
      throw new Error('windows-curl requires nonnegative timeoutMs and positive maxBuffer');
    }
    const body = Buffer.from(JSON.stringify(payload));
    const headers = new Map([
      ['content-type', 'application/json'],
      ['accept', 'application/json, text/event-stream'],
      ['content-length', String(body.length)],
    ]);
    for (const [name, value] of Object.entries(server.headers || {})) {
      if (!/^[!#$%&'*+.^_`|~0-9A-Za-z-]+$/.test(name) || controls.test(String(value))) {
        throw new Error('invalid windows-curl request header');
      }
      headers.set(name.toLowerCase(), String(value));
    }
    if (sessionId) {
      if (controls.test(sessionId)) throw new Error('invalid windows-curl session ID');
      headers.set('mcp-session-id', String(sessionId));
    }
    const args = ['--disable', '--silent', '--show-error', '--include', '--globoff',
      '--noproxy', '*', '--max-time', String(timeoutMs / 1000), '--request', 'POST'];
    args.push('--config', '-');
    // Only this generated config is loaded. JSON bytes are literal data-binary,
    // never an @file reference (even a JSON string beginning with @ is quoted).
    const config = [
      `url = ${configQuote(server.url)}`,
      ...Array.from(headers, ([name, value]) => `header = ${configQuote(`${name}: ${value}`)}`),
      `data-binary = ${configQuote(body.toString('utf8'))}`,
    ].join('\n') + '\n';
    let child;
    let timer;
    let settled = false;
    const fail = (message, code, cause) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (child) child.kill('SIGKILL');
      const error = new Error(`windows-curl ${message}; ${WARNING}`, { cause });
      error.code = code;
      reject(error);
    };
    try {
      child = spawnImpl(server.curlPath || '/mnt/c/Windows/System32/curl.exe', args,
        { shell: false, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    } catch (error) {
      fail('spawn failed', error.code, error);
      return;
    }
    if (timeoutMs > 0) timer = setTimeout(() => fail(`timeout after ${timeoutMs} ms`, 'ETIMEDOUT'), timeoutMs);
    const chunks = [];
    let bytes = 0;
    for (const [stream, keep] of [[child.stdout, true], [child.stderr, false]]) {
      stream.on('data', chunk => {
        if (settled) return;
        bytes += chunk.length;
        if (bytes > maxBuffer) {
          fail(`output exceeds maxBuffer (${maxBuffer} bytes)`, 'ENOBUFS');
        } else if (keep) chunks.push(chunk);
      });
      stream.on('error', error => fail('output stream failed', error.code, error));
    }
    child.on('error', error => fail('spawn/process failed', error.code, error));
    child.stdin.on('error', error => fail('stdin failed', error.code, error));
    child.on('close', (code, signal) => {
      if (settled) return;
      if (code !== 0) {
        fail(code === 28 ? `timeout after ${timeoutMs} ms (curl exit 28)` :
          `failed (exit ${code}, signal ${signal || 'none'})`, code === 28 ? 'ETIMEDOUT' : code);
        return;
      }
      let response;
      try {
        response = parseCurlResponse(Buffer.concat(chunks));
      } catch (error) {
        fail(error.message, 'EPROTO', error);
        return;
      }
      settled = true;
      clearTimeout(timer);
      resolve(response);
    });
    child.stdin.end(Buffer.from(config));
  });
}

module.exports = { postWithCurl, parseCurlResponse };
