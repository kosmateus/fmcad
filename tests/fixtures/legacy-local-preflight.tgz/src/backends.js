const { McpClient } = require('./client');
const { AddinClient } = require('./addin-client');

function createBackend(server, constructors = {}) {
  const backend = server.backend || 'mcp';
  if (backend === 'mcp') return new (constructors.McpClient || McpClient)(server);
  if (backend === 'addin') return new (constructors.AddinClient || AddinClient)(server);
  throw new Error('Unknown backend: ' + backend);
}

module.exports = { createBackend };
