const fs = require('fs');
const path = require('path');
const { pythonValue } = require('./python');

const OPS = {
  projects: 0,
  project_create: 1,
  project_rename: 2,
  folder_list: 1,
  folder_create: 2,
  folder_rename: 3,
  folder_delete: 2,
  file_rename: 4,
  file_move: 4,
  file_delete: 3,
  file_editability: 0,
  file_editability_list: 0,
  tree: 1,
  param_list: 0,
  param_add: 2,
  param_set: 2,
  param_rename: 2,
  param_delete: 1,
  plane_list: 0,
  plane_add: 4,
  plane_rename: 2,
  plane_delete: 1,
  stats: 0,
  bbox: 0,
  bodies: 0,
  comp_list: 0,
  comp_add: 1,
  rollback: 1,
  units: 1,
  upload: 1,
};

const DOCUMENT_OPS = ['param', 'plane', 'stats', 'bbox', 'bodies', 'comp', 'rollback', 'units'];

function scriptFileForOp(op) {
  if (op === 'stats' || op === 'bbox' || op === 'bodies' || op === 'rollback' || op === 'units') return 'inspect.py';
  if (op === 'comp_list' || op === 'comp_add') return 'component.py';
  if (op === 'upload') return 'upload.py';
  return 'fusion_data_manager.py';
}

function buildOpScript(op, args) {
  const file = path.join(__dirname, '..', 'assets', scriptFileForOp(op));
  let code = fs.readFileSync(file, 'utf8');
  code = code.replace('OP = "help"', () => 'OP = ' + pythonValue(op));
  code = code.replace('ARGS = []', () => 'ARGS = ' + pythonValue(args));
  return code;
}

function buildExportScript(args) {
  const file = path.join(__dirname, '..', 'assets', 'export.py');
  let code = fs.readFileSync(file, 'utf8');
  code = code.replace('OP = "help"', 'OP = "export"');
  code = code.replace('ARGS = []', () => 'ARGS = ' + pythonValue(args));
  return code;
}

module.exports = { OPS, DOCUMENT_OPS, buildOpScript, buildExportScript };
