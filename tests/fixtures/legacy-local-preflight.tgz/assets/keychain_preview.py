"""Offline planned-geometry previews and fixed-reference semantic evidence."""
import copy
import io
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET

import cairosvg
import numpy as np
from PIL import Image
from scipy import ndimage as ndi

SVG = 'http://www.w3.org/2000/svg'


def geometry_path(profile, plan):
    """Undo geometry_for's mm transform; preserve exact lines and cubic controls."""
    geometry = json.loads(Path(profile['geometryPath']).read_text())['geometry']
    scale, center = plan['mmPerPixel'], plan['centerPx']
    if not math.isfinite(scale) or scale <= 0 or plan['imageSide'] not in ('top', 'bottom'):
        raise ValueError('Invalid plan coordinate frame')
    def point(raw):
        values = []
        for value in raw[:2]:
            if not isinstance(value, str) or not value.endswith(' mm'):
                raise ValueError('Plan coordinates must be explicit mm strings')
            values.append(float(value[:-3]))
        x, y = values
        if not all(math.isfinite(v) for v in values):
            raise ValueError('Nonfinite plan coordinate')
        return (center[0] + x / scale * (-1 if plan['imageSide'] == 'bottom' else 1),
                center[1] - y / scale)
    def text(p):
        return f'{p[0]:.12g} {p[1]:.12g}'
    rings, ring, start, current = [], [], None, None
    for item in geometry:
        if item['type'] == 'line':
            points = [point(item['start']), point(item['end'])]
            command = 'L'
        elif item['type'] == 'bezier' and len(item['controlPoints']) == 4:
            points = [point(p) for p in item['controlPoints']]
            command = 'C'
        else:
            raise ValueError('Plan preview supports only lines and cubic beziers')
        if start is None:
            start = points[0]
        elif not np.allclose(current, points[0], atol=1e-7, rtol=0):
            raise ValueError('Discontinuous plan ring')
        ring.append((command, points))
        current = points[-1]
        if np.allclose(current, start, atol=1e-7, rtol=0):
            rings.append(ring)
            ring = []
            start = None
    if start is not None or len(rings) != profile['loopCount'] or not rings:
        raise ValueError('Open plan geometry or loopCount mismatch')
    def signed_area(segments):
        area = 0.
        for command, raw in segments:
            p = np.asarray(raw)
            if command == 'L':
                area += (p[0, 0]*p[1, 1] - p[1, 0]*p[0, 1]) / 2
            else:
                # Three-point Gauss quadrature integrates x*y'-y*x' exactly for cubics.
                t = np.array([(1-math.sqrt(3/5))/2, .5, (1+math.sqrt(3/5))/2])[:, None]
                pos = (1-t)**3*p[0] + 3*(1-t)**2*t*p[1] + 3*(1-t)*t*t*p[2] + t**3*p[3]
                tangent = 3*(1-t)**2*(p[1]-p[0]) + 6*(1-t)*t*(p[2]-p[1]) + 3*t*t*(p[3]-p[2])
                area += float(np.dot(pos[:, 0]*tangent[:, 1]-pos[:, 1]*tangent[:, 0], [5/18, 8/18, 5/18])) / 2
        return area
    parts = []
    shell_area = signed_area(rings[0])
    for index, ring in enumerate(rings):
        # CairoSVG ignores evenodd on clip paths. Give the shell and its holes
        # opposite winding too, without changing a single line or cubic curve.
        if index and signed_area(ring) * shell_area > 0:
            ring = [(command, list(reversed(points))) for command, points in reversed(ring)]
        parts.append('M' + text(ring[0][1][0]))
        parts.extend(command + ' '.join(text(p) for p in points[1:]) for command, points in ring)
        parts.append('Z')
    return ' '.join(parts)


def render_plan(plan, size, background, original_uri, output_dir):
    """Paint the footprint and every front cell; retain legacy priority patches."""
    width, height = size
    colors = {c['id']: c['hex'] for c in plan['colors']}
    attrs = dict(xmlns=SVG, width=str(width), height=str(height), viewBox=f'0 0 {width} {height}')
    root = ET.Element('svg', attrs)
    defs = ET.SubElement(root, 'defs')
    layers = []
    def add_clip(identifier, path):
        clip = ET.SubElement(defs, 'clipPath', id=identifier, clipPathUnits='userSpaceOnUse')
        ET.SubElement(clip, 'path', d=path, **{'fill-rule': 'evenodd', 'clip-rule': 'evenodd'})
    base_path = geometry_path(plan['base'], plan)
    add_clip('body', base_path)
    layers.append((base_path, colors[plan['base']['colorId']], []))
    for index, field in enumerate(plan['fields']):
        field_path = geometry_path(field, plan)
        clip = f'field_{index}'
        add_clip(clip, field_path)
        layers.append((field_path, colors[field['colorId']], ['body']))
        for patch in sorted(field['patches'], key=lambda p: p['priority']):
            if patch['clipToField'] != field['id']:
                raise ValueError('Patch clipToField mismatch')
            layers.append((geometry_path(patch, plan), colors[patch['colorId']], ['body', clip]))
    def draw(parent, layer, fill, stroke=None):
        path, _, clips = layer
        for clip in clips:
            parent = ET.SubElement(parent, 'g', **{'clip-path': f'url(#{clip})'})
        values = dict(d=path, fill=fill, **{'fill-rule': 'evenodd'})
        if stroke:
            values.update(stroke=stroke, **{'stroke-width': '.75'})
        ET.SubElement(parent, 'path', values)
    ET.SubElement(root, 'rect', width=str(width), height=str(height), fill=background)
    for layer in layers:
        draw(root, layer, layer[1])
    data = ET.tostring(root, encoding='utf-8', xml_declaration=True)
    png = cairosvg.svg2png(bytestring=data, output_width=width, output_height=height)
    with Image.open(io.BytesIO(png)) as image:
        rendered = image.convert('RGB')
    out = Path(output_dir)
    for name, content in [('normalized.svg', data), ('normalized.png', png)]:
        with (out / name).open('xb') as stream:
            stream.write(content)
    overlay = ET.Element('svg', attrs)
    ET.SubElement(overlay, 'image', width=str(width), height=str(height), href=original_uri)
    overlay_defs = copy.deepcopy(defs)
    overlay.append(overlay_defs)
    for index, layer in enumerate(layers):
        shape = ET.SubElement(overlay_defs, 'g', id=f'paint_{index}')
        draw(shape, layer, 'inherit')
    # Prior paint of the same color suppresses redundant repaint contours. The
    # outside half of a stroke remains where the prior material really differs.
    color_ids = {fill: index for index, fill in enumerate(sorted({layer[1] for layer in layers}))}
    for fill, color_index in color_ids.items():
        for index, layer in enumerate(layers):
            prior = ET.SubElement(overlay_defs, 'g', id=f'prior_{color_index}_{index}')
            if index:
                ET.SubElement(prior, 'use', href=f'#prior_{color_index}_{index-1}')
            ET.SubElement(prior, 'use', href=f'#paint_{index}', fill='black' if layer[1] == fill else 'white')
    # Shared suffix groups avoid quadratic duplication of occluding geometry.
    # Strokes hidden by later paint are masked, without cropping geometry.
    for index in reversed(range(len(layers))):
        covered = ET.SubElement(overlay_defs, 'g', id=f'covered_{index}')
        ET.SubElement(covered, 'use', href=f'#paint_{index}', fill='black')
        if index + 1 < len(layers):
            ET.SubElement(covered, 'use', href=f'#covered_{index+1}')
    for index, layer in enumerate(layers):
        mask = ET.SubElement(overlay_defs, 'mask', id=f'visible_{index}', maskUnits='userSpaceOnUse',
                             x='0', y='0', width=str(width), height=str(height), **{'mask-type': 'luminance'})
        ET.SubElement(mask, 'rect', width=str(width), height=str(height), fill='white')
        if index + 1 < len(layers):
            ET.SubElement(mask, 'use', href=f'#covered_{index+1}')
        different = ET.SubElement(overlay_defs, 'mask', id=f'different_{index}', maskUnits='userSpaceOnUse',
                                 x='0', y='0', width=str(width), height=str(height), **{'mask-type': 'luminance'})
        ET.SubElement(different, 'rect', width=str(width), height=str(height), fill='white')
        if index:
            ET.SubElement(different, 'use', href=f'#prior_{color_ids[layer[1]]}_{index-1}')
        group = ET.SubElement(overlay, 'g', **{'mask': f'url(#visible_{index})'})
        group = ET.SubElement(group, 'g', **{'mask': f'url(#different_{index})'})
        draw(group, layer, 'none', '#00BFFF')
    if plan.get('backing') == 'convex-hull':
        ET.SubElement(overlay, 'path', d=base_path, fill='none', stroke='#D99000',
                      **{'stroke-width': '1.25', 'stroke-dasharray': '5 3',
                         'data-backing': 'convex-hull'})
        ET.SubElement(overlay, 'desc').text = (
            'Explicit convex-hull backing: amber dashed boundary marks the adapted physical footprint; '
            'outline-color material is added beyond the original silhouette.')
    return dict(image=rendered, overlay=ET.tostring(overlay, encoding='utf-8', xml_declaration=True),
                svgPath=str(out / 'normalized.svg'), pngPath=str(out / 'normalized.png'),
                paintedColors=sorted({layer[1] for layer in layers}),
                overlayPolicy='Exact planned L/C controls inverse-transformed to source pixels; evenodd field clips; '
                              'luminance masks suppress later-occluded strokes and same-color prior paint. '
                              'Requires an SVG viewer supporting luminance masks; no geometry cropping or tessellation.')


def significant_regions(mask, min_area=64):
    """Retain original 8-connected boundaries if a 3x3-opened core reaches min_area."""
    structure = np.ones((3, 3), bool)
    raw, _ = ndi.label(mask, structure=structure)
    cores, _ = ndi.label(ndi.binary_opening(mask, structure=structure, border_value=0), structure=structure)
    keep = np.bincount(cores.ravel()) >= min_area
    keep[0] = False
    ids = np.unique(raw[keep[cores]])
    retained = np.isin(raw, ids) & mask
    slices = ndi.find_objects(raw)
    regions = []
    for identifier in ids:
        ys, xs = slices[identifier - 1]
        regions.append(dict(id=int(identifier), bounds=[xs.start, ys.start, xs.stop, ys.stop],
                            mask=raw[ys, xs] == identifier))
    return retained, regions


def reference_features(labels, color_count):
    records = []
    for index in range(1, color_count + 1):
        mask = labels == index
        retained, components = significant_regions(mask)
        holes = ndi.binary_fill_holes(mask, structure=np.ones((3, 3))) & ~mask
        _, holes = significant_regions(holes)
        records.append(dict(mask=retained, components=components, holes=holes))
    background = labels == 0
    exterior = np.zeros(labels.shape, bool)
    exterior[[0, -1], :] = background[[0, -1], :]
    exterior[:, [0, -1]] = background[:, [0, -1]]
    exterior = ndi.binary_propagation(exterior, mask=background, structure=np.ones((3, 3)))
    _, holes = significant_regions(background & ~exterior)
    return dict(colors=records, physicalHoles=holes, size=labels.shape, exterior=exterior)


def semantic_audit(reference, labels, fills, painted_colors, backing='silhouette'):
    if backing not in ('silhouette', 'convex-hull'):
        raise ValueError('Unknown backing mode')
    if labels.shape != reference['size']:
        raise ValueError('Planned preview dimensions differ from frozen reference')
    failures, colors = [], []
    fidelity_mask = ~reference['exterior'] if backing == 'convex-hull' else np.ones(labels.shape, bool)
    def coverage(regions, mask, reason, color):
        records = []
        for region in regions:
            l, t, r, b = region['bounds']
            area = int(region['mask'].sum())
            matched = int(np.count_nonzero(region['mask'] & mask[t:b, l:r]))
            record = dict(id=region['id'], boundsPx=region['bounds'], referenceAreaPx=area,
                          matchedAreaPx=matched, coverage=matched / area, passed=matched / area >= .8)
            records.append(record)
            if not record['passed']:
                failures.append(dict(reason=reason, color=color, **record))
        return records
    for index, (fill, fixed) in enumerate(zip(fills, reference['colors']), 1):
        raw = labels == index
        # Only explicitly declared backing may occupy original exterior background.
        # Original artwork and enclosed physical holes remain protected.
        retained, _ = significant_regions(raw & fidelity_mask)
        union = int(np.count_nonzero(fixed['mask'] | retained))
        intersection = int(np.count_nonzero(fixed['mask'] & retained))
        iou = intersection / union if union else 1.
        record = dict(color=fill, scoringActive=bool(union), iou=iou,
                      referenceAreaPx=int(fixed['mask'].sum()), plannedAreaPx=int(retained.sum()),
                      components=coverage(fixed['components'], raw, 'component_coverage', fill),
                      holes=coverage(fixed['holes'], ~raw, 'hole_retention', fill))
        colors.append(record)
        if union and iou < .8:
            failures.append(dict(reason='color_iou', color=fill, iou=iou))
    holes = coverage(reference['physicalHoles'], labels == 0, 'physical_hole_retention', 'background')
    populations = np.bincount(labels.ravel(), minlength=len(fills) + 1)
    used = [fill for i, fill in enumerate(fills, 1) if populations[i] and fill in painted_colors]
    if len(used) != len(fills):
        failures.append(dict(reason='planned_color_count', expected=len(fills), actual=len(used)))
    return dict(passed=not failures, plannedColorCount=len(used), colors=colors, physicalHoles=holes,
                failures=failures, policy=dict(backing=backing,
                    declaredBackingExteriorExcluded=backing == 'convex-hull',
                    minFeatureArea=64, connectivity=8, openingSize=[3, 3],
                    openingBorderValue=0, componentCoverageMin=.8, holeNonColorRetentionMin=.8,
                    activeColorIoUMin=.8, physicalHoleBackgroundRetentionMin=.8,
                    reference='frozen classified labels; original significant component/hole boundaries retained',
                    iou='reference and planned masks independently exclude components without a significant opened core',
                    exactColorCount='all requested foreground colors must be painted and present in the normalized render',
                    rasterScale=1, geometryValidated=False))
