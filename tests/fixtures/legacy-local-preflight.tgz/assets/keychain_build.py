"""Approved keychain build orchestration with guarded lifecycle cleanup.

Tests replace make_plan, CommandRunner, or subprocess.run; backend credentials
are process arguments only and never enter state or the request journal.
"""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import time
import zipfile
import copy
import binascii
import uuid
from diagnostics import redact_diagnostic


REPO = Path(__file__).resolve().parents[1]
SAVE_POLLS = 20
SAVE_POLL_SECONDS = 3
PRISM_POLL_SECONDS = .25
ARCHIVE_CHUNK_BYTES = 65536
ARCHIVE_MEMBER_LIMIT = 256 * 1024 * 1024
# Native history repeats BRep/graphics streams. A validated 370-prism design
# is 121 MB compressed / 1.09 GB uncompressed; retain bounded streaming with
# headroom for that legitimate archive rather than treating it as corruption.
ARCHIVE_TOTAL_LIMIT = 2 * 1024 * 1024 * 1024
ARCHIVE_ENTRY_LIMIT = 10000


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(ARCHIVE_CHUNK_BYTES), b''):
            value.update(chunk)
    return value.hexdigest()


def inside(path, root):
    path, root = Path(path).absolute(), Path(root).resolve()
    require(path.resolve().is_relative_to(root), 'Path escapes owned directory: ' + str(path))
    require(not any(p.is_symlink() for p in (path, *path.parents)), 'Symlink path rejected: ' + str(path))
    return path


def write_new(path, data):
    mode = 'xb' if isinstance(data, bytes) else 'x'
    with Path(path).open(mode) as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def json_new(path, value):
    write_new(path, json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False))


def publish_final(path, data):
    """Publish complete verified bytes, without replacing any destination entry."""
    path = inside(path, Path(path).parent)
    temporary = '.publish-' + uuid.uuid4().hex + '.tmp'
    directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    owned, descriptor, stream = False, None, None
    errors = []
    try:
        descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                             0o666, dir_fd=directory)
        owned = True
        stream = os.fdopen(descriptor, 'wb', closefd=False)
        require(stream.write(data) == len(data), 'Incomplete final artifact write')
        stream.flush()
        os.fsync(descriptor)
        closing, stream = stream, None
        closing.close()
        closing, descriptor = descriptor, None
        os.close(closing)
        os.link(temporary, path.name, src_dir_fd=directory, dst_dir_fd=directory,
                follow_symlinks=False)
    except BaseException as error:
        errors.append(error)
    finally:
        # Never retry close or remove a final name, even after a durability error.
        # Every name operation stays anchored to the directory we opened above.
        cleanup = []
        if stream is not None:
            cleanup.append(stream.close)
        if descriptor is not None:
            cleanup.append(lambda: os.close(descriptor))
        if owned:
            cleanup.extend((lambda: os.unlink(temporary, dir_fd=directory),
                            lambda: os.fsync(directory)))
        cleanup.append(lambda: os.close(directory))
        for operation in cleanup:
            try:
                operation()
            except BaseException as error:
                errors.append(error)
    if errors:
        primary = errors[0]
        primary.cleanup_errors = tuple(errors[1:])
        if hasattr(primary, 'add_note'):
            for error in errors[1:]:
                primary.add_note('Publication cleanup failed: ' + repr(error))
        raise primary


def archive_codec():
    try:
        import zstandard
    except ImportError as error:
        raise RuntimeError('F3D ZIP method 93 requires zstandard; install assets/keychain_requirements.txt in the selected Python environment before building') from error
    return zstandard


def verify_f3d_archive(path):
    """Read every member and verify length/CRC without extraction or global ZIP patches.

    Fusion currently writes method 93 (Zstandard). ZipInfo copies expose only
    compressed bytes through ZipFile's bounded/header-checked stored reader;
    the original metadata and the archive remain untouched. CRC is checked on
    decompressed bytes below, not on that temporary compressed-byte view.
    """
    codec = archive_codec()
    rows = []
    with zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        require(0 < len(entries) <= ARCHIVE_ENTRY_LIMIT, 'F3D archive entry-count limit exceeded or archive empty')
        require(len({e.filename for e in entries}) == len(entries), 'F3D contains duplicate member names')
        require(sum(e.file_size for e in entries) <= ARCHIVE_TOTAL_LIMIT, 'F3D archive total size limit exceeded')
        for entry in entries:
            require(0 <= entry.file_size <= ARCHIVE_MEMBER_LIMIT and 0 <= entry.compress_size <= ARCHIVE_MEMBER_LIMIT,
                    'F3D archive member size limit exceeded')
            require(not entry.flag_bits & 1, 'Encrypted F3D archives are unsupported')
            if entry.compress_type not in (0, 8, 12, 14, 93):
                raise NotImplementedError(f'Unsupported F3D ZIP compression method {entry.compress_type}; archive integrity not evaluated')
        for entry in entries:
            raw_info = entry
            if entry.compress_type == 93:
                require(entry.compress_size > 0, 'Empty Zstandard frame in F3D')
                raw_info = copy.copy(entry)
                raw_info.compress_type = zipfile.ZIP_STORED
                raw_info.file_size = entry.compress_size
                raw_info.CRC = None
            with archive.open(raw_info) as raw:
                # The installed C backend passes this ceiling as bytes to zstd;
                # use a bounded 128 MiB window, with 64 KiB output reads.
                stream = codec.ZstdDecompressor(max_window_size=128 * 1024 * 1024).stream_reader(
                    raw, read_size=ARCHIVE_CHUNK_BYTES, read_across_frames=True, closefd=False) if entry.compress_type == 93 else raw
                size, crc = 0, 0
                try:
                    while True:
                        chunk = stream.read(min(ARCHIVE_CHUNK_BYTES, entry.file_size - size + 1))
                        if not chunk:
                            break
                        size += len(chunk)
                        require(size <= entry.file_size, 'F3D decompressed member exceeds declared size')
                        crc = binascii.crc32(chunk, crc)
                finally:
                    if stream is not raw:
                        stream.close()
                require(size == entry.file_size and crc == entry.CRC, 'F3D member size/CRC mismatch: ' + entry.filename)
            rows.append({'name': entry.filename, 'method': entry.compress_type, 'bytes': size, 'crc32': f'{crc:08x}'})
    return {'crcVerified': True, 'members': rows, 'compressionMethods': sorted({r['method'] for r in rows}),
            'uncompressedBytes': sum(r['bytes'] for r in rows), 'sha256': digest(path)}


def make_plan(*args):
    from offline_execution import call_offline
    return call_offline('keychain_plan', 'make_plan', args, log_parent=Path(args[7]).parent)


def layer_range(plan):
    thickness, front = plan['thicknessMm'], plan['frontMm']
    require(plan['imageSide'] in ('bottom', 'top') and 0 < front <= thickness,
            'Invalid image side or front thickness')
    return (0, front) if plan['imageSide'] == 'bottom' else (thickness - front, thickness)


def _decode(text):
    for line in reversed(text.splitlines()):
        if line.startswith(('KEYCHAIN_RESULT ', 'FMCAD_RESULT ')):
            value = json.loads(line.split(' ', 1)[1])
            require(value.get('success') is not False, 'Command reported failure')
            return value.get('result', value)
    try:
        value = json.loads(text)
    except ValueError:
        return text
    require(isinstance(value, dict) and value.get('success') is not False, 'Command reported failure')
    return value.get('result', value)


def project_target(runner, request, run_id, name):
    require(name.endswith('-' + run_id), 'Unique run document identity required')
    mode = request.get('projectMode', 'new')
    require(mode in ('new', 'existing'), 'Invalid projectMode')
    require('documentFileId' not in request or mode == 'existing', 'documentFileId requires existing project mode')
    if mode == 'existing':
        selectors = {k: request[k] for k in ('project', 'projectId') if k in request}
        require(len(selectors) == 1, 'existing requires exactly one project selector')
        target = runner.helper('existing_project', dict(selectors, name=name,
            **({'documentFileId': request['documentFileId']} if 'documentFileId' in request else {})))
        require(target.get('projectId') and target.get('folderId'), 'Existing project identity missing')
        key = 'projectId' if 'projectId' in selectors else 'projectName'
        require(target.get(key) == next(iter(selectors.values())), 'Existing project selector mismatch')
        if 'documentFileId' not in request:
            runner.mark(projectId=target['projectId'], folderId=target['folderId'])
        return target
    require('projectId' not in request, 'projectId requires existing mode')
    project_name = re.sub(r'[\\/:*?"<>|\x00-\x1f]', '_', request.get('project') or 'Keychain').strip(' .') + '-' + run_id
    runner.helper('preflight', {'name': name, 'projectName': project_name})
    created = runner.command(['project_create', project_name, 'Approved keychain ' + run_id], True)
    require(isinstance(created, str), 'Unexpected legacy project response')
    match = re.search(r'^CREATED_PROJECT name=(.+) id=(.+)$', created, re.M)
    require(match and match[1] == project_name, 'Project was not uniquely created')
    return {'projectId': match[2].strip()}


class CommandRunner:
    def __init__(self, state, checkpoint, options, work, resume=False):
        self.state, self.checkpoint, self.options = state, checkpoint, list(options)
        allowed = {'--backend', '--config', '--url', '--header', '--timeout', '--tool', '--transport', '--curl-path'}
        require(len(options) % 2 == 0 and all(options[i] in allowed and isinstance(options[i + 1], str)
                for i in range(0, len(options), 2)), 'Unsupported backendOptions')
        self.work, self.number, self.doc = work, 0, None
        self.consumed = {}
        self.pending_input = None
        self.metadata = dict(state.get('build') or {})
        self.metadata['backend'] = dict(zip(options[::2], options[1::2])).get('--backend', 'configured-default')
        require(self.metadata['backend'] in ('mcp', 'addin', 'configured-default'), 'Invalid backend label')
        self.journal = inside(work / 'journal', work)
        if resume:
            require(self.journal.is_dir(), 'Missing resume journal')
            self.number = max((int(p.name.split('.')[0]) for p in self.journal.iterdir()
                               if re.fullmatch(r'\d+\.(request|response)\.json', p.name)), default=0)
        else:
            self.journal.mkdir()
        source = (REPO / 'assets/keychain_fusion.py').read_bytes()
        self.helper_path = inside(work / ('keychain_fusion-' + hashlib.sha256(source).hexdigest() + '.py'), work)
        if self.helper_path.exists():
            require(self.helper_path.read_bytes() == source, 'Existing helper snapshot hash mismatch')
        else:
            write_new(self.helper_path, source)

    def mark(self, status='building', **values):
        self.metadata = dict(self.metadata, **values)
        self.state = self.checkpoint({'status': status, 'build': dict(self.metadata)})

    def journal_new(self, path, record):
        # Sanitize diagnostic copies before serialization. Execution/state stay raw.
        json_new(path, redact_diagnostic(record))

    def prism_pending(self):
        operation = self.metadata.get('prismOperation')
        return bool(operation and (operation.get('status') != 'completed' or not operation.get('cleanupCompleted')))

    def command(self, args, mutation=False, prism_lifecycle=False):
        from offline_execution import event
        from keychain_deadline import remaining
        remaining()  # Refuse to start a new operation after the command deadline.
        require(not mutation or not self.prism_pending() or prism_lifecycle,
                'Prism transaction must finish before other mutations, save or export')
        from generated_cleanup import collect, identity
        from keychain_cleanup import enabled
        if enabled(self.state) and not self.state['request'].get('debug') and not self.prism_pending():
            # A subsequent command means the previous decoded response has been
            # consumed. Never prune the current/unknown Fusion operation.
            _, freed = collect(self.consumed, [self.work])
            import keychain_cleanup
            keychain_cleanup.cleanup_bytes_freed += freed
            self.consumed = {}
        started = time.monotonic()
        self.number += 1
        stem = self.journal / f'{self.number:06}'
        timing = event('build.command.' + str(self.number), 'started', started)
        self.journal_new(str(stem) + '.request.json', {'args': args, 'mutation': mutation,
                                               'backend': self.metadata['backend'], **timing})
        if mutation:
            self.mark(operation=args[:2], operationId=self.number, outcome='unknown', running=True)
        try:
            result = subprocess.run(['node', str(REPO / 'bin/fmcad.js'), *self.options, *args],
                                    cwd=REPO, capture_output=True, text=True, check=False, timeout=remaining())
            # Redact explicit option values if a transport echoes its configuration.
            stdout, stderr = result.stdout, result.stderr
            for value in self.options[1::2]:
                if value:
                    stdout, stderr = stdout.replace(value, '[backend-option]'), stderr.replace(value, '[backend-option]')
            timing = event('build.command.' + str(self.number), 'returned', started)
            self.journal_new(str(stem) + '.response.json', {'returncode': result.returncode,
                                                   'stdout': stdout, 'stderr': stderr, **timing})
            require(result.returncode == 0, 'CLI failed; inspect journal ' + str(stem))
            require(not re.search(r'(^|\n)ERROR\b', result.stdout), 'CLI domain error; inspect ' + str(stem))
            value = _decode(result.stdout)
        except Exception as error:
            response = Path(str(stem) + '.response.json')
            if not response.exists():
                timing = event('build.command.' + str(self.number), 'unknown', started)
                self.journal_new(response, {'errorType': type(error).__name__, 'outcome': 'unknown', **timing})
            if mutation:
                self.mark('blocked', outcome='unknown', running=False,
                          error='Uncertain operation; inspect journal, never blindly rebuild')
            raise
        if mutation:
            # A start/cleanup RPC response is not a completed prism transaction.
            self.mark(outcome='unknown' if self.prism_pending() else 'complete', running=self.prism_pending())
        if enabled(self.state):
            files = [Path(str(stem) + '.request.json'), Path(str(stem) + '.response.json')]
            if self.pending_input is not None:
                files.append(self.pending_input)
            consumed = {str(p): identity(p) for p in files}
            if self.prism_pending():
                self.consumed.update(consumed)  # Retain start inputs/journals throughout pending/unknown work.
            else:
                self.consumed = consumed
            self.metadata['lastCommand'] = {'number': self.number, 'operation': args[:2],
                'requestSha256': digest(files[0]), 'responseSha256': digest(files[1]),
                'outcome': 'unknown' if self.prism_pending() else 'complete'}
        self.pending_input = None
        return value

    def cad(self, operation, data, mutation=True):
        require(self.doc, 'No verified build document')
        require(self.metadata.get('creationId'), 'No verified build document creationId')
        pins = ['--doc-id', self.metadata['creationId']]
        cloud = self.metadata.get('cloud') or {}
        if cloud.get('fileId'):
            pins += ['--doc-file-id', cloud['fileId']]
        # Always use files, avoiding command-line length limits for Bezier artwork.
        path = self.work / f'input-{self.number + 1:06}.json'
        json_new(path, data)
        self.pending_input = path
        return self.command([*operation.split('.'), '--doc', self.doc, *pins, '--file', str(path), '--json'], mutation)

    def helper(self, operation, data=None, mutation=False):
        if operation == 'prism':
            require(mutation, 'Prism is a mutating transaction')
            return self.prism(data)
        if operation in ('prism_start', 'prism_cleanup', 'prism_finalize'):
            require(mutation, 'Prism start/cleanup/finalize requires mutating dispatch')
        if operation == 'prism_status':
            require(not mutation, 'Prism status requires readonly dispatch')
        args = {'operation': operation, 'doc': self.doc, **(data or {})}
        reusable = self.metadata.get('reusableTarget')
        if reusable:
            require(args.get('expectedFileId', reusable['fileId']) == reusable['fileId'], 'Helper cloud ID conflicts with frozen target')
            args['expectedFileId'] = reusable['fileId']
        if args.get('allowIdentityTransition'):
            require(operation == 'saved_status' and not mutation
                    and all(args.get(k) for k in ('expectedRunId', 'expectedFileName', 'projectId', 'folderId')),
                    'Identity transition requires a read-only pinned saved_status request')
        if self.metadata.get('creationId'):
            expected = self.metadata['creationId']
            require(args.get('creationId', expected) == expected, 'Helper creationId conflicts with verified build document')
            args['creationId'] = expected
        # Use the generic local CLI file input for every helper payload, including
        # readback/validation/save evidence that can exceed the OS argv limit.
        path = self.work / f'helper-input-{self.number + 1:06}.json'
        json_new(path, args)
        self.pending_input = path
        helper_path = self.helper_path
        if operation == 'existing_project':
            source = (REPO / 'assets/keychain_project.py').read_bytes()
            helper_path = inside(self.work / ('keychain_project-' + hashlib.sha256(source).hexdigest() + '.py'), self.work)
            if not helper_path.exists():
                write_new(helper_path, source)
            require(helper_path.read_bytes() == source, 'Existing project helper snapshot hash mismatch')
        command = ['run', str(helper_path), '--args-file', str(path)]
        if not mutation:
            command.append('--readonly')
        result = (self.command(command, mutation, prism_lifecycle=True)
                  if operation in ('prism_start', 'prism_cleanup', 'prism_finalize') else self.command(command, mutation))
        require(isinstance(result, dict), 'Missing KEYCHAIN_RESULT from helper')
        return result

    def prism(self, data):
        """Submit once; finalize observes and retires only after destroy, without reentry."""
        from keychain_deadline import remaining
        from keychain_fusion import _prism_request_digest
        require(not self.prism_pending(), 'Unresolved prism transaction; inspect retained state, never replay')
        require(self.doc and self.metadata.get('creationId') and self.metadata.get('runMarker'),
                'Prism requires a verified stamped document')
        budget = remaining()  # None preserves the existing no-hidden-deadline contract.
        deadline = time.time() + budget if budget is not None else None
        payload = {key: data[key] for key in ('spec', 'template', 'start', 'depth')}
        request_sha = _prism_request_digest(payload)
        selector = dict(commandId='fmcad_prism_' + uuid.uuid4().hex, profileId=data['spec']['id'],
                        requestSha256=request_sha, runId=self.metadata['runMarker'])
        reusable = self.metadata.get('reusableTarget')
        if reusable:
            selector['expectedVersion'] = reusable['version']
        record = dict(selector, status='starting', accepted=None, destroyed=False, completed=False,
                      cleanupCompleted=False, creationId=self.metadata['creationId'],
                      expectedFileId=reusable['fileId'] if reusable else None,
                      deadlineEpoch=deadline,
                      inputPath=str(self.work / f'helper-input-{self.number + 1:06}.json'),
                      requestJournal=str(self.journal / f'{self.number + 1:06}.request.json'),
                      helperPath=str(self.helper_path))
        self.mark(prismOperation=record, outcome='unknown', running=True)
        try:
            observation = self.helper('prism_start', dict(payload, **selector,
                deadlineEpoch=deadline), True)
            finalizing = False
            while True:
                require(all(observation.get(k) == selector[k] for k in ('commandId', 'profileId', 'requestSha256', 'runId')),
                        'Prism lifecycle response identity mismatch')
                require(observation.get('creationId') == self.metadata['creationId'], 'Prism response document changed')
                if finalizing:
                    require(type(observation.get('cleanupCompleted')) is bool
                            and type(observation.get('definitionDeleted')) is bool
                            and observation['cleanupCompleted'] == observation['definitionDeleted'],
                            'Prism finalization response is inconsistent; inspect before continuing')
                    require(not observation.get('destroyed') or observation['cleanupCompleted']
                            or observation.get('status') == 'cleanup_pending',
                            'Destroyed prism lacks a finalization outcome; inspect before continuing')
                record.update({k: observation.get(k) for k in ('status', 'accepted', 'destroyed', 'completed',
                               'executeCount', 'executeCompleted', 'terminationCompleted', 'terminationReason', 'error')})
                record['error'] = redact_diagnostic(record['error'])
                self.mark(prismOperation=dict(record), outcome='unknown', running=True)
                if finalizing and observation['cleanupCompleted']:
                    require(observation.get('destroyed') is True,
                            'Prism cleanup reported before destroy; inspect native model')
                    complete = (observation.get('status') == 'completed'
                                and observation.get('completed') is True and observation.get('accepted') is True
                                and observation.get('executeCompleted') is True and observation.get('executeCount') == 1
                                and observation.get('terminationCompleted') is True and not observation.get('error'))
                    result = observation.get('result')
                    record['cleanupCompleted'] = True
                    require(complete and isinstance(result, dict), 'Prism terminated without proven completion; inspect native model')
                    require(result.get('readback', {}).get('checked') is True, 'Native geometry readback missing')
                    record['status'] = 'completed'
                    if self.metadata.get('lastCommand'):
                        self.metadata['lastCommand']['outcome'] = 'complete'
                    self.mark(prismOperation=dict(record), outcome='complete', running=False)
                    return result
                require(observation.get('destroyed') is True or (observation.get('accepted') is True
                        and observation.get('status') in ('submitted', 'created', 'executing', 'executed')),
                        'Prism lifecycle unavailable or rejected; inspect model, never replay')
                budget = remaining()
                if not observation.get('destroyed') or observation.get('status') == 'cleanup_pending':
                    time.sleep(PRISM_POLL_SECONDS if budget is None else min(PRISM_POLL_SECONDS, budget))
                observation = self.helper('prism_finalize', selector, True)
                finalizing = True
        except BaseException as error:
            # Includes command-deadline signal unwinding. Do not clean an
            # unobserved/running command or discard its start payload/journal.
            failure = type(error).__name__ + ': ' + str(error)
            for value in self.options[1::2]:
                if value:
                    failure = failure.replace(value, '[backend-option]')
            record.update(observedStatus=record['status'], status='blocked', failure=redact_diagnostic(failure))
            self.mark('blocked', prismOperation=dict(record), outcome='unknown', running=False,
                      error='Prism transaction unresolved or failed; inspect retained metadata and native model. No replay.')
            raise


def reusable_document(runner, request, target):
    """Resolve, pin and audit only; never clear or create a replacement."""
    file_id = request['documentFileId']
    require(isinstance(file_id, str) and file_id and not re.search(r'\s', file_id)
            and not file_id.startswith('-'), 'Invalid frozen documentFileId')
    identity = runner.helper('reusable_identity', {'expectedFileId': file_id,
        'projectId': target['projectId'], 'folderId': target['folderId']})
    require(identity.get('fileId') == file_id and identity.get('creationId') and identity.get('name')
            and identity.get('fileName') and identity.get('projectId') == target['projectId']
            and identity.get('folderId') == target['folderId'] and identity.get('rootMembershipVerified') is True
            and identity.get('saved') is True and identity.get('modified') is False
            and identity.get('isComplete') is True and identity.get('readOnly') is False
            and type(identity.get('version')) is int and identity['version'] > 0,
            'Reusable cloud target is not verified complete, writable and unmodified')
    runner.doc = identity['name']
    runner.mark(creationId=identity['creationId'], document=identity['name'], cloud=identity,
                reusableTarget=identity)
    audit = runner.cad('document.clear', {'fileId': file_id, 'confirm': True, 'dryRun': True}, False)
    counts, current = audit.get('before'), audit.get('current') or {}
    required_counts = {'occurrences', 'bRepBodies', 'sketches', 'features', 'constructionPlanes',
        'constructionAxes', 'constructionPoints', 'joints', 'asBuiltJoints', 'jointOrigins', 'rigidGroups',
        'canvases', 'customGraphicsGroups', 'meshBodies', 'decals', 'pmiAnnotations', 'userCoordinateSystems',
        'timeline', 'snapshots', 'descendantComponents', 'userParameters', 'modelParameters', 'attributes'}
    require(audit.get('status') == 'inspected' and audit.get('dryRun') is True
            and audit.get('mutation') is False and audit.get('savePerformed') is False
            and audit.get('unsavedChanges') is False and isinstance(counts, dict)
            and required_counts <= counts.keys() and all(type(v) is int and v == 0 for v in counts.values())
            and current.get('fileId') == file_id and current.get('saved') is True
            and current.get('modified') is False and current.get('isComplete') is True
            and current.get('readOnly') is False,
            'Reusable document must pass the complete empty document.clear dryRun audit; never auto-clear')
    runner.mark(emptyAudit=audit)
    return identity


def save_once(runner, name, project_id, folder_id, creation_id):
    require(not runner.metadata.get('saveAttempted'), 'Cloud save was already attempted; reconcile only')
    reusable = runner.metadata.get('reusableTarget')
    target = {'name': reusable['fileName'] if reusable else name, 'projectId': project_id, 'folderId': folder_id}
    if reusable:
        require(reusable['fileId'] == runner.state['request']['documentFileId'], 'Frozen cloud target changed')
        target.update(fileId=reusable['fileId'], baselineVersion=reusable['version'])
    runner.mark('save_pending', creationId=creation_id, preSaveCreationId=creation_id, saveAttempted=True,
                saveTarget=target, saveOperation=['run', str(runner.helper_path)] if reusable else ['document', 'save_as'])
    accepted = None
    try:
        if reusable:
            result = runner.helper('save_version', {'expectedVersion': reusable['version'],
                'projectId': project_id, 'folderId': folder_id, 'runId': runner.state['runId']}, True)
        else:
            result = runner.cad('document.save_as', {'name': name, 'project': project_id,
                                'folder': '', 'confirm': True})
        accepted = result.get('accepted')
    except Exception:
        # saveAs may have returned True before the CLI's parentProject getter failed.
        # Only subsequent read-only evidence can resolve this ambiguity.
        pass
    require(accepted is not False, 'Fusion rejected cloud save; no retry was attempted')
    runner.mark('save_pending', saveAccepted=accepted)
    return reconcile_save(runner)


def reconcile_save(runner, legacy=False, expected_file_id=None):
    from keychain_deadline import remaining
    metadata = runner.metadata
    target = metadata.get('saveTarget') or {'name': metadata['document'], 'projectId': metadata['projectId'],
                                          'folderId': metadata['folderId']}
    run_id = runner.state['runId']
    reusable = metadata.get('reusableTarget')
    expected_version = None
    if reusable:
        require(not legacy and target.get('fileId') == reusable['fileId'] == runner.state['request']['documentFileId']
                and target['projectId'] == reusable['projectId'] and target['folderId'] == reusable['folderId']
                and target.get('baselineVersion') == reusable['version']
                and type(target['baselineVersion']) is int and target['baselineVersion'] > 0,
                'Reusable save recovery requires frozen file/version and run marker')
        require(expected_file_id in (None, target['fileId']), 'Recovery file ID mismatch')
        expected_file_id = target['fileId']
        if metadata.get('saveReconciled') is True:
            cloud = metadata.get('cloud') or {}
            expected_version = cloud.get('version')
            require(cloud.get('fileId') == expected_file_id and type(expected_version) is int
                    and expected_version > target['baselineVersion'],
                    'Export recovery requires the previously reconciled cloud file and exact version')
    else:
        require('documentFileId' not in runner.state['request'], 'Missing reusable save evidence')
        require(target['name'].endswith('-' + run_id), 'Save target must include exact run ID')
    evidence = {'native': metadata['native'], 'canvas': metadata['canvas'],
                'groups': [dict(name=g['component']['name'], hex=g['hex'], **({'colorId': cid}
                           if metadata.get('partitionMetadata') else {})) for cid, g in metadata['groups'].items()],
                'backZMm': runner.state['request']['thicknessMm'] if runner.state['request']['imageSide'] == 'bottom' else 0}
    for index in range(SAVE_POLLS):
        remaining()  # Outside retry handling: no further poll after cancellation.
        try:
            runner.command(['doc', 'list'])
            status = runner.helper('saved_status', {'allowIdentityTransition': True, 'expectedRunId': run_id,
                'expectedFileName': target['name'], 'projectId': target['projectId'], 'folderId': target['folderId'],
                'allowLegacyFingerprint': legacy, 'nativeEvidence': evidence, 'expectedFileId': expected_file_id,
                'existingFile': bool(reusable)})
            if (status.get('creationId') and status.get('fileName') == target['name']
                    and status.get('projectId') == target['projectId'] and status.get('folderId') == target['folderId']
                    and status.get('verifiedRunId') == run_id and status.get('rootMembershipVerified') is True
                    and status.get('identityProof') in (('run_marker', 'legacy_fingerprint') if legacy else ('run_marker',))
                    and status.get('fingerprintVerified') is True
                    and status.get('fileId') and status.get('saved') is True
                    and (expected_file_id is None or status['fileId'] == expected_file_id)
                    and (not reusable or (type(status.get('version')) is int and status['version'] > target['baselineVersion']))
                    and (expected_version is None or status.get('version') == expected_version)
                    and status.get('modified') is False and status.get('isComplete') is True):
                runner.doc = status['name']
                runner.mark('building', outcome='complete', cloud=status, creationId=status['creationId'],
                            document=status['name'], saveTarget=target,
                            preSaveCreationId=metadata.get('preSaveCreationId', metadata['native']['creationId']),
                            saveReconciled=True, running=False, error=None)
                return status
        except (TimeoutError, InterruptedError):
            raise
        except Exception:
            pass
        if index + 1 < SAVE_POLLS:
            time.sleep(SAVE_POLL_SECONDS)
    runner.mark('blocked', outcome='unknown', error='Cloud save not verified; save must not be repeated')
    raise RuntimeError('Cloud save remains uncertain; inspect pinned identity without another save')


def inspect_stl(data):
    import numpy as np
    import trimesh
    mesh = trimesh.load_mesh(io.BytesIO(data), file_type='stl', process=True)
    require(mesh.is_watertight and mesh.is_winding_consistent and mesh.volume > 0
            and np.isfinite(mesh.vertices).all(), 'STL is not a finite, closed, consistently wound solid')
    # Edge watertightness alone accepts two shells sharing only a vertex.
    # A manifold vertex must have exactly one connected cycle in its link.
    links = [{} for _ in mesh.vertices]
    for face in mesh.faces:
        for vertex, a, b in ((face[0], face[1], face[2]), (face[1], face[2], face[0]), (face[2], face[0], face[1])):
            links[vertex].setdefault(a, set()).add(b)
            links[vertex].setdefault(b, set()).add(a)
    for link in links:
        require(link and all(len(neighbors) == 2 for neighbors in link.values()), 'Nonmanifold STL vertex link')
        seen, pending = set(), [next(iter(link))]
        while pending:
            vertex = pending.pop()
            if vertex not in seen:
                seen.add(vertex)
                pending.extend(link[vertex] - seen)
        require(len(seen) == len(link), 'Nonmanifold STL point contact; planar repair required')
    volume = float(mesh.volume)
    return {'watertight': True, 'windingConsistent': True, 'vertexManifold': True, 'volumeMm3': volume,
            'boundsMm': mesh.bounds.tolist(), 'triangles': len(mesh.faces)}


def mesh_report(data, native):
    import numpy as np
    report = inspect_stl(data)
    volume = report['volumeMm3']
    require(abs(volume - native['volumeMm3']) <= native['volumeMm3'] * .001,
            'STL volume disagrees with native volume by more than 0.1%')
    require(np.max(np.abs(np.asarray(report['boundsMm']) - native['boundsMm'])) <= .01, 'STL/native bounds mismatch')
    return {'watertight': True, 'windingConsistent': True, 'vertexManifold': True, 'volumeMm3': volume,
            'volumeDifferenceMm3': volume - native['volumeMm3'], 'boundsMm': report['boundsMm'],
            'triangles': report['triangles']}


def repair_planar_stl(paths, z_start, height):
    """Union constant-height prism caps; preserve input files and absolute Z.

    0.0001 mm closing regularizes contacts; 0.00001 mm is the coordinate grid.
    Mixed-depth outline/base colors are not flattened: callers must use the
    layered repair below, which retains the backing slab and exposed ledges.
    """
    return repair_layered_stl(paths, [(z_start, z_start + height)])


def repair_layered_stl(paths, slabs):
    import numpy as np
    import shapely
    from shapely.geometry import Polygon, LineString
    from shapely.ops import polygonize
    import trimesh
    meshes = [trimesh.load_mesh(p, process=True) for p in paths]
    require(all(m.is_watertight and m.is_winding_consistent and m.volume > 0 for m in meshes),
            'Per-body STL is invalid; section repair cannot mask missing geometry')
    require(all(abs(slabs[i][1] - slabs[i + 1][0]) < 1e-8 for i in range(len(slabs) - 1)),
            'Repair slabs must be contiguous')
    require(all(hi > lo for lo, hi in slabs), 'Repair slabs must have positive thickness')
    footprints, deviations = [], []
    for lo, hi in slabs:
        triangles = []
        for mesh in meshes:
            if len(slabs) == 1:
                require(abs(mesh.bounds[0, 2] - lo) < 1e-5 and abs(mesh.bounds[1, 2] - hi) < 1e-5,
                        'Standard color repair requires constant-height layer prisms')
                cap = mesh.triangles[np.all(np.abs(mesh.triangles[:, :, 2] - hi) < 1e-5, axis=1)]
                require(len(cap) > 0, 'Prism has no horizontal cap')
                triangles.extend(Polygon(t[:, :2]) for t in cap)
                continue
            # Section segments stay in global XY and avoid trimesh's optional
            # networkx/rtree path dependencies. Polygonize preserves ring holes.
            segments = trimesh.intersections.mesh_plane(mesh, [0, 0, 1], [0, 0, (lo + hi) / 2])
            lines = shapely.set_precision([LineString(s[:, :2]) for s in segments], .00001)
            rings = [Polygon(p.exterior) for p in polygonize(shapely.union_all(lines))]
            rings.sort(key=lambda p: p.area, reverse=True)
            region = Polygon()
            for ring in rings:
                region = region.symmetric_difference(ring)
            triangles.append(region)
        footprint = shapely.union_all(shapely.set_precision(triangles, grid_size=.00001))
        require(not footprint.is_empty and footprint.is_valid, 'Empty/invalid planar section')
        original_area = footprint.area
        fixed = shapely.set_precision(footprint.buffer(.0001, join_style='mitre').buffer(
            -.0001, join_style='mitre'), grid_size=.00001)
        require(fixed.is_valid and not fixed.is_empty and abs(fixed.area - original_area) <= original_area * .001,
                'Contact regularization changes area by more than 0.1%')
        footprints.append(fixed)
        deviations.append({'zStartMm': lo, 'zEndMm': hi, 'areaChangeMm2': fixed.area - original_area,
                           'volumeChangeMm3': (fixed.area - original_area) * (hi - lo)})
    solids = []
    # Build exterior surfaces only. Shared horizontal caps are removed by planar
    # difference; a common coordinate grid welds ledges to the vertical walls.
    for index, ((lo, hi), footprint) in enumerate(zip(slabs, footprints)):
        polygons = [footprint] if footprint.geom_type == 'Polygon' else list(footprint.geoms)
        for polygon in polygons:
            solid = trimesh.creation.extrude_polygon(polygon, hi - lo, engine='earcut')
            solid.apply_translation([0, 0, lo])
            vertical = np.abs(solid.face_normals[:, 2]) < .5
            solids.append(solid.submesh([np.flatnonzero(vertical)], append=True))
        for z, neighbor, upward in [(lo, index - 1, False), (hi, index + 1, True)]:
            cap = footprint.difference(footprints[neighbor]) if 0 <= neighbor < len(footprints) else footprint
            pieces = [cap] if cap.geom_type == 'Polygon' else list(cap.geoms)
            for piece in pieces:
                if piece.is_empty or piece.area == 0:
                    continue
                vertices, faces = trimesh.creation.triangulate_polygon(piece, engine='earcut')
                vertices = np.column_stack([vertices, np.full(len(vertices), z)])
                cap_mesh = trimesh.Trimesh(vertices=vertices, faces=faces, process=False)
                if (cap_mesh.face_normals[:, 2].mean() > 0) != upward:
                    cap_mesh.invert()
                solids.append(cap_mesh)
    combined = trimesh.util.concatenate(solids)
    combined.merge_vertices(digits_vertex=5)
    if len(slabs) > 1:
        # Planar differences introduce T junctions on slab boundaries. Split
        # every incident edge at shared vertices before welding/reloading STL.
        from scipy.spatial import cKDTree
        points = combined.vertices.copy()
        tree = cKDTree(points)
        vertices, faces = points.tolist(), []
        for face in combined.faces:
            boundary = []
            for a, b in zip(face, np.roll(face, -1)):
                start, end = points[a], points[b]
                vector = end - start
                length2 = float(vector @ vector)
                candidates = tree.query_ball_point((start + end) / 2, np.sqrt(length2) / 2 + 1e-7)
                split = []
                for candidate in candidates:
                    t = float((points[candidate] - start) @ vector / length2)
                    if 1e-7 < t < 1 - 1e-7 and np.linalg.norm(points[candidate] - start - t * vector) < 1e-7:
                        split.append((t, candidate))
                boundary.extend([int(a), *[c for _, c in sorted(split)]])
            if len(boundary) == 3:
                faces.append(face.tolist())
            else:
                center = len(vertices)
                vertices.append(points[face].mean(axis=0).tolist())
                faces.extend([[center, a, b] for a, b in zip(boundary, boundary[1:] + boundary[:1])])
        combined = trimesh.Trimesh(vertices=vertices, faces=faces, process=True)
    data = combined.export(file_type='stl')
    reloaded = trimesh.load_mesh(io.BytesIO(data), file_type='stl', process=True)
    require(reloaded.is_watertight and reloaded.is_winding_consistent,
            'Layered section repair remains nonmanifold; originals retained')
    return data, {'method': 'planar-section-union', 'regularizationMm': .0001,
                  'coordinateGridMm': .00001, 'slabs': deviations}


def _native_valid(report, plan, full_volume, base_names=(), backing_component=None):
    direct = plan.get('construction') == 'partition_prisms'
    if direct:
        require(report.get('healthy') is True and report.get('constructionProof', {}).get('geometryReadbackChecked') is True,
                'Missing healthy native partition geometry proof')
        require(report['constructionProof'].get('partition', {}).get('checked') is True,
                'Missing checked constructive partition proof')
        require(report.get('nativeBulkQuery', {}).get('status') in ('not_called', 'unavailable')
                and report.get('interferenceCount') is None, 'Partition must not claim an unmeasured ASM zero')
        require(len(report.get('profileGeometry', [])) == 1 + len(plan['fields']), 'Missing profile readback')
    else:
        require(report['interferenceCount'] == 0, 'Native final bodies interfere')
    rows = report['bodies']
    require(rows and all(b['isSolid'] and b['volumeMm3'] > 0 for b in rows), 'Invalid native solid')
    require(abs(sum(b['volumeMm3'] for b in rows) - full_volume) <= full_volume * .00001,
            'Native volume is not conserved')
    lo, hi = layer_range(plan)
    if direct:
        blo, bhi = plan['backZMinMm'], plan['backZMaxMm']
        require((abs(blo - hi) <= 1e-8 and abs(bhi - plan['thicknessMm']) <= 1e-8) if lo == 0
                else (abs(blo) <= 1e-8 and abs(bhi - lo) <= 1e-8), 'Invalid backing range')
        backing = [b for b in rows if abs(b['boundsMm'][0][2] - blo) <= 1e-5
                   and abs(b['boundsMm'][1][2] - bhi) <= 1e-5]
        require(len(backing) == 1 and backing[0]['component'] == backing_component,
                'Expected one backing body in outline component')
        require(abs(backing[0]['volumeMm3'] - plan['base']['areaMm2'] * (bhi - blo)) <= full_volume * .00001,
                'Backing volume mismatch')
        require(len(rows) == len(plan['fields']) + 1, 'Direct prism body count mismatch')
        for component, color in report['colors'].items():
            expected = sorted(f['areaMm2'] * (hi - lo) for f in plan['fields'] if f['colorId'] == color['colorId'])
            actual = sorted(b['volumeMm3'] for b in rows if b['component'] == component and b is not backing[0])
            require(len(expected) == len(actual) and all(abs(a - e) <= e * .001 for a, e in zip(actual, expected)),
                    'Front prism color/volume mismatch')
    elif backing_component is not None:
        backing = [b for b in rows if b['component'] == backing_component]
        require(backing and abs(min(b['boundsMm'][0][2] for b in backing)) <= 1e-5
                and abs(max(b['boundsMm'][1][2] for b in backing) - plan['thicknessMm']) <= 1e-5,
                'Backing component does not span full thickness')
    for body in rows:
        bounds = body['boundsMm']
        require(bounds[0][2] >= -1e-5 and bounds[1][2] <= plan['thicknessMm'] + 1e-5,
                'Native body exceeds thickness')
        is_backing = (body is backing[0] if direct else body['component'] == backing_component if backing_component is not None
                      else body['name'] in base_names)
        if not is_backing:
            require(abs(bounds[0][2] - lo) <= 1e-5 and abs(bounds[1][2] - hi) <= 1e-5,
                    'Colored body lies on wrong side')
    for axis, expected in enumerate((plan['widthMm'], plan['heightMm'], plan['thicknessMm'])):
        actual = max(b['boundsMm'][1][axis] for b in rows) - min(b['boundsMm'][0][axis] for b in rows)
        require(abs(actual - expected) <= .01, 'Native dimensions disagree with approved plan')


def can_resume_save(state):
    value = state.get('build') or {}
    expected = value.get('saveOperation') if value.get('reusableTarget') else ['document', 'save_as']
    return (state.get('status') == 'blocked' and value.get('phase') == 'native_validated'
            and value.get('validationState') == 'passed' and value.get('saveAttempted') is True
            and not value.get('running')
            and bool(expected) and value.get('operation') == expected)


def can_resume_export(state):
    value = state.get('build') or {}
    cloud = value.get('cloud') or {}
    return (state.get('status') == 'blocked' and value.get('phase') == 'exporting' and not value.get('running')
            and value.get('validationState') == 'passed' and value.get('saveReconciled') is True
            and (tuple(value.get('operation') or []) in (('export', 'native'), ('export', 'mesh'), ('document', 'save_as'))
                 or (value.get('reusableTarget') and value.get('saveOperation')
                     and value.get('operation') == value['saveOperation']))
            and bool(value.get('groups') and value.get('native') and value.get('canvas'))
            and bool(cloud.get('fileId') and cloud.get('projectId') and cloud.get('folderId'))
            and cloud.get('saved') is True and cloud.get('modified') is False and cloud.get('isComplete') is True
            and cloud.get('verifiedRunId') == state.get('runId') and cloud.get('rootMembershipVerified') is True
            and cloud.get('fingerprintVerified') is True and cloud.get('identityProof') in ('run_marker', 'legacy_fingerprint'))


def _legacy_save_evidence(state, work):
    """Legacy exception requires original new-project/unsaved-document journal proof."""
    value = state['build']
    name = value.get('saveTarget', {}).get('name', value['document'])
    original_id = value.get('preSaveCreationId', value['native']['creationId'])
    project_created, unsaved, saves = False, False, 0
    for path in sorted((work / 'journal').glob('*.request.json')):
        request = json.loads(inside(path, work).read_text())
        args = request['args']
        response_path = inside(str(path).replace('.request.json', '.response.json'), work)
        response = json.loads(response_path.read_text()) if response_path.exists() else {}
        if args[0] == 'project_create' and response.get('returncode') == 0 and not saves:
            match = re.search(r'^CREATED_PROJECT name=(.+) id=(.+)$', response.get('stdout', ''), re.M)
            project_created = bool(match and match[1] == args[1] and args[1].endswith('-' + state['runId'])
                                   and match[2].strip() == value['projectId'])
        if args[0] == 'run' and response.get('returncode') == 0 and not saves and ('--args' in args or '--args-file' in args):
            data = json.loads(inside(args[args.index('--args-file') + 1], work).read_text()
                              if '--args-file' in args else args[args.index('--args') + 1])
            if data.get('operation') == 'identity':
                status = _decode(response['stdout'])
                unsaved = bool(status['creationId'] == original_id and status['name'] == name
                               and status['saved'] is False and status['fileId'] is None
                               and status['folderId'] == value['folderId'])
        if args[:2] == ['document', 'save_as']:
            data = json.loads(inside(args[args.index('--file') + 1], work).read_text())
            require(project_created and unsaved and data['name'] == name and data['project'] == value['projectId']
                    and data['folder'] == '' and data['confirm'] is True, 'Legacy save target lacks original journal proof')
            saves += 1
        elif saves and request.get('mutation'):
            raise ValueError('Legacy save recovery cannot follow another mutation')
    require(project_created and unsaved and saves == 1, 'Legacy recovery requires exactly one proven first-save attempt')


def _resume_plan(state, run):
    value = state['build']
    plan_path = inside(state['planPath'], run)
    for path, expected in ((plan_path, value['planSha256']),
                           (state['approval']['svgPath'], value['svgSha256']),
                           (state['prepared']['sourcePath'], value['sourceSha256']),
                           (state['prepared']['palettePath'], value['paletteSha256'])):
        require(digest(inside(path, run)) == expected, 'Resume source/plan hash changed')
    if state['prepared'].get('canvasPath'):
        require(digest(inside(state['prepared']['canvasPath'], run)) == state['prepared']['canvasSha256'],
                'Resume canvas-source hash changed')
    if value.get('partitionReferencePath'):
        require(digest(inside(value['partitionReferencePath'], run)) == value['partitionReferenceSha256'],
                'Resume partition reference hash changed')
    plan = json.loads(plan_path.read_text())
    require(plan['sourceSha256'] == state['approval']['svgSha256'], 'Resume plan source differs from approval')
    require(all(plan[k] == state['request'][k] for k in ('widthMm', 'thicknessMm', 'frontMm', 'imageSide')),
            'Resume plan/request mismatch')
    require(len(plan['colors']) == state['request']['colors']
            and plan['outlineColor'] == state['prepared']['outlineColor'], 'Resume palette/outline mismatch')
    groups = value['groups']
    require(set(groups) == {c['id'] for c in plan['colors']} and all(groups[c['id']]['hex'] == c['hex'] for c in plan['colors']),
            'Resume group palette mismatch')
    require(value['canvas']['calibrated'] is True and len(value['canvas']['transform']) == 9, 'Resume requires calibrated source evidence')
    _native_valid(value['native'], plan, value['fullVolume'], backing_component=value['backingComponent'])
    if plan.get('construction') == 'partition_prisms':
        _partition_geometry_unchanged(plan, value['native'])
    return plan


def _partition_geometry_unchanged(plan, native):
    original = {p['id']: p['template'] for p in native['partitionMetadata']['profileMetadata']}
    specs = [plan['base'], *plan['fields']]
    require(set(original) == {s['id'] for s in specs}, 'Partition geometry metadata mismatch')
    for spec in specs:
        require(json.loads(Path(spec['geometryPath']).read_text()) == original[spec['id']],
                'Frozen partition geometry changed since native construction')


def resume_save(state, checkpoint, backend_options, run, public):
    value = state['build']
    plan = _resume_plan(state, run)
    archive_codec()
    work = inside(run / 'cad-build', run)
    legacy = 'runMarker' not in value
    if legacy:
        _legacy_save_evidence(state, work)
    else:
        require(value['runMarker'] == state['runId'], 'Stored run marker mismatch')
    runner = CommandRunner(state, checkpoint, backend_options, work, resume=True)
    runner.doc = value['document']
    try:
        cloud = reconcile_save(runner, legacy=legacy)
        return finish(runner, plan, public, cloud)
    except Exception:
        runner.mark('blocked', running=False, error='Save-only recovery stopped; no geometry or saveAs was repeated.')
        raise


def _resume_export(state, checkpoint, backend_options, run, public):
    require(can_resume_export(state), 'Export-only recovery requires verified cloud/native evidence')
    value, cloud = state['build'], state['build']['cloud']
    plan = _resume_plan(state, run)
    archive_codec()
    require(cloud['projectId'] == value['projectId'] and cloud['folderId'] == value['folderId']
            and cloud['fileName'] == value['saveTarget']['name'], 'Stored export cloud target mismatch')
    legacy = 'runMarker' not in value
    require((legacy and cloud['identityProof'] == 'legacy_fingerprint') or value.get('runMarker') == state['runId'],
            'Export recovery marker/proof mismatch')
    runner = CommandRunner(state, checkpoint, backend_options, inside(run / 'cad-build', run), resume=True)
    runner.doc = value['document']
    try:
        verified = reconcile_save(runner, legacy=legacy, expected_file_id=cloud['fileId'])
        return finish(runner, plan, public, verified)
    except Exception:
        runner.mark('blocked', running=False, error='Export-only recovery stopped; partial exports preserved. No geometry or saveAs repeated.')
        raise


def build(state, checkpoint, backend_options):
    approval = state.get('approval') or {}
    require(approval.get('svgPath') and approval.get('svgSha256') and approval.get('candidateId'),
            'Explicit candidate approval required before CAD')
    run = inside(state['runPath'], state['runPath'])
    public = inside(state['publicPath'], state['publicPath'])
    svg = inside(approval['svgPath'], run)
    require(digest(svg) == approval['svgSha256'], 'Approved SVG hash changed; approve again before CAD')
    if state.get('status') == 'completed':
        artifacts = state.get('artifacts') or []
        require(artifacts, 'Completed build has no artifact manifest')
        for item in artifacts:
            path = inside(item['path'], public / 'print')
            require(path.is_file() and digest(path) == item['sha256'], 'Completed artifact missing or changed')
        return {k: state[k] for k in ('status', 'build', 'artifacts')}
    require(can_resume_save(state) or can_resume_export(state) or (not state.get('build') and state.get('status') == 'approved'),
            'Existing partial/unknown build blocked; inspect it rather than duplicate geometry')
    require(not (public / 'print').exists() and not (public / 'print').is_symlink(),
            'Print destination already exists; refusing overwrite')
    prepared, request = state['prepared'], state['request']
    source = inside(prepared['sourcePath'], run)
    require(digest(source) == prepared['sourceSha256'], 'Frozen source hash changed')
    canvas_source = inside(prepared.get('canvasPath', prepared['sourcePath']), run)
    canvas_hash = prepared.get('canvasSha256', prepared['sourceSha256'])
    require(digest(canvas_source) == canvas_hash, 'Frozen canvas-source hash changed')
    palette = inside(prepared['palettePath'], run)
    palette_hash = digest(palette)
    if can_resume_export(state):
        return _resume_export(state, checkpoint, backend_options, run, public)
    if can_resume_save(state):
        return resume_save(state, checkpoint, backend_options, run, public)
    plan_dir = inside(run / 'cad-plan', run)
    require(not plan_dir.exists(), 'Existing partial plan blocked; no automatic retry')
    reviewed = json.loads(inside(state['planPath'], run).read_text()) if state.get('planPath') else {}
    selected = next((c for c in prepared.get('candidates', []) if c['id'] == approval['candidateId']), {})
    partition_inputs = approval.get('partitionInputs', selected.get('partitionInputs'))
    partition_reference, partition_reference_hash = None, None
    if (reviewed.get('construction') == 'partition_prisms' or prepared.get('construction') == 'partition_prisms'
            or approval.get('construction') == 'partition_prisms'):
        from offline_execution import call_offline
        require(partition_inputs is not None, 'Signed partition approval requires frozen partitionInputs')
        settings = {k: partition_inputs[k] for k in ('backing', 'fit_error_px', 'corner_angle', 'scale') if k in partition_inputs}
        settings.setdefault('backing', request.get('backing', 'silhouette'))
        partition_reference = inside(prepared.get('classifiedPath') or partition_inputs['reference_path'], run)
        require(Path(partition_inputs['reference_path']).resolve() == partition_reference.resolve(),
                'Partition reference differs from frozen classified reference')
        partition_reference_hash = digest(partition_reference)
        plan = call_offline('keychain_partition', 'make_partition_plan',
            [str(svg), str(palette), prepared['outlineColor'], request['widthMm'],
             request['thicknessMm'], request['frontMm'], request['imageSide'], str(plan_dir)],
            log_parent=run, kwargs=dict(reference_path=str(partition_reference), **settings))
    else:
        plan = make_plan(str(svg), str(palette), prepared['outlineColor'], request['widthMm'],
                         request['thicknessMm'], request['frontMm'], request['imageSide'], plan_dir)
    require(plan['schemaVersion'] == 1 and plan['sourceSha256'] == approval['svgSha256'],
             'Plan source hash/schema differs from approved SVG')
    if approval.get('planSignature'):
        from keychain_signature import plan_signature
        require(plan_signature(plan) == approval['planSignature'],
                'Geometry plan differs from the reviewed overlay; approve a fresh preview before CAD')
    require(json.loads((plan_dir / 'plan.json').read_text()) == plan, 'Persisted plan differs from planner return')
    for key in ('widthMm', 'thicknessMm', 'frontMm', 'imageSide'):
        require(plan[key] == request[key], 'Plan/request mismatch: ' + key)
    lo, hi = layer_range(plan)
    direct = plan.get('construction') == 'partition_prisms'
    partition_proof = None
    if direct:
        from keychain_mesh import planar_partition
        _, partition_proof = planar_partition(plan)
    require(plan['outlineColor'].lower() == prepared['outlineColor'].lower(), 'Outline color mismatch')
    colors = {c['id']: c for c in plan['colors']}
    require(all(re.fullmatch(r'#[0-9a-fA-F]{6}', c['hex']) for c in colors.values()), 'Invalid RGB palette entry')
    require(len(colors) == request['colors'] and len({c['hex'].lower() for c in colors.values()}) == len(colors),
            'Plan must contain exactly the requested unique palette colors')
    outline_ids = [c['id'] for c in colors.values() if c['hex'].lower() == plan['outlineColor'].lower()]
    require(len(outline_ids) == 1, 'Outline color is absent from palette')
    geometries = {}
    specs = [plan['base'], *plan['fields'], *[p for f in plan['fields'] for p in f['patches']]]
    require(len({s['id'] for s in specs}) == len(specs), 'Plan geometry IDs must be unique')
    for spec in specs:
        path = inside(spec['geometryPath'], plan_dir)
        geometries[spec['id']] = json.loads(path.read_text())
        require(spec['areaMm2'] > 0 and spec['loopCount'] > 0, 'Invalid planned profile')
        if 'colorId' in spec:
            require(spec['colorId'] in colors, 'Unknown colorId')
    palette_values = json.loads(palette.read_text())
    require({entry['color'].lower() for entry in palette_values['colors']} ==
            {entry['hex'].lower() for entry in colors.values()}, 'Plan RGB values differ from actual palette')
    require(digest(svg) == approval['svgSha256'] and digest(source) == prepared['sourceSha256']
            and digest(palette) == palette_hash, 'Build input changed during planning')
    if partition_reference is not None:
        require(digest(partition_reference) == partition_reference_hash, 'Classified reference changed during planning')
    # Import all offline dependencies before creating any live document.
    import numpy  # noqa: F401
    import shapely  # noqa: F401
    import trimesh  # noqa: F401
    import mapbox_earcut  # noqa: F401
    archive_codec()
    work = inside(run / 'cad-build', run)
    work.mkdir()
    state = checkpoint({'planPath': str(plan_dir / 'plan.json'), 'preparationConsumed': True})
    import keychain_cleanup
    keychain_cleanup.cleanup_bytes_freed += keychain_cleanup.cleanup(state)
    state = checkpoint({'ownedFiles': state.get('ownedFiles', {})})
    runner = CommandRunner(state, checkpoint, backend_options, work)
    try:
        name = re.sub(r'[\\/:*?"<>|\x00-\x1f]', '_', request['name']).strip(' .') + '-' + state['runId']
        target = project_target(runner, request, state['runId'], name)
        project_id = target['projectId']
        if 'documentFileId' in request:
            identity = reusable_document(runner, request, target)
            name = identity['name']
        else:
            created = runner.command(['doc', 'new', '--name', name], True)
            require(isinstance(created, str) and re.search(r'^CREATED_DOC name=' + re.escape(name) + r'$', created, re.M),
                    'Document was not created with the unique requested name')
            runner.doc = name
            identity = runner.helper('identity', {'projectId': project_id})
            require(identity['name'] == name and not identity['saved'], 'New document identity mismatch')
        require(not target.get('folderId') or identity['folderId'] == target['folderId'],
                'Resolved existing project root changed before document identity check')
        runner.mark(creationId=identity['creationId'], document=name, projectId=project_id,
                    folderId=identity['folderId'], sourceSha256=prepared['sourceSha256'],
                    canvasSourcePath=str(canvas_source), canvasSourceSha256=canvas_hash,
                    partitionReferencePath=str(partition_reference) if partition_reference is not None else None,
                    partitionReferenceSha256=partition_reference_hash,
                    svgSha256=approval['svgSha256'], paletteSha256=palette_hash,
                    planSha256=digest(plan_dir / 'plan.json'))
        stamp = runner.helper('stamp', {'runId': state['runId'], **({'projectId': project_id,
            'folderId': identity['folderId'], 'expectedVersion': identity['version']}
            if 'documentFileId' in request else {})}, True)
        require(stamp['creationId'] == identity['creationId'] and stamp['runId'] == state['runId'], 'Run stamp mismatch')
        runner.mark(runMarker=state['runId'])

        profile_metadata = []
        profiles_started = time.monotonic()
        def extrude(spec, start, depth):
            if direct:
                result = runner.helper('prism', {'spec': spec, 'template': geometries[spec['id']],
                                               'start': start, 'depth': depth}, True)
                require(result.get('readback', {}).get('checked') is True, 'Native geometry readback missing')
                profile_metadata.append(dict(id=spec['id'], sketch='kc_' + spec['id'],
                    template=geometries[spec['id']], loopCount=spec['loopCount'], areaMm2=spec['areaMm2'],
                    zMinMm=start, zMaxMm=start + depth, colorId=spec.get('colorId', outline_ids[0])))
                from offline_execution import event
                event('build.profiles', 'running', profiles_started,
                      completed=len(profile_metadata), total=1 + len(plan['fields']))
                return result['bodies']
            sketch = runner.cad('sketch.create', {'name': 'kc_' + spec['id'], 'plane': 'XY'})['sketch']
            geometry = dict(geometries[spec['id']], sketch=sketch)
            runner.cad('sketch.geometry', geometry)
            inspected = runner.cad('sketch.inspect', {'sketch': sketch}, False)
            profiles = [p['ref'] for p in inspected['profiles'] if p['loops'] == spec['loopCount']]
            require(len(profiles) == 1, 'Profile loop count is ambiguous: ' + spec['id'])
            profile = runner.cad('entity.inspect', {'ref': profiles[0]}, False)
            require(abs(profile['area']['value'] * 100 - spec['areaMm2']) <= spec['areaMm2'] * .015,
                    'Live profile area differs from approved plan')
            result = runner.cad('model.extrude', {'name': 'kc_extrude_' + spec['id'],
                'profile': profiles[0], 'distance': f'{depth} mm', 'startOffset': f'{start} mm', 'operation': 'newBody'})
            bodies = result['bodies']
            require(bodies and len({b['name'] for b in bodies}) == len(bodies), 'Extrude returned ambiguous bodies')
            runner.cad('sketch.edit', {'sketch': sketch, 'visible': False})
            return bodies

        def combine(targets, tools, operation):
            if not tools:
                return targets
            output = []
            tool_names = {b['name'] for b in tools}
            require(len(tool_names) == len(tools), 'Boolean tool names are not unique')
            for target in targets:
                require(target['name'] not in tool_names, 'Boolean target also occurs in tools')
                live = runner.helper('overlap', {'target': target['name'], 'tools': sorted(tool_names)})
                overlapping = [b for b in tools if b['name'] in live['overlapping']]
                if not overlapping:
                    require(operation != 'intersect', 'Patch is outside its parent field')
                    output.append(target)
                    continue
                result = runner.cad('model.combine', {'target': target, 'tools': overlapping,
                                  'operation': operation, 'keepTools': True})
                # Tokens are opaque and may change for the same entity. Retained
                # tools are filtered by verified unique native names, not tokens.
                pieces = [b for b in result['bodies'] if b['name'] not in tool_names]
                require(len({b['name'] for b in pieces}) == len(pieces), 'Ambiguous split body names')
                output.extend(pieces)
            return output

        base = extrude(plan['base'], plan['backZMinMm'] if direct else 0,
                       plan['backZMaxMm'] - plan['backZMinMm'] if direct else plan['thicknessMm'])
        baseline = runner.helper('bodies', {'names': [b['name'] for b in base]})
        if direct:
            require(len(base) == len(baseline['bodies']) == 1, 'Direct partition requires one backing body')
            backing_row = baseline['bodies'][0]
            require(backing_row['isSolid'] and abs(backing_row['volumeMm3'] - plan['base']['areaMm2'] *
                    (plan['backZMaxMm'] - plan['backZMinMm'])) <= backing_row['volumeMm3'] * .001,
                    'Backing extrusion volume mismatch')
            require(abs(backing_row['boundsMm'][0][2] - plan['backZMinMm']) <= 1e-5
                    and abs(backing_row['boundsMm'][1][2] - plan['backZMaxMm']) <= 1e-5,
                    'Backing extrusion Z interval mismatch')
        full_volume = (plan['base']['areaMm2'] * plan['thicknessMm'] if direct
                       else sum(b['volumeMm3'] for b in baseline['bodies']))
        if not direct:
            _native_valid(dict(baseline, interferenceCount=0), plan, full_volume, [b['name'] for b in base])
        require(abs(full_volume - plan['base']['areaMm2'] * plan['thicknessMm']) <= full_volume * .001,
                'Base volume disagrees with planned dimensions')
        groups = {key: [] for key in colors}
        for field in plan['fields']:
            parent = extrude(field, lo, hi - lo)
            if direct:
                require(not field['patches'], 'Direct partition field contains patches')
                groups[field['colorId']].extend(parent)
                continue
            base = combine(base, parent, 'cut')
            patches = []
            for patch in sorted(field['patches'], key=lambda p: (p['priority'], p['id']), reverse=True):
                bodies = combine(extrude(patch, lo, hi - lo), parent, 'intersect')
                bodies = combine(bodies, [b for _, bs in patches for b in bs], 'cut')
                patches.append((patch['colorId'], bodies))
            parent = combine(parent, [b for _, bs in patches for b in bs], 'cut')
            groups[field['colorId']].extend(parent)
            for color_id, bodies in patches:
                groups[color_id].extend(bodies)
        base_names = [b['name'] for b in base]
        groups[outline_ids[0]].extend(base)
        require(all(groups.values()), 'Partition eliminated a requested color; review approved SVG')
        grouped = {}
        for number, color in enumerate(plan['colors'], 1):
            color_id = color['id']
            stem = f'stableColor_{number:02}_{color["hex"][1:].lower()}'
            grouped[color_id] = dict(runner.cad('component.from_bodies', {'name': stem,
                                      'bodies': groups[color_id], 'confirm': True}), stem=stem, hex=color['hex'])
        helper_groups = [dict(name=g['component']['name'], hex=g['hex'], **({'colorId': cid} if direct else {}))
                         for cid, g in grouped.items()]
        if direct:
            checkpoint_path = work / 'geometry-checkpoint-unpublished.f3d'
            runner.mark(phase='geometry_checkpoint', groups=grouped, fullVolume=full_volume,
                        validationState='not_yet_validated',
                        partitionMetadata={'construction': 'partition_prisms', 'profileMetadata': profile_metadata,
                            'backZMinMm': plan['backZMinMm'], 'backZMaxMm': plan['backZMaxMm']})
            runner.cad('export.native', {'path': str(checkpoint_path), 'ref': 'root'})
            require(checkpoint_path.is_file() and checkpoint_path.stat().st_size > 0, 'Early native checkpoint missing')
            runner.mark(unpublishedCheckpoint={'path': str(checkpoint_path), 'sha256': digest(checkpoint_path),
                                              'validationState': 'not_yet_validated'})
        runner.helper('appearance', {'groups': helper_groups}, True)
        # Mapping uses the CLI's existing path implementation, not a second WSL policy.
        mapped = subprocess.run(['node', '-e',
            'process.stdout.write(require("./src/cad").mapCadPaths("import.file",{path:process.argv[1]}).path)',
            str(canvas_source)], cwd=REPO, text=True, capture_output=True, check=True).stdout
        canvas_plane = 'XY'
        if plan['imageSide'] == 'top':
            runner.cad('datum.plane', {'name': 'kc_source_plane', 'plane': 'XY', 'offset': f'{hi} mm'})
            runner.cad('visibility.hide', {'refs': ['kc_source_plane']})
            canvas_plane = 'kc_source_plane'
        canvas = runner.helper('canvas', {'sourcePath': mapped, 'plane': canvas_plane, 'imageSize': prepared['imageSize'],
                                'mmPerPixel': plan['mmPerPixel'], 'centerPx': plan['centerPx'],
                                'imageSide': plan['imageSide']}, True)
        history = runner.cad('history.recompute', {})
        require(history['healthy'] is True, 'Native history is unhealthy after recompute')
        backing_component = grouped[outline_ids[0]]['component']['name']
        # These references are post-move and component-qualified. baseNames are
        # pre-group root names retained only as evidence, never final identity.
        runner.mark(phase='geometry_complete', groups=grouped, fullVolume=full_volume, volumeUnits='mm^3',
                    baseNames=base_names, backingComponent=backing_component, canvas=canvas, history=history,
                    validationState='running_readonly')
        partition_metadata = {}
        if direct:
            partition_metadata = {'construction': 'partition_prisms', 'profileMetadata': profile_metadata,
                'backZMinMm': plan['backZMinMm'], 'backZMaxMm': plan['backZMaxMm']}
            runner.mark(partitionMetadata=partition_metadata)
        try:
            native = runner.helper('validate', {'groups': helper_groups,
                                   'backZMm': plan['thicknessMm'] if plan['imageSide'] == 'bottom' else 0,
                                   **partition_metadata})
            if direct:
                native['constructionProof']['partition'] = partition_proof
            require(native['creationId'] == identity['creationId'], 'Native validation document identity changed')
            _native_valid(native, plan, full_volume, backing_component=backing_component)
            require(abs(native['backFaceAreaMm2'] - plan['base']['areaMm2']) <= plan['base']['areaMm2'] * .001,
                    'Native backface does not cover full approved base')
        except Exception:
            runner.mark('blocked', validationState='failed_readonly')
            raise
        runner.mark(phase='native_validated', validationState='passed', native=native)
        bounds = [[min(b['boundsMm'][0][i] for b in native['bodies']) for i in range(3)],
                  [max(b['boundsMm'][1][i] for b in native['bodies']) for i in range(3)]]
        plane_z = 0 if plan['imageSide'] == 'bottom' else plan['thicknessMm']
        sign = -1 if plan['imageSide'] == 'bottom' else 1
        center = [(bounds[0][i] + bounds[1][i]) / 2 for i in range(2)]
        distance = 2 * max(plan['widthMm'], plan['heightMm'], plan['thicknessMm'])
        runner.cad('camera.set', {'projection': 'orthographic', 'up': [0, 1, 0],
                   'eye': [f'{v} mm' for v in [*center, plane_z + sign * distance]],
                   'target': [f'{v} mm' for v in [*center, plane_z]],
                   'extents': [f'{plan[k] * 1.1} mm' for k in ('widthMm', 'heightMm')], 'fit': True})
        view = runner.helper('view', {'imageSide': plan['imageSide'], 'thicknessMm': plan['thicknessMm'], 'boundsMm': bounds})
        require(view['creationId'] == identity['creationId'], 'Colored-side view document identity changed')
        runner.mark(view=view)
        history = runner.cad('history.check', {}, False)
        require(history['healthy'] is True, 'Native history is unhealthy')
        cloud = save_once(runner, name, project_id, identity['folderId'], identity['creationId'])
        return finish(runner, plan, public, cloud)
    except Exception:
        runner.mark('blocked', running=False, error='Build stopped; inspect retained safety checkpoint. No automatic retry.')
        raise


def finish(runner, plan, public, cloud):
    """Export only an identity-verified saved design; never rebuild or save here."""
    metadata = runner.metadata
    native, canvas = metadata['native'], metadata['canvas']
    lo, hi = layer_range(plan)
    history = runner.cad('history.check', {}, False)
    require(history['healthy'] is True, 'Saved native history is unhealthy')
    work = inside(runner.work / f'export-attempt-{runner.number + 1:06}', runner.work)
    runner.mark(phase='exporting', exportAttemptPath=str(work), nativeArchive=None)
    work.mkdir()
    native_path = work / 'model.f3d'
    runner.cad('export.native', {'path': str(native_path), 'ref': 'root'})
    require(native_path.is_file() and native_path.stat().st_size > 0, 'Native export missing')
    native_archive = verify_f3d_archive(native_path)
    runner.mark(nativeArchive=native_archive)
    verified = work / 'verified'
    verified.mkdir()
    reports = {}
    mesh_proof = None
    if plan.get('construction') == 'partition_prisms':
        from keychain_mesh import generate_meshes
        _partition_geometry_unchanged(plan, native)
        reports, mesh_proof = generate_meshes(plan, metadata['groups'], native, verified)
        native = copy.deepcopy(native)
        native['constructionProof']['targetMeshCollisionProof'] = mesh_proof
        runner.mark(native=native)
    for group in ([] if mesh_proof is not None else metadata['groups'].values()):
        # A first save may invalidate pre-save tokens. Resolve qualified names
        # only after the saved native fingerprint has established their identity.
        component = {'kind': 'component', 'name': group['component']['name']}
        bodies = [{'kind': 'body', 'name': b['name'], 'component': component}
                  for b in native['bodies'] if b['component'] == component['name']]
        original = work / (group['stem'] + '.stl')
        runner.cad('export.mesh', {'ref': component, 'path': str(original), 'units': 'mm', 'surfaceDeviation': '.005 mm'})
        color_native = native['colors'][component['name']]
        data, repair = original.read_bytes(), None
        try:
            report = mesh_report(data, color_native)
        except ValueError:
            separate = []
            for index, body in enumerate(bodies):
                path = work / f'{group["stem"]}_body_{index:04}.stl'
                runner.cad('export.mesh', {'ref': body, 'path': str(path), 'units': 'mm', 'surfaceDeviation': '.001 mm'})
                separate.append(path)
            if component['name'] == metadata['backingComponent']:
                t = plan['thicknessMm']
                slabs = [(0, hi), (hi, t)] if lo == 0 else [(0, lo), (lo, t)]
                data, repair = repair_layered_stl(separate, [(a, b) for a, b in slabs if b > a])
            else:
                data, repair = repair_planar_stl(separate, lo, hi - lo)
            report = mesh_report(data, color_native)
        write_new(verified / original.name, data)
        require((verified / original.name).read_bytes() == data, 'Verified mesh write changed bytes')
        reports[original.name] = dict(report, repair=repair)
    write_new(verified / 'model.f3d', native_path.read_bytes())
    verification = {'passed': True, 'native': native, 'meshes': reports, 'targetMeshProof': mesh_proof,
        'canvas': canvas, 'history': history, 'cloud': cloud, 'f3dZipVerified': True, 'nativeArchive': native_archive, 'f3dReimported': False,
        'physicalPrintTested': False, 'imageSide': plan['imageSide'], 'units': 'mm'}
    payloads = sorted(verified.iterdir())
    with (verified / 'keychain.zip').open('xb') as stream:
        with zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED) as archive:
            for path in payloads:
                archive.write(path, path.name)
    with zipfile.ZipFile(verified / 'keychain.zip') as archive:
        require(archive.testzip() is None, 'Delivery ZIP verification failed')
    final_status = runner.helper('saved_status', {'creationId': cloud['creationId'], 'projectId': cloud['projectId']})
    require(final_status['fileId'] == cloud['fileId'] and final_status['modified'] is False
            and final_status['isComplete'] is True, 'Native/cloud state changed after export')
    if runner.metadata.get('reusableTarget'):
        require(final_status.get('version') == cloud['version']
                and final_status.get('projectId') == cloud['projectId']
                and final_status.get('folderId') == cloud['folderId']
                and final_status.get('rootMembershipVerified') is True,
                'Reusable cloud version or root changed after export')
    destination = inside(public / 'print', public)
    runner.mark(outcome='verified', publishing=True)
    destination.mkdir()
    artifacts = []
    for path in sorted(verified.iterdir()):
        target = destination / path.name
        publish_final(target, path.read_bytes())
        require(digest(target) == digest(path), 'Published artifact bytes differ from verified source')
        artifacts.append({'path': str(target), 'sha256': digest(target), 'bytes': target.stat().st_size})
    from keychain_cleanup import completed_build
    final_metadata = (dict(runner.metadata, phase='completed', outcome='complete', publishing=False)
                      if runner.state.get('cleanupPolicy') != 1 or runner.state['request'].get('debug')
                      else completed_build(runner.metadata, verification))
    return {'status': 'completed', 'build': final_metadata,
            'artifacts': artifacts}
