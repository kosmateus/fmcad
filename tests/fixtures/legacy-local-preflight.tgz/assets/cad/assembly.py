"""Assembly placement, real as-built joints, and explicitly scoped history tools.

API signatures verified with Fusion apiDocumentation. No activation or implicit save.
"""


def _assembly_name(name):
    if not isinstance(name, str) or not name.strip():
        raise ValueError('name must be nonempty text')
    return name


def _assembly_top(ctx, ref):
    occurrence = ctx.resolve(ref, 'occurrence')
    if getattr(occurrence, 'assemblyContext', None) is not None or occurrence not in _cad_items(ctx.root.occurrences):
        raise ValueError('This operation supports direct root occurrences only; nested/proxy occurrences are unsupported')
    if occurrence.isReferencedComponent:
        raise ValueError('External referenced occurrences are unsupported')
    return occurrence


def _assembly_root_occurrence(ctx, ref):
    """Resolve a root-qualified occurrence; unlike _assembly_top, allow nested proxies."""
    occurrence = ctx.resolve(ref, 'occurrence')
    if occurrence in _cad_items(ctx.root.occurrences) and getattr(occurrence, 'assemblyContext', None) is None:
        if occurrence.isReferencedComponent:
            raise ValueError('External referenced occurrences are unsupported')
        return occurrence
    path = occurrence.fullPathName
    if not isinstance(path, str) or not path:
        raise ValueError('Occurrence must have an unambiguous root-context path')
    matches = [o for o in _cad_items(ctx.root.allOccurrences) if o.fullPathName == path]
    occurrence = _cad_unique(matches, 'Root-context occurrence ' + path)
    parts = path.split('+')
    for depth in range(1, len(parts) + 1):
        ancestor = _cad_unique([o for o in _cad_items(ctx.root.allOccurrences)
                                if o.fullPathName == '+'.join(parts[:depth])], 'Occurrence path')
        if ancestor.isReferencedComponent:
            raise ValueError('External referenced occurrence or ancestor is unsupported')
    return occurrence


def _assembly_paths(ctx, component):
    return sorted(o.fullPathName for o in _cad_items(ctx.root.allOccurrences) if o.component == component)


def _assembly_root_proxy(ctx, occurrence, parent_occurrence):
    create_proxy = getattr(occurrence, 'createForAssemblyContext', None)
    if create_proxy is not None:
        proxy = _cad_require_result(create_proxy(parent_occurrence), 'Create root-context occurrence proxy')
        if proxy is not None:
            return proxy
    native = getattr(occurrence, 'nativeObject', None) or occurrence
    matches = [item for item in _cad_items(ctx.root.allOccurrences)
               if (getattr(item, 'nativeObject', None) or item) == native]
    if not matches:
        raise RuntimeError('Created occurrence has no root-context proxy; inspect before continuing')
    return sorted(matches, key=lambda item: item.fullPathName)[0]


def _assembly_moved_proxy(ctx, occurrence, predicted_paths):
    matches = [item for item in _cad_items(ctx.root.allOccurrences)
               if item.fullPathName in predicted_paths]
    if not matches and occurrence in _cad_items(ctx.root.occurrences):
        return occurrence
    if not matches:
        raise RuntimeError('Reparented occurrence has no predicted root-context proxy; inspect before continuing')
    return sorted(matches, key=lambda item: item.fullPathName)[0]


def _assembly_nested_options(data):
    if 'placementSpace' in data and data['placementSpace'] not in ('root', 'parent'):
        raise ValueError('placementSpace must be root or parent')
    if 'sharedParentPolicy' in data and data['sharedParentPolicy'] != 'allInstances':
        raise ValueError('sharedParentPolicy must be allInstances')


def _assembly_external_component_reference(ctx, ref):
    if not isinstance(ref, dict) or not isinstance(ref.get('token'), str):
        return False
    for occurrence in _cad_items(ctx.root.allOccurrences):
        if not getattr(occurrence, 'isReferencedComponent', False):
            continue
        component = occurrence.component
        if getattr(component, 'entityToken', None) == ref['token']:
            return True
    return False


def _assembly_matrix(ctx, data):
    _cad_fields(data, optional=('translation', 'axis', 'angle'))
    if ('axis' in data) != ('angle' in data):
        raise ValueError('Rotation requires both axis and angle')
    translation = ctx.point(data.get('translation', ['0 mm', '0 mm', '0 mm']))
    matrix = adsk.core.Matrix3D.create()
    if 'angle' in data:
        angle = ctx.angle(data['angle'])
        axis = adsk.core.Vector3D.create(*_cad_direction(data['axis']))
        _cad_require_result(matrix.setToRotation(angle, axis, adsk.core.Point3D.create(0, 0, 0)), 'Rotation matrix')
    matrix.translation = adsk.core.Vector3D.create(translation.x, translation.y, translation.z)
    return matrix


def _assembly_capture_ready(ctx):
    parametric = ctx.design.designType == adsk.fusion.DesignTypes.ParametricDesignType
    if parametric:
        if ctx.design.timeline.markerPosition != ctx.design.timeline.count:
            raise ValueError('Move timeline marker to the end before assembly changes')
        if ctx.design.snapshots.hasPendingSnapshot:
            raise ValueError('Resolve existing pending positions before this operation; they will not be captured implicitly')
    return parametric


def _assembly_capture(ctx, parametric):
    if parametric and ctx.design.snapshots.hasPendingSnapshot:
        return ctx.ref(_cad_require_result(ctx.design.snapshots.add(), 'Capture assembly position'))
    return None


def _assembly_component(ctx, data, mode):
    if mode == 'inspect':
        _cad_fields(data, optional=('component',))
        component = ctx.resolve(data['component'], 'component') if 'component' in data else ctx.component
        return {'component': ctx.describe(component), 'bodies': [ctx.ref(b) for b in _cad_items(component.bRepBodies)],
                'occurrences': [ctx.ref(o) for o in _cad_items(component.occurrences)]}
    if mode == 'rename':
        _cad_fields(data, ('component', 'name'))
        component = ctx.resolve(data['component'], 'component')
        name = _assembly_name(data['name'])
        component.name = name
        return {'component': ctx.ref(component), 'affectsAllInstances': True}
    if mode == 'reparent':
        _cad_fields(data, ('occurrence', 'target', 'confirm'), ('sharedParentPolicy',))
        _assembly_nested_options(data)
        ctx.require_confirm(data)
        occurrence = _assembly_root_occurrence(ctx, data['occurrence'])
        target = _assembly_root_occurrence(ctx, data['target'])
        source_paths = _assembly_paths(ctx, occurrence.component)
        target_paths = _assembly_paths(ctx, target.component)
        if '+' in occurrence.fullPathName and len(source_paths) > 1:
            raise ValueError('Nested reparent of a repeated source definition is unsupported')
        if len(target_paths) > 1 and data.get('sharedParentPolicy') != 'allInstances':
            raise ValueError('Repeated target requires sharedParentPolicy:allInstances')
        if occurrence == target or occurrence.component == target.component or any(
                o.component == target.component for o in _cad_items(occurrence.component.allOccurrences)):
            raise ValueError('Reparent would create a component cycle')
        _assembly_capture_ready(ctx)
        before = list(_entity_occurrence_matrix(ctx, occurrence))
        moved_name = occurrence.fullPathName.rsplit('+', 1)[-1]
        predicted_paths = sorted(path + '+' + moved_name for path in target_paths)
        moved_native = _cad_require_result(occurrence.moveToComponent(target), 'Reparent occurrence')
        moved = _assembly_moved_proxy(ctx, moved_native, predicted_paths)
        after = list(_entity_occurrence_matrix(ctx, moved))
        if any(abs(a-b) > 1e-7 for a, b in zip(before, after)):
            raise RuntimeError('Reparent world pose readback differs; mutation retained for inspection')
        return {'occurrence': ctx.ref(moved), 'worldPosePreserved': True,
                'affectedPaths': predicted_paths}
    _cad_fields(data, ('name',) + (('bodies', 'confirm') if mode == 'from_bodies' else ()), ('placement',))
    name = _assembly_name(data['name'])
    matrix = _assembly_matrix(ctx, data.get('placement', {}))
    if any(c.name == name for c in _cad_items(ctx.design.allComponents)):
        raise ValueError('Component name already exists')
    bodies = []
    if mode == 'from_bodies':
        ctx.require_confirm(data)
        if not isinstance(data['bodies'], list) or not data['bodies']:
            raise ValueError('bodies must be a nonempty array')
        bodies = [ctx.resolve(r, 'body') for r in data['bodies']]
        if any(b == previous for i, b in enumerate(bodies) for previous in bodies[:i]):
            raise ValueError('Duplicate bodies')
        if any(getattr(b, 'assemblyContext', None) is not None or b.parentComponent != ctx.root for b in bodies):
            raise ValueError('from_bodies supports native root bodies only')
    _assembly_capture_ready(ctx)
    occurrence = _cad_require_result(ctx.root.occurrences.addNewComponent(matrix), 'Create component')
    occurrence.component.name = name
    ctx.created.extend([ctx.ref(occurrence.component), ctx.ref(occurrence)])
    moved = [_cad_require_result(b.moveToComponent(occurrence), 'Move body to component') for b in bodies]
    return {'component': ctx.ref(occurrence.component), 'occurrence': ctx.ref(occurrence),
            'bodies': [ctx.ref(b) for b in moved], 'atomic': False}


def _assembly_occurrence(ctx, data, mode):
    if mode in ('transform', 'align'):
        return _datum_occurrence(ctx, data, mode)
    if mode in ('add', 'duplicate'):
        source = 'component' if mode == 'add' else 'occurrence'
        _cad_fields(data, (source, 'copyMode'), ('placement', 'name', 'destination', 'placementSpace', 'sharedParentPolicy'))
        _assembly_nested_options(data)
        if data['copyMode'] not in ('linked', 'independent'):
            raise ValueError('copyMode must explicitly be linked or independent')
        if data['copyMode'] == 'linked' and 'name' in data:
            raise ValueError('name would rename every linked instance; use component.rename explicitly')
        if 'name' in data:
            _assembly_name(data['name'])
        original = _assembly_root_occurrence(ctx, data[source]) if mode == 'duplicate' else None
        if mode == 'add' and _assembly_external_component_reference(ctx, data[source]):
            raise ValueError('External component insertion/copy is unsupported')
        component = original.component if original else ctx.resolve(data[source], 'component')
        if component == ctx.root:
            raise ValueError('Cannot instance the root component')
        if any(o.component == component and o.isReferencedComponent for o in _cad_items(ctx.root.allOccurrences)):
            raise ValueError('External component insertion/copy is unsupported')
        destination = data.get('destination')
        if 'placementSpace' in data and 'placement' not in data:
            raise ValueError('placementSpace is only valid with placement')
        if 'placement' in data and destination not in (None, 'root') and data.get('placementSpace') not in ('root', 'parent'):
            raise ValueError('placementSpace root or parent is required for nested placement')
        if destination == 'root':
            parent = ctx.root
            parent_occurrence = None
        elif destination is not None:
            parent_occurrence = _assembly_root_occurrence(ctx, destination)
            parent = parent_occurrence.component
            if parent == component or any(o.component == parent for o in _cad_items(component.allOccurrences)):
                raise ValueError('Destination would create an occurrence cycle')
            if len(_assembly_paths(ctx, parent)) > 1 and data.get('sharedParentPolicy') != 'allInstances':
                raise ValueError('Repeated linked parent requires sharedParentPolicy:allInstances')
        else:
            parent, parent_occurrence = ctx.root, None
        if 'placement' in data:
            if parent_occurrence is None and 'placementSpace' in data:
                raise ValueError('placementSpace is only valid for nested placement')
            local = _entity_matrix(_assembly_matrix(ctx, data['placement']).asArray())
            matrix_values = (_entity_multiply(_entity_inverse(_entity_occurrence_matrix(ctx, parent_occurrence)), local)
                             if parent_occurrence is not None and data['placementSpace'] == 'root' else local)
            matrix = adsk.core.Matrix3D.create()
            matrix.setWithArray(matrix_values)
        elif parent_occurrence is not None and mode == 'duplicate':
            matrix_values = _entity_multiply(_entity_inverse(_entity_occurrence_matrix(ctx, parent_occurrence)),
                                             _entity_occurrence_matrix(ctx, original))
            matrix = adsk.core.Matrix3D.create()
            matrix.setWithArray(matrix_values)
        elif mode == 'duplicate':
            matrix = original.transform2.copy()
        else:
            matrix = adsk.core.Matrix3D.create()
        _assembly_capture_ready(ctx)
        method = 'addExistingComponent' if data['copyMode'] == 'linked' else 'addNewComponentCopy'
        occurrence = _cad_require_result(getattr(parent.occurrences, method)(component, matrix), 'Add occurrence')
        result_occurrence = _assembly_root_proxy(ctx, occurrence, parent_occurrence) if parent_occurrence is not None else occurrence
        if 'name' in data:
            result_occurrence.component.name = data['name']
        ctx.created.append(ctx.ref(result_occurrence))
        if data['copyMode'] == 'independent':
            ctx.created.append(ctx.ref(result_occurrence.component))
        return {'occurrence': ctx.ref(result_occurrence), 'component': ctx.ref(result_occurrence.component), 'copyMode': data['copyMode'],
                'affectedPaths': _assembly_paths(ctx, result_occurrence.component)}


_ASSEMBLY_LIMIT_VALUES = ('minimumValue', 'maximumValue', 'restValue')
_ASSEMBLY_LIMIT_FLAGS = ('isMinimumValueEnabled', 'isMaximumValueEnabled', 'isRestValueEnabled')


def _assembly_limits_read(motion):
    return {axis: dict({prop: getattr(getattr(motion, axis + 'Limits'), prop)
                       for prop in _ASSEMBLY_LIMIT_VALUES + _ASSEMBLY_LIMIT_FLAGS}, units=units)
            for axis, units in (('rotation', 'rad'), ('slide', 'cm'))
            if hasattr(motion, axis + 'Limits')}


def _assembly_limits_plan(ctx, motion, data):
    if not isinstance(data, dict):
        raise ValueError('limits must be an object')
    _cad_fields(data, optional=('rotation', 'slide'))
    if not data:
        raise ValueError('limits must specify rotation or slide')
    supported = {'RevoluteJointMotion': ('rotation',), 'SliderJointMotion': ('slide',),
                 'CylindricalJointMotion': ('rotation', 'slide')}.get(_cad_type(motion), ())
    before = _assembly_limits_read(motion)
    plan = []
    for axis, changes in data.items():
        if axis not in supported:
            raise ValueError('Joint motion does not support limits for ' + axis)
        if not isinstance(changes, dict):
            raise ValueError(axis + ' limits must be an object')
        _cad_fields(changes, optional=_ASSEMBLY_LIMIT_VALUES + _ASSEMBLY_LIMIT_FLAGS)
        if not changes:
            raise ValueError(axis + ' limits must not be empty')
        state = {k: v for k, v in before[axis].items() if k != 'units'}
        for prop, value in changes.items():
            if prop in _ASSEMBLY_LIMIT_FLAGS:
                if type(value) is not bool:
                    raise ValueError(prop + ' must be boolean')
            else:
                value = (ctx.angle if axis == 'rotation' else ctx.length)(value)
                if not math.isfinite(value):
                    raise ValueError(prop + ' must be finite')
            state[prop] = value
        if any(not math.isfinite(state[p]) for p in _ASSEMBLY_LIMIT_VALUES):
            raise ValueError(axis + ' limit values must be finite')
        # Disabled stored values are retained, not replaced with invented bounds.
        if state['minimumValue'] > state['maximumValue']:
            raise ValueError(axis + ' minimumValue must be <= maximumValue')
        if state['isRestValueEnabled'] or 'restValue' in changes:
            if ((state['isMinimumValueEnabled'] and state['restValue'] < state['minimumValue']) or
                    (state['isMaximumValueEnabled'] and state['restValue'] > state['maximumValue'])):
                raise ValueError(axis + ' restValue is outside enabled limits')
        plan.append((getattr(motion, axis + 'Limits'), state))
    return plan


def _assembly_limits_write(limits, state):
    # Temporarily disable constraints to avoid invalid intermediate ranges; restore every flag.
    for prop in _ASSEMBLY_LIMIT_FLAGS:
        setattr(limits, prop, False)
    for prop in _ASSEMBLY_LIMIT_VALUES:
        setattr(limits, prop, state[prop])
    for prop in _ASSEMBLY_LIMIT_FLAGS:
        setattr(limits, prop, state[prop])
    if any(getattr(limits, p) != state[p] for p in state):
        raise RuntimeError('Joint limits readback differs from requested state')


def _assembly_limits_apply(motion, plan):
    saved = [(limits, {p: getattr(limits, p) for p in _ASSEMBLY_LIMIT_VALUES + _ASSEMBLY_LIMIT_FLAGS})
             for limits, state in plan]
    try:
        for limits, state in plan:
            _assembly_limits_write(limits, state)
    except Exception as error:
        errors = []
        for limits, state in reversed(saved):
            assignments = [(p, False) for p in _ASSEMBLY_LIMIT_FLAGS] + list(state.items())
            for prop, value in assignments:
                try:
                    setattr(limits, prop, value)
                except Exception as restore_error:
                    errors.append(prop + ': ' + str(restore_error))
            try:
                if any(getattr(limits, p) != state[p] for p in state):
                    errors.append('Restored limits differ from original state')
            except Exception as read_error:
                errors.append(str(read_error))
        actual = None
        try:
            actual = _assembly_limits_read(motion)
        except Exception as read_error:
            errors.append('Readback: ' + str(read_error))
        raise RuntimeError('Joint limits mutation failed: ' + json.dumps({
            'error': str(error), 'rollback': {'restored': not errors, 'errors': errors},
            'limits': actual, 'atomic': False})) from error


def _assembly_joint_line(ctx, name, component, point, axis):
    # A sketch line along the requested axis is the carrier for a JointOrigin Z
    # axis. Fusion silently drops both ConstructionAxis and SketchLine handed to
    # an AsBuiltJoint custom direction entity, so a full (non-as-built) Joint's
    # JointOriginInput.zAxisEntity is used instead; it requires a linear edge in
    # the same component. The line also carries the sign through point order.
    direction = _cad_direction(axis)
    reference = [0.0, 1.0, 0.0] if abs(direction[0]) > 0.9 else [1.0, 0.0, 0.0]
    side = _cad_direction([direction[1] * reference[2] - direction[2] * reference[1],
                           direction[2] * reference[0] - direction[0] * reference[2],
                           direction[0] * reference[1] - direction[1] * reference[0]])
    positions = {'lineStart': point,
                 'lineEnd': [a + b for a, b in zip(point, direction)],
                 'lineSide': [a + b for a, b in zip(point, side)]}
    saved = ctx.component, ctx.occurrence
    ctx.component, ctx.occurrence = component, None
    try:
        for suffix in positions:
            _cad_datum_name(ctx, {'name': name + '__' + suffix}, component.constructionPoints)
        _cad_datum_name(ctx, {'name': name + '__linePlane'}, component.constructionPlanes)
        _cad_datum_name(ctx, {'name': name + '__lineSketch'}, component.sketches)
        point_refs = {suffix: _cad_datum_point(ctx, {'name': name + '__' + suffix,
                                                     'point': [str(v) + ' cm' for v in position]})
                      for suffix, position in positions.items()}
        plane_input = component.constructionPlanes.createInput()
        _cad_require_result(plane_input.setByThreePoints(*[ctx.resolve(ref) for ref in point_refs.values()]),
                            'Define joint axis sketch plane')
        plane = _cad_require_result(component.constructionPlanes.add(plane_input), 'Create joint axis sketch plane')
        plane.name = name + '__linePlane'
        ctx.created.append(ctx.ref(plane))
        sketch = _cad_require_result(component.sketches.addWithoutEdges(plane), 'Create joint axis sketch')
        sketch.name = name + '__lineSketch'
        ctx.created.append(ctx.ref(sketch))
        line = _cad_require_result(sketch.sketchCurves.sketchLines.addByTwoPoints(
            adsk.core.Point3D.create(*positions['lineStart']), adsk.core.Point3D.create(*positions['lineEnd'])),
            'Create joint axis sketch line')
    finally:
        ctx.component, ctx.occurrence = saved
    return line, {'sketch': ctx.ref(sketch), 'plane': ctx.ref(plane), 'line': ctx.ref(line),
                  'points': list(point_refs.values())}


def _assembly_joint_origin(ctx, name, occurrence, point_root, axis_root):
    # Build one JointOrigin in the occurrence's component whose primary (Z) axis
    # is pinned to the requested root-frame direction. The origin sits on the
    # axis line and its Z axis is a sketch line along the axis. This is the only
    # reliable way to persist a custom axis, unlike point-based AsBuiltJoint
    # geometry, which is position-only and drops custom direction entities.
    component = occurrence.component
    conversion = _entity_inverse(_entity_occurrence_matrix(ctx, occurrence))
    local_point = _entity_xyz(conversion, point_root)
    local_axis = _cad_direction(_entity_xyz(conversion, axis_root, True))
    # Fusion orients a JointOrigin primary (Z) axis OPPOSITE to its zAxisEntity
    # sketch line direction (native evidence: a line drawn (0,0,0)->(1,0,0) reads
    # back rotationAxisVector [-1,0,0]). Draw the carrier line along -axis so the
    # read-back sign matches the requested direction.
    line, helpers = _assembly_joint_line(ctx, name, component, local_point, [-v for v in local_axis])
    geometry = _cad_require_result(adsk.fusion.JointGeometry.createByPoint(line.startSketchPoint), 'Joint origin geometry')
    origin_input = _cad_require_result(component.jointOrigins.createInput(geometry), 'Joint origin input')
    origin_input.zAxisEntity = line
    origin = _cad_require_result(component.jointOrigins.add(origin_input), 'Create joint origin')
    ctx.created.append(ctx.ref(origin))
    helpers['origin'] = ctx.ref(origin)
    return origin, helpers


def _assembly_regular_joint_origin(ctx, ref, occurrence, label):
    if not isinstance(ref, dict):
        raise ValueError(label + ' must be {ref:JointOrigin} or {point,xAxis,zAxis}')
    if set(ref) == {'ref'}:
        origin = ctx.resolve(ref['ref'], 'JointOrigin')
        if _cad_owner(origin) != occurrence.component or getattr(origin, 'assemblyContext', None) is not None:
            raise ValueError(label + ' JointOrigin must be native to the matching input component')
        return {'origin': origin}, [ctx.ref(origin)]
    _cad_fields(ref, ('point', 'xAxis', 'zAxis'))
    point = ctx.resolve(ref['point'])
    x_axis = ctx.resolve(ref['xAxis'])
    z_axis = ctx.resolve(ref['zAxis'])
    for entity, expected in ((point, ('ConstructionPoint', 'SketchPoint', 'BRepVertex')),
                             (x_axis, ('ConstructionAxis', 'SketchLine', 'BRepEdge')),
                             (z_axis, ('ConstructionAxis', 'SketchLine', 'BRepEdge'))):
        if _cad_type(entity) not in expected or _cad_owner(entity) != occurrence.component or \
                getattr(entity, 'assemblyContext', None) is not None:
            raise ValueError(label + ' point and axes must be native references owned by the matching input component')
    return {'point': point, 'xAxis': x_axis, 'zAxis': z_axis}, [ctx.ref(point), ctx.ref(x_axis), ctx.ref(z_axis)]


def _assembly_regular_joint_origin_context(ctx, source, occurrence, label):
    if 'origin' in source:
        return _cad_require_result(source['origin'].createForAssemblyContext(occurrence), label + ' occurrence context'), [
            ctx.ref(source['origin'])]
    geometry = _cad_require_result(adsk.fusion.JointGeometry.createByPoint(source['point']), label + ' geometry')
    origin_input = _cad_require_result(occurrence.component.jointOrigins.createInput(geometry), label + ' input')
    origin_input.xAxisEntity = source['xAxis']
    origin_input.zAxisEntity = source['zAxis']
    origin = _cad_require_result(occurrence.component.jointOrigins.add(origin_input), label + ' JointOrigin')
    ctx.created.append(ctx.ref(origin))
    return _cad_require_result(origin.createForAssemblyContext(occurrence), label + ' occurrence context'), [
        ctx.ref(source['point']), ctx.ref(source['xAxis']), ctx.ref(source['zAxis']), ctx.ref(origin)]


def _assembly_pose_snapshot(ctx):
    rows = {}
    for occurrence in _cad_items(ctx.root.allOccurrences):
        path = occurrence.fullPathName
        if path in rows:
            raise ValueError('Occurrence paths must be unique for pose protection: ' + path)
        rows[path] = list(_entity_occurrence_matrix(ctx, occurrence))
    return rows


def _assembly_pose_delta(before, after):
    linear = math.sqrt(sum((before[i] - after[i]) ** 2 for i in (3, 7, 11)))
    trace = sum(before[4 * row + column] * after[4 * row + column]
                for row in range(3) for column in range(3))
    cosine = max(-1.0, min(1.0, (trace - 1.0) / 2.0))
    return linear, math.acos(cosine)


def _assembly_joint_rigid_regular(ctx, data):
    _cad_fields(data, ('name', 'mode', 'occurrenceOne', 'occurrenceTwo', 'confirm', 'originOne', 'originTwo',
                       'posePolicy', 'linearTolerance', 'angularTolerance'),
                ('angle', 'offset', 'isFlipped', 'groundingPolicy'))
    if data['confirm'] is not True:
        raise ValueError('Regular rigid joint requires confirm: true')
    if data['posePolicy'] not in ('preserve', 'moveSecond'):
        raise ValueError('posePolicy must be preserve or moveSecond')
    if data.get('groundingPolicy', 'reject') != 'reject':
        raise ValueError('groundingPolicy accepts only reject; automatic ungrounding is unsupported')
    if 'isFlipped' in data and type(data['isFlipped']) is not bool:
        raise ValueError('isFlipped must be boolean')
    angle = data.get('angle', '0 deg')
    offset = data.get('offset', '0 mm')
    ctx.angle(angle)
    ctx.length(offset)
    linear_tolerance = ctx.length(data['linearTolerance'])
    angular_tolerance = ctx.angle(data['angularTolerance'])
    if not math.isfinite(linear_tolerance) or linear_tolerance <= 0:
        raise ValueError('linearTolerance must be a positive finite length')
    if not math.isfinite(angular_tolerance) or angular_tolerance <= 0:
        raise ValueError('angularTolerance must be a positive finite angle')
    name = _assembly_name(data['name'])
    one, two = [_datum_occurrence_ref(ctx, data[k]) for k in ('occurrenceOne', 'occurrenceTwo')]
    if one == two:
        raise ValueError('Regular rigid joint requires distinct occurrences')
    if one.fullPathName.startswith(two.fullPathName + '+') or two.fullPathName.startswith(one.fullPathName + '+'):
        raise ValueError('Regular rigid joint cannot connect an occurrence to its ancestor')
    for occurrence in (one, two):
        native = getattr(occurrence, 'nativeObject', None) or occurrence
        if getattr(native, 'isGrounded', False) or getattr(native, 'isGroundToParent', False):
            raise ValueError('Regular rigid joint rejects grounded input occurrences; it never ungrounds automatically')
    for component in _cad_items(ctx.design.allComponents):
        for collection_name in ('joints', 'asBuiltJoints'):
            collection = getattr(component, collection_name, None)
            if collection is not None and any(joint.name == name for joint in _cad_items(collection)):
                raise ValueError('Joint name already exists: ' + name)
    _assembly_capture_ready(ctx)
    before = _assembly_pose_snapshot(ctx)
    source_one, refs_one = _assembly_regular_joint_origin(ctx, data['originOne'], one, 'originOne')
    source_two, refs_two = _assembly_regular_joint_origin(ctx, data['originTwo'], two, 'originTwo')
    origin_one, refs_one = _assembly_regular_joint_origin_context(ctx, source_one, one, 'originOne')
    origin_two, refs_two = _assembly_regular_joint_origin_context(ctx, source_two, two, 'originTwo')
    joints = ctx.root.joints
    native_origins = (origin_two, origin_one) if data['posePolicy'] == 'moveSecond' else (origin_one, origin_two)
    inp = _cad_require_result(joints.createInput(*native_origins), 'Regular rigid joint input')
    _cad_require_result(inp.setAsRigidJointMotion(), 'Define regular rigid joint')
    inp.angle = adsk.core.ValueInput.createByString(angle)
    inp.offset = adsk.core.ValueInput.createByString(offset)
    inp.isFlipped = data.get('isFlipped', False)
    joint = _cad_require_result(joints.add(inp), 'Create regular rigid joint')
    ctx.created.append(ctx.ref(joint))
    joint.name = name
    _cad_require_result(ctx.design.computeAll(), 'Recompute regular rigid joint')
    if joint.healthState != adsk.fusion.FeatureHealthStates.HealthyFeatureHealthState:
        raise RuntimeError('Regular rigid joint is unhealthy; created joint retained for inspection')
    after = _assembly_pose_snapshot(ctx)
    if set(before) != set(after):
        raise RuntimeError('Occurrence set changed while creating regular rigid joint; inspect partial changes')
    second_path = two.fullPathName
    pose_rows = []
    violations = []
    for path in before:
        linear_delta, angular_delta = _assembly_pose_delta(before[path], after[path])
        allowed = data['posePolicy'] == 'moveSecond' and (path == second_path or path.startswith(second_path + '+'))
        within = allowed or (linear_delta <= linear_tolerance and angular_delta <= angular_tolerance)
        row = {'path': path, 'linearDelta': linear_delta, 'angularDelta': angular_delta,
               'allowedMove': allowed, 'withinTolerance': within}
        pose_rows.append(row)
        if not within:
            violations.append(row)
    if violations:
        raise RuntimeError('Regular rigid joint pose policy was violated; joint retained for inspection: ' +
                           json.dumps({'joint': ctx.ref(joint), 'posePolicy': data['posePolicy'],
                                        'violations': violations, 'automaticRestore': False}))
    result = _assembly_joint(ctx, {'joint': ctx.ref(joint)}, 'inspect')
    result.update(type='rigid', mode='regular', asBuilt=False, posePolicy=data['posePolicy'],
                  poses=pose_rows, originOne=refs_one, originTwo=refs_two,
                  requestedOccurrences=[ctx.ref(one), ctx.ref(two)],
                  requested={'angle': angle, 'offset': offset, 'isFlipped': data.get('isFlipped', False)},
                  linearTolerance=linear_tolerance, angularTolerance=angular_tolerance,
                  poseUnits={'linear': 'cm', 'angular': 'rad'}, groundingPolicy='reject',
                  associativity='native JointOrigins')
    return result


def _assembly_joint(ctx, data, mode):
    _datum_version(data)
    if mode == 'rigid':
        rigid_mode = data.get('mode', 'asBuilt')
        if rigid_mode == 'regular':
            return _assembly_joint_rigid_regular(ctx, data)
        if rigid_mode != 'asBuilt':
            raise ValueError('joint.rigid mode must be asBuilt or regular')
    if mode in ('inspect', 'edit', 'drive', 'limits'):
        _cad_fields(data, ('joint',), () if mode == 'inspect' else (
            ('name', 'suppressed') if mode == 'edit' else (
                ('limits', 'confirm') if mode == 'limits' else ('rotation', 'slide'))))
        # Core tokens are authoritative and support Joint/AsBuiltJoint without kind enumeration.
        joint = ctx.resolve(data['joint'])
        if _cad_type(joint) not in ('Joint', 'AsBuiltJoint'):
            raise ValueError('joint must resolve to a Joint or AsBuiltJoint token reference')
        if mode != 'inspect':
            if getattr(joint, 'assemblyContext', None) is not None:
                raise ValueError('Mutations require a native joint, not an occurrence proxy')
            owner = _cad_owner(joint)
            if owner not in _cad_items(ctx.design.allComponents):
                raise ValueError('Joint must belong to a native component in this design')
            if any(o.component == owner and o.isReferencedComponent for o in _cad_items(ctx.root.allOccurrences)):
                raise ValueError('External referenced joints are unsupported')
        if mode == 'edit':
            if not any(k in data for k in ('name', 'suppressed')):
                raise ValueError('Specify name or suppressed')
            if 'name' in data:
                _assembly_name(data['name'])
            if 'suppressed' in data and type(data['suppressed']) is not bool:
                raise ValueError('suppressed must be boolean')
            if 'suppressed' in data:
                if ctx.design.designType != adsk.fusion.DesignTypes.ParametricDesignType:
                    raise ValueError('Suppression requires parametric history')
                joint.isSuppressed = data['suppressed']
            if 'name' in data:
                joint.name = data['name']
        motion = joint.jointMotion
        if mode == 'limits':
            ctx.require_confirm(data)
            if 'limits' not in data:
                raise ValueError('Specify limits; use joint.inspect for read-only inspection')
            plan = _assembly_limits_plan(ctx, motion, data['limits'])
            _assembly_capture_ready(ctx)
            _assembly_limits_apply(motion, plan)
        if mode == 'drive':
            if not any(k in data for k in ('rotation', 'slide')):
                raise ValueError('Specify rotation or slide')
            values = {}
            for key, prop, evaluator in (('rotation', 'rotationValue', ctx.angle), ('slide', 'slideValue', ctx.length)):
                if key in data:
                    if not hasattr(motion, prop):
                        raise ValueError('Joint motion does not support ' + key)
                    value = evaluator(data[key])
                    if not math.isfinite(value):
                        raise ValueError(key + ' must be finite')
                    limits = getattr(motion, key + 'Limits')
                    if (limits.isMinimumValueEnabled and value < limits.minimumValue) or (limits.isMaximumValueEnabled and value > limits.maximumValue):
                        raise ValueError(key + ' is outside joint limits')
                    values[prop] = value
            parametric = _assembly_capture_ready(ctx)
            for prop, value in values.items():
                setattr(motion, prop, value)
            snapshot = _assembly_capture(ctx, parametric)
        result = {'joint': ctx.describe(joint), 'motionType': _cad_type(motion),
                  'occurrences': [ctx.ref(o) if o is not None else None
                                  for o in (joint.occurrenceOne, joint.occurrenceTwo)],
                  'limits': _assembly_limits_read(motion), 'units': 'cm/rad',
                  'parametricExpressions': False,
                  'scope': 'occurrence proxy' if getattr(joint, 'assemblyContext', None) is not None else
                           'native component definition; affects all instances'}
        for prop in ('rotationValue', 'slideValue'):
            if hasattr(motion, prop):
                result[prop] = getattr(motion, prop)
        if mode == 'drive':
            result.update(snapshot=snapshot, units='cm/rad', parametricExpressions=False)
        return result
    optional = ('limits', 'confirm', 'point', 'axis', 'frame', 'associativity', 'schemaVersion')
    if mode == 'rigid':
        optional += ('mode',)
    _cad_fields(data, ('name', 'occurrenceOne', 'occurrenceTwo'), optional)
    if 'frame' in data:
        return _datum_joint_create(ctx, data, mode)
    if 'associativity' in data:
        raise ValueError('associativity is only an input for frame-derived joint helpers')
    if mode != 'rigid' and not all(k in data for k in ('point', 'axis')):
        raise ValueError('Joint requires point and axis, or an explicit frame')
    if mode == 'rigid' and any(k in data for k in ('point', 'axis')):
        raise ValueError('Rigid joint does not accept point or axis')
    if 'limits' in data:
        ctx.require_confirm(data)
        if mode == 'rigid':
            raise ValueError('Rigid joints do not support limits')
    elif 'confirm' in data:
        ctx.require_confirm(data)
    name = _assembly_name(data['name'])
    one, two = [_datum_occurrence_ref(ctx, data[k]) for k in ('occurrenceOne', 'occurrenceTwo')]
    if one == two:
        raise ValueError('Joint requires distinct occurrences')
    if one.fullPathName.startswith(two.fullPathName + '+') or two.fullPathName.startswith(one.fullPathName + '+'):
        raise ValueError('Joint cannot connect an occurrence to its ancestor')
    if any(j.name == name for j in _cad_items(ctx.root.asBuiltJoints)):
        raise ValueError('Joint name already exists: ' + name)
    geometry = None
    custom_axis = None
    requested_axis = None
    axis_origin_root = None
    if mode != 'rigid':
        if isinstance(data['axis'], dict):
            if 'vector' in data['axis']:
                raise ValueError('custom vectors are unsupported; create a datum axis first')
            _cad_fields(data['axis'], ('ref',))
            custom_axis = ctx.resolve(data['axis']['ref'])
            if _cad_type(custom_axis) != 'ConstructionAxis':
                raise ValueError('Custom joint axis must be an explicit ConstructionAxis reference')
            axis_context = getattr(custom_axis, 'assemblyContext', None)
            if not ((_cad_owner(custom_axis) == ctx.root and axis_context is None) or axis_context in (one, two)):
                raise ValueError('Custom axis must belong to root or an input occurrence context')
            native_axis = getattr(custom_axis, 'nativeObject', None) or custom_axis
            if getattr(native_axis, 'geometry', None) is None or _cad_type(native_axis.geometry) not in ('InfiniteLine3D', 'Line3D'):
                raise ValueError('Custom joint axis requires line geometry (InfiniteLine3D)')
            conversion = _entity_owner_matrix(ctx, _cad_owner(custom_axis), axis_context)
            requested_axis = _cad_direction(_entity_xyz(conversion, _cad_xyz(native_axis.geometry.direction), True))
            axis_origin_root = _entity_xyz(conversion, _cad_xyz(native_axis.geometry.origin))
        elif data['axis'] not in ('X', 'Y', 'Z'):
            raise ValueError('custom vectors are unsupported; axis must be X, Y, Z or {ref:constructionAxis}')
        point = ctx.root.originConstructionPoint if data['point'] == 'origin' else ctx.resolve(data['point'])
        if _cad_type(point) not in ('ConstructionPoint', 'SketchPoint', 'BRepVertex'):
            raise ValueError('point must be a construction/sketch point or BRep vertex')
        context = getattr(point, 'assemblyContext', None)
        if not ((_cad_owner(point) == ctx.root and context is None) or
                (context in (one, two) and _cad_owner(point) == context.component)):
            raise ValueError('Joint point must be in root or one of the two occurrence contexts')
        if custom_axis is None:
            geometry = _cad_require_result(adsk.fusion.JointGeometry.createByPoint(point), 'Joint geometry')
    _assembly_capture_ready(ctx)
    if custom_axis is not None:
        # Full (non-as-built) Joint via two explicit JointOrigins whose primary
        # (Z) axis is pinned to the requested direction. A full Joint MOVES
        # occurrenceTwo to mate with occurrenceOne (per angle/offset/isFlipped),
        # unlike the pose-preserving AsBuiltJoint used for X/Y/Z axes.
        origin_one, helpers_one = _assembly_joint_origin(ctx, name + '__one', one, axis_origin_root, requested_axis)
        origin_two, helpers_two = _assembly_joint_origin(ctx, name + '__two', two, axis_origin_root, requested_axis)
        joint_one = _cad_require_result(origin_one.createForAssemblyContext(one), 'Create joint origin context')
        joint_two = _cad_require_result(origin_two.createForAssemblyContext(two), 'Create joint origin context')
        joints = ctx.root.joints
        inp = _cad_require_result(joints.createInput(joint_one, joint_two), 'Joint input')
        _cad_require_result(getattr(inp, 'setAs' + mode.capitalize() + 'JointMotion')(
            adsk.fusion.JointDirections.ZAxisJointDirection), 'Define joint motion')
        if 'limits' in data:
            plan = _assembly_limits_plan(ctx, inp.jointMotion, data['limits'])
            states = [(axis, state) for axis, (_, state) in zip(data['limits'], plan)]
        joint = _cad_require_result(joints.add(inp), 'Create joint')
    else:
        joints = ctx.root.asBuiltJoints
        inp = _cad_require_result(joints.createInput(one, two, geometry), 'As-built joint input')
        method = getattr(inp, 'setAs' + mode.capitalize() + 'JointMotion')
        args = [] if mode == 'rigid' else [getattr(adsk.fusion.JointDirections, data['axis'] + 'AxisJointDirection')]
        _cad_require_result(method(*args), 'Define joint motion')
        if 'limits' in data:
            # Validate against input defaults before add, but never rely on native limit transfer.
            plan = _assembly_limits_plan(ctx, inp.jointMotion, data['limits'])
            states = [(axis, state) for axis, (_, state) in zip(data['limits'], plan)]
        joint = _cad_require_result(joints.add(inp), 'Create as-built joint')
    ctx.created.append(ctx.ref(joint))
    joint.name = name
    if 'limits' in data:
        motion = joint.jointMotion
        try:
            _assembly_limits_apply(motion, [(getattr(motion, axis + 'Limits'), state) for axis, state in states])
        except Exception as error:
            raise RuntimeError('Created joint limit application failed: ' + json.dumps({
                'joint': ctx.ref(joint), 'atomic': False, 'createdJointRetained': True,
                'error': str(error)})) from error
    result = _assembly_joint(ctx, {'joint': ctx.ref(joint)}, 'inspect')
    if 'limits' in data and any(result['limits'][axis][prop] != value
                              for axis, state in states for prop, value in state.items()):
        raise RuntimeError('Created joint limits differ from input: ' + json.dumps({
            'joint': ctx.ref(joint), 'limits': result['limits'], 'atomic': False,
            'rollback': {'restored': False, 'errors': ['Created joint retained; inspect before continuing']}}))
    result.update(type=mode, asBuilt=custom_axis is None)
    if custom_axis is not None:
        result['directionEntity'] = [helpers_one, helpers_two]
    if 'schemaVersion' not in data and custom_axis is None and '+' not in one.fullPathName and '+' not in two.fullPathName:
        return result
    result['frameDiagnostics'] = _datum_joint_frame(ctx, {'joint': ctx.ref(joint)})
    result = _datum_contract(ctx, 'joint.' + mode, result, 'nativeReference', frame='root',
                             limitations=['As-built joint preserves current pose; motion limits are evaluated snapshots.' if custom_axis is None else
                                          'Custom-axis joints use a full Joint: occurrenceTwo is moved to mate with occurrenceOne (pose is not preserved), and each joint origin is placed on the requested axis line.'])
    if requested_axis is not None:
        # Read the motion axis back from the CREATED joint (never from the input,
        # where it is null). Fusion has no supported way to orient a point-based
        # AsBuiltJoint origin, so a full Joint with Z-axis-pinned JointOrigins is
        # used instead; still verify rotationAxisVector/slideDirectionVector after
        # create and treat signedDot < 1 as a fail.
        result.update(posePreserved=False,
                      warnings=result.get('warnings', []) + [
                          'Custom-axis joints are full Joints: occurrenceTwo is repositioned to mate with occurrenceOne (pose is not preserved).'])
        actual_axis = result['frameDiagnostics']['motionAxes'].get('slideDirectionVector' if mode == 'slider' else 'rotationAxisVector')
        dot = sum(a*b for a, b in zip(requested_axis, actual_axis)) if actual_axis is not None else None
        result['directionDiagnostics'] = {'requestedRoot': requested_axis, 'actualRoot': actual_axis, 'signedDot': dot}
        if dot is None:
            result.update(status='unknown',
                          warnings=result.get('warnings', []) + ['Native motion axis is unavailable; sign has not been verified.'])
            result['provenance']['nativeAcceptance'] = 'unverified'
        elif dot < 1 - 1e-8:
            result.update(success=False, status='fail',
                          warnings=result.get('warnings', []) + ['Created joint axis/sign differs from the requested datum axis; joint retained for inspection.'])
            result['provenance']['nativeAcceptance'] = 'failed'
    return result


def _assembly_misc(ctx, data, mode):
    if mode == 'parts':
        _cad_fields(data)
        rows = []
        for component in _cad_items(ctx.design.allComponents):
            occurrences = [o for o in _cad_items(ctx.root.allOccurrences) if o.component == component]
            if occurrences:
                rows.append({'component': ctx.ref(component), 'quantity': len(occurrences),
                    'occurrences': [ctx.ref(o) for o in occurrences], 'bodyCount': component.bRepBodies.count})
                imported = _di_get(component, 'item') if '_di_get' in globals() else None
                if imported:
                    rows[-1]['catalog'] = imported
        return {'parts': rows, 'scope': 'all occurrence paths, including subassemblies; root excluded; not a manufacturing BOM'}
    if mode in ('ground', 'unground'):
        _cad_fields(data, ('occurrence',))
        occurrence = _assembly_top(ctx, data['occurrence'])
        _assembly_capture_ready(ctx)
        grounded = mode == 'ground'
        occurrence.isGrounded = grounded
        # Fusion defaults newly created occurrences to ground-to-parent
        # (isGroundToParent), not the legacy root grounding (isGrounded); placement
        # refuses both, so clear both to actually unground.
        if hasattr(occurrence, 'isGroundToParent'):
            occurrence.isGroundToParent = grounded
        return {'occurrence': ctx.ref(occurrence), 'grounded': occurrence.isGrounded}
    _cad_fields(data, ('occurrences',), ('includeChildren', 'name'))
    if not isinstance(data['occurrences'], list) or len(data['occurrences']) < 2:
        raise ValueError('At least two occurrences are required')
    occurrences = [_assembly_top(ctx, r) for r in data['occurrences']]
    if any(o == previous for i, o in enumerate(occurrences) for previous in occurrences[:i]):
        raise ValueError('Duplicate occurrences')
    if type(data.get('includeChildren', False)) is not bool:
        raise ValueError('includeChildren must be boolean')
    if 'name' in data:
        _assembly_name(data['name'])
    _assembly_capture_ready(ctx)
    group = _cad_require_result(ctx.root.rigidGroups.add(ctx.collection(occurrences), data.get('includeChildren', False)), 'Create rigid group')
    if 'name' in data:
        group.name = data['name']
    ctx.created.append(ctx.ref(group))
    return {'rigidGroup': ctx.ref(group)}


def _assembly_feature_plan(ctx, data):
    _cad_fields(data, ('feature',), ('name', 'parameters'))
    feature = ctx.resolve(data['feature'], 'feature')
    if 'name' in data:
        _assembly_name(data['name'])
    changes = data.get('parameters', {})
    if not isinstance(changes, dict) or not changes and 'name' not in data:
        raise ValueError('Specify name or a nonempty parameters object keyed by model parameter name')
    parameters = [p for p in _cad_items(ctx.design.allParameters) if getattr(p, 'createdBy', None) == feature]
    plan = []
    for name, expression in changes.items():
        parameter = _cad_unique([p for p in parameters if p.name == name], 'Feature parameter ' + name)
        ctx._expression(expression, parameter.unit, unitless=parameter.unit == '')
        plan.append((parameter, expression))
    return feature, plan


def _assembly_history(ctx, data, mode):
    if mode == 'dependencies':
        return ctx.call('param.dependencies', data)
    if mode in ('edit', 'preview'):
        feature, plan = _assembly_feature_plan(ctx, data)
        changes = [{'parameter': p.name, 'before': p.expression, 'after': expression} for p, expression in plan]
        if mode == 'edit':
            for parameter, expression in plan:
                parameter.expression = expression
            if 'name' in data:
                feature.name = data['name']
        return {'feature': ctx.describe(feature), 'parameters': changes, 'proposedName': data.get('name'),
                'applied': mode == 'edit', 'atomic': False, 'scope': 'feature name/model parameter expressions only; no geometry simulation or rebuild prediction'}
    if mode in ('inspect', 'suppress', 'unsuppress'):
        _cad_fields(data, ('feature',))
        feature = ctx.resolve(data['feature'], 'feature')
        if mode != 'inspect':
            if ctx.design.designType != adsk.fusion.DesignTypes.ParametricDesignType:
                raise ValueError('Feature suppression requires parametric history')
            feature.isSuppressed = mode == 'suppress'
        return {'feature': ctx.describe(feature), 'parameters': [
            {'name': p.name, 'expression': p.expression, 'unit': p.unit}
            for p in _cad_items(ctx.design.allParameters) if getattr(p, 'createdBy', None) == feature]}
    if mode == 'check':
        return _assembly_history_check(ctx, data)
    _cad_fields(data)
    if mode == 'list':
        return {'features': [ctx.describe(f) for f in _cad_items(ctx.component.features)]}
    if mode == 'recompute':
        _cad_require_result(ctx.design.computeAll(), 'Recompute design')
    return _assembly_history_check(ctx, {}, recomputed=mode == 'recompute')


def _assembly_history_group(ctx, path):
    if not isinstance(path, str) or not path:
        raise ValueError('scope.group requires a nonempty timeline path')
    parts = path.split('/')
    if any(not part.isdecimal() or str(int(part)) != part for part in parts):
        raise ValueError('scope.group path must contain canonical zero-based indexes')
    items = _cad_items(ctx.design.timeline)
    item = None
    for depth, part in enumerate(parts):
        index = int(part)
        if index >= len(items):
            raise ValueError('scope.group path index is out of range')
        item = items[index]
        if depth < len(parts) - 1:
            if getattr(item, 'isGroup', False) is not True:
                raise ValueError('scope.group path crosses a non-group timeline item')
            items = [item.item(i) for i in range(item.count)]
    if getattr(item, 'isGroup', False) is not True:
        raise ValueError('scope.group must identify a TimelineGroup')
    return item


def _assembly_history_check(ctx, data, recomputed=False):
    _cad_fields(data, optional=('scope', 'recursive', 'allowSuppressed'))
    recursive = data.get('recursive', True)
    if type(recursive) is not bool:
        raise ValueError('recursive must be boolean')
    scope = data.get('scope', 'root')
    owner = None
    if scope == 'root':
        items = _cad_items(ctx.design.timeline)
        scope_result = {'root': ctx.ref(ctx.root)}
    elif isinstance(scope, dict) and set(scope) == {'component'}:
        owner = ctx.resolve(scope['component'], 'component')
        items = _cad_items(ctx.design.timeline)
        scope_result = {'component': ctx.ref(owner)}
    elif isinstance(scope, dict) and set(scope) == {'group'}:
        group = _assembly_history_group(ctx, scope['group'])
        items = [group]
        scope_result = {'group': scope['group']}
    else:
        raise ValueError("scope must be 'root', {component:REF}, or {group:TIMELINE_PATH}")
    allowed_refs = data.get('allowSuppressed', [])
    if not isinstance(allowed_refs, list):
        raise ValueError('allowSuppressed must be an array of feature refs')
    allowed = [ctx.resolve(ref, 'feature') for ref in allowed_refs]
    rows = _measure_health(ctx, items, owner=owner, recursive=recursive, allow_suppressed=allowed)
    leaves = [row for row in rows if not row.get('isGroup') and not row.get('duplicate')]
    unvisited = sum(row.get('unvisitedChildren', 0) for row in rows)
    unknown_leaves = sum(not row.get('isGroup') and not row.get('duplicate') and
                         (row.get('state') == 'unknown' or owner is not None and row.get('ownerUnknown', False))
                         for row in rows)
    healthy = _measure_health_passed(rows, require_owner=owner is not None) and not unvisited
    status = 'unknown' if unvisited or unknown_leaves else ('pass' if healthy else 'fail')
    return {'timeline': rows, 'markerPosition': ctx.design.timeline.markerPosition,
            'recomputed': recomputed, 'healthy': healthy, 'status': status,
            'recursive': recursive, 'scope': scope_result,
            'allowSuppressed': [ctx.ref(entity) for entity in allowed],
            'coverage': {'visitedLeaves': len(leaves), 'unknownLeaves': unknown_leaves,
                         'unvisitedChildren': unvisited}}


def _assembly_handler(function, mode):
    def handler(ctx, data):
        return function(ctx, data, mode)
    return handler


for _family, _function, _modes in (
        ('component', _assembly_component, ('inspect', 'create', 'rename', 'reparent', 'from_bodies')),
        ('occurrence', _assembly_occurrence, ('add', 'duplicate', 'transform', 'align')),
        ('joint', _assembly_joint, ('rigid', 'revolute', 'slider', 'cylindrical', 'inspect', 'edit', 'drive', 'limits')),
        ('assembly', _assembly_misc, ('parts', 'ground', 'unground', 'rigid_group')),
        # feature.inspect/feature.edit are registered once by feature.py (GM09 v1)
        # with a payload-shape dispatch back to the legacy handlers below.
        ('feature', _assembly_history, ('list', 'suppress', 'unsuppress', 'dependencies')),
        ('history', _assembly_history, ('check', 'recompute')),
        ('change', _assembly_history, ('preview',))):
    CAD_HANDLERS.update({_family + '.' + mode: _assembly_handler(_function, mode) for mode in _modes})
