"""GM08: surface feature variants, native availability gates and measured continuity evidence.

SDK signatures verified against public Autodesk documentation (TrimFeatures/PatchFeatures/
StitchFeatures/ExtendFeatures/OffsetFeatures, Component.createOpenProfile/createBRepEdgeProfile).
Continuity evidence is only reported where an evaluator actually measures it; everything
else is explicit unknown. Requests that the installed SDK cannot perform are blocked,
never silently substituted. See docs/SURFACE.md.
"""
import json
import math
import re
import time

import adsk.core
import adsk.fusion

_SURFACE_LIMITS = [
    'Native acceptance pending; kernel feasibility is not proven by this contract.',
    'Continuity labels requested at creation are conditions, not measurements; surface.check measures seams separately.',
    'No automatic retry, rollback, styling inference or implicit solid substitution.',
]
_SURFACE_EXTEND_ENUM = {'natural': 'NaturalSurfaceExtendType',
                        'tangent': 'TangentSurfaceExtendType',
                        'perpendicular': 'PerpendicularSurfaceExtendType'}


def _surface_identity(ctx):
    ctx.assert_identity()
    return {'creationId': getattr(ctx.doc, 'creationId', None), 'name': ctx.doc.name}


def _surface_contract(ctx, operation, result, status='pass', readOnly=False, associativity=None, warnings=None, limitations=None, **extra):
    ctx.assert_identity()
    return dict(schemaVersion=1, operation=operation, status=status, success=status == 'pass',
                documentIdentity=_surface_identity(ctx),
                units={'length': 'cm', 'angle': 'rad', 'curvature': '1/cm'},
                frame={'space': 'component', 'component': ctx.ref(ctx.component)},
                associativity=result.pop('associativity', associativity or ('nativeExpression' if not readOnly else 'snapshot')),
                warnings=list(result.pop('warnings', warnings or [])),
                method='Public Fusion surface feature SDK with explicit availability gates (GM08)',
                limitations=_SURFACE_LIMITS + list(result.pop('limitations', limitations or [])),
                provenance={'requirement': 'GM08', 'source': 'docs/SURFACE.md'},
                affected=list(result.pop('affected', [])), **extra, **result)


def _surface_blocked(ctx, operation, reason):
    return _surface_contract(ctx, operation, {}, status='blocked', readOnly=True,
                             warnings=[reason],
                             limitations=['requestedRepresentation not available through the installed SDK; '
                                          'an explicit alternative must be chosen, none was silently substituted'])


def _surface_resolve_curves(ctx, refs):
    if not isinstance(refs, list) or not refs:
        raise ValueError('curves must be a nonempty reference array')
    curves = [ctx.resolve(ref) for ref in refs]
    for curve in curves:
        if not (adsk.fusion.SketchCurve.cast(curve) or adsk.fusion.BRepEdge.cast(curve)):
            raise ValueError('Open profiles require sketch curves or model edges')
        if getattr(curve, 'assemblyContext', None) is not None or _cad_owner(curve) != ctx.component:
            raise ValueError('Surface creation requires native input geometry in the selected component; cross-occurrence creation is unsupported')
    kinds = {_cad_type(curve) for curve in curves}
    if len(kinds) != 1:
        raise ValueError('Open profile curves must be homogeneous sketch curves or BRep edges')
    return curves


def _surface_open_profile(ctx, ref):
    _cad_fields(ref, ('kind', 'curves'), ())
    if ref['kind'] != 'openProfile':
        raise ValueError('Open profile descriptor kind must be openProfile')
    curves = _surface_resolve_curves(ctx, ref['curves'])
    collection = ctx.collection(curves)
    if adsk.fusion.SketchCurve.cast(curves[0]):
        profile = _cad_require_result(ctx.component.createOpenProfile(collection), 'Component.createOpenProfile')
    else:
        profile = _cad_require_result(ctx.component.createBRepEdgeProfile(collection), 'Component.createBRepEdgeProfile')
    return _cad_require_result(profile, 'Open profile result')


def _surface_model_preflight(ctx, data, mode):
    collections = {'loft': 'loftFeatures', 'sweep': 'sweepFeatures', 'revolve': 'revolveFeatures'}
    if not hasattr(ctx.component.features, collections[mode]):
        return _surface_blocked(ctx, 'model.' + mode, 'Native surface ' + mode + ' collection is not available in the installed SDK')
    if mode == 'loft':
        for condition in (data.get('endConditions') or {}).values():
            if condition.get('type') != 'free':
                return _surface_blocked(ctx, 'model.loft', 'LoftFeatureInput exposes no public end-condition API; '
                                        'direction/tangent/smooth conditions are blocked, free remains supported')
    return None


def _surface_loft_conditions(ctx, inp, data):
    for condition in (data.get('endConditions') or {}).values():
        if condition.get('type') != 'free':
            raise ValueError('Non-free loft end conditions are unavailable through the installed SDK')


def _surface_model_result(ctx, mode, data, feature, result):
    status = 'pass' if int(feature.healthState) == 0 else 'fail'
    warnings = [feature.errorOrWarningMessage] if feature.errorOrWarningMessage else []
    payload = dict(result)
    payload['affected'] = [result['feature']] + list(result['bodies'])
    return _surface_contract(ctx, 'model.' + mode, payload, status=status,
                             warnings=warnings, associativity='nativeExpression',
                             surfaceVariant=True, isSolid=False,
                             limitations=['Solid:false variants reuse the public model feature inputs with isSolid=False; '
                                          'open profiles use Component.createOpenProfile/createBRepEdgeProfile.',
                                          'Loft end conditions other than free are blocked (no public API).'])


def _surface_fields(data, required=(), optional=()):
    _cad_fields(data, required, ('schemaVersion', 'frame') + optional)
    if data.get('schemaVersion') != 1 or data.get('frame') != 'component':
        raise ValueError('GM08 surface commands require schemaVersion:1 and frame:component')
    if data.get('onExisting', 'error') != 'error':
        raise ValueError('onExisting supports error only')
    if data.get('representation', 'native') != 'native':
        raise ValueError('Only native representation is implemented; alternatives must be explicit and are not substituted')


def _surface_protected(ctx, data, operation):
    if not data.get('protected'):
        return None
    if operation in ('surface.stitch', 'surface.trim', 'surface.extend', 'surface.offset'):
        return _surface_blocked(ctx, operation, 'Protected zones have no native API on ' + operation +
                                '; explicit unchained selections are the supported alternative')
    return 'Protected zones are not applicable: ' + operation + ' does not modify existing geometry'


@_cad_scoped_step('surface.patch', native_only=True)
def _surface_patch(ctx, data):
    _surface_fields(data, ('boundary',), ('interior', 'continuity', 'weight', 'reverse', 'name', 'onExisting', 'protected'))
    if data.get('continuity', 'G0') != 'G0' or data.get('weight') or data.get('reverse'):
        return _surface_blocked(ctx, 'surface.patch', 'Boundary continuity conditions (G1/G2, weight, reverse) have no public PatchFeatureInput API')
    if 'interior' in data:
        if not hasattr(adsk.fusion, 'PatchFeatureInput') or not hasattr(adsk.fusion.PatchFeatureInput, 'interiorProfile'):
            return _surface_blocked(ctx, 'surface.patch', 'Interior curve/point guidance is not exposed by the installed PatchFeatureInput')
    protected = _surface_protected(ctx, data, 'surface.patch')
    boundary = data['boundary']
    if isinstance(boundary, dict) and (boundary.get('kind') == 'path' or 'curves' in boundary):
        boundary = _model_path(ctx, boundary)
    else:
        boundary = ctx.resolve(boundary, 'profile')
    features = ctx.component.features
    if not hasattr(features, 'patchFeatures'):
        return _surface_blocked(ctx, 'surface.patch', 'patchFeatures is not available in the installed SDK')
    inp = _model_ok(features.patchFeatures.createInput(boundary, adsk.fusion.FeatureOperations.NewBodyFeatureOperation), 'PatchFeatures.createInput')
    if 'interior' in data and hasattr(inp, 'interiorProfile'):
        interior = data['interior']
        if isinstance(interior, list):
            inp.interiorProfile = ctx.collection([ctx.resolve(ref) for ref in interior])
        elif isinstance(interior, dict):
            inp.interiorProfile = _model_path(ctx, interior)
        else:
            inp.interiorProfile = ctx.resolve(interior)
    feature = _model_ok(features.patchFeatures.add(inp), 'surface.patch')
    _model_created(ctx, feature, data.get('name'))
    result = {'feature': ctx.ref(feature), 'bodies': [ctx.ref(body) for body in _model_items(feature.bodies)],
              'healthState': int(feature.healthState), 'message': feature.errorOrWarningMessage,
              'warnings': [protected] if isinstance(protected, str) else [],
              'limitations': ['Patch boundary must already be closed; the SDK may chain a single seed curve automatically.']}
    return _surface_contract(ctx, 'surface.patch', result, status='pass' if int(feature.healthState) == 0 else 'fail')


@_cad_scoped_step('surface.stitch', native_only=True)
def _surface_stitch(ctx, data):
    _surface_fields(data, ('bodies', 'tolerance'), ('expectSolid', 'name', 'onExisting', 'protected'))
    blocked = _surface_protected(ctx, data, 'surface.stitch')
    if blocked and isinstance(blocked, dict):
        return blocked
    if ctx.length(data['tolerance']) <= 0:
        raise ValueError('Stitch tolerance must be a positive length expression')
    features = ctx.component.features
    if not hasattr(features, 'stitchFeatures'):
        return _surface_blocked(ctx, 'surface.stitch', 'stitchFeatures is not available in the installed SDK')
    bodies = _model_entities(ctx, data['bodies'], kind='body')
    if any(body.isSolid for body in bodies):
        raise ValueError('Stitch requires open surface bodies')
    inp = _model_ok(features.stitchFeatures.createInput(ctx.collection(bodies), ctx.value(data['tolerance'])), 'StitchFeatures.createInput')
    feature = _model_ok(features.stitchFeatures.add(inp), 'surface.stitch')
    _model_created(ctx, feature, data.get('name'))
    actual = [body for body in _model_items(feature.bodies)]
    warnings = []
    status = 'pass'
    if data.get('expectSolid') is True and not all(body.isSolid for body in actual):
        status = 'fail'
        warnings.append('expectSolid:true but the stitch result is not entirely solid')
    elif data.get('expectSolid') is False and all(body.isSolid for body in actual):
        status = 'fail'
        warnings.append('expectSolid:false but the stitch result is entirely solid')
    free = [edge for body in actual for edge in _surface_free_edges(body)]
    return _surface_contract(ctx, 'surface.stitch', {'feature': ctx.ref(feature), 'bodies': [ctx.ref(body) for body in actual],
        'freeEdges': [ctx.ref(edge) for edge in free], 'healthState': int(feature.healthState),
        'message': feature.errorOrWarningMessage, 'warnings': warnings}, status=status)


def _surface_trim_cells(inp):
    cells = _cad_items(inp.bRepCells)
    return [{'index': i, 'selected': bool(getattr(cell, 'isSelected', False))} for i, cell in enumerate(cells)]


@_cad_scoped_step('surface.trim', native_only=True)
def _surface_trim(ctx, data):
    _surface_fields(data, ('tool', 'mode'), ('plan', 'removeCells', 'name', 'onExisting', 'protected'))
    blocked = _surface_protected(ctx, data, 'surface.trim')
    if blocked and isinstance(blocked, dict):
        return blocked
    features = ctx.component.features
    if not hasattr(features, 'trimFeatures'):
        return _surface_blocked(ctx, 'surface.trim', 'trimFeatures is not available in the installed SDK')
    tool = ctx.resolve(data['tool'])
    if data['mode'] == 'plan':
        if 'plan' in data or 'removeCells' in data:
            raise ValueError('Plan mode cannot select cells')
        inp = _model_ok(features.trimFeatures.createInput(tool), 'TrimFeatures.createInput')
        plan = {'plan': {'schemaVersion': 1, 'operation': 'surface.trim', 'documentIdentity': _surface_identity(ctx),
                         'tool': ctx.ref(tool), 'cells': _surface_trim_cells(inp), 'cellCount': inp.bRepCells.count}}
        try:
            _model_ok(inp.cancel(), 'TrimFeatureInput.cancel')
        except Exception as primary:
            raise RuntimeError('Trim plan could not be cancelled; the native trim transaction may be left open: ' + str(primary))
        plan['warnings'] = ['Planning started a native partial compute and cancelled it; the operation is not read-only.']
        return _surface_contract(ctx, 'surface.trim', plan, status='pass', associativity='snapshot')
    if not data.get('plan') or not isinstance(data['plan'], dict):
        raise ValueError('Apply requires a reviewed plan from trim plan mode')
    plan = data['plan']
    if plan.get('schemaVersion') != 1 or plan.get('operation') != 'surface.trim' or plan.get('documentIdentity') != _surface_identity(ctx):
        raise ValueError('Plan schema or document identity mismatch; replan before applying')
    if ctx.resolve(plan.get('tool')) != tool:
        raise ValueError('Plan belongs to a different tool')
    remove = data.get('removeCells')
    if not isinstance(remove, list) or not remove or any(not isinstance(i, int) or i < 0 for i in remove) or len(set(remove)) != len(remove):
        raise ValueError('removeCells must be nonempty unique cell indexes')
    inp = _model_ok(features.trimFeatures.createInput(tool), 'TrimFeatures.createInput')
    cells = _cad_items(inp.bRepCells)
    if len(cells) != plan.get('cellCount'):
        _model_ok(inp.cancel(), 'TrimFeatureInput.cancel')
        raise ValueError('Cell count changed since the plan was made; replan before applying')
    if any(i >= len(cells) for i in remove):
        _model_ok(inp.cancel(), 'TrimFeatureInput.cancel')
        raise ValueError('removeCells contains an index outside the planned cells')
    for index in remove:
        cells[index].isSelected = True
    feature = _model_ok(features.trimFeatures.add(inp), 'surface.trim')
    _model_created(ctx, feature, data.get('name'))
    return _surface_contract(ctx, 'surface.trim', {'feature': ctx.ref(feature), 'before': plan['cells'],
        'removedCells': remove, 'bodies': [ctx.ref(body) for body in _model_items(feature.bodies)],
        'healthState': int(feature.healthState), 'message': feature.errorOrWarningMessage},
        status='pass' if int(feature.healthState) == 0 else 'fail',
        limitations=['Cell identity is positional per plan; replan after any geometry change.'])


@_cad_scoped_step('surface.extend', native_only=True)
def _surface_extend(ctx, data):
    _surface_fields(data, ('edges', 'distance'), ('type', 'tangentChain', 'name', 'onExisting', 'protected'))
    blocked = _surface_protected(ctx, data, 'surface.extend')
    if blocked and isinstance(blocked, dict):
        return blocked
    extend_type = data.get('type', 'natural')
    if extend_type not in _SURFACE_EXTEND_ENUM:
        raise ValueError('Extend type must be natural, tangent or perpendicular')
    distance = ctx.length(data['distance'])
    if extend_type in ('natural', 'tangent') and distance <= 0:
        raise ValueError('Natural and tangent extend require a positive distance')
    edges = _model_entities(ctx, data['edges'], kind='edge')
    owners = {id(edge.body) for edge in edges}
    if len(owners) != 1:
        raise ValueError('Extend edges must all come from one open body')
    body = edges[0].body
    if body.isSolid:
        raise ValueError('Extend requires outer edges of an open surface body')
    if any(edge.faces.count != 1 for edge in edges):
        raise ValueError('Only outer (single-face) edges of an open body can be extended')
    features = ctx.component.features
    if not hasattr(features, 'extendFeatures'):
        return _surface_blocked(ctx, 'surface.extend', 'extendFeatures is not available in the installed SDK')
    enum = getattr(adsk.fusion.SurfaceExtendTypes, _SURFACE_EXTEND_ENUM[extend_type])
    inp = _model_ok(features.extendFeatures.createInput(ctx.collection(edges), ctx.value(data['distance']), enum,
        data.get('tangentChain', False)), 'ExtendFeatures.createInput')
    feature = _model_ok(features.extendFeatures.add(inp), 'surface.extend')
    _model_created(ctx, feature, data.get('name'))
    return _surface_contract(ctx, 'surface.extend', {'feature': ctx.ref(feature), 'bodies': [ctx.ref(body) for body in _model_items(feature.bodies)],
        'healthState': int(feature.healthState), 'message': feature.errorOrWarningMessage},
        status='pass' if int(feature.healthState) == 0 else 'fail')


@_cad_scoped_step('surface.offset', native_only=True)
def _surface_offset(ctx, data):
    _surface_fields(data, ('faces', 'distance'), ('tangentChain', 'name', 'onExisting', 'protected'))
    blocked = _surface_protected(ctx, data, 'surface.offset')
    if blocked and isinstance(blocked, dict):
        return blocked
    ctx.length(data['distance'])
    faces = _model_entities(ctx, data['faces'], kind='face')
    features = ctx.component.features
    if not hasattr(features, 'offsetFeatures'):
        return _surface_blocked(ctx, 'surface.offset', 'offsetFeatures is not available in the installed SDK')
    inp = _model_ok(features.offsetFeatures.createInput(ctx.collection(faces), ctx.value(data['distance']),
        adsk.fusion.FeatureOperations.NewBodyFeatureOperation, data.get('tangentChain', False)), 'OffsetFeatures.createInput')
    feature = _model_ok(features.offsetFeatures.add(inp), 'surface.offset')
    _model_created(ctx, feature, data.get('name'))
    return _surface_contract(ctx, 'surface.offset', {'feature': ctx.ref(feature), 'bodies': [ctx.ref(body) for body in _model_items(feature.bodies)],
        'healthState': int(feature.healthState), 'message': feature.errorOrWarningMessage},
        status='pass' if int(feature.healthState) == 0 else 'fail',
        limitations=['Signed distance follows the face normal; zero copies. The source body is untouched.'])


def _surface_free_edges(body):
    return [edge for edge in _model_items(body.edges) if edge.faces.count == 1]


_CURVATURE_UNIT_TO_1CM = {'1/cm': 1.0, '1/mm': 10.0, '1/m': 0.01, '1/in': 1.0 / 2.54, '1/ft': 1.0 / 30.48}


def _surface_curvature_tolerance(expression):
    """Curvature is inverse length; tolerance expressions are parsed locally into
    internal 1/cm units because UnitsManager has no verified inverse-length spec."""
    if not isinstance(expression, str) or not expression.strip():
        raise ValueError('curvatureTolerance must be a nonempty string')
    match = re.fullmatch(r'\s*(\d+(?:\.\d*)?(?:[eE][+-]?\d+)?)\s*(1/cm|1/mm|1/m|1/in|1/ft)\s*', expression)
    if not match:
        raise ValueError('curvatureTolerance must be a nonnegative number with an inverse-length unit (1/cm, 1/mm, 1/m, 1/in, 1/ft)')
    return float(match.group(1)) * _CURVATURE_UNIT_TO_1CM[match.group(2)]


def _surface_check_budget(data):
    samples = data.get('samples', 17)
    if not isinstance(samples, int) or not 2 <= samples <= 1001:
        raise ValueError('samples must be an integer in 2..1001')
    max_items = data.get('maxItems', 1000)
    budget = data.get('budgetMs', 10000)
    if not isinstance(max_items, int) or not 1 <= max_items <= 10000 or not isinstance(budget, int) or not 1 <= budget <= 120000:
        raise ValueError('Invalid check budget')
    return samples, max_items, time.monotonic() + budget / 1000


def _surface_seam_measure(ctx, edge_a, face_a, edge_b, face_b, reverse, samples, tolerance, angle_tolerance, curvature_tolerance, deadline):
    evaluator_a, evaluator_b = edge_a.geometry.evaluator, edge_b.geometry.evaluator
    surface_a, surface_b = face_a.geometry.evaluator, face_b.geometry.evaluator
    ok, start_a, end_a = evaluator_a.getParameterExtents()
    ok_b, start_b, end_b = evaluator_b.getParameterExtents()
    if not (ok and ok_b):
        raise ValueError('Seam edges have no bounded parameter range')
    gaps, angles, curvature = [], [], []
    unknown = []
    for i in range(samples):
        if time.monotonic() > deadline:
            raise ValueError('Seam evidence budget exceeded')
        t_a = start_a + (end_a - start_a) * i / (samples - 1)
        t_b = start_b + (end_b - start_b) * i / (samples - 1)
        ok_a, point_a = evaluator_a.getPointAtParameter(t_a)
        ok_b, point_b = evaluator_b.getPointAtParameter(t_b)
        if not (ok_a and ok_b):
            unknown.append({'sample': i, 'reason': 'getPointAtParameter failed'})
            continue
        gaps.append(math.hypot(*(a - b for a, b in zip(_cad_xyz(point_a), _cad_xyz(point_b)))))
        try:
            ok_pa, param_a = surface_a.getParameterAtPoint(point_a)
            ok_pb, param_b = surface_b.getParameterAtPoint(point_b)
            if not (ok_pa and ok_pb):
                raise ValueError('Surface getParameterAtPoint failed')
            ok_na, normal_a = surface_a.getNormalAtParameter(param_a)
            ok_nb, normal_b = surface_b.getNormalAtParameter(param_b)
            if not (ok_na and ok_nb):
                raise ValueError('Surface getNormalAtParameter failed')
            normal_a = _cad_xyz(normal_a)
            normal_b = _cad_xyz(normal_b)
            if reverse:
                normal_b = [-v for v in normal_b]
            dot = max(-1.0, min(1.0, sum(a * b for a, b in zip(normal_a, normal_b)) / (math.hypot(*normal_a) * math.hypot(*normal_b) or 1)))
            angles.append(math.degrees(math.acos(dot)))
            ok_ca, _, max_curv_a, min_curv_a = surface_a.getCurvature(param_a)
            ok_cb, _, max_curv_b, min_curv_b = surface_b.getCurvature(param_b)
            if not (ok_ca and ok_cb):
                raise ValueError('Surface getCurvature failed')
            curvature.append(_surface_g2_deviation(max_curv_a, min_curv_a, max_curv_b, min_curv_b))
        except Exception as exc:
            unknown.append({'sample': i, 'reason': str(exc)})
    def aggregate(values, limit):
        if len(values) == samples:
            return ('fail' if max(values) > limit else 'pass', max(values), limit)
        if not values:
            return ('unknown', None, limit)
        return ('unknown' if max(values) <= limit else 'fail', max(values), limit)
    gap_status, gap_max, _ = aggregate(gaps, tolerance)
    angle_status, angle_max, _ = aggregate(angles, angle_tolerance)
    curvature_status, curvature_max, _ = aggregate(curvature, curvature_tolerance)
    status = 'fail' if 'fail' in (gap_status, angle_status, curvature_status) else 'unknown' if 'unknown' in (gap_status, angle_status, curvature_status) else 'pass'
    return {'status': status, 'samples': samples,
            'G0': {'status': gap_status, 'gapCm': gap_max, 'toleranceCm': tolerance, 'samples': len(gaps)},
            'G1': {'status': angle_status, 'angleDeg': angle_max, 'toleranceDeg': angle_tolerance, 'samples': len(angles)},
            'G2': {'status': curvature_status, 'deviationInvCm': curvature_max, 'toleranceInvCm': curvature_tolerance, 'samples': len(curvature)},
            'unknown': unknown, 'method': 'Edge-parameter arc-length fractions; face evaluator normals and principal curvature values'}


def _surface_g2_deviation(max_curv_a, min_curv_a, max_curv_b, min_curv_b):
    """Numeric G2 deviation from principal curvature values (1/cm).

    Value-based, not direction-based: for planar/zero-curvature faces the
    principal direction vectors are undefined (zero), so a tensor comparison
    built from those directions would be non-finite. Comparing the principal
    curvature magnitudes stays numeric for planar-planar seams (both zero →
    deviation 0).
    """
    d1 = float(max_curv_a) - float(max_curv_b)
    d2 = float(min_curv_a) - float(min_curv_b)
    if not (math.isfinite(d1) and math.isfinite(d2)):
        raise ValueError('Surface getCurvature returned non-finite curvature values')
    return max(abs(d1), abs(d2))


def _surface_check(ctx, data):
    _surface_fields(data, ('bodies',), ('expectSolid', 'expectClosed', 'allowedOpenEdges', 'seams',
                                        'samples', 'tolerance', 'angleTolerance', 'curvatureTolerance', 'maxItems', 'budgetMs'))
    samples, max_items, deadline = _surface_check_budget(data)
    tolerance = ctx.length(data.get('tolerance', '0.001 mm'))
    angle_tolerance = ctx.angle(data.get('angleTolerance', '0.1 deg'))
    curvature_tolerance = _surface_curvature_tolerance(data.get('curvatureTolerance', '0.001 1/cm'))
    if not tolerance > 0 or not angle_tolerance > 0 or not curvature_tolerance >= 0:
        raise ValueError('Check tolerances require positive tolerances (curvature may be zero)')
    bodies = _model_entities(ctx, data['bodies'], kind='body')
    evidence, status, warnings = [], 'pass', []
    for body in bodies:
        free = _surface_free_edges(body)
        row = {'body': ctx.ref(body), 'isSolid': body.isSolid, 'edgeCount': body.edges.count,
               'freeEdges': [ctx.ref(edge) for edge in free[:max_items]], 'freeEdgeCount': len(free)}
        if data.get('expectSolid') is not None and body.isSolid != data['expectSolid']:
            row['status'] = 'fail'
            status = 'fail'
        else:
            row['status'] = 'pass'
        if data.get('expectClosed') is True:
            allowed = data.get('allowedOpenEdges', [])
            allowed_identity = {ref.get('token') if isinstance(ref, dict) and ref.get('token') else (ref if isinstance(ref, str) else None) for ref in allowed}
            open_edges = [edge for edge in free if edge.entityToken not in allowed_identity and edge.name not in allowed_identity]
            row['status'] = 'fail' if open_edges else row['status']
            status = 'fail' if open_edges else status
            if open_edges:
                warnings.append('expectClosed:true but %d free edges are not in allowedOpenEdges' % len(open_edges))
            unmatched = [identity for identity in allowed_identity if identity is not None and
                         identity not in {edge.entityToken for edge in free} and identity not in {edge.name for edge in free}]
            if unmatched:
                row['unmatchedAllowedEdges'] = len(unmatched)
        evidence.append(row)
        if len(free) > max_items:
            warnings.append('Free-edge report truncated to maxItems=%d' % max_items)
    seam_results = []
    for spec in data.get('seams', []):
        _cad_fields(spec, ('edgeA', 'faceA', 'edgeB', 'faceB'), ('reverse',))
        edge_a, edge_b = ctx.resolve(spec['edgeA'], 'edge'), ctx.resolve(spec['edgeB'], 'edge')
        face_a, face_b = ctx.resolve(spec['faceA'], 'face'), ctx.resolve(spec['faceB'], 'face')
        if not any(f == face_a for f in _model_items(edge_a.faces)) or not any(f == face_b for f in _model_items(edge_b.faces)):
            raise ValueError('Seam faces must be adjacent to their declared edges')
        measured = _surface_seam_measure(ctx, edge_a, face_a, edge_b, face_b, spec.get('reverse', False),
                                         samples, tolerance, angle_tolerance, curvature_tolerance, deadline)
        measured.update({'edgeA': ctx.ref(edge_a), 'edgeB': ctx.ref(edge_b), 'reverse': spec.get('reverse', False)})
        seam_results.append(measured)
        if measured['status'] == 'fail':
            status = 'fail'
        elif measured['status'] == 'unknown' and status == 'pass':
            status = 'unknown'
    return _surface_contract(ctx, 'surface.check', {'bodies': evidence, 'seams': seam_results, 'warnings': warnings},
                             status=status, readOnly=True, associativity='snapshot',
                             limitations=['Free edges are counted per inspected body, not across the whole design.',
                                          'Continuity evidence is sampled at equal arc-length fractions; pass does not certify continuous G1/G2.',
                                          'G2 compares principal curvature values (|k1_a - k1_b| and |k2_a - k2_b|); zero-curvature faces yield deviation 0.'])


CAD_HANDLERS.update({
    'surface.patch': _surface_patch, 'surface.stitch': _surface_stitch, 'surface.trim': _surface_trim,
    'surface.extend': _surface_extend, 'surface.offset': _surface_offset, 'surface.check': _surface_check,
})
