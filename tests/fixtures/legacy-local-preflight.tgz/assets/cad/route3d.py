"""GM25: 3D routing centerline, inspection, cut-list and motion states.

The centerline is numerically solved (uniform Catmull-Rom through waypoints when
requested, otherwise the polyline), so it interpolates all waypoints including
inflection points. Bend radius is measured as the local circumradius of three
consecutive samples (no unstable Frenet frame); transport frames use a declared
up vector projected onto the normal plane, stable through inflections. Route
state is explicitly declared set / numerically-solved / native-dependent. Cut
length follows the explicit interpretation ``L*allowanceFactor + 2*serviceTail``
(``1.1*L + 2*15 mm``) and never double-adds an already-modeled service tail.
"""
import math

import adsk.core
import adsk.fusion


# --- vector helpers (cm internal) -------------------------------------------------

def _point3(ctx, spec):
    p = ctx.point(spec)
    if isinstance(p, (list, tuple)):
        return [float(v) for v in p]
    return [float(p.x), float(p.y), float(p.z)]


def _vsub(a, b):
    return [a[0] - b[0], a[1] - b[1], a[2] - b[2]]


def _vadd(a, b):
    return [a[0] + b[0], a[1] + b[1], a[2] + b[2]]


def _vscale(a, s):
    return [x * s for x in a]


def _vdot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _vcross(a, b):
    return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]


def _vnorm(a):
    return math.sqrt(_vdot(a, a))


def _vunit(a):
    n = _vnorm(a)
    if n == 0 or not math.isfinite(n):
        raise ValueError('Degenerate zero-length tangent')
    return [x / n for x in a]


# --- centerline ------------------------------------------------------------------

def _catmull_rom(p0, p1, p2, p3, t):
    t2, t3 = t * t, t * t * t
    return [0.5 * ((2 * p1[i]) + (-p0[i] + p2[i]) * t + (2 * p0[i] - 5 * p1[i] + 4 * p2[i] - p3[i]) * t2 +
                   (-p0[i] + 3 * p1[i] - 3 * p2[i] + p3[i]) * t3) for i in range(3)]


def _sample_centerline(waypoints, samples_per_segment=20, interpolation='spline'):
    if interpolation == 'polyline':
        return [list(p) for p in waypoints]
    points = []
    for i in range(len(waypoints) - 1):
        p0 = waypoints[max(i - 1, 0)]
        p1 = waypoints[i]
        p2 = waypoints[i + 1]
        p3 = waypoints[min(i + 2, len(waypoints) - 1)]
        for s in range(samples_per_segment):
            points.append(_catmull_rom(p0, p1, p2, p3, s / samples_per_segment))
    points.append(list(waypoints[-1]))
    return points


def _arc_length(points):
    total = 0.0
    for a, b in zip(points, points[1:]):
        total += _vnorm(_vsub(b, a))
    return total


def _circumradius(a, b, c):
    ab = _vnorm(_vsub(b, a))
    bc = _vnorm(_vsub(c, b))
    ca = _vnorm(_vsub(a, c))
    area = 0.5 * _vnorm(_vcross(_vsub(b, a), _vsub(c, a)))
    if area == 0:
        return math.inf
    return (ab * bc * ca) / (4.0 * area)


def _bend_radii(points):
    radii = []
    for i in range(1, len(points) - 1):
        radii.append(_circumradius(points[i - 1], points[i], points[i + 1]))
    return radii


def _transport_frames(points, up):
    frames = []
    up = _vunit(up)
    for i, point in enumerate(points):
        if i < len(points) - 1:
            tangent = _vunit(_vsub(points[i + 1], points[i]))
        else:
            tangent = _vunit(_vsub(points[i], points[i - 1]))
        parallel = _vdot(tangent, up)
        if abs(parallel) > 1.0 - 1e-6:
            continue
        normal = _vunit(_vsub(up, _vscale(tangent, parallel)))
        binormal = _vcross(tangent, normal)
        frames.append({'position': point, 'tangent': tangent, 'normal': normal, 'binormal': binormal})
    return frames


def _segment_distance(a, b, c, d):
    ab = _vsub(b, a)
    cd = _vsub(d, c)
    r = _vsub(a, c)
    denom = _vdot(ab, ab) * _vdot(cd, cd) - _vdot(ab, cd) ** 2
    if denom > 1e-12:
        s = (_vdot(ab, cd) * _vdot(r, cd) - _vdot(cd, cd) * _vdot(r, ab)) / denom
        s = max(0.0, min(1.0, s))
    else:
        s = 0.0
    t = (_vdot(ab, cd) * s + _vdot(r, cd)) / _vdot(cd, cd) if _vdot(cd, cd) > 1e-12 else 0.0
    t = max(0.0, min(1.0, t))
    pa = _vadd(a, _vscale(ab, s))
    pc = _vadd(c, _vscale(cd, t))
    return _vnorm(_vsub(pa, pc))


def _point_at_station(points, station):
    walked = 0.0
    for i in range(len(points) - 1):
        segment = _vnorm(_vsub(points[i + 1], points[i]))
        if walked + segment >= station:
            t = 0.0 if segment == 0 else (station - walked) / segment
            return _vadd(points[i], _vscale(_vsub(points[i + 1], points[i]), t))
        walked += segment
    return list(points[-1])


# --- envelope --------------------------------------------------------------------

def _route_contract(ctx, operation, result, status='pass'):
    identity = None
    if hasattr(ctx, 'doc') and getattr(getattr(ctx, 'doc', None), 'name', None) is not None:
        identity = {'name': ctx.doc.name}
    component = None
    if hasattr(ctx, 'component') and hasattr(ctx, 'ref'):
        try:
            component = ctx.ref(ctx.component)
        except Exception:
            component = None
    merged = dict(schemaVersion=1, operation=operation, documentIdentity=identity,
                  units={'length': 'cm', 'angle': 'rad'},
                  frame={'space': 'component', 'component': component}, associativity='snapshot',
                  warnings=[], method='GM25 numerically-solved 3D centerline; local circumradius bend radius and up-projected transport frames',
                  limitations=['No unstable Frenet frame; inflection points are handled by local circumradius.', 'AWG does not define insulation diameter; callers declare the section/insulated envelope explicitly.',
                               'Endpoints alone do not uniquely define a flexible route; waypoints and constraints are explicit.'],
                  provenance={'requirement': 'GM25', 'source': 'docs/ROUTING.md'}, affected=[])
    merged.update(result)
    merged.setdefault('status', status)
    merged['success'] = merged['status'] == 'pass'
    return merged


def _route_geometry(ctx, data, samples_per_segment):
    if 'centerline' in data:
        centerline = [_point3(ctx, p) for p in data["centerline"]]
        interpolation = 'explicit'
    else:
        waypoints = data['waypoints']
        if not isinstance(waypoints, list) or len(waypoints) < 2:
            raise ValueError('waypoints requires at least two expression coordinate arrays')
        interpolation = data.get('interpolation', 'spline')
        if interpolation not in ('spline', 'polyline'):
            raise ValueError('interpolation must be spline or polyline')
        centerline = _sample_centerline([_point3(ctx, wp) for wp in waypoints],
                                        samples_per_segment, interpolation)
    if len(centerline) < 2:
        raise ValueError('centerline must have at least two points')
    up = _cad_direction(data.get('up', [0, 0, 1]))
    length = _arc_length(centerline)
    radii = _bend_radii(centerline)
    min_radius = min(radii) if radii else math.inf
    return centerline, interpolation, up, length, min_radius, radii


def _route_self_contact(centerline):
    best = math.inf
    n = len(centerline)
    for i in range(n - 1):
        for j in range(i + 2, n - 1):
            d = _segment_distance(centerline[i], centerline[i + 1], centerline[j], centerline[j + 1])
            if d < best:
                best = d
    return best


def _route_clearances(ctx, centerline, obstacles, minimum):
    rows = []
    for obstacle in obstacles:
        point = _point3(ctx, obstacle["point"])
        distance = min(_segment_distance(point, point, centerline[i], centerline[i + 1])
                       for i in range(len(centerline) - 1))
        rows.append({'obstacle': point, 'clearance': distance, 'violates': distance < minimum})
    return rows


def route_create3d(ctx, data):
    _cad_fields(data, ('waypoints',), ('interpolation', 'endTangents', 'up', 'bendConstraints',
                                       'twist', 'section', 'name', 'frame', 'minimumClearance',
                                       'obstacles', 'representation', 'normalSections', 'schemaVersion'))
    samples = data.get('schemaVersion', 1)
    if type(data.get('schemaVersion', 1)) is not int or data.get('schemaVersion', 1) != 1:
        raise ValueError('create3d requires schemaVersion 1')
    centerline, interpolation, up, length, min_radius, radii = _route_geometry(ctx, data, 20)
    frames = _transport_frames(centerline, up)
    self_clearance = _route_self_contact(centerline)
    obstacles = data.get('obstacles', [])
    if not isinstance(obstacles, list):
        raise ValueError('obstacles must be an array')
    minimum = ctx.length(data.get('minimumClearance', '0 mm'))
    clearances = _route_clearances(ctx, centerline, obstacles, minimum) if obstacles else []
    stations = [ctx.length(s.get('station', '0 mm')) for s in data.get('normalSections', [])]
    sections = [{'station': station, 'position': _point_at_station(centerline, station)}
                for station in stations]
    end_tangents = data.get('endTangents')
    tangent_report = None
    if end_tangents is not None:
        start = _cad_direction(end_tangents.get('start', centerline[1]))
        end = _cad_direction(end_tangents.get('end', centerline[-2]))
        tangent_report = {
            'start': start,
            'end': end,
            'computed': {
                'start': _vunit(_vsub(centerline[1], centerline[0])),
                'end': _vunit(_vsub(centerline[-1], centerline[-2])),
            },
        }
    state = 'set' if end_tangents is not None else 'numerically-solved'
    return _route_contract(ctx, 'route.create3d', {
        'centerline': centerline, 'interpolation': interpolation, 'arcLength': length,
        'minBendRadius': min_radius if math.isfinite(min_radius) else None,
        'normalSections': sections, 'frames': frames,
        'selfClearance': self_clearance if math.isfinite(self_clearance) else None,
        'clearances': clearances, 'endTangents': tangent_report, 'routeState': state,
        'state': state, 'twist': ctx.angle(data['twist']) if 'twist' in data else None})


def route_inspect(ctx, data):
    _cad_fields(data, (), ('waypoints', 'centerline', 'interpolation', 'up', 'minimumClearance',
                           'obstacles', 'normalSections', 'frame', 'schemaVersion'))
    if type(data.get('schemaVersion', 1)) is not int or data.get('schemaVersion', 1) != 1:
        raise ValueError('inspect requires schemaVersion 1')
    if 'waypoints' not in data and 'centerline' not in data:
        raise ValueError('inspect requires waypoints or an explicit centerline')
    centerline, interpolation, up, length, min_radius, radii = _route_geometry(ctx, data, 20)
    frames = _transport_frames(centerline, up)
    self_clearance = _route_self_contact(centerline)
    obstacles = data.get('obstacles', [])
    minimum = ctx.length(data.get('minimumClearance', '0 mm'))
    clearances = _route_clearances(ctx, centerline, obstacles, minimum) if obstacles else []
    stations = [ctx.length(s.get('station', '0 mm')) for s in data.get('normalSections', [])]
    sections = [{'station': station, 'position': _point_at_station(centerline, station)}
                for station in stations]
    return _route_contract(ctx, 'route.inspect', {
        'arcLength': length, 'minBendRadius': min_radius if math.isfinite(min_radius) else None,
        'bendRadii': radii, 'frames': frames,
        'selfClearance': self_clearance if math.isfinite(self_clearance) else None,
        'clearances': clearances, 'normalSections': sections, 'routeState': 'numerically-solved'})


def _to_mm(value_cm):
    return value_cm * 10.0


def route_cut_list(ctx, data):
    _cad_fields(data, ('length',), ('allowanceFactor', 'serviceTail', 'serviceTailModeled',
                                    'pieces', 'frame', 'schemaVersion'))
    if type(data.get('schemaVersion', 1)) is not int or data.get('schemaVersion', 1) != 1:
        raise ValueError('cut-list requires schemaVersion 1')
    length = ctx.length(data['length'])
    if length <= 0:
        raise ValueError('length must be positive')
    factor = float(data.get('allowanceFactor', 1.1))
    if not math.isfinite(factor) or factor < 1.0:
        raise ValueError('allowanceFactor must be finite and at least 1.0')
    tail = ctx.length(data.get('serviceTail', '15 mm'))
    if tail < 0:
        raise ValueError('serviceTail must be nonnegative')
    modeled = data.get('serviceTailModeled', False)
    if type(modeled) is not bool:
        raise ValueError('serviceTailModeled must be boolean')
    pieces = data.get('pieces', 1)
    if type(pieces) is not int or pieces < 1:
        raise ValueError('pieces must be a positive integer')
    tails = 0.0 if modeled else 2.0 * tail
    per_piece = (length * factor + tails) / pieces
    interpretation = 'cutLength = L * %.3g + %d * %g mm (L=%.6g mm neutral axis, serviceTailModeled=%s)' % (
        factor, 0 if modeled else 2, _to_mm(tail), _to_mm(length), modeled)
    if modeled:
        warnings = ['serviceTail is already modeled in length; it is not added again.']
    else:
        warnings = []
    return _route_contract(ctx, 'route.cut-list', {
        'length': _to_mm(length), 'allowanceFactor': factor, 'serviceTail': _to_mm(tail),
        'serviceTailModeled': modeled, 'pieces': pieces,
        'cutLengthPerPiece': _to_mm(per_piece), 'totalCutLength': _to_mm(per_piece * pieces),
        'interpretation': interpretation, 'warnings': warnings})


def _pose_required_radius(length, pan, tilt):
    sweep = abs(pan) + abs(tilt)
    if sweep < 1e-9:
        return math.inf
    return length / sweep


def route_motion_states(ctx, data):
    _cad_fields(data, ('length',), ('pan', 'tilt', 'minBendRadius', 'poses', 'state',
                                    'representation', 'frame', 'schemaVersion'))
    if type(data.get('schemaVersion', 1)) is not int or data.get('schemaVersion', 1) != 1:
        raise ValueError('motion-states requires schemaVersion 1')
    length = ctx.length(data['length'])
    if length <= 0:
        raise ValueError('length must be positive')
    min_radius = ctx.length(data['minBendRadius']) if 'minBendRadius' in data else None
    declared = data.get('state', 'numerically-solved')
    if declared not in ('set', 'numerically-solved', 'native-dependent'):
        raise ValueError('state must be set, numerically-solved or native-dependent')
    if 'poses' in data:
        poses = data['poses']
        if not isinstance(poses, list) or not poses:
            raise ValueError('poses must be a nonempty array')
    else:
        pan = data.get('pan')
        tilt = data.get('tilt')
        if not isinstance(pan, dict) or not isinstance(tilt, dict):
            raise ValueError('motion-states requires poses or pan/tilt range objects')
        pan_values = [ctx.angle(pan.get('min', '0 deg')), ctx.angle(pan.get('max', '0 deg'))]
        tilt_values = [ctx.angle(tilt.get('min', '0 deg')), ctx.angle(tilt.get('max', '0 deg'))]
        poses = [{'pan': p, 'tilt': t} for p in pan_values for t in tilt_values]
    rows = []
    for pose in poses:
        pan = ctx.angle(pose.get('pan', '0 deg')) if isinstance(pose.get('pan', '0 deg'), str) else float(pose.get('pan', 0))
        tilt = ctx.angle(pose.get('tilt', '0 deg')) if isinstance(pose.get('tilt', '0 deg'), str) else float(pose.get('tilt', 0))
        if 'bendRadius' in pose:
            radius = ctx.length(pose['bendRadius'])
            state = 'set'
        else:
            radius = _pose_required_radius(length, pan, tilt)
            state = 'native-dependent' if declared == 'native-dependent' else declared
        rows.append({'pan': pan, 'tilt': tilt, 'length': length, 'lengthPreserved': True,
                     'requiredBendRadius': radius if math.isfinite(radius) else None,
                     'fits': min_radius is None or radius >= min_radius,
                     'state': state})
    return _route_contract(ctx, 'route.motion-states', {
        'states': rows, 'length': length, 'lengthPreserved': all(r['lengthPreserved'] for r in rows),
        'declaredState': declared, 'minBendRadius': min_radius,
        'extremeCoverage': 'cartesian product of PAN and TILT extremes, not a synchronous diagonal'})


CAD_HANDLERS.update({
    'route.create3d': route_create3d,
    'route.inspect': route_inspect,
    'route.cut-list': route_cut_list,
    'route.motion-states': route_motion_states,
})
