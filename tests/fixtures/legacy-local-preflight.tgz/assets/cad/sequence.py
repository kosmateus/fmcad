"""GM27: assembly sequence, service path-checks, tool access and fixture access.

``assembly.sequence`` orders parts from a rigid dependency graph; flexible media
(wires/hoses) are recorded as disconnection prerequisites and are never
rigidized into assembly joints. ``service.path-check`` samples a swept
withdrawal in a declared plane so an exploded endpoint is not mistaken for a
feasible insertion path. ``tool.access`` sweeps a cylindrical tool envelope
(explicitly a simplification, not a full fingers/grip model) along an approach
axis to a fastener. ``fixture.access`` checks that a part can seat onto fixture
datums (pin/hole fit, datum coincidence, approach reach and prerequisites).
"""
import math
from collections import deque

import adsk.core
import adsk.fusion


# --- shared vector helpers (cm/rad internal) ---------------------------------------

def _point3(ctx, spec):
    p = ctx.point(spec)
    if isinstance(p, (list, tuple)):
        return [float(v) for v in p]
    return [float(p.x), float(p.y), float(p.z)]


def _vsub(a, b):
    return [a[0] - b[0], a[1] - b[1], a[2] - b[2]]


def _vadd(a, b):
    return [a[0] + b[0], a[1] + b[1], a[2] + b[2]]


def _vscale(a, s):
    return [x * s for x in a]


def _vdot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _vcross(a, b):
    return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]


def _vnorm(a):
    return math.sqrt(_vdot(a, a))


def _vunit(a):
    n = _vnorm(a)
    if n == 0 or not math.isfinite(n):
        raise ValueError('Direction cannot be zero or non-finite')
    return [x / n for x in a]


def _dir2(value):
    if not isinstance(value, (list, tuple)) or len(value) != 2 or any(
            isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x) for x in value):
        raise ValueError('direction must be two finite unitless numbers')
    n = math.hypot(*value)
    if n == 0:
        raise ValueError('direction cannot be zero')
    return [value[0] / n, value[1] / n]


def _outline2(ctx, spec):
    if not isinstance(spec, list) or len(spec) < 3:
        raise ValueError('outline requires at least three [x,y] points')
    return [[ctx.length(v[0]), ctx.length(v[1])] for v in spec]


def _seg_intersect(p1, p2, q1, q2):
    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    d1, d2 = cross(q1, q2, p1), cross(q1, q2, p2)
    d3, d4 = cross(p1, p2, q1), cross(p1, p2, q2)
    return ((d1 > 0 > d2) or (d1 < 0 < d2)) and ((d3 > 0 > d4) or (d3 < 0 < d4))


def _point_in_poly(p, poly):
    inside = False
    j = len(poly) - 1
    for i in range(len(poly)):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if ((yi > p[1]) != (yj > p[1])) and (p[0] < (xj - xi) * (p[1] - yi) / (yj - yi) + xi):
            inside = not inside
        j = i
    return inside


def _polys_overlap(a, b):
    for i in range(len(a)):
        for j in range(len(b)):
            if _seg_intersect(a[i], a[(i + 1) % len(a)], b[j], b[(j + 1) % len(b)]):
                return True
    return any(_point_in_poly(p, b) for p in a) or any(_point_in_poly(p, a) for p in b)


def _point_seg_dist(p, a, b):
    ab = [b[0] - a[0], b[1] - a[1]]
    ap = [p[0] - a[0], p[1] - a[1]]
    denom = ab[0] * ab[0] + ab[1] * ab[1]
    t = (ap[0] * ab[0] + ap[1] * ab[1]) / denom if denom else 0.0
    t = max(0.0, min(1.0, t))
    return math.hypot(p[0] - (a[0] + t * ab[0]), p[1] - (a[1] + t * ab[1]))


def _point_poly_dist(p, poly):
    inside = _point_in_poly(p, poly)
    d = min(_point_seg_dist(p, poly[i], poly[(i + 1) % len(poly)]) for i in range(len(poly)))
    return -d if inside else d


def _poly_dist(a, b):
    return min([_point_poly_dist(p, b) for p in a] + [_point_poly_dist(p, a) for p in b])


# --- envelope ---------------------------------------------------------------------

def _sequence_contract(ctx, operation, result, status='pass'):
    identity = None
    if hasattr(ctx, 'doc') and getattr(getattr(ctx, 'doc', None), 'name', None) is not None:
        identity = {'name': ctx.doc.name}
    component = None
    if hasattr(ctx, 'component') and hasattr(ctx, 'ref'):
        try:
            component = ctx.ref(ctx.component)
        except Exception:
            component = None
    merged = dict(schemaVersion=1, operation=operation, documentIdentity=identity,
                  units={'length': 'cm', 'angle': 'rad'},
                  frame={'space': 'component', 'component': component}, associativity='snapshot',
                  warnings=[], method='GM27 local assembly-sequence/service/tool/fixture geometry recipe',
                  limitations=['An exploded endpoint is not a feasible insertion path; swept access is sampled along the withdrawal and reported as bounds, never a continuous proof.',
                               'Flexible media (wires/hoses) are never rigidized into assembly joints; they are recorded as disconnection prerequisites only.',
                               'A cylindrical tool envelope is a simplification, not a full fingers/grip model.'],
                  provenance={'requirement': 'GM27', 'source': 'docs/ASSEMBLY_SEQUENCE.md'}, affected=[])
    merged.update(result)
    merged.setdefault('status', status)
    merged['success'] = merged['status'] == 'pass'
    return merged


# --- assembly.sequence ------------------------------------------------------------

def _require_schema(data):
    if type(data.get('schemaVersion', 1)) is not int or data.get('schemaVersion', 1) != 1:
        raise ValueError('schemaVersion 1 is required')
    return 1


def assembly_sequence(ctx, data):
    _cad_fields(data, ('parts',), ('dependencies', 'removedParts', 'disconnectedMedia',
                                   'serviceStates', 'phases', 'frame', 'schemaVersion'))
    _require_schema(data)
    parts = data['parts']
    if not isinstance(parts, list) or not parts or any(not isinstance(p, str) for p in parts):
        raise ValueError('parts must be a nonempty array of names')
    if len(set(parts)) != len(parts):
        raise ValueError('part names must be unique')

    dependencies = data.get('dependencies', [])
    if not isinstance(dependencies, list):
        raise ValueError('dependencies must be an array of [prerequisite, dependent] pairs')
    edges = []
    for dep in dependencies:
        if not isinstance(dep, (list, tuple)) or len(dep) != 2:
            raise ValueError('dependencies must be [prerequisite, dependent] pairs')
        a, b = dep[0], dep[1]
        if a not in parts or b not in parts:
            raise ValueError('dependency references an unknown part: %s -> %s' % (a, b))
        edges.append((a, b))

    media = data.get('disconnectedMedia', [])
    if not isinstance(media, list):
        raise ValueError('disconnectedMedia must be an array')
    media_names = set()
    for m in media:
        if not isinstance(m, dict) or 'name' not in m or 'connects' not in m:
            raise ValueError('disconnectedMedia entries require name and connects')
        if m['name'] in media_names:
            raise ValueError('duplicate media name: ' + m['name'])
        media_names.add(m['name'])
        connects = m['connects']
        if not isinstance(connects, (list, tuple)) or len(connects) != 2 or any(c not in parts for c in connects):
            raise ValueError('media connects must reference two known parts')

    service = data.get('serviceStates', [])
    if not isinstance(service, list):
        raise ValueError('serviceStates must be an array')
    service_by_part = {}
    for s in service:
        if not isinstance(s, dict) or 'part' not in s or 'requires' not in s:
            raise ValueError('serviceStates entries require part and requires')
        if s['part'] not in parts:
            raise ValueError('serviceStates references unknown part: ' + s['part'])
        if s['part'] in service_by_part:
            raise ValueError('duplicate serviceStates for part: ' + s['part'])
        if not isinstance(s['requires'], list) or not s['requires']:
            raise ValueError('serviceStates requires must be a nonempty array')
        service_by_part[s['part']] = s['requires']

    phases = data.get('phases', [])
    if not isinstance(phases, list):
        raise ValueError('phases must be an array')
    phase_assign = {}
    for ph in phases:
        if not isinstance(ph, dict) or 'name' not in ph or 'parts' not in ph:
            raise ValueError('phases entries require name and parts')
        for p in ph['parts']:
            if p not in parts:
                raise ValueError('phase references unknown part: ' + p)
            if p in phase_assign:
                raise ValueError('part assigned to more than one phase: ' + p)
            phase_assign[p] = ph['name']

    adj = {p: [] for p in parts}
    indeg = {p: 0 for p in parts}
    for a, b in edges:
        adj[a].append(b)
        indeg[b] += 1

    queue = deque([p for p in parts if indeg[p] == 0])
    order = []
    while queue:
        p = queue.popleft()
        order.append(p)
        for nxt in adj[p]:
            indeg[nxt] -= 1
            if indeg[nxt] == 0:
                queue.append(nxt)

    cycles = sorted(p for p in parts if indeg[p] > 0)
    ok = not cycles

    blockers = {p: [a for a, b in edges if b == p] for p in parts}
    disassembly = list(reversed(order)) if ok else list(order)

    removed = data.get('removedParts', [])
    if not isinstance(removed, list) or any(p not in parts for p in removed):
        raise ValueError('removedParts must reference known parts')
    removals = []
    for p in removed:
        disconnections = [m['name'] for m in media if p in m['connects']]
        row = {'part': p,
               'removeBlockers': [b for a, b in edges if a == p],
               'disconnections': disconnections,
               'servicePrerequisites': service_by_part.get(p, [])}
        removals.append(row)
    removals.sort(key=lambda r: disassembly.index(r['part']) if r['part'] in disassembly else 0)

    return _sequence_contract(ctx, 'assembly.sequence', {
        'order': order, 'disassemblyOrder': disassembly, 'blockers': blockers,
        'removals': removals, 'cycles': cycles, 'mediaRigidized': False,
        'mediaDisconnections': [{'name': m['name'], 'connects': list(m['connects']),
                                 'rigid': bool(m.get('rigid', False))} for m in media],
        'phaseAssignments': phase_assign, 'unphased': [p for p in parts if p not in phase_assign]},
        status='pass' if ok else 'fail')


# --- service.path-check -----------------------------------------------------------

def service_path_check(ctx, data):
    _cad_fields(data, ('part', 'direction', 'distance'), ('obstacles', 'minimumClearance',
                                                          'samples', 'frame', 'schemaVersion'))
    _require_schema(data)
    part = data['part']
    if not isinstance(part, dict) or 'outline' not in part:
        raise ValueError('part requires an outline')
    outline = _outline2(ctx, part['outline'])
    direction = _dir2(data['direction'])
    distance = ctx.length(data['distance'])
    if distance <= 0:
        raise ValueError('distance must be positive')

    minimum = ctx.length(data.get('minimumClearance', '0 mm'))
    if minimum < 0:
        raise ValueError('minimumClearance must be nonnegative')
    samples = data.get('samples', 20)
    if type(samples) is not int or samples < 1:
        raise ValueError('samples must be a positive integer')

    obstacles = data.get('obstacles', [])
    if not isinstance(obstacles, list):
        raise ValueError('obstacles must be an array')
    parsed = []
    for ob in obstacles:
        if not isinstance(ob, dict) or 'outline' not in ob:
            raise ValueError('obstacles require an outline')
        poly = _outline2(ctx, ob['outline'])
        span = ob.get('span', ['0 mm', data['distance']])
        if not isinstance(span, (list, tuple)) or len(span) != 2:
            raise ValueError('obstacle span must be [start, end]')
        parsed.append({'name': ob.get('name'), 'outline': poly,
                       'span': [ctx.length(span[0]), ctx.length(span[1])]})

    clearances = []
    blockers = set()
    for i in range(samples + 1):
        station = distance * i / samples
        offset = [direction[0] * station, direction[1] * station]
        moved = [[p[0] + offset[0], p[1] + offset[1]] for p in outline]
        best = None
        for ob in parsed:
            if not (ob['span'][0] <= station <= ob['span'][1]):
                continue
            d = _poly_dist(moved, ob['outline'])
            if best is None or d < best:
                best = d
            if d < minimum:
                blockers.add(ob['name'] or 'obstacle-%d' % parsed.index(ob))
        clearances.append(best)

    active = [c for c in clearances if c is not None]
    min_clearance = min(active) if active else None
    feasible = (min_clearance is None or min_clearance >= minimum) and not blockers

    xs = [p[0] for p in outline] + [p[0] + direction[0] * distance for p in outline]
    ys = [p[1] for p in outline] + [p[1] + direction[1] * distance for p in outline]

    return _sequence_contract(ctx, 'service.path-check', {
        'feasible': feasible, 'blocked': not feasible,
        'minClearance': min_clearance, 'clearanceAtStations': clearances,
        'blockers': sorted(blockers), 'samples': samples,
        'sweptBounds': {'min': [min(xs), min(ys)], 'max': [max(xs), max(ys)]},
        'withdrawalDistance': distance},
        status='pass' if feasible else 'fail')


# --- tool.access ------------------------------------------------------------------

def _point_to_box_dist(p, minv, maxv):
    q = [max(minv[i], min(maxv[i], p[i])) for i in range(3)]
    return _vnorm(_vsub(p, q))


def _parse_obstacle_distance(ctx, obstacle, point):
    if not isinstance(obstacle, dict):
        raise ValueError('obstacles must be objects')
    if 'point' in obstacle:
        center = _point3(ctx, obstacle['point'])
        radius = ctx.length(obstacle.get('radius', '0 mm'))
        return _vnorm(_vsub(point, center)) - radius
    if 'box' in obstacle:
        box = obstacle['box']
        if not isinstance(box, dict) or 'min' not in box or 'max' not in box:
            raise ValueError('box obstacle requires min and max')
        return _point_to_box_dist(point, _point3(ctx, box['min']), _point3(ctx, box['max']))
    raise ValueError('obstacles accept point/radius or box')


def tool_access(ctx, data):
    _cad_fields(data, ('tool', 'target', 'entry'), ('obstacles', 'minimumClearance',
                                                    'samples', 'frame', 'schemaVersion'))
    _require_schema(data)
    tool = data['tool']
    if not isinstance(tool, dict) or 'diameter' not in tool or 'length' not in tool:
        raise ValueError('tool requires diameter and length')
    diameter = ctx.length(tool['diameter'])
    length = ctx.length(tool['length'])
    if diameter <= 0 or length <= 0:
        raise ValueError('tool diameter and length must be positive')

    target = data['target']
    if not isinstance(target, dict) or 'origin' not in target or 'axis' not in target:
        raise ValueError('target requires origin and axis')
    target_origin = _point3(ctx, target['origin'])
    target_axis = _vunit(_cad_direction(target['axis']))
    engagement_depth = ctx.length(target.get('engagementDepth', '0 mm'))
    if engagement_depth < 0:
        raise ValueError('engagementDepth must be nonnegative')

    entry = data['entry']
    if not isinstance(entry, dict) or 'origin' not in entry or 'direction' not in entry:
        raise ValueError('entry requires origin and direction')
    entry_origin = _point3(ctx, entry['origin'])
    entry_dir = _vunit(_cad_direction(entry['direction']))

    minimum = ctx.length(data.get('minimumClearance', '0 mm'))
    if minimum < 0:
        raise ValueError('minimumClearance must be nonnegative')
    samples = data.get('samples', 20)
    if type(samples) is not int or samples < 1:
        raise ValueError('samples must be a positive integer')

    engage_point = _vadd(target_origin, _vscale(target_axis, engagement_depth))
    to_target = _vsub(engage_point, entry_origin)
    reach = _vnorm(to_target)
    axis_aligned = reach > 0 and _vdot(entry_dir, _vunit(to_target)) > 1 - 1e-9
    length_sufficient = reach <= length
    tool_radius = diameter / 2.0

    obstacles = data.get('obstacles', [])
    if not isinstance(obstacles, list):
        raise ValueError('obstacles must be an array')

    obstacle_rows = []
    blockers = []
    min_clearance = None
    for ob in obstacles:
        ob_min = None
        for i in range(samples + 1):
            t = reach * i / samples if reach > 0 else 0.0
            point = _vadd(entry_origin, _vscale(entry_dir, t))
            clearance = _parse_obstacle_distance(ctx, ob, point) - tool_radius
            if ob_min is None or clearance < ob_min:
                ob_min = clearance
        obstacle_rows.append({'obstacle': ob.get('name', 'unnamed'), 'minClearance': ob_min,
                              'blocks': ob_min < minimum})
        if ob_min < minimum:
            blockers.append(ob.get('name', 'unnamed'))
        if min_clearance is None or ob_min < min_clearance:
            min_clearance = ob_min

    reachable = axis_aligned and length_sufficient and not blockers
    return _sequence_contract(ctx, 'tool.access', {
        'reachable': reachable, 'reach': reach, 'toolDiameter': diameter, 'toolLength': length,
        'lengthSufficient': length_sufficient, 'axisAligned': axis_aligned,
        'engagementDepth': engagement_depth, 'clearances': obstacle_rows,
        'minClearance': min_clearance, 'blockers': blockers},
        status='pass' if reachable else 'fail')


# --- fixture.access ---------------------------------------------------------------

def _feature(ctx, spec):
    if not isinstance(spec, dict) or 'name' not in spec or 'kind' not in spec:
        raise ValueError('features require name and kind')
    kind = spec['kind']
    if kind not in ('pin', 'hole', 'datum'):
        raise ValueError('feature kind must be pin, hole or datum')
    origin = _point3(ctx, spec['origin'])
    direction = _vunit(_cad_direction(spec['direction'])) if 'direction' in spec else None
    diameter = ctx.length(spec['diameter']) if 'diameter' in spec else None
    if kind in ('pin', 'hole') and (diameter is None or diameter <= 0):
        raise ValueError(kind + ' features require a positive diameter')
    if kind == 'datum' and direction is None:
        raise ValueError('datum features require a direction')
    return {'name': spec['name'], 'kind': kind, 'origin': origin, 'direction': direction,
            'diameter': diameter}


def fixture_access(ctx, data):
    _cad_fields(data, ('part', 'fixture', 'pairs'), ('tolerance', 'angleTolerance',
                                                     'clearance', 'frame', 'schemaVersion'))
    _require_schema(data)
    part = data['part']
    fixture = data['fixture']
    if not isinstance(part, dict) or 'features' not in part:
        raise ValueError('part requires features')
    if not isinstance(fixture, dict) or 'features' not in fixture:
        raise ValueError('fixture requires features')
    approach = _vunit(_cad_direction(fixture.get('approach', {}).get('direction', [0, 0, 1])))

    part_features = {f['name']: _feature(ctx, f) for f in part['features']}
    fixture_features = {f['name']: _feature(ctx, f) for f in fixture['features']}

    pairs = data['pairs']
    if not isinstance(pairs, list) or not pairs:
        raise ValueError('pairs must be a nonempty array of [partFeature, fixtureFeature]')

    tolerance = ctx.length(data.get('tolerance', '0.01 mm'))
    angle_tolerance = ctx.angle(data.get('angleTolerance', '1 deg'))
    clearance = ctx.length(data.get('clearance', '0 mm'))
    if tolerance < 0 or angle_tolerance < 0 or clearance < 0:
        raise ValueError('tolerance, angleTolerance and clearance must be nonnegative')

    rows = []
    for pair in pairs:
        if not isinstance(pair, (list, tuple)) or len(pair) != 2:
            raise ValueError('pairs must be [partFeature, fixtureFeature]')
        if pair[0] not in part_features or pair[1] not in fixture_features:
            raise ValueError('pair references an unknown feature: %s / %s' % (pair[0], pair[1]))
        pf, ff = part_features[pair[0]], fixture_features[pair[1]]
        delta = _vsub(ff['origin'], pf['origin'])
        axial_gap = _vdot(delta, approach)
        lateral = _vsub(delta, _vscale(approach, axial_gap))
        lateral_offset = _vnorm(lateral)
        angle = _angle_between(pf['direction'], ff['direction'])
        reasons = []
        fits = True
        if pf['kind'] in ('pin', 'hole') and ff['kind'] in ('pin', 'hole'):
            if pf['kind'] == ff['kind']:
                fits = False
                reasons.append('mating pin/hole pair must mix a pin with a hole')
            pin = pf if pf['kind'] == 'pin' else ff
            hole = ff if ff['kind'] == 'hole' else pf
            if hole['diameter'] is None or pin['diameter'] is None:
                fits = False
                reasons.append('pin/hole pair requires both diameters')
            elif pin['diameter'] > hole['diameter'] - clearance:
                fits = False
                reasons.append('pin diameter exceeds hole diameter minus clearance')
            if pf['direction'] and ff['direction'] and angle > angle_tolerance:
                fits = False
                reasons.append('axis angle exceeds angleTolerance')
        elif pf['kind'] == 'datum' and ff['kind'] == 'datum':
            if lateral_offset > tolerance:
                fits = False
                reasons.append('datum lateral offset exceeds tolerance')
            if angle > angle_tolerance:
                fits = False
                reasons.append('datum angle exceeds angleTolerance')
        else:
            fits = False
            reasons.append('incompatible feature kinds: %s / %s' % (pf['kind'], ff['kind']))
        rows.append({'part': pf['name'], 'fixture': ff['name'], 'kinds': [pf['kind'], ff['kind']],
                     'lateralOffset': lateral_offset, 'axialGap': axial_gap,
                     'angle': angle, 'fits': fits, 'reasons': reasons})

    seat_possible = all(r['fits'] for r in rows)
    return _sequence_contract(ctx, 'fixture.access', {
        'seatPossible': seat_possible, 'approach': approach, 'tolerance': tolerance,
        'angleTolerance': angle_tolerance, 'clearance': clearance, 'pairs': rows,
        'blockers': [r for r in rows if not r['fits']]},
        status='pass' if seat_possible else 'fail')


def _angle_between(a, b):
    if a is None or b is None:
        return 0.0
    d = _vdot(_vunit(a), _vunit(b))
    d = max(-1.0, min(1.0, d))
    return math.acos(d)


CAD_HANDLERS.update({
    'assembly.sequence': assembly_sequence,
    'service.path-check': service_path_check,
    'tool.access': tool_access,
    'fixture.access': fixture_access,
})
