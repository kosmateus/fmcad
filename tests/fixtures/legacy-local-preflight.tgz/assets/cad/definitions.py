"""Durable recipe ownership and guarded in-place native parameter regeneration.

The Node batch runner remains the only operation executor. This module records
ownership and edits model parameters; it never deletes or recreates geometry.
"""
_DEFINITION_GROUP = 'fmcad.recipes.v1'
_DEFINITION_OWNER = 'fmcad.recipeOwner.v1'


def _definition_ready(ctx):
    ctx.assert_identity()
    if not ctx.doc_file_id or not ctx.doc.dataFile or ctx.doc.dataFile.id != ctx.doc_file_id:
        raise ValueError('Durable recipes require a saved document pinned with --doc-file-id')
    if ctx.design.designType != adsk.fusion.DesignTypes.ParametricDesignType:
        raise ValueError('Durable recipes require native parametric history')
    timeline = ctx.design.timeline
    if timeline.markerPosition != timeline.count:
        raise ValueError('Recipe requires timeline at end; marker is not moved automatically')
    if any(int(item.healthState) != int(adsk.fusion.FeatureHealthStates.HealthyFeatureHealthState)
           for item in _cad_items(timeline)):
        raise ValueError('Unhealthy history blocks recipe changes')
    return timeline


def _definition_id(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_-]+', value):
        raise ValueError('Recipe id must contain letters, digits, underscores or hyphens')
    return value


def _definition_store(ctx, record):
    _cad_require_result(ctx.root.attributes.add(_DEFINITION_GROUP, record['id'],
                        json.dumps(record, allow_nan=False, sort_keys=True)), 'Store durable recipe')


def _definition_load(ctx, name):
    attribute = ctx.root.attributes.itemByName(_DEFINITION_GROUP, _definition_id(name))
    if not attribute:
        raise ValueError('Missing durable recipe/source: ' + name)
    record = json.loads(attribute.value)
    if record.get('formatVersion') != 1 or record.get('fileId') != ctx.doc_file_id:
        raise ValueError('Recipe format or document identity conflict')
    return record


def _definition_state(ctx, entity):
    state = {'type': entity.objectType, 'name': getattr(entity, 'name', None),
             'suppressed': getattr(entity, 'isSuppressed', False)}
    state['parameters'] = [{'name': p.name, 'expression': p.expression, 'unit': p.unit}
                           for p in _cad_items(ctx.design.allParameters)
                           if getattr(p, 'createdBy', None) == entity]
    if _cad_kind(entity) == 'sketch':
        # Exact control data, rather than tessellation or sampled bounding boxes.
        curves = []
        for curve in _cad_items(entity.sketchCurves):
            geometry = curve.geometry
            nurbs = getattr(geometry, 'asNurbsCurve', None)
            if nurbs is None:
                raise ValueError('Recipe snapshot does not support curve type ' + geometry.objectType)
            data = nurbs.getData()
            if not data[0]:
                raise ValueError('Cannot read curve control data for recipe ownership')
            # getData arrays can be SWIG vectors, not list/tuple or Fusion Base.
            _, points, degree, knots, rational, weights, periodic = data
            curves.append({'type': curve.objectType, 'construction': curve.isConstruction,
                           'fixed': curve.isFixed, 'data': _cad_json([
                               list(points), degree, list(knots), rational, list(weights), periodic])})
        state.update(curves=curves,
                     points=[_cad_xyz(p.geometry) for p in _cad_items(entity.sketchPoints)],
                     constraints=[c.objectType for c in _cad_items(entity.geometricConstraints)],
                     dimensions=[{'type': d.objectType, 'expression': d.parameter.expression}
                                 for d in _cad_items(entity.sketchDimensions)])
    if _cad_kind(entity) == 'occurrence':
        state['transform'] = list(entity.transform2.asArray())
    return state


def _definition_snapshot(ctx):
    return [{'ref': ctx.ref(item.entity), 'state': _definition_state(ctx, item.entity)}
            for item in _cad_items(ctx.design.timeline)]


def _definition_user_parameters(ctx):
    return [{'name': p.name, 'expression': p.expression, 'unit': p.unit}
            for p in _cad_items(ctx.design.allParameters) if getattr(p, 'createdBy', None) is None]


def _definition_compare(ctx, snapshot, prefix=False):
    timeline = ctx.design.timeline
    if len(snapshot) > timeline.count or not prefix and len(snapshot) != timeline.count:
        raise ValueError('Downstream/history membership conflict; recipe migration required')
    for i, saved in enumerate(snapshot):
        entity = ctx.resolve(saved['ref'])
        if entity != timeline.item(i).entity or _definition_state(ctx, entity) != saved['state']:
            raise ValueError('User edit or history order conflict at ' + str(i))


def _definition_bindings(ctx, bindings, owned):
    if not isinstance(bindings, list) or not bindings:
        raise ValueError('Nonempty native parameter bindings required')
    result, seen = [], set()
    for binding in bindings:
        _cad_fields(binding, ('parameter', 'target', 'input'), ('name', 'role'))
        feature = ctx.resolve(binding['target'], 'feature')
        if not any(feature == entity for entity in owned):
            raise ValueError('Binding target is not an owned recipe feature')
        if 'name' not in binding and 'role' not in binding:
            raise ValueError('Binding requires a native parameter name or role')
        candidates = [p for p in _cad_items(ctx.design.allParameters)
                      if getattr(p, 'createdBy', None) == feature
                      and ('name' not in binding or p.name == binding['name'])
                      and ('role' not in binding or p.role == binding['role'])]
        parameter = _cad_unique(candidates, 'Recipe parameter binding')
        if parameter.name in seen:
            raise ValueError('Duplicate native parameter binding: ' + parameter.name)
        seen.add(parameter.name)
        result.append({'parameter': binding['parameter'], 'target': ctx.ref(feature),
                       'name': parameter.name, 'unit': parameter.unit, 'expression': parameter.expression})
    return result


def _definition_recipe(ctx, data):
    _cad_fields(data, ('action', 'recipe', 'sourceHash'), ('source', 'bindings', 'exports', 'created'))
    timeline = _definition_ready(ctx)
    recipe = data['recipe']
    _cad_fields(recipe, ('id', 'bindings'))
    name = _definition_id(recipe['id'])
    if not isinstance(data['sourceHash'], str) or not re.fullmatch('[a-f0-9]{64}', data['sourceHash']):
        raise ValueError('sourceHash must be a SHA256 hex string')
    if data['action'] == 'begin':
        if ctx.root.attributes.itemByName(_DEFINITION_GROUP, name):
            raise ValueError('Recipe already exists; inspect instead of replaying mutations')
        if not isinstance(data.get('source'), dict) or not data['source'].get('operations'):
            raise ValueError('Embedded recipe source required before mutation')
        if not isinstance(recipe['bindings'], list) or not recipe['bindings']:
            raise ValueError('Recipe declaration requires nonempty bindings')
        for binding in recipe['bindings']:
            _cad_fields(binding, ('parameter', 'input', 'target'), ('name', 'role'))
            if not isinstance(binding['input'], str) or not binding['input'] or not isinstance(
                    data['source'].get('parameters', {}).get(binding['parameter']), str):
                raise ValueError('Binding requires an input path and a root expression parameter')
            if not isinstance(binding['target'], dict) or set(binding['target']) != {'$ref'} or not isinstance(binding['target']['$ref'], str):
                raise ValueError('Binding target must be a symbolic output reference')
            if not any(isinstance(binding.get(key), str) and binding[key] for key in ('name', 'role')):
                raise ValueError('Binding requires a native parameter name or role')
        record = {'formatVersion': 1, 'id': name, 'revision': 1, 'fileId': ctx.doc_file_id,
                  'sourceHash': data['sourceHash'], 'source': data['source'], 'declaration': recipe,
                  'status': 'building', 'baseline': _definition_snapshot(ctx)}
        _definition_store(ctx, record)
    elif data['action'] == 'complete':
        record = _definition_load(ctx, name)
        if record['status'] != 'building' or record['sourceHash'] != data['sourceHash'] or record['declaration'] != recipe:
            raise ValueError('Recipe source/state conflict; completion refused')
        _definition_compare(ctx, record['baseline'], prefix=True)
        owned = [timeline.item(i).entity for i in range(len(record['baseline']), timeline.count)]
        if not owned:
            raise ValueError('Recipe created no native history entities')
        if not isinstance(data.get('created'), list):
            raise ValueError('Actual batch created refs required for ownership attribution')
        created = [ctx.resolve(ref) for ref in data['created']]
        if any(not any(entity == candidate for candidate in created) for entity in owned):
            raise ValueError('Unattributed downstream history; refusing to adopt foreign entities')
        bindings = _definition_bindings(ctx, data.get('bindings'), owned)
        for entity in owned:
            if entity.attributes.itemByName(_DEFINITION_OWNER, 'id'):
                raise ValueError('Entity already owned by another recipe')
        snapshot = _definition_snapshot(ctx)
        for entity in owned:
            _cad_require_result(entity.attributes.add(_DEFINITION_OWNER, 'id', name), 'Tag recipe ownership')
        record.update(status='ready', bindings=bindings, snapshot=snapshot,
                      owned=[ctx.ref(entity) for entity in owned], exports=data.get('exports', {}),
                      userParameters=_definition_user_parameters(ctx),
                      parameters=record['source'].get('parameters', {}))
        _definition_store(ctx, record)
    else:
        raise ValueError('Recipe action must be begin or complete')
    return {'status': 'pass', 'recipeStatus': record['status'], 'id': name, 'revision': record['revision'],
            'sourceHash': record['sourceHash'], 'documentIdentity': {'fileId': ctx.doc_file_id},
            'associativity': 'recipeRegeneration', 'savedToCloud': False,
            'method': 'durable document attributes; appended native history ownership', 'atomic': False}


def _definition_regenerate(ctx, data):
    _cad_fields(data, ('id', 'expectedRevision', 'sourceHash'), ('parameters', 'dryRun'))
    if type(data.get('dryRun', True)) is not bool or type(data['expectedRevision']) is not int or data['expectedRevision'] < 1:
        raise ValueError('dryRun must be boolean; expectedRevision must be a positive integer')
    _definition_ready(ctx)
    record = _definition_load(ctx, data['id'])
    if record['status'] != 'ready' or record['revision'] != data['expectedRevision']:
        raise ValueError('Recipe revision/state conflict; no automatic retry')
    if not record.get('source') or record['sourceHash'] != data['sourceHash']:
        raise ValueError('Missing or changed source hash; preflight/migration required')
    _definition_compare(ctx, record['snapshot'])
    if _definition_user_parameters(ctx) != record['userParameters']:
        raise ValueError('User parameter/dependency conflict')
    owned = [ctx.resolve(ref) for ref in record['owned']]
    for entity in owned:
        tag = entity.attributes.itemByName(_DEFINITION_OWNER, 'id')
        if not tag or tag.value != record['id']:
            raise ValueError('Recipe ownership conflict')
    changes = data.get('parameters', {})
    if not isinstance(changes, dict):
        raise ValueError('parameters must be an object')
    available = {b['parameter'] for b in record['bindings']}
    if changes.keys() - available:
        raise ValueError('Unbound or structural parameter change; explicit recipe migration required')
    plan = []
    for binding in record['bindings']:
        if binding['parameter'] not in changes:
            continue
        expression = changes[binding['parameter']]
        # Reuse the existing feature-edit validator and native parameter selector.
        feature, edits = _assembly_feature_plan(ctx, {'feature': binding['target'],
                                                     'parameters': {binding['name']: expression}})
        parameter = edits[0][0]
        if parameter.expression != binding['expression'] or parameter.unit != binding['unit']:
            raise ValueError('User-edited binding conflicts with durable recipe')
        plan.append({'parameter': binding['parameter'], 'name': parameter.name, 'unit': parameter.unit,
                     'target': ctx.ref(feature), 'before': parameter.expression, 'after': expression})
    result = {'status': 'pass', 'id': record['id'], 'revision': record['revision'], 'plan': plan,
              'applied': False, 'documentIdentity': {'fileId': ctx.doc_file_id},
              'associativity': 'recipeRegeneration', 'units': 'per-binding unit', 'frame': 'native owning component',
              'affected': [], 'warnings': [], 'atomic': False,
              'provenance': {'sourceHash': record['sourceHash'], 'formatVersion': 1},
              'method': 'in-place native model parameter expressions',
              'limitations': ['Conservative whole-history fence; not a complete downstream dependency graph.',
                              'Snapshot checks names, parameter expressions, curve control data and history membership; not every SDK feature property.',
                              'No automatic save, rollback, source migration or structural rebuild.']}
    if data.get('dryRun', True) or not plan:
        return result
    # Write uncertainty before the first assignment; any exception leaves a durable fence.
    record['status'] = 'updating'
    record['pending'] = plan
    _definition_store(ctx, record)
    for change in plan:
        ctx.assert_identity()
        ctx.call('feature.edit', {'feature': change['target'], 'parameters': {change['name']: change['after']}})
    _cad_require_result(ctx.design.computeAll(), 'Recipe recompute')
    _definition_ready(ctx)
    for binding in record['bindings']:
        if binding['parameter'] in changes:
            feature, edits = _assembly_feature_plan(ctx, {'feature': binding['target'],
                'parameters': {binding['name']: changes[binding['parameter']]}})
            actual = edits[0][0].expression
            expected_value = ctx._expression(changes[binding['parameter']], binding['unit'], unitless=binding['unit'] == '')[1]
            actual_value = ctx._expression(actual, binding['unit'], unitless=binding['unit'] == '')[1]
            if not math.isclose(expected_value, actual_value, rel_tol=1e-10, abs_tol=1e-12):
                raise RuntimeError('Native binding readback differs from requested expression')
            binding['expression'] = actual
    record['parameters'].update(changes)
    record.update(status='ready', revision=record['revision'] + 1, snapshot=_definition_snapshot(ctx))
    del record['pending']
    _definition_store(ctx, record)
    result.update(applied=True, revision=record['revision'], affected=[c['target'] for c in plan])
    return result


CAD_HANDLERS.update({'definition.recipe': _definition_recipe, 'definition.regenerate': _definition_regenerate})
