"""GM18: named product states (poses) stored as an explicit local manifest.

The manifest is a JSON blob held in root-component attributes; it is explicitly
not a native Fusion ConfigurationTable. A pose captures: identity/revision, joint
values, parameter values, visibility, fill state, spring state, route variant and
service/disconnection flags. `apply` leaves the requested state; `evaluate` applies
temporarily and restores the previous state, reporting restoration failure as a
separate error. Incompatible documents and stale refs are rejected.

Reuses `joint.drive` and `param.apply` by dispatch; visibility uses the native
light-bulb flag. Fill/spring/route/service states are manifest-carried declarations
whose geometric and mass effect is resolved by the corresponding GM methods
(GM12 spring evaluate, GM23 fluid mass), never re-computed here.
"""
import datetime
import json

_POSE_GROUP = 'fmcad.pose'
_POSE_INDEX = '__index__'
_POSE_SCHEMA = 'fmcad.pose.manifest.v1'
_POSE_FILL_STATES = (None, 'FULL', 'EMPTY')
_POSE_SPRING_STATES = (None, 'FREE', 'COCKED', 'COMPRESSED')


def _pose_contract(ctx, operation, result, status='pass', read_only=True, **extra):
    identity = None
    if hasattr(ctx, 'doc') and getattr(ctx.doc, 'name', None) is not None:
        identity = {'creationId': getattr(ctx.doc, 'creationId', None), 'name': ctx.doc.name}
    component = None
    if hasattr(ctx, 'component') and hasattr(ctx, 'ref'):
        try:
            component = ctx.ref(ctx.component)
        except Exception:
            component = None
    out = dict(schemaVersion=1, operation=operation, status=status, success=status == 'pass',
               documentIdentity=identity,
               units={'length': 'cm', 'angle': 'rad'},
               frame={'space': 'component', 'component': component},
               associativity='snapshot',
               method='GM18 named product states; local manifest, not a native ConfigurationTable',
               provenance={'requirement': 'GM18', 'source': 'docs/POSES.md'})
    out['warnings'] = list(result.pop('warnings', [])) + list(extra.pop('warnings', []))
    out['limitations'] = ['Local attribute manifest, not a native Fusion ConfigurationTable.',
                          'Fill/spring/route/service states are manifest-carried; their mass/force effect is resolved by GM12/GM23, not recomputed here.'] + \
                         list(result.pop('limitations', [])) + list(extra.pop('limitations', []))
    out['affected'] = list(result.pop('affected', [])) + list(extra.pop('affected', []))
    out.update(extra)
    out.update(result)
    return out


def _pose_identity(ctx):
    if not hasattr(ctx, 'doc') or ctx.doc is None:
        return {'creationId': None, 'name': None}
    return {'creationId': getattr(ctx.doc, 'creationId', None), 'name': getattr(ctx.doc, 'name', None)}


def _pose_version(data):
    if data.get('schemaVersion') != 1 or data.get('frame') != 'component':
        raise ValueError('GM18 pose operations require schemaVersion:1 and frame:component')


def _pose_attributes(ctx):
    root = ctx.root if hasattr(ctx, 'root') else getattr(ctx, 'component', None)
    if root is None or not hasattr(root, 'attributes') or root.attributes is None:
        raise ValueError('Pose manifest requires root-component attributes')
    return root.attributes


def _pose_index_read(ctx):
    attribute = _pose_attributes(ctx).itemByName(_POSE_GROUP, _POSE_INDEX)
    if attribute is None:
        return {}
    value = json.loads(attribute.value)
    return value if isinstance(value, dict) else {}


def _pose_index_write(ctx, index):
    _cad_require_result(_pose_attributes(ctx).add(_POSE_GROUP, _POSE_INDEX, json.dumps(index)), 'Store pose index')


def _pose_validate_fields(data, optional=()):
    for key in ('joints', 'parameters', 'visibility'):
        if key in data and not isinstance(data[key], list):
            raise ValueError(key + ' must be an array')
    if 'fillState' in data and data['fillState'] not in _POSE_FILL_STATES:
        raise ValueError('fillState must be FULL or EMPTY')
    if 'springState' in data and data['springState'] not in _POSE_SPRING_STATES:
        raise ValueError('springState must be FREE, COCKED or COMPRESSED')
    if 'routeVariant' in data and not isinstance(data['routeVariant'], str):
        raise ValueError('routeVariant must be text')
    if 'service' in data:
        service = data['service']
        if not isinstance(service, dict) or 'disconnections' not in service or not isinstance(service['disconnections'], list):
            raise ValueError('service requires a disconnections array')


def _pose_manifest(ctx, name, revision, data):
    return {'schema': _POSE_SCHEMA, 'name': name, 'revision': revision,
            'document': _pose_identity(ctx),
            'savedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'joints': data.get('joints', []),
            'parameters': data.get('parameters', []),
            'visibility': data.get('visibility', []),
            'fillState': data.get('fillState'),
            'springState': data.get('springState'),
            'routeVariant': data.get('routeVariant'),
            'service': data.get('service')}


def _pose_read_manifest(ctx, name):
    index = _pose_index_read(ctx)
    if name not in index:
        raise ValueError('No saved pose named ' + name)
    manifest = index[name]
    if not isinstance(manifest, dict) or manifest.get('schema') != _POSE_SCHEMA:
        raise ValueError('Pose manifest has an incompatible schema')
    return manifest


def _pose_resolve_refs(ctx, manifest):
    """Fail before mutation on any stale ref; returns resolved visibility entities."""
    for spec in manifest.get('joints', []):
        ctx.resolve(spec.get('joint'))
    for spec in manifest.get('parameters', []):
        name = spec.get('name')
        if not isinstance(name, str) or not name:
            raise ValueError('parameter entries require a name')
    visibility = []
    for spec in manifest.get('visibility', []):
        visibility.append((ctx.resolve(spec.get('ref')), spec.get('visible')))
    return visibility


def pose_save(ctx, data):
    _pose_version(data)
    _model_fields(data, ('schemaVersion', 'frame', 'name'),
                  ('revision', 'joints', 'parameters', 'visibility', 'fillState', 'springState',
                   'routeVariant', 'service', 'onExisting', 'confirm'))
    name = data['name']
    if not isinstance(name, str) or not name.strip():
        raise ValueError('pose name must be nonempty')
    _pose_validate_fields(data)
    policy = data.get('onExisting', 'error')
    if policy not in ('error', 'update'):
        raise ValueError('onExisting must be error or update')
    revision = data.get('revision', 1)
    if type(revision) is not int or revision < 1:
        raise ValueError('revision must be a positive integer')
    index = _pose_index_read(ctx)
    if name in index and policy == 'error':
        raise ValueError('Pose already exists: ' + name + '; choose onExisting:update with confirm')
    if name in index and policy == 'update':
        ctx.require_confirm(data)
        if 'revision' not in data:
            revision = index[name].get('revision', 0) + 1
    manifest = _pose_manifest(ctx, name, revision, data)
    index[name] = manifest
    _pose_index_write(ctx, index)
    return _pose_contract(ctx, 'pose.save',
                          {'name': name, 'revision': revision, 'manifest': manifest,
                           'identity': _pose_identity(ctx), 'changed': True},
                          read_only=False)


def _pose_key(ref):
    if isinstance(ref, dict):
        return ref.get('token') or ref.get('name') or ref.get('path') or json.dumps(ref, sort_keys=True)
    return str(ref)


def _pose_capture(ctx, manifest):
    joints = {}
    for spec in manifest.get('joints', []):
        inspected = ctx.call('joint.inspect', {'joint': spec['joint']})
        for key, units in (('rotationValue', 'rad'), ('slideValue', 'cm')):
            if key in inspected:
                joints[_pose_key(spec['joint'])] = {'value': inspected[key], 'units': units}
                break
    parameters = {}
    names = [s.get('name') for s in manifest.get('parameters', []) if isinstance(s.get('name'), str)]
    if names:
        inspected = ctx.call('param.inspect', {'names': names})
        for row in inspected.get('parameters', []):
            parameters[row['name']] = row.get('expression', row.get('value'))
    visibility = {}
    for spec in manifest.get('visibility', []):
        try:
            visibility[_pose_key(spec.get('ref'))] = bool(ctx.resolve(spec.get('ref')).isLightBulbOn)
        except Exception:
            visibility[_pose_key(spec.get('ref'))] = None
    return {'joints': joints, 'parameters': parameters, 'visibility': visibility}


def _pose_apply_manifest(ctx, manifest, resolve=True):
    visibility = _pose_resolve_refs(ctx, manifest) if resolve else []
    applied = []
    unapplied = []
    for spec in manifest.get('joints', []):
        drive = {'joint': spec['joint']}
        if 'rotation' in spec:
            drive['rotation'] = spec['rotation']
        elif 'slide' in spec:
            drive['slide'] = spec['slide']
        else:
            unapplied.append({'dimension': 'joint', 'ref': spec.get('joint'), 'reason': 'no rotation or slide value'})
            continue
        result = ctx.call('joint.drive', drive)
        applied.append({'dimension': 'joint', 'ref': spec.get('joint'),
                        'requested': drive, 'actual': {k: result.get(k) for k in ('rotationValue', 'slideValue') if k in result}})
    if manifest.get('parameters'):
        result = ctx.call('param.apply', {'parameters': manifest['parameters'], 'overwrite': True})
        for row in result.get('parameters', []):
            applied.append({'dimension': 'parameter', 'ref': row.get('name'), 'actual': row.get('expression')})
    for entity, visible in visibility:
        entity.isLightBulbOn = visible
        applied.append({'dimension': 'visibility', 'ref': None, 'actual': {'isLightBulbOn': entity.isLightBulbOn, 'visible': visible}})
    for dimension, key in (('fillState', 'fillState'), ('springState', 'springState'),
                           ('routeVariant', 'routeVariant'), ('service', 'service')):
        if manifest.get(key) is not None:
            applied.append({'dimension': dimension, 'requested': manifest.get(key),
                            'actual': manifest.get(key), 'applied': 'manifest-carried'})
    return applied, unapplied


def pose_apply(ctx, data):
    _pose_version(data)
    _model_fields(data, ('schemaVersion', 'frame', 'name'), ())
    manifest = _pose_read_manifest(ctx, data['name'])
    if manifest.get('document') != _pose_identity(ctx):
        raise ValueError('Pose belongs to a different document; recapture the pose for this document')
    before = _pose_capture(ctx, manifest)
    applied, unapplied = _pose_apply_manifest(ctx, manifest)
    after = _pose_capture(ctx, manifest)
    status = 'pass' if not unapplied else 'fail'
    return _pose_contract(ctx, 'pose.apply',
                          {'name': manifest['name'], 'revision': manifest['revision'],
                           'requested': manifest, 'applied': applied, 'unapplied': unapplied,
                           'before': before, 'after': after, 'leftApplied': True},
                          status=status, read_only=False,
                          limitations=['apply leaves the requested state; no automatic restoration.'])


def pose_evaluate(ctx, data):
    _pose_version(data)
    _model_fields(data, ('schemaVersion', 'frame', 'name'), ())
    manifest = _pose_read_manifest(ctx, data['name'])
    if manifest.get('document') != _pose_identity(ctx):
        raise ValueError('Pose belongs to a different document; recapture the pose for this document')
    before = _pose_capture(ctx, manifest)
    applied, unapplied, after = [], [], None
    primary_error = None
    restore_errors = []
    try:
        applied, unapplied = _pose_apply_manifest(ctx, manifest)
        after = _pose_capture(ctx, manifest)
    except Exception as exc:
        primary_error = type(exc).__name__ + ': ' + str(exc)
    finally:
        restore_errors.extend(_pose_restore(ctx, manifest, before))
    try:
        restored = _pose_capture(ctx, manifest)
    except Exception as exc:
        restored = None
        restore_errors.append('readback: ' + type(exc).__name__ + ': ' + str(exc))
    restored_ok = not restore_errors and restored == before
    status = 'pass' if primary_error is None and not unapplied and restored_ok else 'fail'
    result = {'name': manifest['name'], 'revision': manifest['revision'],
              'requested': manifest, 'applied': applied, 'unapplied': unapplied,
              'before': before, 'after': after, 'restored': restored_ok,
              'restoration': restored, 'primaryError': primary_error, 'restoreErrors': restore_errors}
    if not restored_ok:
        result['warnings'] = ['Restoration failed; the previous state was not fully re-established. Restore failure is a separate error from the requested evaluation.']
    return _pose_contract(ctx, 'pose.evaluate', result, status=status, read_only=False,
                          limitations=['evaluate applies temporarily and restores the previous state; restoration failure is reported separately.'])


def _pose_restore(ctx, manifest, before):
    errors = []
    for spec in manifest.get('joints', []):
        captured = before['joints'].get(_pose_key(spec.get('joint')))
        if not captured:
            continue
        drive = {'joint': spec['joint']}
        if 'rotation' in spec:
            drive['rotation'] = format(float(captured['value']), '.17g') + ' ' + captured['units']
        elif 'slide' in spec:
            drive['slide'] = format(float(captured['value']), '.17g') + ' ' + captured['units']
        else:
            continue
        try:
            ctx.call('joint.drive', drive)
        except Exception as exc:
            errors.append('joint %s: %s: %s' % (_pose_key(spec.get('joint')), type(exc).__name__, str(exc)))
    names = [s.get('name') for s in manifest.get('parameters', []) if isinstance(s.get('name'), str)]
    if names:
        for name in names:
            expression = before['parameters'].get(name)
            if expression is None:
                errors.append('parameter %s: no baseline expression' % name)
                continue
            try:
                ctx.call('param.apply', {'parameters': [{'name': name, 'expression': expression}], 'overwrite': True})
            except Exception as exc:
                errors.append('parameter %s: %s: %s' % (name, type(exc).__name__, str(exc)))
    for spec in manifest.get('visibility', []):
        value = before['visibility'].get(_pose_key(spec.get('ref')))
        if value is None:
            errors.append('visibility %s: no baseline state' % _pose_key(spec.get('ref')))
            continue
        try:
            ctx.resolve(spec.get('ref')).isLightBulbOn = value
        except Exception as exc:
            errors.append('visibility %s: %s: %s' % (_pose_key(spec.get('ref')), type(exc).__name__, str(exc)))
    return errors


def pose_list(ctx, data):
    _pose_version(data)
    _model_fields(data, ('schemaVersion', 'frame'), ())
    index = _pose_index_read(ctx)
    rows = []
    for name, manifest in index.items():
        if isinstance(manifest, dict):
            rows.append({'name': name, 'revision': manifest.get('revision'),
                         'savedAt': manifest.get('savedAt'), 'document': manifest.get('document')})
    rows.sort(key=lambda r: r['name'])
    return _pose_contract(ctx, 'pose.list', {'poses': rows, 'count': len(rows)}, read_only=True)


def pose_delete(ctx, data):
    _pose_version(data)
    _model_fields(data, ('schemaVersion', 'frame', 'name'), ('confirm',))
    ctx.require_confirm(data)
    name = data['name']
    index = _pose_index_read(ctx)
    if name not in index:
        raise ValueError('No saved pose named ' + name)
    removed = index.pop(name)
    _pose_index_write(ctx, index)
    return _pose_contract(ctx, 'pose.delete',
                          {'name': name, 'deleted': True,
                           'revision': removed.get('revision') if isinstance(removed, dict) else None},
                          read_only=False)


CAD_HANDLERS.update({'pose.save': pose_save, 'pose.apply': pose_apply, 'pose.list': pose_list,
                     'pose.delete': pose_delete, 'pose.evaluate': pose_evaluate})
