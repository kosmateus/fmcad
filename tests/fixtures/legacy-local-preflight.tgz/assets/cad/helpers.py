class FMCAD:
    """Trusted convenience facade; dispatch is not a Python sandbox."""
    def __init__(self, context, readonly=False):
        self._context = context
        self._readonly = readonly
        self._emitted = _NOT_EMITTED
        self.calls = []
        self.doc = getattr(context, 'doc', None)
        self.design = getattr(context, 'design', None)
        self.root = getattr(context, 'root', None)

    def call(self, operation, data, component=None):
        readonly = getattr(self._context, 'read_only_operations', ())
        if self._readonly and operation not in readonly:
            raise RuntimeError('readonly helper dispatch rejected mutating operation')
        record = {'operation': operation, 'status': 'failed', 'effects': 'unknown'}
        self.calls.append(record)
        try:
            previous = self._context.component
            try:
                if component is not None:
                    self._context.component = self.resolve(component, 'component')
                result = self._context.call(operation, data)
            finally:
                self._context.component = previous
            record.update(status='completed', effects='observed')
            return result
        except BaseException:
            raise

    def resolve(self, ref, expected_kind=None):
        return self._context.resolve(ref, expected_kind)

    def length(self, expression): return self._context.length(expression)
    def angle(self, expression): return self._context.angle(expression)
    def point(self, coordinates): return self._context.point(coordinates)
    def value(self, expression): return self._context.value(expression)
    def collection(self, entities): return self._context.collection(entities)

    def parameter_test(self, spec, check_case, check_restored):
        if self._readonly:
            raise RuntimeError('readonly helper dispatch rejected mutating operation')
        if not callable(check_case) or not callable(check_restored):
            raise TypeError('parameter_test requires check_case and check_restored callbacks')
        return _measure_parameter_test(self._context, spec, check_case, check_restored)

    def temporary_body(self, ref, frame):
        return _measure_temporary_body(self._context, ref, frame)

    def compare_bodies(self, a, b, frame, volume_tolerance, linear_tolerance, angular_tolerance):
        return _measure_compare_bodies(self._context, a, b, frame, volume_tolerance,
                                       linear_tolerance, angular_tolerance)

    def require_pass(self, result):
        if not isinstance(result, dict): raise RuntimeError('result is not an object')
        flags = [key for key in ('accepted', 'checkPassed', 'passed') if key in result]
        if not flags or any(type(result[key]) is not bool or not result[key] for key in flags):
            raise RuntimeError('result does not contain unambiguous acceptance')
        if result.get('success') is False or result.get('failed') is True:
            raise RuntimeError('result reports failure')
        if str(result.get('status', '')).lower() in ('unknown','missing','stale','blocked','error','fail','failed'):
            raise RuntimeError('result status is unresolved or failed')
        return result

    def require_history_end(self):
        timeline = self.design.timeline
        if timeline.markerPosition != timeline.count: raise RuntimeError('history marker is not at end')

    def emit(self, payload):
        if self._emitted is not _NOT_EMITTED: raise RuntimeError('FMCAD.emit may be called once')
        import json
        json.dumps(payload, allow_nan=False)
        self._emitted = payload

    def _terminal(self, error=None):
        import json
        result = {'success': error is None, 'helperCallsOnly': self.calls}
        if self._emitted is not _NOT_EMITTED: result['result'] = self._emitted
        if error is not None: result['error'] = str(error)
        try: print('FMCAD_RESULT ' + json.dumps(result, allow_nan=False))
        except Exception: pass


_NOT_EMITTED = object()
