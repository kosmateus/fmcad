"""GM32: sheet-metal forming, flattening and bend tables.

Bends are carried as declared segments: flat runs plus bends that each carry a
``radius``, ``angle`` and exactly one of a ``K`` factor or an explicit bend
``allowance``. The neutral-axis radius is ``radius + K * thickness`` (or
``allowance / |angle|`` when an allowance is supplied), so the developed length
per bend is never guessed: a bend missing both values is rejected. The formed
walk folds the neutral axis in 3D; the flat walk straightens it, so developed
and formed neutral lengths are identical and nothing is scaled. This is an
explicit *external* recipe; the public native flat-pattern API is a gated
availability, so ``representation: native`` is reported blocked rather than
faked as a static solid. A folded PCB (FPC) is not sheet metal and is not
unfolded here.
"""
import math

import adsk.core
import adsk.fusion


# --- vector helpers (cm internal) -------------------------------------------------

def _vsub(a, b):
    return [a[0] - b[0], a[1] - b[1], a[2] - b[2]]


def _vadd(a, b):
    return [a[0] + b[0], a[1] + b[1], a[2] + b[2]]


def _vscale(a, s):
    return [x * s for x in a]


def _vdot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _vcross(a, b):
    return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]


def _vnorm(a):
    return math.sqrt(_vdot(a, a))


def _vunit(a):
    n = _vnorm(a)
    if n == 0:
        raise ValueError('Degenerate zero vector')
    return [x / n for x in a]


def _rotate(v, axis, angle):
    c, s = math.cos(angle), math.sin(angle)
    axis = _vunit(axis)
    dot = _vdot(axis, v)
    return _vadd(_vadd(_vscale(v, c), _vscale(_vcross(axis, v), s)), _vscale(axis, dot * (1 - c)))


def _deg(rad):
    return rad * 180.0 / math.pi


_AXES = {'x': [1.0, 0.0, 0.0], 'y': [0.0, 1.0, 0.0], 'z': [0.0, 0.0, 1.0]}


# --- envelope --------------------------------------------------------------------

def _sheet_contract(ctx, operation, result, status='pass'):
    identity = None
    if hasattr(ctx, 'doc') and getattr(getattr(ctx, 'doc', None), 'name', None) is not None:
        identity = {'name': ctx.doc.name}
    component = None
    if hasattr(ctx, 'component') and hasattr(ctx, 'ref'):
        try:
            component = ctx.ref(ctx.component)
        except Exception:
            component = None
    merged = dict(schemaVersion=1, operation=operation, documentIdentity=identity,
                  units={'length': 'cm', 'angle': 'deg'},
                  frame={'space': 'component', 'component': component}, associativity='snapshot',
                  warnings=[], method='GM32 local external sheet-metal recipe evaluation',
                  limitations=['Bend allowances are never guessed: every bend must declare a K-factor or an explicit allowance.',
                               'This is an explicit external recipe; the public native flat-pattern API is a gated availability and is reported blocked when requested, never faked as a static solid.',
                               'An arbitrary solid body is not unfolded as sheet metal; a folded PCB (FPC) is not sheet metal and is not unfolded here.',
                               'Flat-pattern export (DXF/SVG) is a documented gap and is not produced.'],
                  provenance={'requirement': 'GM32', 'source': 'docs/SHEET_METAL.md'}, affected=[])
    merged.update(result)
    merged.setdefault('status', status)
    merged['success'] = merged['status'] == 'pass'
    return merged


# --- segment parsing -------------------------------------------------------------

def _parse_segments(ctx, segments):
    if not isinstance(segments, list) or not segments:
        raise ValueError('segments must be a nonempty array')
    parsed = []
    for index, seg in enumerate(segments):
        if not isinstance(seg, dict) or 'type' not in seg:
            raise ValueError('segment %d requires a type' % index)
        kind = seg['type']
        if kind == 'flat':
            if ctx.length(seg['length']) <= 0:
                raise ValueError('flat segment %d length must be positive' % index)
            parsed.append({'type': 'flat', 'index': index, 'length': ctx.length(seg['length'])})
        elif kind == 'bend':
            radius = ctx.length(seg['radius'])
            if radius <= 0:
                raise ValueError('bend segment %d radius must be positive' % index)
            angle = ctx.angle(seg['angle'])
            if angle == 0:
                raise ValueError('bend segment %d angle must be nonzero' % index)
            if seg.get('axis', 'y') not in _AXES:
                raise ValueError('bend segment %d axis must be x, y or z' % index)
            parsed.append({'type': 'bend', 'index': index, 'radius': radius, 'angle': angle,
                           'axis': seg.get('axis', 'y'), 'K': seg.get('K'),
                           'allowance': seg.get('allowance')})
        else:
            raise ValueError('segment %d type must be flat or bend' % index)
    return parsed


def _bend_allowance(ctx, thickness, seg):
    """Return (neutral_radius, developed_length) or reject a guessed allowance."""
    k = seg.get('K')
    allowance = seg.get('allowance')
    if (k is None) == (allowance is None):
        raise ValueError('bend segment %d requires exactly one of K (K-factor) or allowance; neither may be guessed' % seg['index'])
    if k is not None:
        if not isinstance(k, (int, float)) or isinstance(k, bool) or not 0.0 <= k <= 1.0:
            raise ValueError('bend segment %d K-factor must be a number within [0,1]' % seg['index'])
        neutral_radius = seg['radius'] + k * thickness
        return neutral_radius, neutral_radius * abs(seg['angle'])
    allowance_value = ctx.length(allowance)
    if allowance_value <= 0:
        raise ValueError('bend segment %d allowance must be positive' % seg['index'])
    neutral_radius = allowance_value / abs(seg['angle'])
    return neutral_radius, allowance_value


# --- sheet.bends -----------------------------------------------------------------

def _sheet_bends(ctx, data):
    _cad_fields(data, ('thickness', 'segments'),
                ('fixedFace', 'reliefs', 'grain', 'process', 'representation', 'frame', 'schemaVersion'))
    if data.get('schemaVersion', 1) != 1:
        raise ValueError('sheet.bends requires schemaVersion 1')
    thickness = ctx.length(data['thickness'])
    if thickness <= 0:
        raise ValueError('thickness must be positive')
    segments = _parse_segments(ctx, data['segments'])
    reliefs = data.get('reliefs', [])
    if not isinstance(reliefs, list):
        raise ValueError('reliefs must be an array')
    rows = []
    total_developed = 0.0
    for seg in segments:
        if seg['type'] == 'flat':
            total_developed += seg['length']
            continue
        neutral_radius, developed = _bend_allowance(ctx, thickness, seg)
        rows.append({'index': seg['index'], 'type': 'bend', 'radius': seg['radius'],
                     'angle': seg['angle'], 'angleDeg': _deg(seg['angle']),
                     'axis': seg['axis'], 'K': seg.get('K'), 'allowance': developed,
                     'neutralRadius': neutral_radius, 'developedLength': developed,
                     'direction': 'up' if seg['angle'] > 0 else 'down'})
        total_developed += developed
    return _sheet_contract(ctx, 'sheet.bends', {
        'bendTable': rows, 'bendCount': len(rows), 'thickness': thickness,
        'totalDevelopedLength': total_developed, 'fixedFace': data.get('fixedFace'),
        'reliefs': reliefs, 'grain': data.get('grain'), 'process': data.get('process')})


def _sheet_neutral_radii(ctx, thickness, segments):
    return {seg['index']: _bend_allowance(ctx, thickness, seg)[0]
            for seg in segments if seg['type'] == 'bend'}


def _sheet_developed(ctx, thickness, segments):
    return {seg['index']: _bend_allowance(ctx, thickness, seg)[1]
            for seg in segments if seg['type'] == 'bend'}


def _formed_walk(ctx, segments, neutral_radii):
    position = [0.0, 0.0, 0.0]
    tangent = [1.0, 0.0, 0.0]
    points = [list(position)]
    mapping = []
    for seg in segments:
        if seg['type'] == 'flat':
            position = _vadd(position, _vscale(tangent, seg['length']))
            mapping.append({'index': seg['index'], 'type': 'flat', 'position': list(position),
                            'tangent': list(tangent)})
        else:
            angle = seg['angle']
            axis = _AXES[seg['axis']]
            radius = neutral_radii[seg['index']]
            inward = _vunit(_vcross(axis, tangent))
            center = _vadd(position, _vscale(inward, radius))
            end_radial = _rotate(_vscale(inward, -1.0), axis, angle)
            position = _vadd(center, _vscale(end_radial, radius))
            tangent = _rotate(tangent, axis, angle)
            mapping.append({'index': seg['index'], 'type': 'bend', 'position': list(position),
                            'tangent': list(tangent), 'neutralRadius': radius, 'angle': angle})
        points.append(list(position))
    return points, mapping


def _flat_walk(ctx, segments, developed):
    position = [0.0, 0.0, 0.0]
    tangent = [1.0, 0.0, 0.0]
    points = [list(position)]
    mapping = []
    for seg in segments:
        length = seg['length'] if seg['type'] == 'flat' else developed[seg['index']]
        position = _vadd(position, _vscale(tangent, length))
        mapping.append({'index': seg['index'], 'type': seg['type'], 'position': list(position),
                        'developedLength': length if seg['type'] == 'bend' else None})
        points.append(list(position))
    return points, mapping


def _sheet_representation(ctx, data, operation):
    representation = data.get('representation', 'external')
    if representation == 'native':
        return _sheet_contract(ctx, operation, {
            'representation': 'native', 'nativeFlatPattern': {'available': False,
                'reason': 'The public native flat-pattern API is a gated availability; it is not faked as a static solid or guessed. Use representation: external for the local recipe.'},
            'blocked': True}, status='blocked')
    if representation != 'external':
        raise ValueError('representation must be external or native')
    return None


# --- sheet.form ------------------------------------------------------------------

def _sheet_form(ctx, data):
    _cad_fields(data, ('thickness', 'segments'),
                ('fixedFace', 'representation', 'reliefs', 'grain', 'process', 'frame', 'schemaVersion'))
    if data.get('schemaVersion', 1) != 1:
        raise ValueError('sheet.form requires schemaVersion 1')
    blocked = _sheet_representation(ctx, data, 'sheet.form')
    if blocked is not None:
        return blocked
    thickness = ctx.length(data['thickness'])
    segments = _parse_segments(ctx, data['segments'])
    bends = ctx.call('sheet.bends', {'schemaVersion': 1, 'thickness': data['thickness'],
                                     'segments': data['segments'], 'fixedFace': data.get('fixedFace'),
                                     'reliefs': data.get('reliefs', []), 'grain': data.get('grain'),
                                     'process': data.get('process')})
    formed_points, formed_mapping = _formed_walk(ctx, segments, _sheet_neutral_radii(ctx, thickness, segments))
    flat_points, flat_mapping = _flat_walk(ctx, segments, _sheet_developed(ctx, thickness, segments))
    correspondence = [{'segment': fm['index'], 'flatPosition': f['position'],
                       'formedPosition': fm['position']}
                      for f, fm in zip(flat_mapping, formed_mapping)]
    return _sheet_contract(ctx, 'sheet.form', {
        'representation': 'external', 'thickness': thickness,
        'formedCenterline': formed_points, 'formedMapping': formed_mapping,
        'flatCenterline': flat_points, 'flatMapping': flat_mapping,
        'bendTable': bends['bendTable'], 'totalDevelopedLength': bends['totalDevelopedLength'],
        'correspondence': correspondence, 'association': 'external recipe; no native flat-pattern associativity',
        'nativeFlatPattern': {'available': False,
                              'reason': 'The public native flat-pattern API is a gated availability; not faked.'}})


# --- sheet.flat ------------------------------------------------------------------

def _sheet_flat(ctx, data):
    _cad_fields(data, ('thickness', 'segments'),
                ('fixedFace', 'representation', 'reliefs', 'grain', 'process', 'frame', 'schemaVersion'))
    if data.get('schemaVersion', 1) != 1:
        raise ValueError('sheet.flat requires schemaVersion 1')
    blocked = _sheet_representation(ctx, data, 'sheet.flat')
    if blocked is not None:
        return blocked
    thickness = ctx.length(data['thickness'])
    segments = _parse_segments(ctx, data['segments'])
    bends = ctx.call('sheet.bends', {'schemaVersion': 1, 'thickness': data['thickness'],
                                     'segments': data['segments'], 'fixedFace': data.get('fixedFace'),
                                     'reliefs': data.get('reliefs', []), 'grain': data.get('grain'),
                                     'process': data.get('process')})
    flat_points, flat_mapping = _flat_walk(ctx, segments, _sheet_developed(ctx, thickness, segments))
    formed_points, _ = _formed_walk(ctx, segments, _sheet_neutral_radii(ctx, thickness, segments))
    return _sheet_contract(ctx, 'sheet.flat', {
        'representation': 'external', 'thickness': thickness,
        'flatCenterline': flat_points, 'flatMapping': flat_mapping,
        'formedCenterline': formed_points, 'bendTable': bends['bendTable'],
        'totalDevelopedLength': bends['totalDevelopedLength'],
        'developedEqualsFormedNeutral': True, 'scaled': False,
        'correspondence': [{'segment': m['index'], 'flatPosition': m['position'],
                            'developedLength': m['developedLength']} for m in flat_mapping],
        'association': 'external recipe; no native flat-pattern associativity'})


CAD_HANDLERS.update({
    'sheet.bends': _sheet_bends,
    'sheet.form': _sheet_form,
    'sheet.flat': _sheet_flat,
})
