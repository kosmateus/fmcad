"""Bounded document metadata shared by full and lightweight status bundles."""


def _document_snapshot(doc):
    saved = doc.isSaved
    file = doc.dataFile if saved else None
    folder = file.parentFolder if file else None
    project = folder.parentProject if folder else None
    return {'name': doc.name, 'creationId': doc.creationId,
            'saved': saved, 'modified': doc.isModified,
            'fileId': file.id if file else None,
            'fileName': file.name if file else None,
            'version': getattr(file, 'versionNumber', None),
            'versionId': getattr(file, 'versionId', None),
            'isComplete': getattr(file, 'isComplete', None),
            'isReadOnly': getattr(file, 'isReadOnly', None),
            'folderId': folder.id if folder else None,
            'projectId': project.id if project else None}
