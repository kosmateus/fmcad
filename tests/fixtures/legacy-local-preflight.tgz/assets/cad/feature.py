"""GM09: feature parameter roles, typical extents and marker-restoring edits.

Roles are read from the feature structure (extent definitions, start definitions,
named parameter properties), never assumed from a generic label such as AlongDistance.
Structural extent edits roll the timeline marker to the feature and always restore it;
restore replays downstream features and never deletes geometry. Cross-component
extent targets are reported with explicit ownership and refused for edit without an
explicit proxy/transform context. See docs/FEATURE.md.
"""
import json
import re

import adsk.core
import adsk.fusion


def _feature_identity(ctx):
    ctx.assert_identity()
    return {'creationId': getattr(ctx.doc, 'creationId', None), 'name': ctx.doc.name}


def _feature_contract(ctx, operation, result, status='pass', associativity=None, warnings=None, limitations=None, **extra):
    ctx.assert_identity()
    return dict(schemaVersion=1, operation=operation, status=status, success=status == 'pass',
                documentIdentity=_feature_identity(ctx),
                units={'length': 'cm', 'angle': 'rad'}, frame={'space': 'component', 'component': ctx.ref(ctx.component)},
                associativity=result.pop('associativity', associativity or 'snapshot'),
                warnings=list(result.pop('warnings', warnings or [])),
                method='Feature structure readback and marker-restoring edits (GM09)',
                limitations=list(result.pop('limitations', limitations or [])),
                provenance={'requirement': 'GM09', 'source': 'docs/FEATURE.md'},
                affected=list(result.pop('affected', [])), **extra, **result)


def _feature_owner_check(ctx, feature):
    if getattr(feature, 'assemblyContext', None) is not None or (_cad_owner(feature) is not None and _cad_owner(feature) != ctx.component):
        raise ValueError('Feature commands require a native feature in the selected component')


def _feature_parameter(parameter, role, target=None, ownership=None):
    row = {'role': role, 'name': parameter.name, 'expression': parameter.expression,
           'unit': parameter.unit, 'value': parameter.value}
    if target is not None:
        row['target'] = target
    if ownership is not None:
        row['ownership'] = ownership
    return row


def _feature_target(ctx, entity):
    if entity is None:
        return {'status': 'none'}
    owner = _cad_owner(entity)
    occurrence = getattr(entity, 'assemblyContext', None)
    reference = ctx.ref(entity)
    if owner is None:
        return {'ref': reference, 'ownership': 'unknown', 'associativity': 'unknown', 'editable': False}
    if owner == ctx.component and occurrence is None:
        return {'ref': reference, 'ownership': 'local', 'associativity': 'nativeReference', 'editable': True}
    return {'ref': reference, 'ownership': 'foreign', 'associativity': 'nativeReference', 'editable': False,
            'occurrence': ctx.ref(occurrence) if occurrence is not None else None,
            'transform': 'not evaluated',
            'message': 'Cross-component entity: explicit proxy/transform/ownership is required; no fake associative copy is reported'}


def _feature_cast(name, value):
    cls = getattr(adsk.fusion, name, None)
    return None if cls is None or value is None else cls.cast(value)


def _feature_extrude_bindings(ctx, feature):
    bindings = []
    symmetric = _feature_cast('SymmetricExtentDefinition', getattr(feature, 'symmetricExtent', None))
    if symmetric is not None:
        if getattr(symmetric, 'distance', None) is not None:
            bindings.append((_feature_parameter(symmetric.distance, 'distance'), symmetric.distance))
        if getattr(symmetric, 'taperAngle', None) is not None:
            bindings.append((_feature_parameter(symmetric.taperAngle, 'taperAngle'), symmetric.taperAngle))
    for side, role in (('One', 'distance'), ('Two', 'distanceTwo')):
        extent = getattr(feature, 'extent' + side, None)
        distance = _feature_cast('DistanceExtentDefinition', extent)
        if distance is not None and getattr(distance, 'distance', None) is not None:
            bindings.append((_feature_parameter(distance.distance, role), distance.distance))
        to_entity = _feature_cast('ToEntityExtentDefinition', extent)
        if to_entity is not None:
            if getattr(to_entity, 'offset', None) is not None:
                bindings.append((_feature_parameter(to_entity.offset, 'offset' if side == 'One' else 'offsetTwo',
                    target=_feature_target(ctx, getattr(to_entity, 'entity', None))), to_entity.offset))
    start = getattr(feature, 'startExtent', None)
    offset_start = _feature_cast('OffsetStartDefinition', start)
    if offset_start is not None and getattr(offset_start, 'offset', None) is not None:
        bindings.append((_feature_parameter(offset_start.offset, 'startOffset'), offset_start.offset))
    from_entity = _feature_cast('FromEntityStartDefinition', start)
    if from_entity is not None and getattr(from_entity, 'offset', None) is not None:
        bindings.append((_feature_parameter(from_entity.offset, 'startEntityOffset',
            target=_feature_target(ctx, getattr(from_entity, 'entity', None))), from_entity.offset))
    for prop, role in (('taperAngleOne', 'taperAngle'), ('taperAngleTwo', 'taperAngleTwo')):
        parameter = getattr(feature, prop, None)
        if parameter is not None:
            bindings.append((_feature_parameter(parameter, role), parameter))
    return bindings


def _feature_revolve_bindings(ctx, feature):
    extent = _feature_cast('AngleExtentDefinition', getattr(feature, 'extentDefinition', None))
    angle = getattr(extent, 'angle', None) if extent is not None else None
    if angle is not None:
        return [(_feature_parameter(angle, 'angle'), angle)]
    two_sided = _feature_cast('TwoSidesAngleExtentDefinition', getattr(feature, 'extentDefinition', None))
    if two_sided is not None:
        return [(_feature_parameter(two_sided.angleOne, 'angle'), two_sided.angleOne),
                (_feature_parameter(two_sided.angleTwo, 'angleTwo'), two_sided.angleTwo)]
    return []


def _feature_hole_bindings(ctx, feature):
    bindings = []
    for prop, role in (('holeDiameter', 'diameter'), ('tipAngle', 'tipAngle'),
                       ('counterboreDiameter', 'counterboreDiameter'), ('counterboreDepth', 'counterboreDepth'),
                       ('countersinkDiameter', 'countersinkDiameter'), ('countersinkAngle', 'countersinkAngle')):
        parameter = getattr(feature, prop, None)
        if parameter is not None:
            bindings.append((_feature_parameter(parameter, role), parameter))
    extent = getattr(feature, 'extentDefinition', None)
    distance = _feature_cast('DistanceHoleExtentDefinition', extent)
    if distance is not None and getattr(distance, 'depth', None) is not None:
        bindings.append((_feature_parameter(distance.depth, 'depth'), distance.depth))
    to_entity = _feature_cast('ToEntityHoleExtentDefinition', extent)
    if to_entity is not None and getattr(to_entity, 'offset', None) is not None:
        bindings.append((_feature_parameter(to_entity.offset, 'offset',
            target=_feature_target(ctx, getattr(to_entity, 'entity', None))), to_entity.offset))
    return bindings


def _feature_edge_set_parameters(ctx, feature, collection_name, types):
    bindings = []
    edge_sets = getattr(feature, collection_name, None)
    if edge_sets is None:
        return bindings
    for index in range(getattr(edge_sets, 'count', 0)):
        edge_set = edge_sets.item(index)
        for class_name, properties in types:
            cls = getattr(adsk.fusion, class_name, None)
            typed = cls.cast(edge_set) if cls is not None else None
            if typed is None:
                continue
            for prop, role in properties:
                parameter = getattr(typed, prop, None)
                if parameter is not None and hasattr(parameter, 'expression'):
                    bindings.append((_feature_parameter(parameter, role), parameter))
            break
    return bindings


def _feature_fillet_bindings(ctx, feature):
    return _feature_edge_set_parameters(ctx, feature, 'edgeSets', (
        ('ConstantRadiusFilletEdgeSet', (('radius', 'radius'),)),
        ('ChordLengthFilletEdgeSet', (('chordLength', 'chordLength'),)),
        ('AsymmetricFilletEdgeSet', (('offsetOne', 'offsetOne'), ('offsetTwo', 'offsetTwo'))),
        ('VariableRadiusFilletEdgeSet', (('startRadius', 'startRadius'), ('endRadius', 'endRadius')))))


def _feature_chamfer_bindings(ctx, feature):
    return _feature_edge_set_parameters(ctx, feature, 'edgeSets', (
        ('EqualDistanceChamferEdgeSet', (('distance', 'distance'),)),
        ('TwoDistancesChamferEdgeSet', (('distanceOne', 'distanceOne'), ('distanceTwo', 'distanceTwo'))),
        ('DistanceAndAngleChamferEdgeSet', (('distance', 'distance'), ('angle', 'angle')))))


def _feature_misc_bindings(feature, fields):
    bindings = []
    for prop, role in fields:
        parameter = getattr(feature, prop, None)
        if parameter is not None and hasattr(parameter, 'expression'):
            bindings.append((_feature_parameter(parameter, role), parameter))
    return bindings


def _feature_pattern_bindings(feature, kind):
    fields = {
        'CircularPatternFeature': (('quantity', 'quantity'), ('totalAngle', 'angle')),
        'RectangularPatternFeature': (('quantityOne', 'quantity'), ('quantityTwo', 'quantityTwo'),
                                      ('distanceOne', 'distance'), ('distanceTwo', 'distanceTwo')),
        'PathPatternFeature': (('quantity', 'quantity'), ('distance', 'distance')),
    }
    return _feature_misc_bindings(feature, fields.get(kind, ()))


def _feature_sweep_bindings(ctx, feature):
    bindings = []
    for prop, role in (('twistAngle', 'twistAngle'), ('taperAngle', 'taperAngle')):
        parameter = getattr(feature, prop, None)
        if parameter is not None:
            bindings.append((_feature_parameter(parameter, role), parameter))
    return bindings


def _feature_bindings(ctx, feature):
    kind = _cad_type(feature)
    readers = {'ExtrudeFeature': _feature_extrude_bindings, 'RevolveFeature': _feature_revolve_bindings,
               'HoleFeature': _feature_hole_bindings, 'SweepFeature': _feature_sweep_bindings,
               'FilletFeature': _feature_fillet_bindings, 'ChamferFeature': _feature_chamfer_bindings,
               'ShellFeature': lambda c, f: _feature_misc_bindings(f, (('insideThickness', 'insideThickness'), ('outsideThickness', 'outsideThickness'))),
               'ThickenFeature': lambda c, f: _feature_misc_bindings(f, (('thickness', 'thickness'),)),
               'CircularPatternFeature': lambda c, f: _feature_pattern_bindings(f, kind),
               'RectangularPatternFeature': lambda c, f: _feature_pattern_bindings(f, kind),
               'PathPatternFeature': lambda c, f: _feature_pattern_bindings(f, kind)}
    bindings = readers[kind](ctx, feature) if kind in readers else []
    covered = {row['name'] for row, unused in bindings}
    parameters = getattr(getattr(ctx, 'design', None), 'allParameters', None)
    if parameters is not None:
        for parameter in _cad_items(parameters):
            if getattr(parameter, 'createdBy', None) == feature and parameter.name not in covered:
                bindings.append((_feature_parameter(parameter, 'unknown'), parameter))
    return bindings, kind in readers or kind in ('MirrorFeature', 'LoftFeature')


def _feature_extent_summary(ctx, feature, kind):
    summary = {}
    if kind == 'ExtrudeFeature':
        if getattr(feature, 'hasTwoExtents', False):
            summary['mode'] = 'twoSides'
            summary['distance'] = _feature_binding_row(ctx, feature, 'distance')
            summary['distanceTwo'] = _feature_binding_row(ctx, feature, 'distanceTwo')
        else:
            symmetric = _feature_cast('SymmetricExtentDefinition', getattr(feature, 'symmetricExtent', None))
            distance = _feature_cast('DistanceExtentDefinition', getattr(feature, 'extentOne', None))
            to_entity = _feature_cast('ToEntityExtentDefinition', getattr(feature, 'extentOne', None))
            through = _feature_cast('ThroughAllExtentDefinition', getattr(feature, 'extentOne', None))
            if symmetric is not None:
                summary['mode'] = 'symmetric'
                summary['distance'] = _feature_parameter(symmetric.distance, 'distance') if getattr(symmetric, 'distance', None) is not None else None
                summary['taperAngle'] = _feature_parameter(symmetric.taperAngle, 'taperAngle') if getattr(symmetric, 'taperAngle', None) is not None else None
            elif distance is not None:
                summary['mode'] = 'distance'
                summary['distance'] = _feature_parameter(distance.distance, 'distance') if getattr(distance, 'distance', None) is not None else None
            elif to_entity is not None:
                summary['mode'] = 'toEntity'
                summary['target'] = _feature_target(ctx, getattr(to_entity, 'entity', None))
                summary['offset'] = _feature_parameter(to_entity.offset, 'offset') if getattr(to_entity, 'offset', None) is not None else None
            elif through is not None:
                summary['mode'] = 'throughAll'
            else:
                summary['mode'] = 'unknown'
        offset_start = _feature_cast('OffsetStartDefinition', getattr(feature, 'startExtent', None))
        if offset_start is not None and getattr(offset_start, 'offset', None) is not None:
            summary['startOffset'] = _feature_parameter(offset_start.offset, 'startOffset')
    elif kind == 'RevolveFeature':
        extent_definition = getattr(feature, 'extentDefinition', None)
        extent = _feature_cast('AngleExtentDefinition', extent_definition)
        angle = getattr(extent, 'angle', None) if extent is not None else None
        two_sided = _feature_cast('TwoSidesAngleExtentDefinition', extent_definition)
        to_entity = _feature_cast('ToEntityExtentDefinition', extent_definition)
        if angle is not None:
            summary['mode'] = 'angle'
            summary['angle'] = _feature_parameter(angle, 'angle')
        elif two_sided is not None:
            summary['mode'] = 'twoSideAngle'
            summary['angle'] = _feature_parameter(two_sided.angleOne, 'angle')
            summary['angleTwo'] = _feature_parameter(two_sided.angleTwo, 'angleTwo')
        elif to_entity is not None:
            summary['mode'] = 'toEntity'
            summary['target'] = _feature_target(ctx, getattr(to_entity, 'entity', None))
        else:
            summary['mode'] = 'unknown'
    elif kind == 'HoleFeature':
        diameter = getattr(feature, 'holeDiameter', None)
        if diameter is not None:
            summary['diameter'] = _feature_parameter(diameter, 'diameter')
        extent = getattr(feature, 'extentDefinition', None)
        if _feature_cast('DistanceHoleExtentDefinition', extent) is not None:
            summary['mode'] = 'distance'
            if getattr(extent, 'depth', None) is not None:
                summary['depth'] = _feature_parameter(extent.depth, 'depth')
        elif _feature_cast('ThroughAllHoleExtentDefinition', extent) is not None:
            summary['mode'] = 'throughAll'
        elif _feature_cast('ToEntityHoleExtentDefinition', extent) is not None:
            summary['mode'] = 'toEntity'
            summary['target'] = _feature_target(ctx, getattr(extent, 'entity', None))
        else:
            summary['mode'] = 'unknown'
    else:
        summary['mode'] = 'unsupported'
    return summary


def _feature_binding_row(ctx, feature, role):
    for row, unused in _feature_extrude_bindings(ctx, feature):
        if row['role'] == role:
            return row
    return None


def _feature_snapshot(ctx, feature):
    kind = _cad_type(feature)
    bindings, structured = _feature_bindings(ctx, feature)
    timeline_object = getattr(feature, 'timelineObject', None)
    snapshot = {'feature': ctx.ref(feature), 'name': feature.name, 'type': kind,
                'healthState': int(feature.healthState), 'message': feature.errorOrWarningMessage,
                'isParametric': getattr(feature, 'isParametric', None), 'isSuppressed': getattr(feature, 'isSuppressed', None),
                'isSolid': getattr(feature, 'isSolid', None)}
    if timeline_object is not None and hasattr(timeline_object, 'index'):
        snapshot['timelineIndex'] = timeline_object.index
    snapshot['parameters'] = [row for row, unused in bindings]
    snapshot['extent'] = _feature_extent_summary(ctx, feature, kind)
    snapshot['roleSource'] = 'feature structure' if structured else 'unknown'
    capabilities = _feature_edit_capabilities(kind, snapshot['parameters'])
    if kind == 'FilletFeature':
        variant = getattr(feature, 'filletFeatureType', None)
        full_round = getattr(adsk.fusion.FilletFeatureTypes, 'FullRoundFilletFeatureType', None)
        capabilities['featureVariant'] = _cad_json(variant) if variant is not None else None
        if variant != full_round:
            capabilities['supported'] = [name for name in capabilities['supported'] if name != 'full-round face sets']
    snapshot['editCapabilities'] = capabilities
    snapshot['limitations'] = ['Roles are structural positions on this feature type; parameters the structure does not expose remain role unknown.',
                               'Target ownership is classified but foreign transforms are not evaluated.']
    return snapshot


_FEATURE_EDITABLE_NATIVE = {
    'ExtrudeFeature': ['profile', 'startExtent', 'extentOne', 'extentTwo', 'operation', 'participantBodies'],
    'RevolveFeature': ['profile', 'axis', 'signed/partial/full angle extent', 'two-side angle extent', 'one-side to-entity extent', 'operation', 'participantBodies'],
    'FilletFeature': ['edge-set edges/continuity/weight', 'constant/chord/variable/asymmetric parameters', 'variable mid-radius points', 'full-round face sets', 'rolling-ball corner'],
    'ChamferFeature': ['edge-set edges', 'edge-set tangent chain', 'edge-set variant parameters', 'cornerType'],
    'HoleFeature': ['diameter/depth model parameters', 'distance/through-all/to-entity extent', 'simple/counterbore/countersink type', 'position references', 'participantBodies'],
    'CircularPatternFeature': ['inputEntities', 'axis', 'isSymmetric', 'suppressedElementsIds'],
    'RectangularPatternFeature': ['inputEntities', 'directionOneEntity', 'directionTwoEntity', 'symmetric directions', 'patternDistanceType', 'suppressedElementsIds'],
    'PathPatternFeature': ['inputEntities', 'path', 'startPoint', 'isFlipDirection', 'patternDistanceType', 'isSymmetric', 'suppressedElementsIds'],
    'MirrorFeature': ['inputEntities', 'mirrorPlane', 'patternComputeOption'],
    'ShellFeature': ['inputEntities', 'inside/outside thickness', 'tangent-chain selection', 'shellType'],
    'SweepFeature': ['profile', 'path', 'orientation', 'guideRail', 'guide surfaces', 'direction flip', 'operation', 'participantBodies'],
    'LoftFeature': ['loft section entities/order', 'rail/centerline entities', 'section end conditions', 'closed/tangent merge', 'start/end edge alignment', 'operation', 'participantBodies'],
    'ThickenFeature': ['inputFaces', 'thickness model parameter (signed expression controls direction)', 'isSymmetric', 'operation', 'thickenType', 'tangent-chain selection'],
}


_FEATURE_UNSUPPORTED_NATIVE = {
    'ExtrudeFeature': ['thin-extrude conversion and unsupported feature-type conversion are refused'],
    'RevolveFeature': ['direction is controlled by signed angle; a separate direction property is unsupported', 'two-side to-entity extent is not offered because the installed SDK definitions expose no stable extent readback type'],
    'FilletFeature': ['feature operation change and convert-to/from-fillet-variant are unsupported; full-round face sets can only be edited on an existing full-round feature'],
    'ChamferFeature': ['feature operation/type conversion is unsupported; edit only the existing edge-set variants'],
    'HoleFeature': ['feature operation change, clearance/tapped-hole variants and transient Point3D positions are unsupported; use native sketch/edge references'],
    'CircularPatternFeature': ['FeatureOperations conversion is not exposed; pattern feature-type conversion is unsupported'],
    'RectangularPatternFeature': ['FeatureOperations conversion is not exposed; pattern feature-type conversion is unsupported'],
    'PathPatternFeature': ['FeatureOperations conversion is not exposed; pattern feature-type conversion is unsupported'],
    'MirrorFeature': ['FeatureOperations conversion is not exposed; mirror feature-type conversion is unsupported'],
    'ShellFeature': ['FeatureOperations conversion is not exposed; shell feature-type conversion is unsupported'],
    'SweepFeature': ['profileScaling and solidBody/solid-axis conversion are unsupported; setting solidBody clears existing profile/path references'],
    'LoftFeature': ['changing section or rail count is refused; same-count edits preserve feature lineage'],
    'ThickenFeature': ['the installed in-place API exposes no separate direction setter; one-sided direction follows selected face normals'],
}

_FEATURE_OPERATION_CHANGE_TYPES = ('ExtrudeFeature', 'RevolveFeature', 'SweepFeature', 'LoftFeature', 'ThickenFeature')


def _feature_edit_capabilities(kind, parameters):
    supported = list(_FEATURE_EDITABLE_NATIVE.get(kind, []))
    if parameters:
        supported.append('entries: exact owned ModelParameter expressions (listed in parameters)')
    unsupported = list(_FEATURE_UNSUPPORTED_NATIVE.get(kind, []))
    if kind not in _FEATURE_NATIVE_FIELDS:
        unsupported.append('type-specific nativeEdits are unsupported for ' + kind)
    return {'supported': supported,
            'modelParameters': [{'name': row['name'], 'role': row['role'], 'unit': row['unit']} for row in parameters],
            'unsupported': unsupported}


@_cad_scoped_step('feature.inspect', native_only=True)
def _feature_inspect(ctx, data):
    _cad_fields(data, ('schemaVersion', 'frame', 'feature'), ())
    if data['schemaVersion'] != 1 or data['frame'] != 'component':
        raise ValueError('GM09 feature commands require schemaVersion:1 and frame:component')
    feature = ctx.resolve(data['feature'], 'feature')
    _feature_owner_check(ctx, feature)
    return _feature_contract(ctx, 'feature.inspect', _feature_snapshot(ctx, feature), associativity='nativeReference')


def _feature_extent_plan(ctx, feature, before, spec):
    kind = _cad_type(feature)
    if kind == 'ExtrudeFeature':
        _cad_fields(spec, ('mode',), ('distance', 'distanceTwo', 'startOffset', 'taper', 'taperTwo', 'target', 'offset', 'direction', 'isFullLength'))
        mode = spec['mode']
        if mode not in ('distance', 'throughAll', 'toEntity', 'symmetric', 'twoSides'):
            raise ValueError('Extrude extent mode must be distance, throughAll, toEntity, symmetric or twoSides')
        if (mode in ('distance', 'symmetric', 'twoSides')) != ('distance' in spec):
            raise ValueError('distance is required for distance/symmetric/twoSides and forbidden otherwise')
        if (mode == 'twoSides') != ('distanceTwo' in spec):
            raise ValueError('distanceTwo is required for twoSides and forbidden otherwise')
        if (mode == 'toEntity') != ('target' in spec):
            raise ValueError('target is required for toEntity and forbidden otherwise')
        if mode != 'twoSides' and 'taperTwo' in spec:
            raise ValueError('taperTwo requires twoSides')
        if 'direction' in spec and spec['direction'] not in ('positive', 'negative'):
            raise ValueError('direction must be positive or negative')
        for key in ('distance', 'distanceTwo', 'startOffset', 'offset'):
            if key in spec:
                ctx.length(spec[key])
        for key in ('taper', 'taperTwo'):
            if key in spec:
                ctx.angle(spec[key])
        if 'isFullLength' in spec and mode != 'symmetric':
            raise ValueError('isFullLength requires symmetric mode')
        if 'isFullLength' in spec and type(spec['isFullLength']) is not bool:
            raise TypeError('isFullLength must be boolean')
        plan = {'kind': kind, 'mode': mode}
        if mode == 'toEntity':
            target = ctx.resolve(spec['target'])
            if not any(cls.cast(target) for cls in (adsk.fusion.ConstructionPlane, adsk.fusion.BRepFace, adsk.fusion.BRepBody)):
                raise ValueError('toEntity target must be a construction plane, face or body')
            ownership = _feature_target(ctx, target)
            if ownership.get('ownership') != 'local':
                raise ValueError('Cross-component extent target is refused: explicit proxy/transform/ownership is required, no fake associative copy is created')
            # Keep the already-resolved native entity, not a ref/token: the
            # token is invalidated by timelineObject.rollTo before apply runs.
            plan['target'] = target
        return plan
    if kind == 'RevolveFeature':
        _cad_fields(spec, ('mode',), ('angle', 'angleTwo', 'target', 'symmetric'))
        mode = spec['mode']
        allowed_modes = ('angle', 'twoSideAngle', 'toEntity')
        if mode not in allowed_modes:
            raise ValueError('Revolve extent mode must be angle, twoSideAngle or toEntity')
        if 'symmetric' in spec and (mode != 'angle' or type(spec['symmetric']) is not bool):
            raise ValueError('symmetric is a boolean for angle revolve extent only')
        for key in ('angle', 'angleTwo'):
            if key in spec:
                ctx.angle(spec[key])
        if (mode in ('angle', 'twoSideAngle')) != ('angle' in spec):
            raise ValueError('angle is required for angle/twoSideAngle revolve extent')
        if (mode == 'twoSideAngle') != ('angleTwo' in spec):
            raise ValueError('angleTwo is required for twoSideAngle extent')
        if mode == 'toEntity':
            if 'target' not in spec:
                raise ValueError('target is required for toEntity revolve extent')
            target = ctx.resolve(spec['target'])
            if not any(cls.cast(target) for cls in (adsk.fusion.BRepBody, adsk.fusion.BRepFace, adsk.fusion.BRepVertex,
                                                     adsk.fusion.ConstructionPlane, adsk.fusion.ConstructionPoint)):
                raise ValueError('Revolve target must be a body, face, vertex, plane or point')
            if _feature_target(ctx, target).get('ownership') != 'local':
                raise ValueError('Cross-component revolve targets are refused')
            return {'kind': kind, 'mode': mode, 'target': target}
        return {'kind': kind, 'mode': mode}
    if kind == 'HoleFeature':
        _cad_fields(spec, ('mode',), ('distance', 'target', 'reverse', 'matchShape'))
        mode = spec['mode']
        if mode not in ('distance', 'throughAll', 'toEntity'):
            raise ValueError('Hole extent mode must be distance, throughAll or toEntity')
        if (mode == 'distance') != ('distance' in spec):
            raise ValueError('distance is required only for distance hole extent')
        if 'distance' in spec:
            ctx.length(spec['distance'])
        if (mode == 'toEntity') != ('target' in spec):
            raise ValueError('target is required only for toEntity hole extent')
        if 'reverse' in spec and type(spec['reverse']) is not bool:
            raise TypeError('Hole reverse must be boolean')
        if mode == 'toEntity' and 'reverse' in spec:
            raise ValueError('toEntity hole extent infers direction; reverse is unsupported')
        if 'matchShape' in spec and (mode != 'toEntity' or type(spec['matchShape']) is not bool):
            raise ValueError('matchShape is a boolean for toEntity hole extent only')
        if mode == 'toEntity':
            target = ctx.resolve(spec['target'])
            if not any(cls.cast(target) for cls in (adsk.fusion.BRepBody, adsk.fusion.BRepFace, adsk.fusion.BRepVertex,
                                                     adsk.fusion.ConstructionPlane, adsk.fusion.ConstructionPoint)):
                raise ValueError('Hole target must be a body, face, vertex, plane or point')
            if _feature_target(ctx, target).get('ownership') != 'local':
                raise ValueError('Cross-component hole targets are refused')
            return {'kind': kind, 'mode': mode, 'target': target}
        return {'kind': kind, 'mode': mode}
    raise ValueError('Extent editing is unsupported for feature type ' + kind + '; use parameter entries')


def _feature_apply_extent(ctx, feature, spec, plan):
    kind = plan['kind']
    if kind == 'ExtrudeFeature':
        direction = getattr(adsk.fusion.ExtentDirections, 'PositiveExtentDirection' if spec.get('direction', 'positive') == 'positive' else 'NegativeExtentDirection')
        if plan['mode'] == 'distance':
            definition = adsk.fusion.DistanceExtentDefinition.create(ctx.value(spec['distance']))
            _cad_require_result(feature.setOneSideExtent(definition, direction, ctx.value(spec.get('taper', '0 deg'))), 'setOneSideExtent')
        elif plan['mode'] == 'throughAll':
            definition = adsk.fusion.ThroughAllExtentDefinition.create()
            _cad_require_result(feature.setOneSideExtent(definition, direction, ctx.value(spec.get('taper', '0 deg'))), 'setOneSideExtent')
        elif plan['mode'] == 'toEntity':
            definition = adsk.fusion.ToEntityExtentDefinition.create(plan['target'], False)
            if 'offset' in spec:
                definition.offset = ctx.value(spec['offset'])
            _cad_require_result(feature.setOneSideExtent(definition, direction, ctx.value(spec.get('taper', '0 deg'))), 'setOneSideExtent')
        elif plan['mode'] == 'symmetric':
            _cad_require_result(feature.setSymmetricExtent(ctx.value(spec['distance']), spec.get('isFullLength', True), ctx.value(spec.get('taper', '0 deg'))), 'setSymmetricExtent')
        else:
            one = adsk.fusion.DistanceExtentDefinition.create(ctx.value(spec['distance']))
            two = adsk.fusion.DistanceExtentDefinition.create(ctx.value(spec['distanceTwo']))
            _cad_require_result(feature.setTwoSidesExtent(one, two, ctx.value(spec.get('taper', '0 deg')), ctx.value(spec.get('taperTwo', '0 deg'))), 'setTwoSidesExtent')
        if 'startOffset' in spec:
            feature.startExtent = adsk.fusion.OffsetStartDefinition.create(ctx.value(spec['startOffset']))
    elif kind == 'RevolveFeature':
        if plan['mode'] == 'angle':
            _cad_require_result(feature.setAngleExtent(spec.get('symmetric', False), ctx.value(spec['angle'])), 'setAngleExtent')
        elif plan['mode'] == 'twoSideAngle':
            _cad_require_result(feature.setTwoSideAngleExtent(ctx.value(spec['angle']), ctx.value(spec['angleTwo'])), 'setTwoSideAngleExtent')
        elif plan['mode'] == 'toEntity':
            _cad_require_result(feature.setOneSideToExtent(plan['target']), 'setOneSideToExtent')
        else:
            _cad_require_result(feature.setOneSideToExtent(plan['target']), 'setOneSideToExtent')
    elif kind == 'HoleFeature':
        if plan['mode'] == 'distance':
            _cad_require_result(feature.setDistanceExtent(ctx.value(spec['distance'])), 'setDistanceExtent')
            feature.isDefaultDirection = not spec.get('reverse', False)
        elif plan['mode'] == 'throughAll':
            direction = getattr(adsk.fusion.ExtentDirections, 'PositiveExtentDirection' if spec.get('reverse', False) else 'NegativeExtentDirection')
            _cad_require_result(feature.setAllExtent(direction), 'setAllExtent')
            feature.isDefaultDirection = not spec.get('reverse', False)
        else:
            _cad_require_result(feature.setOneSideToExtent(plan['target'], spec.get('matchShape', False)), 'setOneSideToExtent')
    else:
        raise ValueError('Unsupported extent application for feature type ' + kind)


def _feature_downstream(ctx, feature):
    timeline = getattr(getattr(ctx, 'design', None), 'timeline', None)
    if timeline is None:
        return {'status': 'unknown', 'scanned': 0, 'unhealthy': [], 'limitation': 'timeline not exposed by the installed SDK'}
    index = getattr(getattr(feature, 'timelineObject', None), 'index', None)
    unhealthy, scanned = [], 0
    for i in range(timeline.count):
        if index is not None and i <= index:
            continue
        scanned += 1
        item = timeline.item(i)
        if int(item.healthState) != 0:
            unhealthy.append({'name': item.name, 'healthState': int(item.healthState), 'message': item.errorOrWarningMessage})
    return {'status': 'fail' if unhealthy else ('pass' if index is not None else 'unknown'), 'scanned': scanned, 'unhealthy': unhealthy}


def _feature_operation_pose_snapshot(ctx):
    root = getattr(getattr(ctx, 'design', None), 'rootComponent', None)
    occurrences = getattr(root, 'allOccurrences', None)
    if occurrences is None:
        return None
    rows = []
    for occurrence in _cad_items(occurrences):
        if getattr(occurrence, 'component', None) != ctx.component:
            continue
        transform = getattr(occurrence, 'transform2', None)
        if transform is None or not hasattr(transform, 'asArray'):
            return None
        rows.append((occurrence, tuple(transform.asArray())))
    return rows


_FEATURE_NATIVE_FIELDS = {
    'ExtrudeFeature': ('profile',),
    'RevolveFeature': ('profile', 'axis'),
    'FilletFeature': ('edgeSets', 'fullRoundFaceSets', 'isRollingBallCorner'),
    'ChamferFeature': ('edgeSets', 'cornerType'),
    'HoleFeature': ('holeType', 'position', 'participants'),
    'CircularPatternFeature': ('entities', 'axis', 'isSymmetric', 'suppressedElementsIds', 'patternComputeOption'),
    'RectangularPatternFeature': ('entities', 'directionOneEntity', 'directionTwoEntity', 'isSymmetricInDirectionOne', 'isSymmetricInDirectionTwo', 'patternDistanceType', 'suppressedElementsIds'),
    'PathPatternFeature': ('entities', 'path', 'startPoint', 'isFlipDirection', 'patternDistanceType', 'isSymmetric', 'suppressedElementsIds'),
    'MirrorFeature': ('entities', 'mirrorPlane', 'patternComputeOption'),
    'ShellFeature': ('entities', 'insideThickness', 'outsideThickness', 'isTangentChain', 'shellType'),
    'SweepFeature': ('profile', 'path', 'orientation', 'guideRail', 'isDirectionFlipped', 'guideSurfaces', 'isChainSelection', 'participants'),
    'LoftFeature': ('sections', 'rails', 'centerLine', 'sectionConditions', 'isClosed', 'isTangentEdgesMerged', 'startLoftEdgeAlignment', 'endLoftEdgeAlignment', 'participants'),
    'ThickenFeature': ('entities', 'isSymmetric', 'thickenType', 'isChainSelection'),
}


def _feature_native_ref(ctx, ref, kind=None):
    entity = ctx.resolve(ref, kind)
    if getattr(entity, 'assemblyContext', None) is not None or (_cad_owner(entity) is not None and _cad_owner(entity) != ctx.component):
        raise ValueError('Native feature edits require references owned by the selected component')
    return entity


def _feature_native_path(ctx, value):
    if isinstance(value, dict) and 'curves' in value:
        return _model_path(ctx, value)
    path = _feature_native_ref(ctx, value)
    if _cad_type(path) != 'Path':
        raise ValueError('Path refs must resolve to a native Path or explicit curve-path descriptor')
    return path


def _feature_native_collection(ctx, refs, kind=None, expected_type=None):
    if not isinstance(refs, list) or not refs:
        raise ValueError('Native selection must be a nonempty reference array')
    entities = [_feature_native_ref(ctx, ref, kind) for ref in refs]
    kinds = {_cad_type(entity) for entity in entities}
    if expected_type is not None and any(not expected_type.cast(entity) for entity in entities):
        raise ValueError('Native selection contains an unsupported reference type')
    if expected_type is None and len(kinds) > 1:
        raise ValueError('Native selections must contain a homogeneous entity type')
    if len(entities) > 1 and kinds <= {'ConstructionAxis', 'ConstructionPlane', 'ConstructionPoint'}:
        raise ValueError('Only one construction entity can be selected')
    return entities


def _feature_native_object_collection(entities):
    collection = adsk.core.ObjectCollection.create()
    for entity in entities:
        collection.add(entity)
    return collection


def _feature_native_is(entity, names):
    return any(_feature_cast(name, entity) is not None for name in names)


def _feature_validate_hole_position(ctx, spec):
    if not isinstance(spec, dict) or not isinstance(spec.get('mode'), str):
        raise ValueError('hole position requires a mode')
    mode = spec['mode']
    if mode == 'point':
        raise ValueError('Point3D hole positions are non-associative and unsupported; use native sketch/edge reference modes')
    fields = {
        'sketchPoint': (('point',), ()),
        'sketchPoints': (('points',), ()),
        'point': (('plane', 'point'), ()),
        'center': (('plane', 'edge'), ()),
        'offsets': (('plane', 'point', 'edgeOne', 'offsetOne'), ('edgeTwo', 'offsetTwo')),
        'onEdge': (('plane', 'edge', 'position'), ()),
    }
    if mode not in fields:
        raise ValueError('Unsupported hole position mode: ' + mode)
    required, optional = fields[mode]
    _cad_fields(spec, ('mode',) + required, optional)
    if mode == 'offsets' and (('edgeTwo' in spec) != ('offsetTwo' in spec)):
        raise ValueError('edgeTwo and offsetTwo must be supplied together')
    resolved = {'mode': mode}
    kind_by_key = {'point': 'point', 'points': 'point', 'plane': None, 'edge': 'edge',
                   'edgeOne': 'edge', 'edgeTwo': 'edge'}
    for key in required + optional:
        if key not in spec:
            continue
        if key in ('point',) and mode == 'point':
            point = spec[key]
            if not isinstance(point, list) or len(point) != 3:
                raise ValueError('point must be a three-coordinate array')
            for coordinate in point:
                ctx.length(coordinate)
            resolved[key] = point
        elif key in ('offsetOne', 'offsetTwo'):
            ctx.length(spec[key])
            resolved[key] = spec[key]
        elif key == 'position':
            if spec[key] not in ('start', 'end', 'middle'):
                raise ValueError('onEdge position must be start, end or middle')
            resolved[key] = spec[key]
        elif key == 'points':
            points = _feature_native_collection(ctx, spec[key], 'point')
            if any(not adsk.fusion.SketchPoint.cast(point) for point in points):
                raise ValueError('Hole sketchPoints position requires native SketchPoint refs')
            resolved[key] = points
        else:
            entity = _feature_native_ref(ctx, spec[key], kind_by_key.get(key))
            if key == 'point' and mode == 'sketchPoint' and not adsk.fusion.SketchPoint.cast(entity):
                raise ValueError('sketchPoint position requires a SketchPoint ref')
            if key == 'plane' and not (adsk.fusion.ConstructionPlane.cast(entity) or adsk.fusion.BRepFace.cast(entity)):
                raise ValueError('Hole position plane must be a construction plane or planar face')
            if key in ('edge', 'edgeOne', 'edgeTwo') and not adsk.fusion.BRepEdge.cast(entity):
                raise ValueError('Hole position edge refs must be BRepEdge objects')
            if key in ('edgeOne', 'edgeTwo') and not adsk.core.Line3D.cast(entity.geometry):
                raise ValueError('Hole offset edges must be linear BRepEdges')
            if key == 'edge' and mode == 'center' and not (adsk.core.Circle3D.cast(entity.geometry) or adsk.core.Ellipse3D.cast(entity.geometry)):
                raise ValueError('Hole center position requires a circular or elliptical edge')
            resolved[key] = entity
    return resolved


def _feature_native_enum(enum_class, name_map, value, label):
    if not isinstance(value, str) or value not in name_map:
        raise ValueError(label + ' must be one of ' + ', '.join(sorted(name_map)))
    member = getattr(enum_class, name_map[value], None)
    if member is None:
        raise ValueError(label + ' value is unavailable in this Fusion SDK: ' + value)
    return member


def _feature_native_plan(ctx, feature, spec):
    kind = _cad_type(feature)
    if kind not in _FEATURE_NATIVE_FIELDS:
        raise ValueError('nativeEdits is unsupported for feature type ' + kind)
    if not isinstance(spec, dict) or not spec:
        raise ValueError('nativeEdits must be a nonempty object')
    unknown = [key for key in spec if key not in _FEATURE_NATIVE_FIELDS[kind]]
    if unknown:
        raise ValueError('Unsupported nativeEdits for ' + kind + ': ' + ', '.join(unknown))
    if kind == 'FilletFeature':
        full_round = getattr(adsk.fusion.FilletFeatureTypes, 'FullRoundFilletFeatureType', None)
        is_full_round = getattr(feature, 'filletFeatureType', None) == full_round
        if is_full_round and 'edgeSets' in spec:
            raise ValueError('Existing full-round fillets use fullRoundFaceSets, not edgeSets')
        if not is_full_round and 'fullRoundFaceSets' in spec:
            raise ValueError('fullRoundFaceSets applies only to an existing full-round FilletFeature')
    resolved, summary = {}, {}
    ref_fields = {'axis', 'directionOneEntity', 'directionTwoEntity', 'mirrorPlane', 'solidAlignedAxis', 'solidTwistAxis'}
    for key, value in spec.items():
        if key in ('entities', 'participants', 'guideSurfaces'):
            required_kind = 'body' if key == 'participants' else ('face' if key == 'guideSurfaces' else None)
            if kind in ('ShellFeature', 'ThickenFeature') and key == 'entities':
                if not isinstance(value, list) or not value:
                    raise ValueError('entities must be a nonempty reference array')
                items = [_feature_native_ref(ctx, ref) for ref in value]
                if kind == 'ShellFeature' and any(not (adsk.fusion.BRepBody.cast(item) or adsk.fusion.BRepFace.cast(item)) for item in items):
                    raise ValueError('Shell entities must be bodies and/or faces')
                if kind == 'ShellFeature':
                    bodies = [adsk.fusion.BRepBody.cast(item) for item in items if adsk.fusion.BRepBody.cast(item)]
                    faces = [adsk.fusion.BRepFace.cast(item) for item in items if adsk.fusion.BRepFace.cast(item)]
                    if any(getattr(face, 'body', None) == body for face in faces for body in bodies):
                        raise ValueError('Shell selections cannot include both a body and one of its faces')
                if kind == 'ThickenFeature' and any(not (adsk.fusion.BRepBody.cast(item) or adsk.fusion.BRepFace.cast(item)) for item in items):
                    raise ValueError('Thicken entities must be faces or patch bodies')
            else:
                items = _feature_native_collection(ctx, value, required_kind)
            resolved[key] = items
            summary[key] = [ctx.ref(entity) for entity in items]
        elif key in ref_fields:
            entity = None if value is None and key == 'directionTwoEntity' else _feature_native_ref(ctx, value)
            expected = {
                'axis': ('ConstructionAxis', 'SketchLine', 'BRepEdge', 'BRepFace'),
                'directionOneEntity': ('ConstructionAxis', 'SketchLine', 'BRepEdge', 'RectangularPatternFeature'),
                'directionTwoEntity': ('ConstructionAxis', 'SketchLine', 'BRepEdge', 'RectangularPatternFeature'),
                'mirrorPlane': ('ConstructionPlane', 'BRepFace'),
                'solidAlignedAxis': ('ConstructionAxis', 'SketchLine', 'BRepEdge'),
                'solidTwistAxis': ('ConstructionAxis', 'SketchLine', 'BRepEdge', 'BRepFace'),
            }.get(key)
            if entity is not None and expected is not None and not _feature_native_is(entity, expected):
                raise ValueError(key + ' has an unsupported reference type for ' + kind)
            resolved[key] = entity
            summary[key] = ctx.ref(entity) if entity is not None else None
        elif key in ('profile', 'solidBody'):
            entity = _feature_native_ref(ctx, value, 'body' if key == 'solidBody' else None)
            if key == 'profile' and not any(getattr(cls, 'cast', lambda _: None)(entity) for cls in (adsk.fusion.Profile, adsk.fusion.BRepFace)):
                raise ValueError('profile must resolve to a Profile or planar face')
            resolved[key] = entity
            summary[key] = ctx.ref(entity)
        elif key in ('path', 'guideRail'):
            if value is None and key == 'guideRail':
                path = None
            else:
                path = _feature_native_path(ctx, value)
            resolved[key] = path
            summary[key] = {'kind': 'path', 'curves': len(value.get('curves', []))} if isinstance(value, dict) else (ctx.ref(path) if path is not None else None)
        elif key == 'suppressedElementsIds':
            if not isinstance(value, list) or any(type(item) is not int or item < 0 for item in value):
                raise ValueError('suppressedElementsIds must be an array of nonnegative integers')
            current_ids = {int(item.id) for item in _cad_items(getattr(feature, 'patternElements', []))}
            if any(item not in current_ids for item in value):
                raise ValueError('suppressedElementsIds must refer to existing pattern element ids')
            resolved[key] = list(value)
            summary[key] = list(value)
        elif key == 'startPoint':
            if type(value) not in (float, int) or not 0 <= value <= 1:
                raise ValueError('startPoint must be a number between 0 and 1')
            resolved[key] = float(value)
            summary[key] = float(value)
        elif key in ('operation', 'cornerType', 'patternDistanceType', 'shellType', 'orientation', 'solidOrientation', 'thickenType', 'startLoftEdgeAlignment', 'endLoftEdgeAlignment', 'patternComputeOption'):
            enums = {
                'operation': ('FeatureOperations', {'newBody': 'NewBodyFeatureOperation', 'join': 'JoinFeatureOperation', 'cut': 'CutFeatureOperation', 'intersect': 'IntersectFeatureOperation'}),
                'cornerType': ('ChamferCornerTypes', {'chamfer': 'ChamferCornerType', 'miter': 'MiterCornerType', 'blend': 'BlendCornertype'}),
                'patternDistanceType': ('PatternDistanceType', {'spacing': 'SpacingPatternDistanceType', 'extent': 'ExtentPatternDistanceType'}),
                'shellType': ('ShellTypes', {'sharpOffset': 'SharpOffsetShellType', 'roundedOffset': 'RoundedOffsetShellType'}),
                'orientation': ('SweepOrientationTypes', {'perpendicular': 'PerpendicularOrientationType', 'parallel': 'ParallelOrientationType'}),
                'solidOrientation': ('SweepSolidOrientationTypes', {'perpendicular': 'PerpendicularSolidOrientationType', 'aligned': 'AlignedSolidOrientationType'}),
                'thickenType': ('ThickenTypes', {'sharp': 'SharpThickenType', 'rounded': 'RoundedThickenType'}),
                'startLoftEdgeAlignment': ('LoftEdgeAlignments', {'free': 'FreeEdgesLoftEdgeAlignment', 'align': 'AlignEdgesLoftEdgeAlignment', 'alignToSurface': 'AlignToSurfaceLoftEdgeAlignment'}),
                'endLoftEdgeAlignment': ('LoftEdgeAlignments', {'free': 'FreeEdgesLoftEdgeAlignment', 'align': 'AlignEdgesLoftEdgeAlignment', 'alignToSurface': 'AlignToSurfaceLoftEdgeAlignment'}),
                'patternComputeOption': ('PatternComputeOptions', {'optimized': 'OptimizedPatternCompute', 'identical': 'IdenticalPatternCompute', 'adjust': 'AdjustPatternCompute'}),
            }
            enum_name, names = enums[key]
            enum_class = getattr(adsk.fusion, enum_name, None)
            if enum_class is None:
                raise ValueError(key + ' is not supported by this Fusion SDK')
            resolved[key] = _feature_native_enum(enum_class, names, value, key)
            summary[key] = value
        elif key in ('isSymmetric', 'isSymmetricInDirectionOne', 'isSymmetricInDirectionTwo', 'isClosed', 'isTangentEdgesMerged', 'isTangentChain', 'isChainSelection', 'isDirectionFlipped', 'isRollingBallCorner'):
            if type(value) is not bool:
                raise TypeError(key + ' must be boolean')
            resolved[key] = value
            summary[key] = value
        elif key == 'edgeSets':
            if not isinstance(value, list) or not value:
                raise ValueError('edgeSets must be a nonempty array')
            existing_sets = getattr(feature, 'edgeSets', None)
            existing_count = getattr(existing_sets, 'count', 0)
            rows = []
            seen_indices = set()
            for row in value:
                if not isinstance(row, dict) or 'index' not in row or type(row['index']) is not int or row['index'] < 0:
                    raise ValueError('each edgeSets row requires a nonnegative index')
                if row['index'] >= existing_count:
                    raise ValueError('edgeSets index is outside the existing feature edge sets')
                if row['index'] in seen_indices:
                    raise ValueError('edgeSets indices must be unique')
                seen_indices.add(row['index'])
                allowed = {'index', 'edges', 'tangentChain', 'continuity', 'tangencyWeight', 'radius', 'chordLength', 'startRadius', 'endRadius', 'offsetOne', 'offsetTwo', 'midRadii', 'midPositions', 'distance', 'distanceOne', 'distanceTwo', 'angle', 'isFlipped'}
                unexpected = set(row) - allowed
                if unexpected:
                    raise ValueError('Unsupported edgeSets fields: ' + ', '.join(sorted(unexpected)))
                existing_set = existing_sets.item(row['index'])
                edge_set_type = _cad_type(existing_set)
                field_variants = ({'radius': ('ConstantRadiusFilletEdgeSet',), 'chordLength': ('ChordLengthFilletEdgeSet',),
                                   'startRadius': ('VariableRadiusFilletEdgeSet',), 'endRadius': ('VariableRadiusFilletEdgeSet',),
                                   'offsetOne': ('AsymmetricFilletEdgeSet',), 'offsetTwo': ('AsymmetricFilletEdgeSet',),
                                   'isFlipped': ('AsymmetricFilletEdgeSet',),
                                   'midRadii': ('VariableRadiusFilletEdgeSet',), 'midPositions': ('VariableRadiusFilletEdgeSet',)}
                                  if kind == 'FilletFeature' else
                                  {'distance': ('EqualDistanceChamferEdgeSet', 'DistanceAndAngleChamferEdgeSet'),
                                   'distanceOne': ('TwoDistancesChamferEdgeSet',), 'distanceTwo': ('TwoDistancesChamferEdgeSet',),
                                   'angle': ('DistanceAndAngleChamferEdgeSet',), 'isFlipped': ('TwoDistancesChamferEdgeSet', 'DistanceAndAngleChamferEdgeSet')})
                for field, allowed_types in field_variants.items():
                    if field in row and edge_set_type not in allowed_types:
                        raise ValueError(field + ' is unsupported for existing edge-set variant ' + edge_set_type)
                item = dict(row)
                if 'edges' in row:
                    if not isinstance(row['edges'], list) or not row['edges']:
                        raise ValueError('edgeSets.edges must be a nonempty reference array')
                    item['edges'] = [_feature_native_ref(ctx, ref) for ref in row['edges']]
                    if kind == 'FilletFeature' and any(not (adsk.fusion.BRepEdge.cast(e) or adsk.fusion.BRepFace.cast(e) or _cad_type(e).endswith('Feature')) for e in item['edges']):
                        raise ValueError('Fillet edge sets accept BRepEdge, BRepFace or feature refs')
                    if kind == 'ChamferFeature' and any(not (adsk.fusion.BRepEdge.cast(e) or adsk.fusion.BRepFace.cast(e) or _cad_type(e).endswith('Feature')) for e in item['edges']):
                        raise ValueError('Chamfer edge sets accept BRepEdge, BRepFace or feature refs')
                for field in ('radius', 'chordLength', 'startRadius', 'endRadius', 'offsetOne', 'offsetTwo', 'distance', 'distanceOne', 'distanceTwo'):
                    if field in row:
                        ctx.length(row[field])
                for field in ('angle',):
                    if field in row:
                        ctx.angle(row[field])
                if 'continuity' in row:
                    if row['continuity'] not in ('tangent', 'curvature'):
                        raise ValueError('continuity must be tangent or curvature')
                    item['continuity'] = _feature_native_enum(adsk.fusion.SurfaceContinuityTypes,
                        {'tangent': 'TangentSurfaceContinuityType', 'curvature': 'CurvatureSurfaceContinuityType'}, row['continuity'], 'continuity')
                if 'tangencyWeight' in row and (type(row['tangencyWeight']) not in (int, float) or not 0.1 <= row['tangencyWeight'] <= 2.0):
                    raise ValueError('tangencyWeight must be unitless in range 0.1..2.0')
                if 'midRadii' in row or 'midPositions' in row:
                    radii, positions = row.get('midRadii'), row.get('midPositions')
                    if not isinstance(radii, list) or not isinstance(positions, list) or len(radii) != len(positions):
                        raise ValueError('midRadii and midPositions must be equally sized arrays')
                    for radius in radii:
                        ctx.length(radius)
                    if any(type(position) not in (int, float) or not 0 < position < 1 for position in positions):
                        raise ValueError('midPositions values must be numeric and strictly between 0 and 1')
                for field in ('tangentChain', 'isFlipped'):
                    if field in row and type(row[field]) is not bool:
                        raise TypeError(field + ' must be boolean')
                rows.append(item)
            resolved[key] = rows
            summary[key] = [{'index': row['index'], **{k: ([ctx.ref(e) for e in v] if k == 'edges' else v) for k, v in row.items() if k != 'index'}} for row in rows]
        elif key == 'fullRoundFaceSets':
            if not isinstance(value, list) or not value:
                raise ValueError('fullRoundFaceSets must be a nonempty array')
            full_round = getattr(adsk.fusion.FilletFeatureTypes, 'FullRoundFilletFeatureType', None)
            if getattr(feature, 'filletFeatureType', None) != full_round:
                raise ValueError('fullRoundFaceSets applies only to an existing full-round FilletFeature; variant conversion is refused')
            rows = []
            for row in value:
                if not isinstance(row, dict):
                    raise TypeError('fullRoundFaceSets entries must be objects')
                _cad_fields(row, ('centerFace', 'sideOneFaces', 'sideTwoFaces'), ('automaticSideFaces',))
                center = _feature_native_ref(ctx, row['centerFace'], 'face')
                side_one = _feature_native_collection(ctx, row['sideOneFaces'], 'face')
                side_two = _feature_native_collection(ctx, row['sideTwoFaces'], 'face')
                automatic = row.get('automaticSideFaces', True)
                if type(automatic) is not bool:
                    raise TypeError('automaticSideFaces must be boolean')
                rows.append({'centerFace': center, 'sideOneFaces': side_one, 'sideTwoFaces': side_two,
                             'automaticSideFaces': automatic})
            resolved[key] = rows
            summary[key] = [{'centerFace': ctx.ref(row['centerFace']),
                             'sideOneFaces': [ctx.ref(face) for face in row['sideOneFaces']],
                             'sideTwoFaces': [ctx.ref(face) for face in row['sideTwoFaces']],
                             'automaticSideFaces': row['automaticSideFaces']} for row in rows]
        elif key in ('sections', 'rails'):
            if not isinstance(value, list) or not value:
                raise ValueError(key + ' must be a nonempty array')
            items = []
            for item in value:
                ref = item.get('entity') if isinstance(item, dict) and 'entity' in item else item
                entity = _feature_native_path(ctx, ref) if key == 'rails' or (isinstance(ref, dict) and 'curves' in ref) else _feature_native_ref(ctx, ref)
                if key == 'rails' and not _feature_native_is(entity, ('SketchCurve', 'BRepEdge', 'Path')):
                    raise ValueError('Loft rails must be sketch curves, BRepEdge or Path refs')
                if key == 'sections' and not any(cls.cast(entity) for cls in (adsk.fusion.Profile, adsk.fusion.BRepFace,
                                                                              adsk.fusion.Path, adsk.fusion.SketchPoint,
                                                                              adsk.fusion.ConstructionPoint)):
                    raise ValueError('Loft sections must be profiles, faces, paths or supported point sections')
                if key == 'rails' and isinstance(item, dict) and 'edgeCondition' in item:
                    if not adsk.fusion.BRepEdge.cast(entity):
                        raise ValueError('Loft rail edgeCondition applies only to BRepEdge rails')
                    edge_condition = _feature_native_enum(adsk.fusion.LoftRailEdgeConditions,
                        {'G0': 'G0LoftRailEdgeCondition', 'G1': 'G1LoftRailEdgeCondition', 'G2': 'G2LoftRailEdgeCondition'},
                        item['edgeCondition'], 'edgeCondition')
                    items.append({'entity': entity, 'edgeCondition': edge_condition})
                else:
                    items.append({'entity': entity} if key == 'rails' else entity)
            resolved[key] = items
            summary[key] = [({'entity': ctx.ref(item['entity']), **({'edgeCondition': _feature_native_value(ctx, item['edgeCondition'])} if 'edgeCondition' in item else {})}
                              if isinstance(item, dict) else ctx.ref(item)) for item in items]
        elif key == 'centerLine':
            resolved[key] = _feature_native_path(ctx, value)
            if not _feature_native_is(resolved[key], ('SketchCurve', 'BRepEdge', 'Path')):
                raise ValueError('Loft centerLine must be a sketch curve, BRepEdge or Path ref')
            summary[key] = ctx.ref(resolved[key])
        elif key == 'sectionConditions':
            if not isinstance(value, list) or not value:
                raise ValueError('sectionConditions must be a nonempty array')
            conditions = []
            for condition in value:
                if not isinstance(condition, dict) or type(condition.get('index')) is not int or condition['index'] < 0:
                    raise ValueError('sectionConditions rows require a nonnegative index')
                _cad_fields(condition, ('index', 'type'), ('angle', 'weight'))
                if condition['type'] not in ('free', 'direction', 'tangent', 'smooth', 'pointSharp', 'pointTangent'):
                    raise ValueError('Unsupported loft end-condition type: ' + str(condition['type']))
                if 'angle' in condition:
                    ctx.angle(condition['angle'])
                if 'weight' in condition and (type(condition['weight']) not in (int, float) or condition['weight'] <= 0):
                    raise ValueError('Loft end-condition weight must be positive and unitless')
                conditions.append(dict(condition))
            resolved[key] = conditions
            summary[key] = list(conditions)
        elif key in ('insideThickness', 'outsideThickness'):
            ctx.length(value)
            resolved[key] = value
            summary[key] = value
        elif key == 'position':
            resolved[key] = _feature_validate_hole_position(ctx, value)
            summary[key] = value
        elif key == 'holeType':
            if not isinstance(value, dict) or value.get('type') not in ('simple', 'counterbore', 'countersink'):
                raise ValueError('holeType.type must be simple, counterbore or countersink')
            required = {'simple': (), 'counterbore': ('diameter', 'depth'), 'countersink': ('diameter', 'angle')}[value['type']]
            _cad_fields(value, ('type',) + required, ())
            for field in ('diameter', 'depth'):
                if field in value:
                    ctx.length(value[field])
            if 'angle' in value:
                ctx.angle(value['angle'])
            resolved[key] = dict(value)
            summary[key] = dict(value)
        else:
            raise ValueError('Unsupported nativeEdits property: ' + key)
    if kind == 'LoftFeature':
        for key in ('sections', 'rails'):
            if key in resolved:
                collection = getattr(feature, 'loftSections' if key == 'sections' else 'centerLineOrRails', None)
                current_count = getattr(collection, 'count', 0) if collection is not None else 0
                if len(resolved[key]) != current_count:
                    raise ValueError('Loft ' + key + ' edits must preserve collection cardinality')
    return {'kind': kind, 'resolved': resolved, 'summary': summary}


def _feature_native_value(ctx, value):
    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    if isinstance(value, (list, tuple)):
        return [_feature_native_value(ctx, item) for item in value]
    if hasattr(value, 'objectType'):
        return ctx.ref(value)
    return _cad_json(value)


def _feature_hole_position_snapshot(ctx, feature):
    definition = getattr(feature, 'holePositionDefinition', None)
    for class_name, key_map in (
        ('SketchPointHolePositionDefinition', {'sketchPoint': 'sketchPoint'}),
        ('SketchPointsHolePositionDefinition', {'sketchPoints': 'sketchPoints'}),
        ('AtCenterHolePositionDefinition', {'plane': 'planarEntity', 'edge': 'centerEdge'}),
        ('OnEdgeHolePositionDefinition', {'plane': 'planarEntity', 'edge': 'edge', 'position': 'position'}),
        ('PlaneAndOffsetsHolePositionDefinition', {'plane': 'planarEntity', 'edgeOne': 'edgeOne', 'offsetOne': 'offsetOne',
                                                   'edgeTwo': 'edgeTwo', 'offsetTwo': 'offsetTwo'}),
        ('PointHolePositionDefinition', {'plane': 'planarEntity', 'point': 'point'})):
        cls = getattr(adsk.fusion, class_name, None)
        typed = cls.cast(definition) if cls is not None else None
        if typed is None:
            continue
        result = {'definitionType': class_name}
        for out_key, prop in key_map.items():
            value = getattr(typed, prop, None)
            if value is None:
                result[out_key] = None
            elif hasattr(value, 'expression'):
                result[out_key] = _feature_parameter(value, out_key)
            elif isinstance(value, (list, tuple)):
                result[out_key] = [ctx.ref(item) for item in value]
            elif hasattr(value, 'objectType'):
                result[out_key] = ctx.ref(value)
            else:
                result[out_key] = _feature_native_value(ctx, value)
        return result
    return {'definitionType': 'unsupportedOrUnknown'}


def _feature_native_read(ctx, feature, plan):
    kind = plan['kind']
    rows = {}
    for key in plan['resolved']:
        if key == 'entities':
            prop = 'inputFaces' if kind == 'ThickenFeature' else 'inputEntities'
            collection = getattr(feature, prop, None)
            rows[key] = [ctx.ref(item) for item in _cad_items(collection)] if collection is not None else None
        elif key == 'participants':
            rows[key] = [ctx.ref(item) for item in _cad_items(feature.participantBodies)]
        elif key == 'edgeSets':
            collection = feature.edgeSets
            result = []
            for item in plan['resolved'][key]:
                if item['index'] >= collection.count:
                    raise ValueError('edgeSets index is outside the existing feature edge sets')
                edge_set = collection.item(item['index'])
                result.append({'index': item['index'], 'type': _cad_type(edge_set),
                    'edges': [ctx.ref(edge) for edge in _cad_items(getattr(edge_set, 'edges', None))]})
            rows[key] = result
        elif key == 'fullRoundFaceSets':
            rows[key] = [{'centerFace': ctx.ref(item.centerFace),
                          'sideOneFaces': [ctx.ref(face) for face in _cad_items(item.sideOneFaces)],
                          'sideTwoFaces': [ctx.ref(face) for face in _cad_items(item.sideTwoFaces)],
                          'automaticSideFaces': bool(item.areAutomaticSideFaces)}
                         for item in _cad_items(feature.fullRoundFilletFaceSets)]
        elif key == 'sections':
            rows[key] = [ctx.ref(feature.loftSections.item(index).entity) for index in range(feature.loftSections.count)]
        elif key == 'rails':
            rows[key] = [{'entity': ctx.ref(feature.centerLineOrRails.item(index).entity),
                          'isCenterLine': bool(feature.centerLineOrRails.item(index).isCenterLine),
                          'edgeCondition': _feature_native_value(ctx, feature.centerLineOrRails.item(index).edgeCondition)}
                         for index in range(feature.centerLineOrRails.count)]
        elif key == 'sectionConditions':
            rows[key] = [{'index': item['index'], 'type': str(getattr(feature.loftSections.item(item['index']).endCondition, 'objectType', 'unknown'))}
                          for item in plan['resolved'][key]]
        elif key == 'position':
            rows[key] = _feature_hole_position_snapshot(ctx, feature)
        elif key == 'holeType':
            rows[key] = {'type': _feature_native_value(ctx, getattr(feature, 'holeType', None)),
                         'tapType': _feature_native_value(ctx, getattr(feature, 'holeTapType', None))}
        elif key in ('insideThickness', 'outsideThickness'):
            parameter = getattr(feature, key, None)
            rows[key] = _feature_parameter(parameter, key) if parameter is not None else None
        elif key in ('startLoftEdgeAlignment', 'endLoftEdgeAlignment'):
            rows[key] = _feature_native_value(ctx, getattr(feature, key))
        elif key == 'centerLine':
            collection = feature.centerLineOrRails
            rows[key] = [{'entity': ctx.ref(item.entity), 'isCenterLine': bool(item.isCenterLine)} for item in _cad_items(collection)]
        else:
            prop = {'isTangentChain': 'isTangentChain', 'isChainSelection': 'isChainSelection'}.get(key, key)
            rows[key] = _feature_native_value(ctx, getattr(feature, prop, None))
    return rows


def _feature_native_set_parameter(parameter, value, unit_kind, ctx, label):
    if unit_kind == 'length':
        ctx.length(value)
    elif unit_kind == 'angle':
        ctx.angle(value)
    parameter.expression = value


def _feature_native_apply(ctx, feature, plan):
    kind, edits = plan['kind'], plan['resolved']
    for key, value in edits.items():
        if key == 'edgeSets':
            collection = feature.edgeSets
            if any(row['index'] >= collection.count for row in value):
                raise ValueError('edgeSets index is outside the existing feature edge sets')
            for row in value:
                if 'midRadii' in row:
                    edge_set = collection.item(row['index'])
                    if len(row['midRadii']) != len(_cad_items(edge_set.midRadii)) or len(row['midPositions']) != len(_cad_items(edge_set.midPositions)):
                        raise ValueError('Variable fillet mid-point cardinality must be preserved')
            for row in value:
                edge_set = collection.item(row['index'])
                if 'edges' in row:
                    edge_set.edges = _feature_native_object_collection(row['edges'])
                    edge_set = feature.edgeSets.item(row['index'])
                for prop, unit_kind in (('radius', 'length'), ('chordLength', 'length'), ('startRadius', 'length'),
                                        ('endRadius', 'length'), ('offsetOne', 'length'), ('offsetTwo', 'length'),
                                        ('distance', 'length'), ('distanceOne', 'length'),
                                        ('distanceTwo', 'length'), ('angle', 'angle')):
                    if prop in row:
                        parameter = getattr(edge_set, prop, None)
                        if parameter is None:
                            raise ValueError('Existing edge-set variant does not expose ' + prop)
                        _feature_native_set_parameter(parameter, row[prop], unit_kind, ctx, prop)
                if 'midRadii' in row:
                    mid_radii = _cad_items(edge_set.midRadii)
                    mid_positions = _cad_items(edge_set.midPositions)
                    for parameter, expression in zip(mid_radii, row['midRadii']):
                        _feature_native_set_parameter(parameter, expression, 'length', ctx, 'midRadius')
                    for parameter, position in zip(mid_positions, row['midPositions']):
                        parameter.expression = str(position)
                if 'tangentChain' in row:
                    edge_set.isTangentChain = row['tangentChain']
                if 'isFlipped' in row:
                    edge_set.isFlipped = row['isFlipped']
                if 'continuity' in row:
                    edge_set.continuity = row['continuity']
                if 'tangencyWeight' in row:
                    edge_set.tangencyWeight = ctx.value(str(row['tangencyWeight']))
        elif key == 'fullRoundFaceSets':
            collection = feature.fullRoundFilletFaceSets
            for index in range(collection.count - 1, -1, -1):
                _cad_require_result(collection.item(index).deleteMe(), 'FullRoundFilletFaceSet.deleteMe')
            for row in value:
                _cad_require_result(collection.add(row['centerFace'], row['sideOneFaces'], row['sideTwoFaces'],
                                                   row['automaticSideFaces']), 'FullRoundFilletFaceSets.add')
        elif key == 'isRollingBallCorner':
            feature.isRollingBallCorner = value
        elif key == 'cornerType':
            feature.cornerType = value
        elif key == 'holeType':
            hole_type = value['type']
            if hole_type == 'simple':
                _cad_require_result(feature.setToSimple(), 'HoleFeature.setToSimple')
            elif hole_type == 'counterbore':
                _cad_require_result(feature.setToCounterbore(ctx.value(value['diameter']), ctx.value(value['depth'])), 'HoleFeature.setToCounterbore')
            else:
                _cad_require_result(feature.setToCountersink(ctx.value(value['diameter']), ctx.value(value['angle'])), 'HoleFeature.setToCountersink')
        elif key == 'position':
            mode = value['mode']
            if mode == 'sketchPoint':
                _cad_require_result(feature.setPositionBySketchPoint(value['point']), 'HoleFeature.setPositionBySketchPoint')
            elif mode == 'sketchPoints':
                _cad_require_result(feature.setPositionBySketchPoints(ctx.collection(value['points'])), 'HoleFeature.setPositionBySketchPoints')
            elif mode == 'point':
                point = adsk.core.Point3D.create(*[ctx.length(v) for v in value['point']])
                _cad_require_result(feature.setPositionByPoint(value['plane'], point), 'HoleFeature.setPositionByPoint')
            elif mode == 'center':
                _cad_require_result(feature.setPositionAtCenter(value['plane'], value['edge']), 'HoleFeature.setPositionAtCenter')
            elif mode == 'offsets':
                args = [value['plane'], adsk.core.Point3D.create(*[ctx.length(v) for v in value['point']]), value['edgeOne'], ctx.value(value['offsetOne'])]
                if 'edgeTwo' in value:
                    args.extend((value['edgeTwo'], ctx.value(value['offsetTwo'])))
                _cad_require_result(feature.setPositionByPlaneAndOffsets(*args), 'HoleFeature.setPositionByPlaneAndOffsets')
            else:
                positions = {'start': adsk.fusion.HoleEdgePositions.EdgeStartPointPosition,
                             'end': adsk.fusion.HoleEdgePositions.EdgeEndPointPosition,
                             'middle': adsk.fusion.HoleEdgePositions.EdgeMidPointPosition}
                _cad_require_result(feature.setPositionOnEdge(value['plane'], value['edge'], positions[value['position']]), 'HoleFeature.setPositionOnEdge')
        elif key == 'participants':
            feature.participantBodies = value
        elif key == 'entities':
            collection = _feature_native_object_collection(value)
            if kind == 'ShellFeature':
                _cad_require_result(feature.setInputEntities(collection, plan['resolved'].get('isTangentChain', True)), 'ShellFeature.setInputEntities')
            elif kind == 'ThickenFeature':
                _cad_require_result(feature.setInputEntities(collection, plan['resolved'].get('isChainSelection', True)), 'ThickenFeature.setInputEntities')
            else:
                feature.inputEntities = collection
        elif key in ('insideThickness', 'outsideThickness'):
            if key == 'outsideThickness' and 'insideThickness' in edits:
                continue
            inside = edits.get('insideThickness')
            outside = edits.get('outsideThickness')
            if inside is None:
                parameter = getattr(feature, 'insideThickness', None)
                inside = parameter.expression if parameter is not None else None
            if outside is None:
                parameter = getattr(feature, 'outsideThickness', None)
                outside = parameter.expression if parameter is not None else None
            _cad_require_result(feature.setThicknesses(ctx.value(inside) if inside is not None else None,
                                                      ctx.value(outside) if outside is not None else None), 'ShellFeature.setThicknesses')
        elif key == 'centerLine':
            _cad_require_result(feature.centerLineOrRails.addCenterLine(value), 'LoftFeature.addCenterLine')
        elif key in ('sections', 'rails'):
            collection = feature.loftSections if key == 'sections' else feature.centerLineOrRails
            if collection.count != len(value):
                raise ValueError('Loft ' + key + ' collection cardinality changed before edit')
            for index, entity in enumerate(value):
                if key == 'rails':
                    item = collection.item(index)
                    if bool(item.isCenterLine):
                        raise ValueError('Loft rails edit cannot replace a centerline with a rail')
                    row = entity if isinstance(entity, dict) else {'entity': entity}
                    item.entity = row['entity']
                    if 'edgeCondition' in row:
                        item.edgeCondition = row['edgeCondition']
                else:
                    collection.item(index).entity = entity
        elif key == 'sectionConditions':
            collection = feature.loftSections
            for condition in value:
                index, mode = condition['index'], condition['type']
                if index >= collection.count or index not in (0, collection.count - 1):
                    raise ValueError('Loft end conditions apply only to the first or last section')
                section = collection.item(index)
                weight = ctx.value(str(condition.get('weight', 1)))
                if mode == 'free': result = section.setFreeEndCondition()
                elif mode == 'direction': result = section.setDirectionEndCondition(ctx.value(condition.get('angle', '0 deg')), weight)
                elif mode == 'tangent': result = section.setTangentEndCondition(weight)
                elif mode == 'smooth': result = section.setSmoothEndCondition(weight)
                elif mode == 'pointSharp': result = section.setPointSharpEndCondition()
                else: result = section.setPointTangentEndCondition(weight)
                _cad_require_result(result, 'LoftSection end condition')
        elif key == 'path' or key == 'guideRail' or key == 'profile' or key == 'solidBody' or key in ('axis', 'directionOneEntity', 'directionTwoEntity', 'mirrorPlane', 'solidAlignedAxis', 'solidTwistAxis'):
            setattr(feature, key, value)
        elif key in ('suppressedElementsIds', 'startPoint', 'isFlipDirection', 'isSymmetric', 'isSymmetricInDirectionOne', 'isSymmetricInDirectionTwo', 'patternDistanceType', 'patternComputeOption', 'orientation', 'isDirectionFlipped', 'guideSurfaces', 'isChainSelection', 'solidOrientation', 'isClosed', 'isTangentEdgesMerged', 'startLoftEdgeAlignment', 'endLoftEdgeAlignment', 'thickenType'):
            setattr(feature, key, value)
        elif key == 'isTangentChain':
            if kind == 'ShellFeature':
                if 'entities' in edits:
                    continue
                current = feature.inputEntities
                _cad_require_result(feature.setInputEntities(current, value), 'ShellFeature.setInputEntities')
            elif kind == 'ThickenFeature':
                if 'entities' in edits:
                    continue
                current = feature.inputFaces
                _cad_require_result(feature.setInputEntities(current, value), 'ThickenFeature.setInputEntities')
            else:
                raise ValueError('isTangentChain is not applicable to ' + kind)


def _feature_native_edit(ctx, data, feature):
    before = _feature_snapshot(ctx, feature)
    plan = _feature_native_plan(ctx, feature, data['nativeEdits'])
    request = {'featureType': plan['kind'], 'properties': plan['summary'],
               'supportedProperties': _feature_edit_capabilities(plan['kind'], before['parameters'])['supported'],
               'unsupportedProperties': _FEATURE_UNSUPPORTED_NATIVE.get(plan['kind'], [])}
    if data.get('preview') is True:
        return _feature_contract(ctx, 'feature.edit', {'applied': False, 'before': before,
            'after': dict(before), 'nativeEdits': request, 'preview': True, 'mutation': False,
            'skippedFields': [], 'unsupportedFields': request['unsupportedProperties']},
            status='pass', associativity='snapshot')
    if data.get('confirm') is not True:
        return _feature_contract(ctx, 'feature.edit', {'applied': False, 'before': before,
            'after': dict(before), 'nativeEdits': request,
            'reason': 'nativeEdits requires confirm:true', 'mutation': False,
            'skippedFields': [], 'unsupportedFields': request['unsupportedProperties']},
            status='blocked', associativity='snapshot')
    timeline = ctx.design.timeline
    marker = getattr(timeline, 'markerPosition', None)
    if marker != timeline.count:
        raise ValueError('nativeEdits requires the timeline marker at the end')
    poses_before = _feature_operation_pose_snapshot(ctx)
    rolled, primary_error, restore_error = False, None, None
    native_before, native_after = None, None
    try:
        rolled = True
        _cad_require_result(feature.timelineObject.rollTo(True), 'TimelineObject.rollTo')
        native_before = _feature_native_read(ctx, feature, plan)
        _feature_native_apply(ctx, feature, plan)
        native_after = _feature_native_read(ctx, feature, plan)
    except Exception as exc:
        primary_error = str(exc)
        try:
            native_after = _feature_native_read(ctx, feature, plan)
        except Exception as read_error:
            request['afterReadError'] = str(read_error)
    finally:
        marker_restored = True
        if rolled:
            try:
                timeline = ctx.design.timeline
                timeline.markerPosition = marker
                marker_restored = getattr(ctx.design.timeline, 'markerPosition', None) == marker
                if not marker_restored:
                    raise RuntimeError('Timeline marker readback did not match captured position')
            except Exception as exc:
                restore_error = str(exc)
                marker_restored = False
    try:
        after = _feature_snapshot(ctx, feature)
    except Exception as read_error:
        after = {'status': 'unknown', 'error': str(read_error)}
    poses_after = _feature_operation_pose_snapshot(ctx)
    poses_preserved = (poses_before is not None and poses_after is not None and
                       [(row[0], row[1]) for row in poses_before] == [(row[0], row[1]) for row in poses_after])
    identity_preserved = ctx.resolve(data['feature'], 'feature') == feature
    health = int(getattr(feature, 'healthState', -1))
    status = 'pass' if not primary_error and not restore_error and marker_restored and poses_preserved and identity_preserved and health == 0 else 'fail'
    result = {'applied': True, 'before': before, 'after': after, 'nativeEdits': request,
              'nativeBefore': native_before, 'nativeAfter': native_after,
              'featureIdentityPreserved': identity_preserved, 'health': health,
              'timelinePositionBefore': marker, 'timelinePositionAfter': getattr(ctx.design.timeline, 'markerPosition', None),
              'markerRestored': marker_restored, 'posesPreserved': poses_preserved,
              'skippedFields': [], 'unsupportedFields': request['unsupportedProperties'],
              'partialEffectsUnknown': bool(primary_error or restore_error), 'atomic': False,
              'geometryDeleted': False, 'affected': [ctx.ref(feature)]}
    if primary_error:
        result['primaryError'] = primary_error
    if restore_error:
        result['restoreError'] = restore_error
    return _feature_contract(ctx, 'feature.edit', result, status=status, associativity='nativeReference')


@_cad_scoped_step('feature.edit', native_only=True)
def _feature_edit(ctx, data):
    _cad_fields(data, ('schemaVersion', 'frame', 'feature'), ('name', 'entries', 'extent', 'operationChange', 'nativeEdits', 'preview', 'confirm'))
    if data['schemaVersion'] != 1 or data['frame'] != 'component':
        raise ValueError('GM09 feature commands require schemaVersion:1 and frame:component')
    if 'preview' in data and type(data['preview']) is not bool:
        raise ValueError('preview must be boolean')
    if 'confirm' in data and type(data['confirm']) is not bool:
        raise ValueError('confirm must be boolean')
    if not any(key in data for key in ('name', 'entries', 'extent', 'operationChange', 'nativeEdits')):
        raise ValueError('Provide at least one of name, entries, extent, operationChange or nativeEdits')
    if 'operationChange' in data and any(key in data for key in ('name', 'entries', 'extent')):
        raise ValueError('operationChange cannot be combined with other feature edits')
    if 'nativeEdits' in data and any(key in data for key in ('name', 'entries', 'extent', 'operationChange')):
        raise ValueError('nativeEdits cannot be combined with name, entries, extent or operationChange')
    feature = ctx.resolve(data['feature'], 'feature')
    _feature_owner_check(ctx, feature)
    if 'nativeEdits' in data:
        return _feature_native_edit(ctx, data, feature)
    before = _feature_snapshot(ctx, feature)
    operation_plan = None
    if 'operationChange' in data:
        operation_kind = _cad_type(feature)
        if operation_kind not in _FEATURE_OPERATION_CHANGE_TYPES or not hasattr(type(feature), 'operation'):
            raise ValueError('operationChange is unsupported for feature type ' + operation_kind)
        spec = data['operationChange']
        _cad_fields(spec, ('expected', 'value', 'expectedResultBodyCount'), ('participants',))
        supported_operations = ('newBody', 'join', 'cut') if operation_kind == 'ExtrudeFeature' else ('newBody', 'join', 'cut', 'intersect')
        if spec['expected'] not in supported_operations or spec['value'] not in supported_operations:
            raise ValueError('operationChange expected/value must be ' + ', '.join(supported_operations))
        if type(spec['expectedResultBodyCount']) is not int or spec['expectedResultBodyCount'] < 1:
            raise ValueError('expectedResultBodyCount must be an integer >= 1')
        if spec['value'] == 'newBody':
            if 'participants' in spec:
                raise ValueError('newBody forbids participants')
            participants = []
        else:
            refs = spec.get('participants')
            if not isinstance(refs, list) or not refs:
                raise ValueError('join/cut/intersect require explicit nonempty participants')
            participants = [ctx.resolve(ref, 'body') for ref in refs]
            if any(_cad_owner(body) != ctx.component or getattr(body, 'assemblyContext', None) is not None for body in participants):
                raise ValueError('operationChange participants must be native bodies owned by the selected component')
        operation_names = {getattr(adsk.fusion.FeatureOperations, key): value for key, value in (
            ('NewBodyFeatureOperation', 'newBody'), ('JoinFeatureOperation', 'join'), ('CutFeatureOperation', 'cut'),
            ('IntersectFeatureOperation', 'intersect'))
            if hasattr(adsk.fusion.FeatureOperations, key)}
        actual = operation_names.get(getattr(feature, 'operation', None))
        if actual is None:
            raise ValueError('Current ' + operation_kind + ' operation is unsupported or unknown')
        if actual != spec['expected']:
            raise ValueError('Expected operation does not match current operation')
        if spec['value'] != 'newBody' and not hasattr(type(feature), 'participantBodies'):
            raise ValueError('This SDK does not expose participantBodies for ' + operation_kind)
        operation_target = next((key for key, value in operation_names.items() if value == spec['value']), None)
        if operation_target is None:
            raise ValueError('Requested operation is unavailable in this Fusion SDK: ' + spec['value'])
        operation_plan = {'spec': spec, 'participants': participants,
                          'target': operation_target}
    if 'name' in data:
        name = data['name']
        if not isinstance(name, str) or not name.strip():
            raise ValueError('Feature name must be nonempty')
        if any(candidate.name == name for candidate in _cad_items(ctx.component.features) if candidate != feature):
            raise ValueError('Feature name collision: ' + name)
    resolved = []
    if 'entries' in data:
        entries = data['entries']
        if not isinstance(entries, list) or not entries:
            raise ValueError('entries must be a nonempty array')
        for entry in entries:
            _cad_fields(entry, ('expression',), ('name', 'role'))
            if not entry.get('name') and not entry.get('role'):
                raise ValueError('Each entry needs a name and/or role selector')
            for key in ('name', 'role'):
                if key in entry and (not isinstance(entry[key], str) or not entry[key].strip()):
                    raise ValueError('Entry ' + key + ' must be a nonempty string')
            expression = entry['expression']
            if not isinstance(expression, str) or not expression.strip():
                raise ValueError('Entry expression must be a nonempty string')
            matches = [(row, parameter) for row, parameter in _feature_bindings(ctx, feature)[0]
                       if (entry.get('name') is None or row['name'] == entry['name']) and (entry.get('role') is None or row['role'] == entry['role'])]
            if not matches:
                raise ValueError('No feature parameter matches the selector ' + json.dumps({k: v for k, v in entry.items() if k != 'expression'}))
            if len(matches) > 1:
                raise ValueError('Ambiguous role selector; supply the unique parameter name: ' + entry['role'])
            row, parameter = matches[0]
            ctx._expression(expression, row['unit'] if row.get('unit') not in (None, '', 'text') else None)
            resolved.append((row, parameter, expression))
    extent_plan = _feature_extent_plan(ctx, feature, before, data['extent']) if 'extent' in data else None
    projected = dict(before)
    projected['parameters'] = [{**row, 'expression': next((expression for candidate, unused, expression in resolved if candidate is row), row['expression'])} for row in before['parameters']]
    plan = {'applied': False, 'before': before, 'after': projected, 'atomic': False,
            'requiresMarkerRoll': extent_plan is not None,
            'steps': ([{'kind': 'rename', 'name': data['name']}] if 'name' in data else []) +
                     [{'kind': 'parameter', 'name': row['name'], 'role': row['role'], 'expression': expression} for row, unused, expression in resolved] +
                     ([{'kind': 'extent', 'mode': extent_plan['mode'], 'data': data['extent']}] if extent_plan is not None else [])}
    if data.get('preview') is True:
        plan['preview'] = True
        return _feature_contract(ctx, 'feature.edit', plan, status='pass', associativity='snapshot')
    risky_confirmation = ((operation_plan is not None and operation_kind != 'ExtrudeFeature' and operation_plan['spec']['expected'] != operation_plan['spec']['value']) or
                          (extent_plan is not None and extent_plan['kind'] == 'HoleFeature'))
    if risky_confirmation and data.get('confirm') is not True:
        return _feature_contract(ctx, 'feature.edit', {'applied': False, 'before': before,
            'after': dict(before), 'plan': plan, 'reason': 'This native edit requires confirm:true',
            'mutation': False, 'skippedFields': [], 'unsupportedFields': []},
            status='blocked', associativity='snapshot')
    marker = getattr(ctx.design.timeline, 'markerPosition', None)
    if operation_plan is not None and marker != ctx.design.timeline.count:
        raise ValueError('operationChange requires the timeline marker at the end')
    poses_before = _feature_operation_pose_snapshot(ctx) if operation_plan is not None else None
    rolled, primary_error, marker_restored = False, None, True
    applied = []
    try:
        for row, parameter, expression in resolved:
            before_row = {'name': row['name'], 'role': row['role'], 'expression': row['expression'], 'unit': row['unit'], 'value': row['value']}
            parameter.expression = expression
            applied.append({'name': row['name'], 'role': row['role'], 'before': before_row, 'requested': expression})
        if 'name' in data:
            feature.name = data['name']
        if extent_plan is not None:
            rolled = True
            _cad_require_result(feature.timelineObject.rollTo(True), 'TimelineObject.rollTo')
            _feature_apply_extent(ctx, feature, data['extent'], extent_plan)
        if operation_plan is not None and operation_plan['spec']['expected'] != operation_plan['spec']['value']:
            rolled = True
            _cad_require_result(feature.timelineObject.rollTo(True), 'TimelineObject.rollTo')
            if operation_plan['target'] is None:
                raise ValueError('Requested extrude operation is unavailable in this SDK')
            if operation_plan['spec']['value'] != 'newBody':
                feature.participantBodies = operation_plan['participants']
            feature.operation = operation_plan['target']
        if operation_plan is None or operation_plan['spec']['expected'] != operation_plan['spec']['value']:
            ctx.design.timeline.moveToEnd()
    except Exception as exc:
        primary_error = exc
    finally:
        restore_error = None
        if rolled:
            try:
                if operation_plan is not None and marker is not None:
                    ctx.design.timeline.markerPosition = marker
                else:
                    ctx.design.timeline.moveToEnd()
                marker_restored = (getattr(ctx.design.timeline, 'markerPosition', marker) == marker
                                   if operation_plan is not None and marker is not None else True)
                if not marker_restored:
                    raise RuntimeError('Timeline marker readback did not match captured position')
            except Exception as exc:
                restore_error = str(exc)
                marker_restored = False
        elif operation_plan is not None and marker is not None:
            marker_restored = getattr(ctx.design.timeline, 'markerPosition', None) == marker
    if primary_error is not None:
        message = str(primary_error)
        if restore_error:
            message += '; timeline marker restore failed: ' + restore_error
        if operation_plan is not None and operation_kind != 'ExtrudeFeature':
            after = _feature_snapshot(ctx, feature)
            spec = operation_plan['spec']
            actual = operation_names.get(getattr(feature, 'operation', None))
            bodies = [body for body in _cad_items(getattr(ctx.component, 'bRepBodies', [])) if getattr(body, 'isSolid', False)]
            identity_ok = ctx.resolve(data['feature'], 'feature') == feature
            poses_after = _feature_operation_pose_snapshot(ctx)
            poses_preserved = (poses_before is not None and poses_after is not None and
                               [(row[0], row[1]) for row in poses_before] == [(row[0], row[1]) for row in poses_after])
            operation_result = {'actualOperation': actual, 'directSolidBodyCount': len(bodies),
                                'featureIdentityPreserved': identity_ok, 'health': int(feature.healthState),
                                'markerRestored': marker_restored, 'posesPreserved': poses_preserved,
                                'expectedResultBodyCount': spec['expectedResultBodyCount']}
            result = {'applied': True, 'before': before, 'after': after, 'operationChange': operation_result,
                      'primaryError': str(primary_error), 'restoreError': restore_error,
                      'markerRestored': marker_restored, 'posesPreserved': poses_preserved,
                      'featureIdentityPreserved': identity_ok, 'featureTypeBefore': before['type'],
                      'featureTypeAfter': after['type'], 'timelinePositionBefore': marker,
                      'timelinePositionAfter': getattr(ctx.design.timeline, 'markerPosition', None),
                      'directSolidBodyCount': len(bodies), 'health': int(feature.healthState),
                      'skippedFields': [], 'unsupportedFields': [], 'partialEffectsUnknown': True,
                      'atomic': False, 'geometryDeleted': False, 'affected': [ctx.ref(feature)]}
            if restore_error:
                result['warnings'] = ['timeline marker restore failed: ' + restore_error]
            return _feature_contract(ctx, 'feature.edit', result, status='fail', associativity='nativeExpression')
        if extent_plan is not None and extent_plan['kind'] in ('RevolveFeature', 'HoleFeature'):
            try:
                after = _feature_snapshot(ctx, feature)
            except Exception as read_error:
                after = {'status': 'unknown', 'error': str(read_error)}
            result = {'applied': True, 'before': before, 'after': after, 'plan': plan,
                      'primaryError': str(primary_error), 'restoreError': restore_error,
                      'markerRestored': marker_restored, 'timelinePositionBefore': marker,
                      'timelinePositionAfter': getattr(ctx.design.timeline, 'markerPosition', None),
                      'featureTypeBefore': before.get('type'), 'featureTypeAfter': after.get('type'),
                      'featureIdentityPreserved': ctx.resolve(data['feature'], 'feature') == feature,
                      'health': int(feature.healthState), 'skippedFields': [], 'unsupportedFields': [],
                      'partialEffectsUnknown': True, 'atomic': False, 'geometryDeleted': False,
                      'affected': [ctx.ref(feature)]}
            return _feature_contract(ctx, 'feature.edit', result, status='fail', associativity='nativeExpression')
        raise RuntimeError('feature.edit failed; no feature was deleted, partial changes may remain: ' + message) from primary_error
    after = _feature_snapshot(ctx, feature)
    conflicts = []
    for entry in applied:
        current = next((row for row in after['parameters'] if row['name'] == entry['name'] and row['role'] == entry['role']), None)
        if current is None or re.sub(r'\s+', '', current['expression']) != re.sub(r'\s+', '', entry['requested']):
            conflicts.append({'name': entry['name'], 'role': entry['role'], 'requested': entry['requested'],
                              'actual': current['expression'] if current else None})
    downstream = _feature_downstream(ctx, feature)
    if conflicts or downstream['status'] == 'fail' or int(feature.healthState) != 0:
        status = 'fail'
    else:
        status = 'pass'
    identity_preserved = ctx.resolve(data['feature'], 'feature') == feature
    if not identity_preserved:
        status = 'fail'
    result = {'applied': True, 'before': before, 'after': after, 'plan': plan, 'conflicts': conflicts,
              'downstream': downstream, 'markerRestored': marker_restored, 'atomic': False,
              'geometryDeleted': False, 'affected': [ctx.ref(feature)],
              'featureTypeBefore': before['type'], 'featureTypeAfter': after.get('type'),
              'timelinePositionBefore': marker,
              'timelinePositionAfter': getattr(ctx.design.timeline, 'markerPosition', None),
              'featureIdentityPreserved': identity_preserved, 'skippedFields': [], 'unsupportedFields': [],
              'warnings': [feature.errorOrWarningMessage] if feature.errorOrWarningMessage else []}
    if restore_error:
        result['warnings'].append('timeline marker restore failed: ' + restore_error)
    if operation_plan is not None:
        spec = operation_plan['spec']
        actual = operation_names.get(getattr(feature, 'operation', None))
        bodies = [body for body in _cad_items(getattr(ctx.component, 'bRepBodies', [])) if getattr(body, 'isSolid', False)]
        identity_ok = ctx.resolve(data['feature'], 'feature') == feature
        poses_after = _feature_operation_pose_snapshot(ctx)
        poses_preserved = (poses_before is not None and poses_after is not None and
                           [(row[0], row[1]) for row in poses_before] == [(row[0], row[1]) for row in poses_after])
        if actual != spec['value'] or len(bodies) != spec['expectedResultBodyCount'] or not identity_ok or not poses_preserved or not marker_restored or int(feature.healthState) != 0:
            status = 'fail'
        result.update(operationChange={'actualOperation': actual, 'directSolidBodyCount': len(bodies),
            'featureIdentityPreserved': identity_ok, 'health': int(feature.healthState),
            'markerRestored': marker_restored, 'posesPreserved': poses_preserved,
            'expectedResultBodyCount': spec['expectedResultBodyCount']})
    return _feature_contract(ctx, 'feature.edit', result, status=status, associativity='nativeExpression')


def _feature_dispatch(mode, rework):
    def handler(ctx, data):
        if not isinstance(data, dict):
            raise TypeError('Operation data must be an object')
        if 'schemaVersion' in data or 'frame' in data:
            return rework(ctx, data)
        # The legacy assembly history handlers remain the implementation for
        # payloads without schemaVersion; resolve them at call time from the
        # shared bundle namespace so registration order does not matter.
        return _assembly_handler(_assembly_history, mode)(ctx, data)
    return handler


CAD_HANDLERS.update({
    'feature.inspect': _feature_dispatch('inspect', _feature_inspect),
    'feature.edit': _feature_dispatch('edit', _feature_edit),
})
