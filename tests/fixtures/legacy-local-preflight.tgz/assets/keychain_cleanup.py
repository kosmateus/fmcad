"""Lifecycle retention for newly opted-in keychain runs; never scan old runs."""
import contextlib
import hashlib
import json
import os
from pathlib import Path
import re

from generated_cleanup import collect, inventory, directories, collect_directories, safe, identity

cleanup_bytes_freed = 0


def allowed(name):
    # Output names declared by image_trace/optimize, planners and CommandRunner.
    return bool(re.fullmatch(
        r'(?:optimization/(?:source\.png|palette\.json|reference\.png|candidates\.jsonl|'
        r'best_settings\.json|ranking\.json|report\.json|top_candidates\.png|region_\d+_top\.png|'
        r'candidate_\d+/(?:segmented\.png|raw_contours\.svg|contours\.svg|preview\.png|overlay\.svg|'
        r'overlay\.png|import_sketches\.json|report\.json|sketches/\d+\.json))|'
        r'(?:plan-checks/candidate_\d+|cad-plan|approvals/[a-f0-9]+-plan)/'
        r'(?:(?:base|field_\d+(?:_patch_\d+)?|patch_\d+|plan|check|failure-plan)\.json|'
        r'partition-preview\.svg|normalized\.svg|normalized\.png)|'
        r'approvals/[a-f0-9]+\.svg|preparation-report\.json|classified\.png|palette\.json|'
        r'canvas_source\.png|display_source\.png|'
        r'cad-build/(?:keychain_(?:fusion|project)-[a-f0-9]+\.py|(?:helper-)?input-\d+\.json|'
        r'journal/\d+\.(?:request|response)\.json|export-attempt-\d+/(?:verified/)?'
        r'(?:model\.f3d|keychain\.zip|stableColor_\d+_[a-fA-F0-9]{6}(?:_body_\d+)?\.stl))|'
        r'overlays/(?:\d+-candidate_\d+|approved-[a-f0-9]+)-overlay\.svg)', name))


def enabled(state):
    return state.get('cleanupPolicy') == 1


def directory_snapshot(state):
    result = {}
    for root in (state['runPath'], state['publicPath']):
        result.update(directories(root, lambda name: bool(re.fullmatch(
            r'optimization(?:/candidate_\d+(?:/sketches)?)?|plan-checks(?:/candidate_\d+)?|'
            r'cad-plan|approvals(?:/[a-f0-9]+-plan)?|overlays|'
            r'cad-build(?:/journal|/export-attempt-\d+(?:/verified)?)?', name))))
    return result


def snapshot(state):
    result = {}
    for root in (state['runPath'], state['publicPath']):
        result.update(inventory(root, allowed))
    return result


@contextlib.contextmanager
def produced(state):
    """Register only new declared outputs of this invocation, even after failure."""
    before = snapshot(state) if enabled(state) else {}
    before_dirs = directory_snapshot(state) if enabled(state) else {}
    generated = {'files': {}, 'directories': {}}
    try:
        yield generated
    finally:
        if enabled(state):
            after = snapshot(state)
            generated['files'].update({p: v for p, v in after.items() if p not in before})
            generated['directories'].update({p: v for p, v in directory_snapshot(state).items() if p not in before_dirs})
            state.setdefault('ownedFiles', {}).update(generated['files'])
            state.setdefault('ownedDirectories', {}).update(generated['directories'])


def unconfirmed_worker(root):
    """Presence check, not a deletion inventory: linked markers also block."""
    root = Path(root).absolute()
    if not safe(root, root):
        return True
    def unreadable(error):
        raise error
    try:
        for parent, names, files in os.walk(root, followlinks=False, onerror=unreadable):
            if 'active.json' in names or 'active.json' in files:
                return True
            # A replaced directory could conceal a worker checkpoint.
            if any((Path(parent) / name).is_symlink() for name in names):
                return True
    except OSError:
        return True
    return False


def cleanup(state):
    if not enabled(state) or state['request'].get('debug', False):
        return 0
    # An interrupted nested supervisor can leave an unconfirmed worker. Never
    # collect its outputs just because the outer process has exited.
    if unconfirmed_worker(state['runPath']):
        return 0
    prepared, build = state.get('prepared') or {}, state.get('build') or {}
    keep = {prepared.get(k) for k in ('sourcePath', 'canvasPath', 'displaySourcePath', 'palettePath', 'classifiedPath')}
    keep.add((state.get('approval') or {}).get('svgPath'))
    keep.update(p for p in state.get('ownedFiles', {})
                if Path(p).parent == Path(state['runPath']) and Path(p).name.startswith('source.'))
    keep.update(item['path'] for item in state.get('artifacts', []))
    completed = state['status'] == 'completed'
    # All candidates remain approvable until CAD starts, including corrected SVGs.
    if not completed and not build and not state.get('preparationConsumed'):
        keep.add((state.get('approval') or {}).get('overlayPath'))
        for candidate in prepared.get('candidates', []):
            keep.update(candidate.get(k) for k in ('svgPath', 'overlayPath', 'planningCheckPath'))
            if candidate.get('planningCheckPath'):
                folder = Path(candidate['planningCheckPath']).parent
                failed_bundle = (candidate.get('planningFailure') and
                    candidate.get('planningFailureBundlePath') == str(folder / 'failure-plan.json') and
                    str(folder / 'failure-plan.json') in state.get('ownedFiles', {}))
                if candidate.get('planSignature') or failed_bundle:
                    suffixes = ('.json', '.svg') if failed_bundle else ('.json',)
                    keep.update(p for p in state.get('ownedFiles', {})
                                if Path(p).parent == folder and p.endswith(suffixes))
    if not completed:
        # Corrected-SVG planning can fail before an approval checkpoint exists.
        # Its owned failure bundle anchors evidence until the run succeeds.
        run = Path(state['runPath'])
        owned = state.get('ownedFiles', {})
        for name, expected in owned.items():
            bundle = Path(name)
            if not safe(bundle, run) or not re.fullmatch(
                    r'approvals/[a-f0-9]+-plan/failure-plan\.json', bundle.relative_to(run).as_posix()):
                continue
            try:
                if expected is None or identity(bundle) != expected:
                    continue
            except OSError:
                continue
            keep.update(p for p in owned if Path(p).parent == bundle.parent and p.endswith(('.json', '.svg')))
            source = str(bundle.parent.with_name(bundle.parent.name[:-5] + '.svg'))
            if source in owned:
                keep.add(source)
        # Unknown Fusion may still consume any live-build input/export. Preserve
        # these and its full latest checkpoint, but obsolete offline trials go.
        keep.update(p for p in state.get('ownedFiles', {}) if
                    Path(p).is_relative_to(Path(state['runPath']) / 'cad-build') or
                    Path(p).is_relative_to(Path(state['runPath']) / 'cad-plan'))
    else:
        keep = {prepared.get('sourcePath'), (state.get('approval') or {}).get('svgPath'),
                *(a['path'] for a in state.get('artifacts', []))}
    protected = [state['request'].get(k) for k in ('input', 'palette')]
    # Persisted ownership alone cannot enroll manifests, locks or unknown names.
    owned = state.get('ownedFiles', {})
    removable_files = {p: v for p, v in owned.items() if any(
        Path(p).is_relative_to(root) and allowed(Path(p).relative_to(root).as_posix())
        for root in (state['runPath'], state['publicPath']))}
    remaining, freed = collect(removable_files,
        [state['runPath'], state['publicPath']], keep=keep, protected=protected)
    state['ownedFiles'] = {p: v for p, v in owned.items() if p not in removable_files}
    state['ownedFiles'].update(remaining)
    # Retain partial-plan/build directories as safety sentinels, even if empty.
    directory_keep = {p: v for p, v in state.get('ownedDirectories', {}).items()
                      if not completed and (Path(p).is_relative_to(Path(state['runPath']) / 'cad-build') or
                                            Path(p).is_relative_to(Path(state['runPath']) / 'cad-plan'))}
    removable = {p: v for p, v in state.get('ownedDirectories', {}).items() if p not in directory_keep}
    state['ownedDirectories'] = dict(collect_directories(removable, [state['runPath'], state['publicPath']]), **directory_keep)
    return freed


def completed_build(metadata, verification):
    """Identity + verification hashes, not repeated native geometry/journals."""
    keep = ('backend', 'document', 'creationId', 'preSaveCreationId', 'projectId', 'folderId',
            'cloud', 'runMarker', 'saveTarget', 'saveAttempted', 'saveReconciled', 'saveAccepted',
            'sourceSha256', 'svgSha256', 'paletteSha256', 'planSha256', 'canvasSourceSha256',
            'partitionReferenceSha256', 'validationState', 'lastCommand', 'reusableTarget', 'emptyAudit', 'saveOperation')
    result = {k: metadata[k] for k in keep if k in metadata}
    encoded = json.dumps(verification, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
    result.update(phase='completed', outcome='complete', running=False, publishing=False,
                  verification={'passed': True, 'sha256': hashlib.sha256(encoded).hexdigest(),
                                'f3dReimported': False, 'physicalPrintTested': False})
    return result


def purge_completed(state):
    """Remove a verified run under its held lock; never remove public deliverables.

    Preflight the entire tree first. Unknown/user files, links, active workers or
    changed exports make cleanup fail closed rather than recursively deleting.
    """
    if not enabled(state) or state['status'] != 'completed' or state['request'].get('debug'):
        return 0
    run = Path(state['runPath']).absolute()
    root = run.parent
    if (root.name != '.fmcad-keychain' or run.name != state['runId'] or not safe(run, root)
            or unconfirmed_worker(run)):
        raise ValueError('Completed cleanup blocked by unsafe path or unconfirmed worker')
    build = state.get('build') or {}
    cloud = build.get('cloud') or {}
    if (state.get('error') or build.get('running') or build.get('validationState') != 'passed'
            or not cloud.get('saved') or not cloud.get('isComplete') or cloud.get('modified')
            or not cloud.get('fingerprintVerified') or not cloud.get('fileId')):
        raise ValueError('Completed cleanup requires validated geometry and verified cloud save')
    # Inputs and deliverables must remain outside the disposable workspace.
    protected = [state['request'].get(k) for k in ('input', 'palette')]
    artifacts = state.get('artifacts') or []
    suffixes = {Path(item['path']).suffix.lower() for item in artifacts}
    if not {'.f3d', '.stl', '.zip'} <= suffixes:
        raise ValueError('Completed cleanup requires F3D, STL and ZIP deliverables')
    for item in artifacts:
        path = Path(item['path']).absolute()
        if not safe(path, Path(state['publicPath'])) or path.is_relative_to(root) or identity(path) is None:
            raise ValueError('Unsafe completed artifact location: ' + str(path))
        with path.open('rb') as stream:
            checksum = hashlib.file_digest(stream, 'sha256').hexdigest()
        if checksum != item['sha256'] or path.stat().st_size != item['bytes']:
            raise ValueError('Completed artifact missing or changed: ' + str(path))
        protected.append(str(path))
    if any(Path(p).absolute().is_relative_to(root) for p in protected if p):
        raise ValueError('Source input is inside the disposable workspace')
    frozen = (state.get('prepared') or {}).get('sourcePath')
    files, dirs = {}, {}
    def traversal_error(error):
        raise error
    for parent, names, filenames in os.walk(run, followlinks=False, onerror=traversal_error):
        for name in names:
            path = Path(parent) / name
            if (not safe(path, run) or (path != run / 'state'
                    and str(path) not in state.get('ownedDirectories', {}))):
                raise ValueError('Unknown or linked directory in completed workspace: ' + str(path))
            info = path.lstat()
            dirs[str(path)] = [info.st_dev, info.st_ino]
        for name in filenames:
            path = Path(parent) / name
            relative = path.relative_to(run).as_posix()
            expected = identity(path) if safe(path, run) else None
            declared = (allowed(relative) or str(path) == frozen or relative == 'run.lock'
                or relative == 'cad-build/geometry-checkpoint-unpublished.f3d'
                or re.fullmatch(r'state/(?:current|\d{8})\.json', relative)
                or re.fullmatch(r'(?:prepare|approve|build|status)-\d+-\d+-error\.log', relative))
            if not declared or expected is None:
                raise ValueError('Unknown or linked file retained in completed workspace: ' + str(path))
            prior = state.get('ownedFiles', {}).get(str(path))
            if prior is not None and expected != prior:
                raise ValueError('Modified generated file retained: ' + str(path))
            files[str(path)] = expected
    # The saved manifest must still describe this exact completed invocation.
    from keychain_state import read
    if read(run) != state:
        raise ValueError('Completed workspace state changed before cleanup')
    info = run.lstat()
    dirs[str(run)] = [info.st_dev, info.st_ino]
    # Keep the manifest and lock until all other files have been collected.
    final = {p: v for p, v in files.items() if Path(p).parent == run / 'state' or Path(p).name == 'run.lock'}
    temporary = {p: v for p, v in files.items() if p not in final}
    remaining, freed = collect(temporary, [run], protected=protected)
    if remaining:
        raise OSError('Could not remove all completed helper files; workspace retained')
    remaining, final_bytes = collect(final, [run], protected=protected)
    freed += final_bytes
    if remaining:
        raise OSError('Could not remove completed state files; workspace retained')
    remaining_dirs = collect_directories(dirs, [run])
    if remaining_dirs:
        raise OSError('Could not remove completed workspace directories')
    # Other failed/debug/in-progress runs or unknown files keep the parent alive.
    info = root.lstat()
    collect_directories({str(root): [info.st_dev, info.st_ino]}, [root])
    return freed
