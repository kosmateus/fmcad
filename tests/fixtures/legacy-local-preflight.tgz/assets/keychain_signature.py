"""Path-independent signatures of approved native keychain geometry."""

import hashlib
import json
from pathlib import Path


def plan_signature(plan: dict) -> str:
    """Return a SHA-256 hex digest without modifying the plan or filesystem.

    Uses the planner's thicknessMm/frontMm (T/front), exact JSON numbers and
    verbatim expression strings. List order and field/patch nesting are signed;
    paths, provenance, sketch labels and diagnostic evidence are not. Optional
    partition topology and layer construction are signed only when present,
    preserving the canonical payload of legacy plans.

    All templates must be existing regular files directly beside the base
    template, with no symlink components or '..'. The base parent is the trust
    boundary, not an independently authenticated run root. Invalid paths and
    non-finite signed numbers raise ValueError; malformed JSON/schema errors
    propagate. Callers must keep the plan and templates stable while signing.
    """
    specs = [plan['base']]
    for field in plan['fields']:
        specs.extend([field, *field['patches']])
    root = Path(plan['base']['geometryPath']).absolute().parent
    # Preflight every path before reading any template, including the base.
    for spec in specs:
        path = Path(spec['geometryPath']).absolute()
        if ('..' in path.parts or path.parent != root or
                any(part.is_symlink() for part in (path, *path.parents)) or
                not path.is_file()):
            raise ValueError('geometryPath must be a regular non-symlink file in the base parent')

    def profile(spec):
        record = {key: spec[key] for key in ('id', 'colorId', 'loopCount')}
        for key in ('priority', 'clipToField', 'zMinMm', 'zMaxMm'):
            if key in spec:
                record[key] = spec[key]
        template = json.loads(Path(spec['geometryPath']).read_text(encoding='utf-8'))
        if not isinstance(template['geometry'], list):
            raise ValueError('Template geometry must be an array')
        record['geometry'] = template['geometry']
        return record

    canonical = {key: plan[key] for key in (
        'widthMm', 'heightMm', 'thicknessMm', 'frontMm', 'imageSide',
        'mmPerPixel', 'centerPx', 'boundsPx', 'outlineColor')}
    canonical['colors'] = [{key: color[key] for key in ('id', 'name', 'hex')}
                           for color in plan['colors']]
    for key in ('construction', 'backing', 'partitionTopology', 'backZMinMm',
                'backZMaxMm', 'colorZMinMm', 'colorZMaxMm'):
        if key in plan:
            canonical[key] = plan[key]
    canonical['base'] = profile(plan['base'])
    canonical['fields'] = [dict(profile(field), patches=[profile(patch) for patch in field['patches']])
                           for field in plan['fields']]
    payload = json.dumps(canonical, sort_keys=True, allow_nan=False, separators=(',', ':'))
    return hashlib.sha256(payload.encode('utf-8')).hexdigest()
