"""Generic, local keychain preparation; scores are not CAD or fidelity proof."""
import base64
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import cv2
import numpy as np
from PIL import Image, ImageOps
from scipy import ndimage as ndi

_spec = importlib.util.spec_from_file_location('_keychain_offline_execution',
                                             Path(__file__).with_name('offline_execution.py'))
_offline = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_offline)
timed_stage = _offline.timed_stage

_spec = importlib.util.spec_from_file_location('_keychain_image_optimize',
                                             Path(__file__).with_name('image_optimize.py'))
optimize = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(optimize)
_spec = importlib.util.spec_from_file_location('_keychain_prepare_plan',
                                             Path(__file__).with_name('keychain_partition.py'))
planner = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(planner)
_spec = importlib.util.spec_from_file_location('_keychain_prepare_preview',
                                             Path(__file__).with_name('keychain_preview.py'))
preview = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(preview)
_spec = importlib.util.spec_from_file_location('_keychain_prepare_signature',
                                             Path(__file__).with_name('keychain_signature.py'))
signature = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(signature)

MIN_FEATURE_AREA = 64
LAB_WEIGHTS = (.35, 1., 1.)


def _physical_topology(foreground):
    """Measure significant union topology without modifying any input pixels."""
    structure = np.ones((3, 3), dtype=bool)
    raw, raw_count = ndi.label(foreground, structure=structure)
    opened = ndi.binary_opening(foreground, structure=structure, border_value=0)
    cores, _ = ndi.label(opened, structure=structure)
    significant = np.bincount(cores.ravel()) >= MIN_FEATURE_AREA
    significant[0] = False
    significant_count = int(np.count_nonzero(significant))
    # Reconstruct only for accounting: erosion fringes on a retained component
    # are not insignificant pixels. Neither this mask nor opening edits imagery.
    retained = np.unique(raw[significant[cores]])
    insignificant_pixels = int(np.count_nonzero(foreground & ~np.isin(raw, retained)))
    warnings = []
    if significant_count != 1:
        warnings.append(f'Disconnected or missing physical envelope: {significant_count} significant foreground '
                        f'components ({raw_count} raw); requires exactly one 8-connected component of at least '
                        f'{MIN_FEATURE_AREA} pixels after 3x3 opening. No islands removed or bridges invented; '
                        'correct/approve geometry before building.')
    if insignificant_pixels:
        warnings.append(f'{insignificant_pixels} foreground pixels belong to raw components without an opened '
                        f'core of at least {MIN_FEATURE_AREA} pixels. Ignored for physical readiness only, '
                        'not deleted or assumed to be noise; inspect small/narrow real features before building.')
    return dict(physicalTopologyReady=significant_count == 1,
                foregroundComponentCount=int(raw_count), rawForegroundComponentCount=int(raw_count),
                significantForegroundComponentCount=significant_count, insignificantPixelCount=insignificant_pixels,
                physicalTopologyPolicy=dict(connectivity=8, openingSize=[3, 3], openingBorderValue=0,
                                            minFeatureArea=MIN_FEATURE_AREA, scope='union of all foreground colors',
                                            significantComponentCount='8-connected opened cores with area >= minFeatureArea; '
                                                                      'opening may split narrow connections',
                                            readiness='exactly one significant component in both source and candidate',
                                            insignificantPixelCount='all pixels of raw components containing no significant '
                                                                    'opened core; excludes fringes of retained components',
                                            modifiesPixels=False), warnings=warnings)


def _classify(rgba, count, seed, supplied=None, override=None):
    pixels = np.asarray(rgba)
    rgb = pixels[..., :3]
    alpha = pixels[..., 3]
    lab = cv2.cvtColor(rgb.astype(np.float32) / 255, cv2.COLOR_RGB2LAB)
    border = np.zeros(alpha.shape, bool)
    border[[0, -1], :] = True
    border[:, [0, -1]] = True
    opaque_border = border & (alpha >= 128)
    background_lab = (np.median(lab[opaque_border], axis=0) if opaque_border.any()
                      else np.array([100., 0., 0.]))
    delta = np.linalg.norm(lab - background_lab, axis=2)
    spread = float(np.median(delta[opaque_border])) if opaque_border.any() else 0.
    threshold = min(18., max(6., 3 * spread))
    transparent = alpha < 128
    has_alpha_background = bool(np.any(transparent & border))
    warnings = []
    holes = dict(rawPossibleHoleCount=0, significantPossibleHoleCount=0, insignificantPossibleHolePixelCount=0,
                 possibleHolePolicy='RGB-only: count 4-connected enclosed near-background regions classified as '
                                    'background by the existing size rule; significant means original area >=64 pixels, '
                                    'without opening. Reporting only; classification unchanged.')
    if has_alpha_background:
        # Alpha supplies stronger evidence than white RGB values in a cutout.
        background = transparent.copy()
        segmentation_origin = 'alpha>=128 foreground; RGB values of transparent pixels ignored'
    else:
        near = delta <= threshold
        background = ndi.binary_propagation(border & near, mask=near) | transparent
        enclosed, components = ndi.label(near & ~background)
        silhouette_area = max(1, int((~background).sum()))
        # Small isolated background-like areas are possible eyelets. Large white
        # fields remain material; no filling all holes or dropping islands.
        for component, slices in enumerate(ndi.find_objects(enclosed), 1):
            if slices is None:
                continue
            mask = enclosed[slices] == component
            area = int(mask.sum())
            if area <= max(9, silhouette_area * .05):
                background[slices] |= mask
                holes['rawPossibleHoleCount'] += 1
                if area >= MIN_FEATURE_AREA:
                    holes['significantPossibleHoleCount'] += 1
                else:
                    holes['insignificantPossibleHolePixelCount'] += area
        segmentation_origin = 'border median CIELAB; border-connected near-color flood; small enclosed near-color holes'
        if components:
            warnings.append('RGB enclosed background-like regions are ambiguous: small regions (<=5% of silhouette, '
                            'minimum 9 pixels) treated as possible holes, larger regions retained as foreground. '
                            f"{holes['significantPossibleHoleCount']} significant possible holes (area >=64 pixels), "
                            f"{holes['rawPossibleHoleCount']} raw regions including subthreshold regions. "
                            'Classification unchanged by this reporting threshold; review original-photo overlays '
                            'or supply an alpha cutout.')
    foreground = ~background
    if not foreground.any():
        raise ValueError('No foreground detected; provide an image with a distinct background or alpha cutout')
    # Reduce shade-driven slot splitting, not image detail: segmentation above
    # remains unweighted, and neither pixels nor spatial labels are blurred.
    weights = np.asarray(LAB_WEIGHTS, dtype=np.float32)
    values = lab[foreground] * weights
    rgb_values = rgb[foreground]
    if supplied is None:
        rng = np.random.default_rng(seed % (2 ** 64))
        indices = (rng.choice(len(values), 50000, replace=False) if len(values) > 50000
                   else np.arange(len(values)))
        sample = values[indices].astype(np.float32)
        if len(np.unique(rgb_values[indices], axis=0)) < count:
            raise ValueError(f'Foreground has fewer than {count} distinct sampled colors; cannot invent colors')
        cv2.setRNGSeed(int(seed) % 2147483647)
        _, assignment, centers = cv2.kmeans(sample, count, None,
                                          (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_MAX_ITER, 80, .05),
                                          3, cv2.KMEANS_PP_CENTERS)
        representatives = []
        for index, center in enumerate(centers):
            members = np.flatnonzero(assignment.ravel() == index)
            nearest = members[np.argmin(np.sum((sample[members] - center) ** 2, axis=1))]
            representatives.append(tuple(int(v) for v in rgb_values[indices[nearest]]))
        representatives.sort()
        fills = ['#%02X%02X%02X' % value for value in representatives]
        palette_origin = ('seeded weighted CIELAB kmeans, <=50000 samples, observed nearest-center representatives; '
                          'IDs RGB-sorted before optional perimeter representative adaptation')
    else:
        fills = supplied
        palette_origin = 'user palette foreground colors unchanged, declaration order; nearest weighted CIELAB assignment'
    if override and override not in fills:
        if supplied is not None:
            raise ValueError('outlineColor must belong to the supplied palette')
        target = cv2.cvtColor(np.array([[list(bytes.fromhex(override[1:]))]], np.float32) / 255,
                              cv2.COLOR_RGB2LAB)[0, 0] * weights
        centers = cv2.cvtColor(np.array([[list(bytes.fromhex(c[1:])) for c in fills]], np.float32) / 255,
                              cv2.COLOR_RGB2LAB)[0] * weights
        fills[int(np.argmin(np.linalg.norm(centers - target, axis=1)))] = override
        fills.sort()
    if len(set(fills)) != count:
        raise ValueError('Quantization could not produce the requested distinct foreground colors')
    centers = cv2.cvtColor(np.array([[list(bytes.fromhex(c[1:])) for c in fills]], np.float32) / 255,
                          cv2.COLOR_RGB2LAB)[0] * weights
    best = np.full(len(values), np.inf, np.float32)
    assigned = np.zeros(len(values), np.uint8)
    for index, center in enumerate(centers):
        distance = np.sum((values - center) ** 2, axis=1)
        take = distance < best
        best[take] = distance[take]
        assigned[take] = index + 1
    if len(np.unique(assigned)) != count:
        raise ValueError('Requested palette contains unused colors; cannot fabricate foreground regions')
    labels = np.zeros(alpha.shape, np.uint8)
    labels[foreground] = assigned
    silhouette = ndi.binary_fill_holes(foreground)
    depth = ndi.distance_transform_edt(np.pad(silhouette, 1))[1:-1, 1:-1]
    band = foreground & (depth <= max(1., min(4., min(alpha.shape) * .012)))
    votes = np.bincount(labels[band], minlength=count + 1)[1:]
    winner = int(np.argmax(votes))
    original_representatives = [dict(id=f'Color_{i+1:02d}', hex=c) for i, c in enumerate(fills)]
    winning_band = band & (labels == winner + 1)
    band_rgb = rgb[winning_band]
    adaptation = dict(enabled=supplied is None and override is None, applied=False,
                      colorId=f'Color_{winner+1:02d}', originalRepresentative=fills[winner],
                      representative=fills[winner], foregroundClusterPixelCount=int(np.count_nonzero(labels == winner + 1)),
                      perimeterBandPixelCount=int(band.sum()), winningClusterPerimeterPixelCount=len(band_rgb),
                      eligibleObservedPixelCount=0, medianObservedRGB=None, reassignedPixelCount=0,
                      policy='Winning external inward-band cluster only; nearest observed RGB to that cluster\'s '
                             'perimeter median RGB, excluding collisions with other palette colors. '
                             'Change representative value only; no reassignment or ID reordering.')
    if adaptation['enabled'] and len(band_rgb):
        median = np.median(band_rgb, axis=0)
        allowed = np.ones(len(band_rgb), dtype=bool)
        for index, fill in enumerate(fills):
            if index != winner:
                allowed &= ~np.all(band_rgb == list(bytes.fromhex(fill[1:])), axis=1)
        adaptation.update(eligibleObservedPixelCount=int(allowed.sum()), medianObservedRGB=median.tolist())
        if allowed.any():
            observations = band_rgb[allowed]
            selected = observations[np.argmin(np.sum((observations.astype(np.float32) - median) ** 2, axis=1))]
            fills[winner] = '#%02X%02X%02X' % tuple(selected)
            adaptation.update(representative=fills[winner], applied=fills[winner] != adaptation['originalRepresentative'],
                              reason='observed_perimeter_representative')
        else:
            adaptation['reason'] = 'no_unique_observed_perimeter_color; original representative retained'
    else:
        adaptation['reason'] = ('supplied_palette_preserved' if supplied is not None else
                                'explicit_outline_override_preserved' if override is not None else 'empty_perimeter_band')
    inferred = fills[winner]
    outline = override or inferred
    confidence = float(votes[fills.index(outline)] / max(1, votes.sum()))
    if confidence < .65:
        warnings.append('Ambiguous perimeter color: inward external-silhouette band has less than 65% support '
                        'for outlineColor; review or provide an outlineColor override.')
    topology = _physical_topology(foreground)
    warnings.extend(topology['warnings'])
    warnings.append('Weighted CIELAB palette distance is a shade-resistant heuristic, not image blur or a guarantee '
                    'of recovering artwork colors. Requested N is unchanged; inspect classified colors and semantic evidence.')
    # Near-white sentinel remains distinct even when real material is white.
    background_hex = next('#%02X%02X%02X' % (255, 255, b) for b in range(255, 237, -1)
                          if '#%02X%02X%02X' % (255, 255, b) not in fills)
    colors = [dict(id=f'Color_{i+1:02d}', name=f'Color_{i+1:02d}', hex=c) for i, c in enumerate(fills)]
    palette = dict(background=background_hex,
                   colors=[dict(name=c['name'], color=c['hex']) for c in colors],
                   rules=[dict(color=c['name'], ranges={channel: [v, v] for channel, v in
                                                      zip('rgb', bytes.fromhex(c['hex'][1:]))}) for c in colors])
    table = np.array([list(bytes.fromhex(c[1:])) for c in [background_hex] + fills], np.uint8)
    return Image.fromarray(table[labels]), palette, dict(topology, **holes,
        outlineColor=outline, outlineConfidence=confidence, inferredOutlineColor=inferred,
        outlineOrigin='user override' if override else 'external silhouette inward-band majority',
        colors=colors, colorCount=count, warnings=warnings, segmentationOrigin=segmentation_origin,
        backgroundLab=background_lab.tolist(), backgroundThresholdLab=threshold, paletteOrigin=palette_origin,
        paletteLabWeights=list(LAB_WEIGHTS),
        paletteMetric='Squared Euclidean distance after multiplying CIELAB [L*,a*,b*] by paletteLabWeights; '
                      'same metric for kmeans, observed-center representatives and nearest-prototype assignment. '
                      'Background segmentation remains unweighted.',
        originalClusterRepresentatives=original_representatives, outlineAdaptation=adaptation)


def _overlay(svg_path, size, background, original_uri):
    """Optimizer emits simple paths; omit nonpainting/helper subtrees defensively."""
    width, height = size
    root = ET.Element('svg', xmlns=optimize.trace.SVG, width=str(width), height=str(height),
                      viewBox=f'0 0 {width} {height}')
    ET.SubElement(root, 'image', width=str(width), height=str(height), href=original_uri)
    visible_fills = set()
    def visit(element, parent, inherited_fill='#000000'):
        tag = element.tag.split('}')[-1]
        style = dict(pair.split(':', 1) for pair in element.get('style', '').split(';') if ':' in pair)
        attrs = {**element.attrib, **{k.strip(): v.strip() for k, v in style.items()}}
        if (tag in ('defs', 'clipPath', 'mask', 'symbol', 'metadata', 'title', 'desc')
                or attrs.get('display') == 'none' or attrs.get('visibility') in ('hidden', 'collapse')
                or float(attrs.get('opacity', '1')) == 0 or float(attrs.get('fill-opacity', '1')) == 0):
            return
        fill = attrs.get('fill', inherited_fill).upper()
        if tag == 'path' and fill not in (background, 'NONE') and element.get('d'):
            visible_fills.add(fill)
            ET.SubElement(parent, 'path', d=element.get('d'), transform=element.get('transform', ''),
                          fill='none', stroke='#00BFFF', **{'stroke-width': '.75'})
        elif tag in ('svg', 'g'):
            group = ET.SubElement(parent, 'g', transform=element.get('transform', ''))
            for child in element:
                visit(child, group, fill)
    visit(ET.parse(svg_path).getroot(), root)
    return ET.tostring(root, encoding='utf-8', xml_declaration=True), visible_fills


def prepare(request, run_dir: Path, public_dir: Path) -> dict:
    backing = request.get('backing', 'silhouette')
    if backing not in ('silhouette', 'convex-hull'):
        raise ValueError('backing must be silhouette or convex-hull')
    count = request.get('colors')
    if type(count) is not int or not 1 <= count <= 16:
        raise ValueError('colors must be an integer in [1, 16]; dispatcher must request missing input')
    if not optimize.trace.numeric(request.get('thicknessMm')) or request['thicknessMm'] <= 0:
        raise ValueError('thicknessMm must be positive; dispatcher must request missing input')
    trials = request.get('trials', 24)
    seed = request.get('seed', 17)
    if type(trials) is not int or not 2 <= trials <= 128 or type(seed) is not int:
        raise ValueError('trials must be in [2,128] and seed must be an integer')
    override = optimize.trace.color(request['outlineColor']) if request.get('outlineColor') else None
    supplied = None
    if request.get('palette'):
        data = json.loads(Path(request['palette']).read_text(encoding='utf-8'))
        # Accept the existing image.trace palette schema, not a new project format.
        if not isinstance(data, dict) or not isinstance(data.get('colors'), list):
            raise ValueError('palette must be an image.trace palette with a colors array')
        if any(not isinstance(c, dict) or 'color' not in c for c in data['colors']):
            raise ValueError('Each palette entry must declare color as #RRGGBB')
        supplied = [optimize.trace.color(c['color']) for c in data['colors']]
        if len(supplied) != count or len(set(supplied)) != count:
            raise ValueError('palette must declare exactly colors distinct foreground colors')
    source = Path(request['input']).read_bytes()
    with Image.open(io.BytesIO(source)) as loaded:
        raw_format = loaded.format
        raw_size = list(loaded.size)
        animated = bool(getattr(loaded, 'is_animated', False))
        loaded.seek(0)
        orientation = loaded.getexif().get(274, 1)
        rgba = ImageOps.exif_transpose(loaded).convert('RGBA')
        suffix = '.' + (raw_format or 'img').lower()
        mime = Image.MIME.get(raw_format)
        canvas_converted = raw_format not in ('PNG', 'JPEG', 'TIFF') or orientation != 1 or animated
        display_converted = canvas_converted or raw_format not in ('PNG', 'JPEG')
        embedded = source
        if display_converted:
            # Canvas and browser share normalized first-frame pixels. Remove EXIF
            # from the helper so no consumer can apply the orientation a second time.
            rgba.info.pop('exif', None)
            buffer = io.BytesIO()
            rgba.save(buffer, format='PNG')
            embedded, mime = buffer.getvalue(), 'image/png'
    normalization = dict(rawFormat=raw_format, originalImageSize=raw_size, normalizedImageSize=list(rgba.size),
                         exifOrientation=orientation, appliedOrientation=orientation if orientation in range(2, 9) else 1,
                         orientationApplied=orientation in range(2, 9), frameIndex=0, animated=animated,
                         canvasConverted=canvas_converted, displayConverted=display_converted)
    original_uri = 'data:' + mime + ';base64,' + base64.b64encode(embedded).decode('ascii')
    classified, palette, metadata = timed_stage('prepare.classify', _classify, rgba, count, seed, supplied, override)
    run_dir, public_dir = Path(run_dir).resolve(), Path(public_dir).resolve()
    overlays = public_dir / 'overlays'
    if public_dir == run_dir or public_dir in run_dir.parents or run_dir in public_dir.parents:
        raise ValueError('run_dir and public_dir must be separate non-nested directories')
    for directory in (run_dir, public_dir):
        if directory.exists() and not directory.is_dir():
            raise ValueError('Output must be a directory')
        if not directory.exists() and not directory.parent.is_dir():
            raise ValueError('Output parent directory must exist')
    targets = [run_dir / ('source' + suffix), run_dir / 'classified.png', run_dir / 'palette.json',
               run_dir / 'optimization', run_dir / 'preparation-report.json', overlays, run_dir / 'plan-checks']
    canvas_path = run_dir / 'canvas_source.png' if canvas_converted else targets[0]
    display_path = (canvas_path if canvas_converted else run_dir / 'display_source.png') if display_converted else targets[0]
    if display_converted:
        targets.append(display_path)
    if any(p.exists() or p.is_symlink() for p in targets):
        raise ValueError('Preparation artifacts already exist; use new run/public directories; no overwrite')
    run_dir.mkdir(exist_ok=True)
    public_dir.mkdir(exist_ok=True)
    with targets[0].open('xb') as stream:
        stream.write(source)
    if display_converted:
        with display_path.open('xb') as stream:
            stream.write(embedded)
    with targets[1].open('xb') as stream:
        classified.save(stream, format='PNG')
    optimize.trace.write_json(targets[2], palette)
    optimization_request = dict(input=str(targets[1]), reference=str(targets[1]), palette=str(targets[2]),
                                out=str(targets[3]), trials=trials, seed=seed, topK=min(3, trials),
                                minFeatureArea=MIN_FEATURE_AREA,
                                base=dict(widthMm=request.get('widthMm', 50), mirrorX=False))
    for field in ('search', 'regions'):
        if field in request:
            optimization_request[field] = request[field]
    report = timed_stage('prepare.optimize', optimize.execute, optimization_request)['result']
    from generated_cleanup import collect, inventory
    from keychain_cleanup import allowed
    # Scoring/contact sheets have consumed these images and sketch batches.
    # Keep every editable candidate SVG for explicit selection/correction.
    cleanup_bytes = 0
    if not request.get('debug', False):
        owned = inventory(run_dir, allowed)
        consumed = {p: v for p, v in owned.items() if Path(p).is_relative_to(targets[3])}
        _, cleanup_bytes = collect(consumed, [targets[3]],
            keep=[str(Path(c['out']) / 'contours.svg') for c in report['candidates']],
            protected=[request['input'], request.get('palette')])
        # Internal stdout transport survives a later timeout; supervisor folds
        # this into its final JSON counter before removing execution logs.
        print('FMCAD_CLEANUP_BYTES ' + str(cleanup_bytes), flush=True)
    plan_checks = run_dir / 'plan-checks'
    plan_checks.mkdir()
    candidates = []
    overlay_data = {}
    color_table = np.array([list(bytes.fromhex(c[1:])) for c in
                            [palette['background']] + [c['color'] for c in palette['colors']]], np.float32)
    reference_labels, _ = optimize.labels_for(classified, color_table, np)
    semantic_reference = preview.reference_features(reference_labels, count)
    for record in report['candidates']:
        svg = Path(record['out']) / 'contours.svg'
        candidate = dict(record, svgPath=str(svg) if svg.is_file() else None, overlayPath=None,
                         colorCount=0, physicalTopologyReady=False, backing=backing,
                         geometryPlanReady=False, planningFailure=None, planningCheckPath=None,
                         semanticAuditPassed=False, semanticAudit=None, semanticFailure=None, plannedColorCount=0,
                         normalizedSvgPath=None, normalizedPngPath=None, overlayOrigin='raw_candidate',
                         rasterTopologyRepaired=False, rasterFailures=list(record.get('failures', [])),
                         failures=list(record.get('failures', [])))
        raw_audit_passed = False
        if svg.is_file():
            try:
                # Count rendered foreground, not declared fills or invisible helper paths.
                rendered_bytes = optimize.trace.importlib.import_module('cairosvg').svg2png(bytestring=svg.read_bytes())
                with Image.open(io.BytesIO(rendered_bytes)) as image:
                    if image.size != rgba.size:
                        raise ValueError('Candidate SVG dimensions differ from source')
                    rendered = Image.alpha_composite(Image.new('RGBA', image.size, palette['background']),
                                                     image.convert('RGBA')).convert('RGB')
                labels, _ = optimize.labels_for(rendered, color_table, np)
                overlay, visible_fills = _overlay(svg, rgba.size, palette['background'], original_uri)
                populations = np.bincount(labels.ravel(), minlength=count + 1)
                candidate['colorCount'] = sum(int(populations[i + 1] > 0 and c['color'] in visible_fills)
                                              for i, c in enumerate(palette['colors']))
                candidate.update(_physical_topology(labels > 0))
                candidate['physicalTopologyReady'] &= metadata['physicalTopologyReady']
                overlay_data[candidate['id']] = overlay
                raw_audit_passed = True
            except Exception as exc:
                # Optimizer failures may leave incomplete SVGs. Retain the evidence
                # and reject the candidate rather than aborting or recommending it.
                candidate['failures'].append(dict(reason='candidate_svg_audit_error',
                                                   type=type(exc).__name__, message=str(exc)))
        if candidate['colorCount'] != count:
            candidate['failures'].append(dict(reason='foreground_color_count', expected=count,
                                               actual=candidate['colorCount']))
        source_topology_allowed = candidate['physicalTopologyReady'] or backing == 'convex-hull'
        candidate['rawPhysicalTopologyReady'] = candidate['physicalTopologyReady']
        if not source_topology_allowed:
            candidate['failures'].append(dict(reason='disconnected_or_missing_physical_envelope'))
        candidate['rasterEligible'] = bool(record['eligible'] and not candidate['failures'])
        topology_only = bool(record.get('failures')) and all(
            set(f) == {'scope', 'color', 'reference', 'candidate'}
            and isinstance(f['reference'], dict) and isinstance(f['candidate'], dict)
            and set(f['reference']) == set(f['candidate']) == {'components', 'holes'}
            for f in record['failures'])
        candidate['planningEligible'] = bool(raw_audit_passed and source_topology_allowed
            and candidate['colorCount'] == count and not record.get('error') and record.get('score') is not None
            and (candidate['rasterEligible'] or topology_only))
        if candidate['planningEligible']:
            plan_out = plan_checks / candidate['id']
            inputs = dict(svg_path=str(svg), palette_path=str(targets[2]), outline_color=metadata['outlineColor'],
                          width_mm=request.get('widthMm', 50), thickness_mm=request['thicknessMm'],
                          front_mm=request.get('frontMm', min(.8, request['thicknessMm'] / 2)),
                          image_side=request.get('imageSide', 'bottom'),
                          reference_path=str(targets[1]), backing=backing,
                          fit_error_px=float(np.clip(record['parameters'].get('lengthThreshold', 4) * .08, .15, .65)),
                          corner_angle=record['parameters'].get('cornerThreshold', 55), scale=2)
            candidate['partitionInputs'] = inputs
            check = dict(candidateId=candidate['id'], inputs=inputs, geometryPlanReady=False,
                         geometryValidated=False, purpose='Offline preflight only; build regenerates its own approved plan')
            try:
                plan = timed_stage(candidate['id'] + '.partition_plan', planner.make_partition_plan, **inputs, output_dir=plan_out)
                candidate['geometryPlanReady'] = True
                candidate.update(construction=plan.get('construction'), backing=backing,
                                 partitionValidation=plan.get('validation', {}),
                                 backingProof=plan.get('backingProof', dict(
                                     mode=backing, explicitMaterialAddition=backing == 'convex-hull',
                                     sourceComponentCount=metadata['significantForegroundComponentCount'],
                                     sourceRawComponentCount=metadata['rawForegroundComponentCount'],
                                     addedAreaPx2=plan.get('validation', {}).get('backingAddedAreaPx2'))),
                                 backZMinMm=plan.get('backZMinMm'), backZMaxMm=plan.get('backZMaxMm'))
                candidate['warnings'].extend(plan.get('warnings', []))
                check.update(geometryPlanReady=True, sourceSha256=plan.get('sourceSha256'),
                             warnings=plan.get('warnings', []), validation=plan.get('validation', {}))
                candidate['planSignature'] = signature.plan_signature(plan)
                normalized = timed_stage(candidate['id'] + '.preview', preview.render_plan, plan, rgba.size, palette['background'], original_uri, plan_out)
                planned_labels, _ = optimize.labels_for(normalized['image'], color_table, np)
                audit = timed_stage(candidate['id'] + '.semantic_audit', preview.semantic_audit, semantic_reference, planned_labels,
                                              [c['color'] for c in palette['colors']], normalized['paintedColors'],
                                              backing=backing)
                planned_topology = _physical_topology(planned_labels > 0)
                if not planned_topology['physicalTopologyReady']:
                    audit['failures'].append(dict(reason='planned_physical_envelope',
                                                 significantForegroundComponentCount=planned_topology['significantForegroundComponentCount']))
                    audit['passed'] = False
                candidate.update(semanticAuditPassed=audit['passed'], semanticAudit=audit,
                                 physicalTopologyReady=planned_topology['physicalTopologyReady'],
                                 plannedColorCount=audit['plannedColorCount'], plannedPhysicalTopology=planned_topology,
                                 normalizedSvgPath=normalized['svgPath'], normalizedPngPath=normalized['pngPath'],
                                 overlayOrigin='canonical_plan', overlayPolicy=normalized['overlayPolicy'])
                overlay_data[candidate['id']] = normalized['overlay']
                check.update(semanticAudit=audit, plannedPhysicalTopology=planned_topology,
                             normalizedSvgPath=normalized['svgPath'], normalizedPngPath=normalized['pngPath'])
                if audit['passed']:
                    if topology_only:
                        candidate['failures'] = [f for f in candidate['failures'] if f not in record['failures']]
                        candidate['rasterTopologyRepaired'] = True
                        candidate['warnings'].append('Raw optimizer topology counts describe intermediate traced fills, '
                            'not final planned paint. Canonical shared-partition paint passed the fixed-reference '
                            'semantic replacement gate; raw topology mismatches no longer veto eligibility. '
                            'Optimizer score remains an unchanged intermediate-raster heuristic, not a global optimum.')
                else:
                    candidate['semanticFailure'] = 'Planned semantic audit failed: ' + ', '.join(
                        sorted({f['reason'] for f in audit['failures']})) + '. See planningCheckPath for component evidence.'
                    candidate['failures'].append(dict(reason='planned_semantic_audit_failed', evidence=audit['failures']))
            except Exception as exc:
                # Retain partial planner output and the failure; do not repair,
                # retry, or let a failed preflight become a recommendation.
                candidate['planningFailure'] = f'{type(exc).__name__}: {exc}'
                if candidate['geometryPlanReady']:
                    candidate['semanticFailure'] = candidate['planningFailure']
                failure = dict(reason='planned_preview_failed' if candidate['geometryPlanReady'] else 'geometry_plan_failed',
                               type=type(exc).__name__, message=str(exc))
                candidate['failures'].append(failure)
                check['failure'] = failure
                bundle = plan_out / 'failure-plan.json'
                if not candidate['geometryPlanReady'] and bundle.is_file():
                    candidate['planningFailureBundlePath'] = str(bundle)
                    check['failurePlanPath'] = str(bundle)
            plan_out.mkdir(exist_ok=True)
            check_path = plan_out / 'check.json'
            optimize.trace.write_json(check_path, check)
            candidate['planningCheckPath'] = str(check_path)
        else:
            candidate['planningFailure'] = 'Skipped: processing/SVG error, missing colors, disconnected envelope, or non-topology optimizer failure.'
        candidate['eligible'] = bool(candidate['planningEligible'] and candidate['geometryPlanReady'] and candidate['semanticAuditPassed'])
        candidates.append(candidate)
    candidates.sort(key=lambda c: (not c['eligible'], c['score'] is None,
                                    c['score'] if c['score'] is not None else 0, c['index']))
    overlays.mkdir()
    for rank, candidate in enumerate(candidates, 1):
        if candidate['id'] in overlay_data:
            path = overlays / f"{rank:03d}-{candidate['id']}-overlay.svg"
            with path.open('xb') as stream:
                stream.write(overlay_data[candidate['id']])
            candidate['overlayPath'] = str(path)
            candidate['overlaySha256'] = hashlib.sha256(overlay_data[candidate['id']]).hexdigest()
    recommendations = [c['id'] for c in candidates if c['eligible']][:3]
    reason = None if recommendations else ('No eligible candidate: inspect candidate failures for optimizer topology, '
                                           'exact foreground color count, disconnected physical envelope, or offline '
                                           'geometry planning failure (see planningFailure), or planned semantic feature loss '
                                           '(see semanticAudit); '
                                           'correct the source/palette or SVG before approval.')
    warnings = metadata['warnings'] + ['Scores compare candidate curves to one frozen classified reference, not to '
                                       'original-photo truth; segmentation, subpixel defects and CAD validity are not proven.',
                                        'Recommendations require offline geometry planning and the fixed-reference planned semantic audit to pass. '
                                        'Raw topology counts are intermediate diagnostics, not final planned topology. This is not native CAD '
                                       'validation; build must regenerate the plan from the approved SVG.']
    if reason:
        warnings.append(reason)
    if backing == 'convex-hull':
        warnings.append('Explicit convex-hull backing adds outline-color material outside the original silhouette. '
                        'Review the amber dashed backing boundary; original artwork features and enclosed physical '
                        'holes must still pass the semantic audit. This adaptation is not automatic approval.')
    result = dict(metadata, sourcePath=str(targets[0]), sourceSha256=hashlib.sha256(source).hexdigest(),
                  canvasPath=str(canvas_path), canvasSha256=hashlib.sha256(embedded if canvas_converted else source).hexdigest(),
                  displaySourcePath=str(display_path), displaySourceSha256=hashlib.sha256(embedded).hexdigest(),
                   imageNormalization=normalization, backing=backing, construction='partition_prisms',
                  classifiedPath=str(targets[1]), palettePath=str(targets[2]), imageSize=list(rgba.size),
                  candidates=candidates, recommendations=recommendations, warnings=warnings,
                  status='awaiting_selection' if recommendations else 'no_eligible_candidate', reason=reason,
                  optimizationReportPath=str(targets[4]), rawOptimizationReportPath=report['files']['report'],
                  referenceOrigin='immutable classified PNG; exact RGB rules; never candidate-dependent',
                  scoreOrigin='image.optimize heuristic against frozen classified reference',
                  colorCountCriterion='Exactly N foreground colors in both the visible raw SVG and normalized planned '
                                      'paint, with nonzero nearest-palette pixel population at source resolution; '
                                      'no automatic color-count reduction',
                  geometryValidated=False)
    if request.get('debug', False):
        optimize.trace.write_json(targets[4], dict(result, optimization=report))
    else:
        result['optimizationReportPath'] = None
        result['rawOptimizationReportPath'] = None
    return result
