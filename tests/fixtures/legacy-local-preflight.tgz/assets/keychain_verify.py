"""Local, read-only inspection of a final keychain delivery, without run metadata."""
import math
from pathlib import Path
import zipfile

from keychain_build import ARCHIVE_CHUNK_BYTES, inspect_stl, require, verify_f3d_archive


def report_base():
    return {'status': 'failed', 'fileChecksPassed': False,
            'nativeComparison': 'notEvaluated', 'physicalValidation': 'notEvaluated',
            'units': 'mm', 'unitConvention': 'keychain-mm',
            'unitEvidence': 'Explicit caller convention; STL has no unit metadata',
            'sideEffects': False}


def verify(data):
    report = report_base()
    colors = data.get('colors')
    require(type(colors) is int and 1 <= colors <= 16, 'colors must be an integer in [1,16]')
    for key in ('widthMm', 'thicknessMm', 'frontMm'):
        value = data.get(key)
        require(type(value) in (int, float) and math.isfinite(value) and value > 0,
                key + ' must be an explicit finite positive number')
    width, thickness, front = (data[key] for key in ('widthMm', 'thicknessMm', 'frontMm'))
    require(front < thickness, 'frontMm must be less than thicknessMm')
    side = data.get('imageSide')
    require(side in ('bottom', 'top'), 'imageSide must be explicitly bottom or top')
    directory = data.get('directory')
    require(isinstance(directory, str) and Path(directory).is_absolute(), 'directory must be an absolute local path')
    directory = Path(directory)
    require(not any(p.is_symlink() for p in (directory, *directory.parents)), 'Symlink directory rejected')
    require(directory.is_dir(), 'directory must exist')
    entries = sorted(directory.iterdir())
    require(all(p.is_file() and not p.is_symlink() for p in entries), 'Delivery entries must be regular files')
    stls = [p for p in entries if p.suffix == '.stl']
    require(len(stls) == colors, f'Expected {colors} STL files, found {len(stls)}')
    names = {p.name for p in entries}
    payloads = {'model.f3d', *(p.name for p in stls)}
    require(names == payloads | {'keychain.zip'}, 'Expected only model.f3d, keychain.zip and color STLs')
    report['nativeArchive'] = verify_f3d_archive(directory / 'model.f3d')
    with zipfile.ZipFile(directory / 'keychain.zip') as archive:
        members = archive.infolist()
        require(len(members) == len(payloads) and {m.filename for m in members} == payloads,
                'Delivery ZIP member set differs from files (or duplicate members)')
        for member in members:
            path = directory / member.filename
            require(member.file_size == path.stat().st_size, 'Delivery ZIP member size mismatch: ' + member.filename)
            with archive.open(member) as zipped, path.open('rb') as local:
                while True:
                    chunk = zipped.read(ARCHIVE_CHUNK_BYTES)
                    require(chunk == local.read(ARCHIVE_CHUNK_BYTES), 'Delivery ZIP member bytes mismatch: ' + member.filename)
                    if not chunk:
                        break
    report['deliveryArchive'] = {'crcVerified': True, 'exactFileBytesMatched': True, 'members': sorted(payloads)}
    meshes = {}
    for path in stls:
        try:
            meshes[path.name] = inspect_stl(path.read_bytes())
        except (TimeoutError, InterruptedError):
            raise
        except Exception as error:
            raise ValueError('STL inspection failed: ' + path.name + ': ' + str(error)) from error
    require(all(math.isfinite(m['volumeMm3']) for m in meshes.values()), 'STL volume must be finite')
    bounds = [[extreme(m['boundsMm'][end][axis] for m in meshes.values())
               for axis in range(3)] for end, extreme in enumerate((min, max))]
    # Same 0.01 mm bounds tolerance as build's native comparison; no unit inference.
    tolerance = .01
    def close(actual, expected):
        return abs(actual - expected) <= tolerance
    require(close(bounds[1][0] - bounds[0][0], width), 'Union X width disagrees with widthMm (keychain-mm convention)')
    require(close(bounds[1][2] - bounds[0][2], thickness), 'Union Z thickness disagrees with thicknessMm')
    require(close(bounds[0][2], 0) and close(bounds[1][2], thickness), 'Union Z must span 0..thicknessMm')
    lo, hi = (0, front) if side == 'bottom' else (thickness - front, thickness)
    backing = []
    for name, mesh in meshes.items():
        zlo, zhi = mesh['boundsMm'][0][2], mesh['boundsMm'][1][2]
        if close(zlo, 0) and close(zhi, thickness):
            backing.append(name)
        else:
            require(close(zlo, lo) and close(zhi, hi), 'Front Z interval mismatch: ' + name)
    require(len(backing) == 1, 'Expected exactly one full-thickness backing-color STL')
    report.update(status='verified', fileChecksPassed=True, directory=str(directory), meshes=meshes,
                  expectations=data.copy(), boundsMm=bounds, boundsToleranceMm=tolerance,
                  frontZIntervalMm=[lo, hi], backingColorFile=backing[0])
    return report
