"""Read-only existing-project preflight; no project/folder/document creation."""
import json

ARGS = {}


def items(collection):
    return [collection.item(i) for i in range(collection.count)]


def resolve(app, args):
    selector = 'projectId' if 'projectId' in args else 'project'
    if (('projectId' in args) + ('project' in args) != 1 or
            not isinstance(args.get(selector), str) or not args[selector].strip()):
        raise ValueError('Existing project requires exactly one nonempty name or ID')
    matches = [p for p in items(app.data.dataProjects)
               if getattr(p, 'id' if selector == 'projectId' else 'name') == args[selector]]
    if len(matches) != 1:
        raise ValueError('Existing project must match exactly one accessible project')
    project = matches[0]
    folder = project.rootFolder
    if not project.id or not folder.id or folder.parentProject.id != project.id:
        raise ValueError('Existing project root membership mismatch')
    if not args.get('documentFileId') and any(f.name.casefold() == args['name'].casefold() for f in items(folder.dataFiles)):
        raise ValueError('Unique document filename already exists in project root')
    return dict(projectId=project.id, projectName=project.name, folderId=folder.id)


def execute(args):
    import adsk.core
    import adsk.fusion
    app = adsk.core.Application.get()
    target = resolve(app, args)
    documents = items(app.documents)
    if any(not d.creationId for d in documents) or not hasattr(adsk.core.Document, 'creationId'):
        raise ValueError('Installed SDK lacks document creationId inspection')
    if not args.get('documentFileId') and any(d.name.casefold() == args['name'].casefold() for d in documents):
        raise ValueError('Unique document name already exists')
    for api, members in ((adsk.fusion.Canvases, ('createInput', 'add')),
                         (adsk.fusion.ExportManager, ('createSTLExportOptions', 'createFusionArchiveExportOptions', 'execute')),
                         (adsk.fusion.STLExportOptions, ('surfaceDeviation', 'unitType', 'sendToPrintUtility', 'isOneFilePerBody')),
                         (adsk.fusion.CanvasInput, ('transform',)), (adsk.core.Matrix2D, ('setWithArray', 'asArray'))):
        if not all(hasattr(api, member) for member in members):
            raise ValueError('Installed SDK lacks required export/canvas APIs: ' + str(members))
    return target


def run(_context: str):
    print('KEYCHAIN_RESULT ' + json.dumps({'success': True, 'result': execute(ARGS)}, allow_nan=False))
