"""Bounded POSIX offline children only. Never use to supervise Fusion itself."""
import datetime
import array
from contextlib import ExitStack
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import uuid
from diagnostics import DiagnosticStream, redact_diagnostic

DEFAULT_TIMEOUT_MS = 0


def timeout_seconds(value=None):
    value = float(value if value is not None else os.environ.get('FMCAD_OFFLINE_TIMEOUT_MS', DEFAULT_TIMEOUT_MS))
    if not math.isfinite(value) or value < 0:
        raise ValueError('offline timeout must be finite nonnegative milliseconds (zero means unlimited)')
    return value / 1000


def event(stage, status, started, **details):
    record = dict(timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  stage=stage, status=status, elapsedSeconds=round(time.monotonic() - started, 6), **details)
    print(redact_diagnostic(json.dumps(record)), file=sys.stderr, flush=True)
    return record


def timed_stage(stage, function, *args, **kwargs):
    started = time.monotonic()
    event(stage, 'started', started)
    try:
        value = function(*args, **kwargs)
    except BaseException:
        event(stage, 'failed', started)
        raise
    event(stage, 'completed', started)
    return value


def run_offline(command, *, log_parent, stage, input_text=None, timeout=None, cwd=None, debug=None):
    """Pump nonblocking pipes; only redacted diagnostic copies reach disk.

    Raw input/stdout and incomplete diagnostic lines use proportional memory,
    preserving the full execution-result contract without a raw disk spill.

    Only the new session/group is signalled. SIGTERM/SIGINT of this supervisor
    triggers the same cleanup. Normal exit also cleans up leftover descendants.
    Explicitly fail closed where POSIX group cleanup is unavailable.
    """
    if os.name != 'posix':
        raise RuntimeError('Offline process-group supervision currently requires POSIX (use WSL)')
    import fcntl
    import termios
    debug = os.environ.get('FMCAD_KEYCHAIN_DEBUG') == 'true' if debug is None else debug
    budget = timeout_seconds() if timeout is None else float(timeout)
    if not math.isfinite(budget) or budget < 0:
        raise ValueError('offline timeout seconds must be finite and nonnegative')
    started = time.monotonic()
    deadline = started + budget if budget else float('inf')
    from keychain_deadline import remaining, note_signal
    command_remaining = remaining()
    if command_remaining is not None:
        deadline = min(deadline, started + command_remaining)
    inherited = os.environ.get('FMCAD_OFFLINE_DEADLINE_MONOTONIC')
    if inherited:
        inherited = float(inherited)
        if not math.isfinite(inherited):
            raise ValueError('Invalid inherited offline deadline')
        deadline = min(deadline, inherited)
    if deadline <= started:
        raise TimeoutError('Offline pipeline deadline exhausted; no child started')
    folder = Path(log_parent) / ('execution-' + uuid.uuid4().hex)
    folder.mkdir(mode=0o700)
    active = folder / 'active.json'
    active.write_text('{}')
    events = (folder / 'events.jsonl').open('x')
    def report(status, **details):
        record = event(stage, status, started, **details)
        events.write(redact_diagnostic(json.dumps(record)) + '\n')
        events.flush()
    interrupted = []
    previous = {}
    child = None
    owned = {}
    cleaned = False
    timed_out = False
    pipes = []
    captures = []
    raw_stdout = bytearray()
    source_bytes = (input_text or '').encode('utf-8')
    source_offset = 0
    def pump():
        nonlocal source_offset
        moved = False
        if child.stdin and not child.stdin.closed:
            try:
                if source_offset < len(source_bytes):
                    source_offset += os.write(child.stdin.fileno(), source_bytes[source_offset:source_offset+65536])
                    moved = True
                if source_offset == len(source_bytes):
                    child.stdin.close()
            except BlockingIOError:
                pass
            except BrokenPipeError:
                child.stdin.close()
        for stream, capture, raw in captures:
            if stream.closed:
                continue
            try:
                chunk = os.read(stream.fileno(), 65536)
            except BlockingIOError:
                continue
            if chunk:
                moved = True
                if raw:
                    raw_stdout.extend(chunk)
                capture.feed(chunk)
            else:
                stream.close()
        return moved
    def interrupt(signum, frame):
        nonlocal timed_out
        if signum == signal.SIGALRM:
            timed_out = True
        else:
            interrupted.append(signum)
            note_signal(signum)
    def group_signal(signum):
        try:
            os.killpg(child.pid, signum)
        except ProcessLookupError:
            pass
    def discover():
        processes = process_snapshot()
        if not owned and child.pid in processes:
            owned[child.pid] = processes[child.pid][2]
        changed = True
        while changed:
            changed = False
            for pid, (_, parent, identity) in processes.items():
                if pid not in owned and parent in owned and processes.get(parent, (None, None, None))[2] == owned[parent]:
                    owned[pid] = identity
                    changed = True
    def owned_running(signum=None):
        running = False
        for pid, (state, _, identity) in process_snapshot().items():
            if owned.get(pid) == identity and state not in ('Z', 'X'):
                running = True
                if signum is not None:
                    try:
                        os.kill(pid, signum)
                    except ProcessLookupError:
                        pass
        return running
    try:
        # Defer the command alarm while owning a group, including cleanup. An
        # asynchronous exception must not interrupt termination/checkpoint rules.
        for signum in (signal.SIGTERM, signal.SIGINT, signal.SIGALRM):
            previous[signum] = signal.signal(signum, interrupt)
        env = dict(os.environ, PYTHONUNBUFFERED='1')
        if math.isfinite(deadline):
            env['FMCAD_OFFLINE_DEADLINE_MONOTONIC'] = str(deadline)
        else:
            env.pop('FMCAD_OFFLINE_DEADLINE_MONOTONIC', None)
        # Sanitize the copy in memory before even creating its file.
        sanitized_input = []
        DiagnosticStream(sanitized_input.append).feed(source_bytes, final=True)
        with (folder / 'stdin.txt').open('x', encoding='utf-8') as source:
            source.write(''.join(sanitized_input))
        with (folder / 'stdout.txt').open('x', encoding='utf-8') as out, (folder / 'stderr.txt').open('x', encoding='utf-8') as err, ExitStack() as capture_end:
            def write_out(text):
                out.write(text)
                out.flush()
            def write_err(text):
                err.write(text)
                err.flush()
                if os.environ.get('FMCAD_PROGRESS_EVENTS') == '1':
                    for line in text.splitlines(keepends=True):
                        try:
                            value = json.loads(line)
                            progress = isinstance(value, dict) and 'stage' in value and 'status' in value
                        except ValueError:
                            progress = line.startswith('image.optimize: ')
                        if progress:
                            print(line, end='', file=sys.stderr, flush=True)
            child = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     bufsize=0, cwd=cwd, env=env, start_new_session=True)
            pipes = [child.stdin, child.stdout, child.stderr]
            for stream in pipes:
                os.set_blocking(stream.fileno(), False)
            captures = [(child.stdout, DiagnosticStream(write_out), True),
                        (child.stderr, DiagnosticStream(write_err), False)]
            for _, capture, _ in captures:
                capture_end.callback(capture.feed, b'', final=True)
            discover()
            active.write_text(json.dumps({'pid': child.pid, 'pgid': child.pid}))
            report('started', pid=child.pid, pgid=child.pid,
                   timeoutSeconds=deadline-started if math.isfinite(deadline) else None, logs=str(folder))
            heartbeat = started + 10
            while child.poll() is None:
                discover()
                moved = pump()
                now = time.monotonic()
                timed_out = timed_out or now >= deadline
                if timed_out or interrupted:
                    break
                if now >= heartbeat:
                    report('running', supervisorHeartbeat=True, pid=child.pid, remainingSeconds=max(0, deadline-now) if math.isfinite(deadline) else None)
                    heartbeat = now + 10
                if not moved:
                    time.sleep(min(.05, max(0, deadline-now)))
            timed_out = timed_out or time.monotonic() >= deadline
            # Clean the entire owned group, even if its leader already exited.
            cleanup_started = time.monotonic()
            discover()
            group_signal(signal.SIGTERM)
            owned_running(signal.SIGTERM)
            cleanup_end = time.monotonic() + 1
            while time.monotonic() < cleanup_end:
                pump()
                child.poll()
                discover()
                try:
                    os.killpg(child.pid, 0)
                except ProcessLookupError:
                    if not owned_running():
                        break
                time.sleep(.02)
            # Nested supervisors own separate sessions. Freeze known parents,
            # collect their children, then kill identity-checked local PIDs too.
            owned_running(signal.SIGSTOP)
            discover()
            group_signal(signal.SIGKILL)
            owned_running(signal.SIGKILL)
            try:
                child.wait(timeout=1)
            except subprocess.TimeoutExpired:
                report('cleanup_unconfirmed', pid=child.pid)
                raise RuntimeError('Owned child did not reap within cleanup bound; inspect ' + str(folder))
            # Reaping the leader alone does not prove its descendants stopped.
            # Linux/WSL exposes process-group members, including stubborn children.
            if not Path('/proc').is_dir():
                raise RuntimeError('Cannot confirm offline descendants stopped; retained checkpoint ' + str(active))
            stop_deadline = time.monotonic() + 1
            while group_running(child.pid) or owned_running():
                pump()
                if time.monotonic() >= stop_deadline:
                    raise RuntimeError('Offline descendants still running; retained checkpoint ' + str(active))
                time.sleep(.02)
            cleaned = True
            # No EOF wait: terminated writers leave a finite kernel pipe buffer.
            # An unobserved inherited writer must not extend our cleanup bound.
            for stream, capture, raw in captures:
                if not stream.closed:
                    available = array.array('i', [0])
                    fcntl.ioctl(stream.fileno(), termios.FIONREAD, available, True)
                    left = available[0]
                    while left:
                        chunk = os.read(stream.fileno(), min(left, 65536))
                        if not chunk:
                            break
                        left -= len(chunk)
                        if raw:
                            raw_stdout.extend(chunk)
                        capture.feed(chunk)
        status = 'interrupted' if interrupted else 'timed_out' if timed_out else 'completed' if child.returncode == 0 else 'failed'
        report(status, returncode=child.returncode, logs=str(folder), cleanup='confirmed',
               cleanupSeconds=round(time.monotonic() - cleanup_started, 6))
        result = subprocess.CompletedProcess(command, 130 if interrupted else 124 if timed_out else child.returncode,
            raw_stdout.decode('utf-8', errors='replace').replace('\r\n', '\n').replace('\r', '\n'),
            (folder / 'stderr.txt').read_text(encoding='utf-8'))
        result.log_directory = str(folder)
        result.cleanup_bytes_freed = 0
        return result
    except BaseException:
        report('cleanup_unconfirmed' if child is not None and not cleaned else 'failed',
               timedOut=timed_out, interrupted=bool(interrupted), cleanup='confirmed' if cleaned else 'unconfirmed',
               logs=str(folder))
        raise
    finally:
        try:
            if child is not None and not cleaned:
                group_signal(signal.SIGKILL)
                owned_running(signal.SIGKILL)
                try:
                    child.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    pass
        finally:
            for stream in pipes:
                stream.close()
            for signum, handler in previous.items():
                signal.signal(signum, handler)
            events.close()
        if cleaned:
            active.unlink()
            if not debug and 'result' in locals() and result.returncode == 0:
                from generated_cleanup import collect, identity
                owned = {str(folder / name): identity(folder / name)
                         for name in ('stdin.txt', 'stdout.txt', 'stderr.txt', 'events.jsonl')}
                _, freed = collect(owned, [folder])
                # Bytes are transport metadata only; never a disk cleanup report.
                if 'result' in locals():
                    result.cleanup_bytes_freed = freed
                try:
                    folder.rmdir()
                except OSError:
                    pass


def group_running(pgid):
    for path in Path('/proc').glob('[0-9]*/stat'):
        try:
            fields = path.read_text().rsplit(') ', 1)[1].split()
            if int(fields[2]) == pgid and fields[0] not in ('Z', 'X'):
                return True
        except FileNotFoundError:
            pass
    return False


def process_snapshot():
    """Linux/WSL ancestry and start ticks, scoped by the caller to its child."""
    processes = {}
    for path in Path('/proc').glob('[0-9]*/stat'):
        try:
            fields = path.read_text().rsplit(') ', 1)[1].split()
            processes[int(path.parent.name)] = (fields[0], int(fields[1]), fields[19])
        except FileNotFoundError:
            pass
    return processes


def call_offline(module, function, args, *, log_parent, kwargs=None):
    payload = json.dumps(dict(module=module, function=function, args=args, kwargs=kwargs or {}), default=str)
    result = run_offline([sys.executable, '-B', str(Path(__file__).with_name('offline_worker.py'))],
                         log_parent=log_parent, stage=module + '.' + function, input_text=payload)
    global cleanup_bytes_freed
    cleanup_bytes_freed += result.cleanup_bytes_freed
    lines = []
    for line in result.stdout.splitlines():
        if line.startswith('FMCAD_CLEANUP_BYTES ') and line.split(' ', 1)[1].isdigit():
            cleanup_bytes_freed += int(line.split(' ', 1)[1])
        else:
            lines.append(line)
    if result.returncode:
        error = TimeoutError if result.returncode == 124 else RuntimeError
        raise error(f'Offline {module}.{function} stopped ({result.returncode}); ' +
                    (f'inspect retained logs {result.log_directory}' if Path(result.log_directory).exists()
                     else result.stderr[-4000:]))
    return json.loads('\n'.join(lines))


cleanup_bytes_freed = 0
