"""Durable latest checkpoint; debug and legacy runs retain snapshot history."""
import contextlib
import errno
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import os
import stat
import time
import uuid

cleanup_bytes_freed = 0


def ensure_hidden(path):
    """Hide only the generated directory; report unverified Windows hiding honestly."""
    path=Path(path)
    if path.name!='.fmcad-keychain' or not path.is_dir():
        raise ValueError('Expected an existing .fmcad-keychain directory')
    if any(part.is_symlink() for part in (path, *path.parents)):
        raise ValueError('Refusing symlink keychain directory or ancestor')
    path=path.absolute()
    fallback=dict(mode='dotfolder',windowsHidden=False)
    try:
        if sys.platform=='win32':
            import ctypes
            from ctypes import wintypes
            kernel=ctypes.WinDLL('kernel32',use_last_error=True)
            get=kernel.GetFileAttributesW
            get.argtypes=[wintypes.LPCWSTR];get.restype=wintypes.DWORD
            set_attributes=kernel.SetFileAttributesW
            set_attributes.argtypes=[wintypes.LPCWSTR,wintypes.DWORD]
            set_attributes.restype=wintypes.BOOL
            attributes=get(str(path))
            if attributes==0xFFFFFFFF:
                raise OSError('GetFileAttributesW failed')
            if not set_attributes(str(path),attributes | 0x2):
                raise OSError('SetFileAttributesW failed')
            verified=get(str(path))
            if verified==0xFFFFFFFF or not verified & 0x2:
                raise OSError('Windows hidden attribute read-back failed')
            return dict(mode='windows',windowsHidden=True)
        parts=path.parts
        if (sys.platform.startswith('linux') and len(parts)>3 and parts[1]=='mnt'
                and len(parts[2])==1 and parts[2] in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'):
            executable=shutil.which('attrib.exe')
            if not executable:
                raise OSError('attrib.exe is unavailable')
            if any('\\' in part for part in parts[3:]):
                raise OSError('Path contains a Windows separator in a Linux filename')
            windows_path=parts[2].upper()+':\\'+'\\'.join(parts[3:])
            # attrib interprets wildcards even without a shell; never permit recursion or globbing.
            if any(character in windows_path[2:] for character in '*?\r\n:'):
                raise OSError('Path cannot be safely passed to attrib.exe')
            subprocess.run([executable,'+H',windows_path],check=True,capture_output=True,
                           text=True,timeout=10,shell=False)
            result=subprocess.run([executable,windows_path],check=True,capture_output=True,
                                  text=True,timeout=10,shell=False)
            lines=[line.strip() for line in result.stdout.splitlines() if line.strip()]
            flags=''
            if len(lines)==1 and lines[0].casefold().endswith(windows_path.casefold()):
                flags=lines[0][:-len(windows_path)].strip()
            if 'H' not in flags or any(c not in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ ' for c in flags):
                raise OSError('attrib.exe hidden attribute read-back failed')
            return dict(mode='wsl',windowsHidden=True)
    except (OSError,subprocess.SubprocessError,UnicodeError) as error:
        fallback['warning']=f'Windows hidden attribute not verified: {error}. Using dotfolder only; Explorer hiding is not guaranteed.'
    return fallback


def read(run):
    run=Path(run)
    if run.is_symlink() or not run.is_dir():
        raise ValueError('run must be an existing non-symlink keychain directory')
    if any(p.is_symlink() for p in (run/'state', *run.parents)):
        raise ValueError('Refusing symlink state directory or ancestor')
    current=run/'state'/'current.json'
    files=[current] if current.exists() else sorted((run/'state').glob('[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].json'))
    if not files:
        raise ValueError('No keychain state snapshots in run')
    if files[-1].is_symlink():raise ValueError('Refusing symlink state snapshot')
    state=json.loads(files[-1].read_text(encoding='utf8'))
    if state.get('schemaVersion')!=1 or Path(state.get('runPath','')).resolve()!=run.resolve():
        raise ValueError('Keychain state identity mismatch')
    return state


def _checkpoint_identity(path):
    try:
        before=path.lstat()
        if not stat.S_ISREG(before.st_mode):
            raise ValueError('Refusing nonregular checkpoint publication entry')
        # DrvFS rename can replace an NTFS ReadOnly file despite its 0555 mode.
        # Refuse explicit protection instead of relying on rename to enforce it.
        if not before.st_mode & 0o222:
            raise PermissionError(errno.EACCES,'Refusing read-only checkpoint publication entry',str(path))
        digest=hashlib.sha256(path.read_bytes()).digest()
        after=path.lstat()
    except FileNotFoundError:
        return None
    # Attribute/cloud bookkeeping can change ctime without changing the state.
    # Keep inode and permissions pinned, and compare bytes rather than timestamps.
    identity=lambda info:(info.st_dev,info.st_ino,info.st_mode,info.st_size)
    if identity(before)!=identity(after) or before.st_mtime_ns!=after.st_mtime_ns:
        raise ValueError('Checkpoint changed while reading publication identity')
    return (*identity(after),digest)


def _replace_permission_error(error):
    windows=getattr(error,'winerror',None)
    return windows in (5,32,33) if windows is not None else error.errno==errno.EACCES


def _replace_checkpoint(temporary,target):
    # The caller holds the run lock. Retry only this local atomic publication,
    # never serialization, state generation, or the already returned native call.
    started=time.monotonic()
    deadline=started+1.8
    prepared=_checkpoint_identity(temporary)
    previous=_checkpoint_identity(target)
    attempts=1
    try:
        os.replace(temporary,target)
        return
    except OSError as original:
        if not _replace_permission_error(original):
            raise
        reason='attempt_limit'
        for delay in (.05,.1)+(.2,)*8:
            if time.monotonic()+delay>=deadline:
                reason='deadline'
                break
            time.sleep(delay)
            # EACCES normally leaves both names unchanged. Missing/changed temp
            # is not proof of success: preserve the error instead of replaying.
            if prepared is None or _checkpoint_identity(temporary)!=prepared:
                reason='prepared_changed_or_missing'
                break
            if _checkpoint_identity(target)!=previous:
                reason='target_changed_or_missing'
                break
            if time.monotonic()>=deadline:
                reason='deadline'
                break
            try:
                attempts+=1
                os.replace(temporary,target)
                return
            except OSError as error:
                if not _replace_permission_error(error):
                    raise
        print(json.dumps(dict(stage='keychain.checkpoint.replace',status='failed',reason=reason,
                              attempts=attempts,elapsedSeconds=round(time.monotonic()-started,6),
                              errno=original.errno,winerror=getattr(original,'winerror',None))),file=sys.stderr)
        raise  # Persistent denial: retain the original exception and its paths.


def write(run,state):
    folder=Path(run)/'state';folder.mkdir(exist_ok=True)
    if any(p.is_symlink() for p in (folder,*folder.parents)):
        raise ValueError('Refusing symlink state directory')
    if state.get('cleanupPolicy')==1:
        target=folder/'current.json'
        if target.is_symlink():raise ValueError('Refusing symlink state snapshot')
        if target.exists():
            previous=read(run)
            if previous.get('cleanupPolicy')!=1 or previous['runId']!=state['runId']:
                raise ValueError('Refusing unrelated current checkpoint')
        temporary=folder/('checkpoint-'+uuid.uuid4().hex+'.tmp')
        with temporary.open('x',encoding='utf8') as stream:
            json.dump(state,stream,ensure_ascii=False,separators=(',',':'),allow_nan=False)
            stream.flush();os.fsync(stream.fileno())
        if state['request'].get('debug',False):
            files=sorted(folder.glob('[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].json'))
            number=int(files[-1].stem)+1 if files else 0
            with (folder/f'{number:08}.json').open('xb') as stream:
                stream.write(temporary.read_bytes());stream.flush();os.fsync(stream.fileno())
        old_size=target.stat().st_size if target.exists() else 0
        new_size=temporary.stat().st_size
        _replace_checkpoint(temporary,target)
        global cleanup_bytes_freed
        cleanup_bytes_freed+=max(0,old_size-new_size)
        return state
    files=sorted(folder.glob('[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].json'))
    number=int(files[-1].stem)+1 if files else 0
    target=folder/f'{number:08}.json'
    with target.open('x',encoding='utf8') as f:
        json.dump(state,f,ensure_ascii=False,indent=2,allow_nan=False)
        f.flush()
        os.fsync(f.fileno())
    return state


@contextlib.contextmanager
def locked(run):
    path=Path(run)/'run.lock'
    if path.is_symlink():
        raise ValueError('Refusing symlink run lock')
    with path.open('a+b') as f:
        if __import__('os').name=='nt':
            import msvcrt
            f.seek(0,2)
            if f.tell()==0:f.write(b'0');f.flush()
            f.seek(0)
            msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
            try:yield
            finally:f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
        else:
            import fcntl
            fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
            try:yield
            finally:fcntl.flock(f,fcntl.LOCK_UN)
