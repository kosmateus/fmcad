"""Shared-curve target STLs and independent binary-roundtrip collision proof."""
import io
import json
from pathlib import Path
import numpy as np
import shapely
from shapely.geometry import Polygon
from shapely.ops import unary_union
import trimesh
import manifold3d as manifold

TESSELLATION_MM = .0005
TESSELLATION_BUDGET_MM = .005


def require(ok, message):
    if not ok:
        raise ValueError(message)


def controls(item):
    kind = item['type']
    require(kind in ('line', 'bezier'), 'Partition requires line/cubic templates')
    raw = item['controlPoints'] if kind == 'bezier' else [item['start'], item['end']]
    require(len(raw) == (4 if kind == 'bezier' else 2), 'Invalid control count')
    result = []
    for point in raw:
        require(len(point) in (2, 3), 'Invalid point dimension')
        require(all(isinstance(v, str) and v.endswith(' mm') for v in point), 'Explicit mm required')
        xyz = tuple(float(v[:-3]) for v in point)
        require(np.isfinite(xyz).all() and (len(xyz) == 2 or xyz[2] == 0), 'Nonplanar/nonfinite template')
        result.append(xyz[:2])
    return tuple(result)


def sample_curve(points, tolerance=TESSELLATION_MM, depth=0, area_tolerance=None):
    p = np.asarray(points, dtype=float)
    if len(p) == 2:
        return p.tolist()
    chord = p[-1] - p[0]
    length2 = float(chord @ chord)
    t = np.clip((p[1:3] - p[0]) @ chord / length2, 0, 1) if length2 else np.zeros(2)
    error = np.linalg.norm(p[1:3] - (p[0] + t[:, None] * chord), axis=1).max()
    # Exact Green integral between a cubic and its closing chord. Translate
    # first to avoid cancellation from model coordinates on tiny profiles.
    q = p[1:] - p[0]
    def cross(a, b):
        return a[0]*b[1] - a[1]*b[0]
    area_error = abs((3*cross(q[0], q[1]) + 3*cross(q[0], q[2]) + 6*cross(q[1], q[2])) / 20)
    if error <= tolerance and (area_tolerance is None or area_error <= area_tolerance):
        return [p[0].tolist(), p[-1].tolist()]
    require(depth < 24, 'Curve sampling depth exceeded')
    a, b, c = (p[:-1] + p[1:]) / 2
    d, e = (a + b) / 2, (b + c) / 2
    middle = (d + e) / 2
    child_area = None if area_tolerance is None else area_tolerance / 2
    return (sample_curve([p[0], a, d, middle], tolerance, depth + 1, child_area)[:-1]
            + sample_curve([middle, e, c, p[3]], tolerance, depth + 1, child_area))


def planar_partition(plan):
    require(plan.get('construction') == 'partition_prisms', 'Expected partition_prisms')
    ids = [c['id'] for c in plan['colors']]
    require(1 <= len(ids) <= 16 and len(set(ids)) == len(ids), 'Expected 1..16 unique colors')
    require(plan['imageSide'] in ('bottom', 'top') and 0 < plan['frontMm'] < plan['thicknessMm'], 'Invalid layers')
    cache, regions, repairs = {}, {}, []
    profiles, area_budgets = [], {}
    for spec in [plan['base'], *plan['fields']]:
        require(not spec.get('patches'), 'Direct fields cannot contain patches')
        template = json.loads(Path(spec['geometryPath']).read_text())
        curves = [controls(item) for item in template['geometry']]
        require(np.isfinite(spec['areaMm2']) and spec['areaMm2'] > 0 and curves, 'Invalid planned profile')
        # Reserve half the existing 0.1% gate for plan/control rounding. Sum
        # of absolute leaf errors is bounded by this per-profile allocation,
        # including holes and repeated occurrences of the same shared curve.
        budget = spec['areaMm2'] * .001 / 2 / len(curves)
        for points in curves:
            key = min(points, points[::-1])
            area_budgets[key] = min(area_budgets.get(key, budget), budget)
        profiles.append((spec, curves))
    for spec, curves in profiles:
        rings, ring, start, current = [], [], None, None
        repeated = 0
        for points in curves:
            if all(p == points[0] for p in points):
                repeated += 1
                continue
            key = min(points, points[::-1])
            if key not in cache:
                cache[key] = sample_curve(key, area_tolerance=area_budgets[key])
            sampled = cache[key] if key == points else cache[key][::-1]
            if start is None:
                start = points[0]
            else:
                require(current == points[0], 'Discontinuous partition ring')
            for p in sampled[:-1]:
                if ring and p == ring[-1]:
                    repeated += 1
                else:
                    ring.append(p)
            current = points[-1]
            if current == start and len(ring) >= 3:
                rings.append(ring)
                ring, start = [], None
        require(start is None and len(rings) == spec['loopCount'], 'Open ring/loop count mismatch')
        shape = Polygon(rings[0], rings[1:])
        topology_repair = not shape.is_valid
        if not shape.is_valid:
            fixed = shapely.make_valid(shape)
            require(fixed.geom_type in ('Polygon', 'MultiPolygon') and abs(fixed.area - shape.area) <= 1e-8,
                    f"Invalid partition needs planner repair: profileId={spec['id']!r}; "
                    f"fixedType={fixed.geom_type}; areaDeltaMm2={fixed.area - shape.area:.17g}; "
                    f"invalidityReason={shapely.is_valid_reason(shape).split('[', 1)[0].strip()}")
            shape = fixed
        require(shape.area > 0 and abs(shape.area - spec['areaMm2']) <= spec['areaMm2'] * .001,
                 f"Sampled profile area mismatch: {spec['id']} sampled={shape.area:.17g} mm2 planned={spec['areaMm2']:.17g} mm2 limit={spec['areaMm2'] * .001:.17g} mm2")
        regions[spec['id']] = shape
        repairs.append({'fieldId': spec['id'], 'colorId': spec.get('colorId'), 'repeatedPointRepair': repeated > 0,
                        'removedRepeatedPoints': repeated, 'zeroAreaTopologyRepair': topology_repair, 'displacementMm': 0})
    base = regions[plan['base']['id']]
    fields = [regions[f['id']] for f in plan['fields']]
    require(fields and all(f['colorId'] in ids for f in plan['fields']), 'Missing/unknown front fields')
    union = unary_union(fields)
    overlaps = sum(f.area for f in fields) - union.area
    missing, excess = base.difference(union).area, union.difference(base).area
    require(max(overlaps, missing, excess) <= 1e-8, 'Sampled partition has overlaps, gaps or excess')
    require(abs(base.bounds[2] - base.bounds[0] - plan['widthMm']) <= .01
            and abs(base.bounds[3] - base.bounds[1] - plan['heightMm']) <= .01, 'Partition dimensions mismatch')
    return regions, {'checked': True, 'method': 'canonical-control-map-shared-sampling',
        'coordinateSpace': 'model XY mm', 'canonicalCurveCount': len(cache),
        'sampledOnce': True, 'tessellationMm': TESSELLATION_MM, 'tessellationBudgetMm': TESSELLATION_BUDGET_MM,
        'samplingAreaBudgetFraction': .0005,
        'overlapAreaMm2': overlaps, 'missingAreaMm2': missing, 'excessAreaMm2': excess, 'repairs': repairs}


def as_manifold(mesh):
    solid = manifold.Manifold(manifold.Mesh(np.asarray(mesh.vertices, dtype=np.float32),
                                          np.asarray(mesh.faces, dtype=np.uint32)))
    require(solid.status() == manifold.Error.NoError, 'Manifold rejected target mesh')
    return solid


def checked_volume(solid):
    require(solid.status() == manifold.Error.NoError, 'Manifold Boolean proof unavailable')
    volume = float(solid.volume())
    require(np.isfinite(volume), 'Nonfinite Manifold Boolean volume')
    return abs(volume)


def prism(shape, lo, hi):
    require(callable(getattr(shapely, 'constrained_delaunay_triangles', None))
            and shapely.geos_version >= (3, 10, 0),
            'Constrained cap triangulation requires Shapely >= 2.1 and GEOS >= 3.10')
    pieces = [shape] if shape.geom_type == 'Polygon' else list(shape.geoms)
    solids = []
    for piece in pieces:
        if piece.is_empty:
            continue
        # Earcut's hole bridges can leave collinear T-junctions in the caps.
        # Extrusion then treats those internal edges as walls; a Boolean can
        # hide the open edges but leave a disconnected vertex link in the STL.
        # Constrain the cap to the existing rings instead of repairing solids
        # or changing any source controls / sampled boundary coordinates.
        triangles = list(shapely.constrained_delaunay_triangles(piece).geoms)
        require(triangles and all(t.area > 0 for t in triangles), 'Invalid constrained cap')
        cap = unary_union(triangles)
        require(cap.equals(piece) and abs(sum(t.area for t in triangles) - piece.area) <= 1e-8,
                'Constrained cap changed profile coverage')
        coordinates = np.asarray([np.asarray(t.exterior.coords)[:3] for t in triangles])
        vertices, faces = np.unique(coordinates.reshape(-1, 2), axis=0, return_inverse=True)
        boundary_vertices = {tuple(p) for ring in [piece.exterior, *piece.interiors] for p in ring.coords}
        require(all(tuple(p) in boundary_vertices for p in vertices), 'Constrained cap added coordinates')
        mesh = trimesh.creation.extrude_triangulation(vertices, faces.reshape(-1, 3), hi - lo)
        require(mesh.is_watertight and mesh.is_winding_consistent,
                'Constrained prism is not closed and consistently wound')
        mesh.apply_translation([0, 0, lo])
        solids.append(as_manifold(mesh))
    require(solids, 'Empty color prism')
    return manifold.Manifold.batch_boolean(solids, manifold.OpType.Add)


def binary(solid):
    require(solid.status() == manifold.Error.NoError and solid.volume() > 0, 'Invalid Boolean solid')
    mesh = solid.to_mesh()
    return trimesh.Trimesh(mesh.vert_properties[:, :3], mesh.tri_verts, process=False).export(file_type='stl')


def generate_meshes(plan, groups, native, output_dir):
    """Write exclusively new validated binary STLs, return per-file + assembly proof."""
    from keychain_build import mesh_report, write_new
    regions, partition = planar_partition(plan)
    outline = [c['id'] for c in plan['colors'] if c['hex'].lower() == plan['outlineColor'].lower()]
    require(len(outline) == 1, 'Outline must resolve uniquely')
    outline = outline[0]
    lo = 0 if plan['imageSide'] == 'bottom' else plan['thicknessMm'] - plan['frontMm']
    hi = lo + plan['frontMm']
    footprint = regions[plan['base']['id']]
    target = prism(footprint, 0, plan['thicknessMm'])
    solids = {}
    for color in plan['colors']:
        if color['id'] == outline:
            continue
        region = unary_union([regions[f['id']] for f in plan['fields'] if f['colorId'] == color['id']])
        solids[color['id']] = prism(region, lo, hi)
    tools = manifold.Manifold.batch_boolean(list(solids.values()), manifold.OpType.Add) if solids else None
    solids[outline] = target - tools if tools is not None else target
    reports, actual, payloads = {}, {}, {}
    for color in plan['colors']:
        cid = color['id']
        group = groups[cid]
        data = binary(solids[cid])
        report = mesh_report(data, native['colors'][group['component']['name']])
        loaded = trimesh.load_mesh(io.BytesIO(data), file_type='stl', process=True)
        actual[cid] = as_manifold(loaded)
        filename = group['stem'] + '.stl'
        payloads[filename] = data
        reports[filename] = dict(report, colorId=cid, binarySTLReloaded=True)
    intersections = []
    for i, a in enumerate(actual):
        for b in list(actual)[i + 1:]:
            volume = checked_volume(actual[a] ^ actual[b])
            require(volume <= 1e-5, 'Actual target meshes intersect')
            intersections.append({'colorIds': [a, b], 'volumeMm3': volume, 'limitMm3': 1e-5})
    assembled = manifold.Manifold.batch_boolean(list(actual.values()), manifold.OpType.Add)
    target_actual = as_manifold(trimesh.load_mesh(io.BytesIO(binary(target)), file_type='stl', process=True))
    checked_volume(assembled)
    missing, excess = checked_volume(target_actual - assembled), checked_volume(assembled - target_actual)
    max_coordinate = max(1., max(abs(v) for v in footprint.bounds), plan['thicknessMm'])
    float32_ulp = float(np.spacing(np.float32(max_coordinate)))
    require(float32_ulp <= .001 and TESSELLATION_MM + float32_ulp <= TESSELLATION_BUDGET_MM,
            'Float32 coordinates exceed declared displacement/tessellation budget')
    bound = max(1e-7, 8 * float32_ulp * (2 * footprint.area + footprint.length * plan['thicknessMm']))
    require(bound <= target_actual.volume() * .001, 'Float32 assembly bound exceeds 0.1% volume budget')
    require(max(missing, excess) <= bound, 'Actual assembly has void/excess')
    proof = {'checked': True, 'method': 'reloaded-binary-STL-Manifold', 'partition': partition,
        'capTriangulation': {'method': 'constrained-Delaunay', 'coverageChecked': True,
                             'verticesFromSampledRingsOnly': True, 'boundaryDisplacementMm': 0},
        'pairwiseIntersections': intersections, 'missingVolumeMm3': missing, 'excessVolumeMm3': excess,
        'assemblyLimitMm3': bound, 'float32UlpMm': float32_ulp,
        'assemblyBoundFormula': '8 * float32Ulp(maxAbsCoordinate) * footprintPrismSurfaceArea',
        'contactRegularizationMm': 0, 'contactRegularizationLimitMm': .001}
    for filename, data in payloads.items():
        path = Path(output_dir) / filename
        write_new(path, data)
        require(path.read_bytes() == data, 'Target STL bytes changed on write')
    return reports, proof
