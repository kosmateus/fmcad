"""Approval-gated keychain workflow with generated-file lifecycle retention."""
import sys
from pathlib import Path

ASSETS=Path(__file__).resolve().parent
if __name__=='__main__' and not __package__:
    sys.path.pop(0)
# Sibling assets/inspect.py is a Fusion script, not the Python standard library.
import inspect  # noqa: F401
if str(ASSETS) not in sys.path:sys.path.append(str(ASSETS))

import base64
import copy
import datetime
import hashlib
import json
import math
import os
import re
import uuid

import keychain_state as storage
import keychain_cleanup as retention

cleanup_bytes_freed=0

PREPARE={'input','out','name','project','projectMode','projectId','documentFileId','colors','thicknessMm','imageSide','widthMm',
         'frontMm','trials','seed','palette','outlineColor','search','regions','backing','debug'}
SELECT={'candidate','svg','approve'}
ALLOWED={'prepare':PREPARE,'status':{'run'},'approve':{'run','debug'}|SELECT,
         'verify':{'directory','colors','widthMm','thicknessMm','frontMm','imageSide'},
         'build':{'run','backendOptions','debug'}|SELECT}


def require(ok,message):
    if not ok:raise ValueError(message)


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()


def safe_path(value,label,exists=False):
    require(isinstance(value,str) and Path(value).is_absolute(),label+' must be an absolute local path')
    p=Path(value)
    require(not any(x.is_symlink() for x in (p,*p.parents)),label+' must not traverse symlinks')
    if exists:require(p.is_file(),label+' must be an existing file')
    return p


def slug(value):
    return re.sub(r'[^\w.-]+','_',value,flags=re.UNICODE).strip('._')[:64] or 'brelok'


def validate_prepare(data):
    data=copy.deepcopy(data)
    source=safe_path(data.get('input'),'input',True)
    data.setdefault('out',str(Path.cwd()))
    workspace=safe_path(data['out'],'out')
    require(workspace.is_dir() if workspace.exists() else workspace.parent.is_dir(),
            'out must be a directory or have an existing parent')
    for key in ('name','project','projectId','documentFileId'):
        if key in data:require(isinstance(data[key],str) and data[key].strip(),key+' must be nonempty text')
    data.setdefault('name',source.stem)
    mode=data.get('projectMode','new')
    require(mode in ('new','existing'),'projectMode must be new or existing')
    if 'documentFileId' in data:
        require(mode=='existing','documentFileId requires projectMode existing')
        require(not re.search(r'\s',data['documentFileId']) and not data['documentFileId'].startswith('-'),
                'documentFileId must be an exact cloud ID without whitespace')
    if mode=='existing':
        require(('project' in data)+('projectId' in data)==1,
                'existing requires exactly one of project or projectId')
    else:
        require('projectId' not in data,'projectId requires projectMode existing')
        data.setdefault('project','Brelok '+data['name'])
    data.setdefault('imageSide','bottom');data.setdefault('widthMm',50)
    data.setdefault('trials',24);data.setdefault('seed',17)
    data.setdefault('backing','silhouette')
    require(data['imageSide'] in ('bottom','top'),'imageSide must be bottom or top')
    require(data['backing'] in ('silhouette','convex-hull'),'backing must be silhouette or convex-hull')
    if 'colors' in data:require(type(data['colors']) is int and 1<=data['colors']<=16,'colors must be an integer in [1,16]')
    for key in ('widthMm','thicknessMm','frontMm'):
        if key in data:require(type(data[key]) in (int,float) and math.isfinite(data[key]) and data[key]>0,key+' must be finite and positive')
    require(type(data['trials']) is int and 2<=data['trials']<=128,'trials must be an integer in [2,128]')
    require(type(data['seed']) is int,'seed must be an integer')
    if 'palette' in data:safe_path(data['palette'],'palette',True)
    if 'outlineColor' in data:
        require(isinstance(data['outlineColor'],str) and re.fullmatch(r'#[0-9a-fA-F]{6}',data['outlineColor']),
                'outlineColor must be #RRGGBB')
        data['outlineColor']=data['outlineColor'].upper()
    if 'search' in data:require(isinstance(data['search'],dict),'search must be an object')
    if 'regions' in data:require(isinstance(data['regions'],list),'regions must be an array')
    if 'thicknessMm' in data:
        data.setdefault('frontMm',min(.8,data['thicknessMm']/2))
        require(data['frontMm']<data['thicknessMm'],'frontMm must be less than thicknessMm')
    return data


def compact(state,include_candidates=True):
    p=state.get('prepared') or {}
    candidates=[{k:c.get(k) for k in ('id','score','eligible','svgPath','overlayPath','colorCount','failures','geometryPlanReady','planningFailure',
                                   'semanticAuditPassed','semanticFailure','overlayOrigin','rasterTopologyRepaired')}
                for c in p.get('candidates',[])]
    build=state.get('build')
    if build:
        build={k:v for k,v in build.items() if k in ('backend','phase','outcome','running','document','creationId',
               'preSaveCreationId','projectId','folderId','cloud','operation','operationId','error','saveAttempted',
                'validationState','saveTarget','saveReconciled','saveAccepted','reusableTarget','emptyAudit','saveOperation','prismOperation')}
    return {'status':state['status'],'run':state['runPath'],'runId':state['runId'],
            'publicPath':state['publicPath'],'parameters':state['request'],
            'outlineColor':p.get('outlineColor'),'outlineConfidence':p.get('outlineConfidence'),'palette':p.get('colors',[]),
            'imageNormalization':p.get('imageNormalization'),'hiddenWorkspace':state.get('hiddenWorkspace'),
            'recommendations':p.get('recommendations',[]),'candidateCount':len(candidates),
            'candidates':candidates if include_candidates else [],
            'warnings':p.get('warnings',[]),'approval':state.get('approval'),
            'build':build,'artifacts':state.get('artifacts',[]),
            'error':state.get('error'),'geometryValidated':state['status']=='completed' or (
                state['status']=='blocked' and (state.get('error') or {}).get('phase')=='cleanup'
                and (build or {}).get('validationState')=='passed')}


def prepare(data):
    global cleanup_bytes_freed
    request=validate_prepare(data)
    os.environ['FMCAD_KEYCHAIN_DEBUG']='true' if request.get('debug') else 'false'
    questions=[]
    if 'colors' not in request:
        questions.append({'field':'colors','question':'How many colors should the keychain have?',
                          'type':'integer','minimum':1,'maximum':16})
    if 'thicknessMm' not in request:
        questions.append({'field':'thicknessMm','question':'How thick should the keychain be, in millimeters?',
                          'type':'number','exclusiveMinimum':0})
    if questions:return {'status':'needs_input','questions':questions,'sideEffects':False}
    # Import dependencies before creating a run, so missing packages make no clutter.
    from keychain_prepare import prepare as prepare_images
    workspace=Path(request['out']);workspace.mkdir(exist_ok=True)
    hidden=workspace/'.fmcad-keychain'
    require(not hidden.is_symlink(),'.fmcad-keychain must not be a symlink')
    hidden.mkdir(exist_ok=True)
    hidden_metadata=storage.ensure_hidden(hidden)
    short=uuid.uuid4().hex[:10]
    runid=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+short
    run=hidden/runid;run.mkdir()
    public=workspace/(slug(request['name'])+'-'+short)
    require(not public.exists(),'Unexpected public output collision')
    state={'schemaVersion':1,'runId':runid,'runPath':str(run),'publicPath':str(public),
           'createdAt':now(),'updatedAt':now(),'status':'preparing','request':request,
           'prepared':None,'approval':None,'planPath':None,'build':None,'artifacts':[],
            'hiddenWorkspace':hidden_metadata,'cleanupPolicy':1,'ownedFiles':{}}
    with storage.locked(run):
        storage.write(run,state)
        try:
            from offline_execution import call_offline
            with retention.produced(state):
                prepared=call_offline('keychain_prepare','prepare',[request,str(run),str(public)],log_parent=run)
            if hidden_metadata.get('warning'):prepared['warnings'].append(hidden_metadata['warning'])
            # Retain approval inputs and compact measurements; full report is debug-only.
            prepared['candidates']=[{k:v for k,v in c.items() if k in
                ('id','score','eligible','svgPath','overlayPath','parameters','colorCount','failures','physicalTopologyReady',
                 'rasterEligible','geometryPlanReady','planningFailure','planningCheckPath','planningFailureBundlePath','planningEligible',
                 'semanticAuditPassed','semanticFailure','plannedColorCount','overlayOrigin','rasterTopologyRepaired',
                 'normalizedSvgPath','normalizedPngPath','planSignature','overlaySha256','construction',
                 'partitionInputs','backing','partitionValidation','backingProof','backZMinMm','backZMaxMm','traceDetailAudit')}
                for c in prepared['candidates']]
            state.update(prepared=prepared,status='awaiting_selection',updatedAt=now())
            storage.write(run,state)
        except Exception as e:
            state.update(status='failed',updatedAt=now(),error={'type':type(e).__name__,'message':str(e),
                         'phase':'prepare','modelMutated':False})
            storage.write(run,state)
        finally:
            cleanup_bytes_freed+=retention.cleanup(state)
            storage.write(run,state)
    return compact(state)


def approve(state,data,checkpoint):
    require(data.get('approve') is True and isinstance(data.get('candidate'),str) and data['candidate'],
            'Explicit candidate and approve:true are required; recommendation is not approval')
    require(state['status'] in ('awaiting_selection','approved','completed'),
            'Run cannot be approved while failed, building or blocked')
    prepared=state.get('prepared') or {}
    selected=[c for c in prepared.get('candidates',[]) if c['id']==data['candidate']]
    require(len(selected)==1,'Candidate ID does not belong to this run')
    selected=selected[0]
    partition=(selected.get('construction')=='partition_prisms'
               or prepared.get('construction')=='partition_prisms')
    partition_inputs=None
    if partition:
        inputs=selected.get('partitionInputs') or {}
        partition_inputs={k:inputs[k] for k in ('backing','fit_error_px','corner_angle','scale') if k in inputs}
        partition_inputs.setdefault('backing',state['request'].get('backing','silhouette'))
        partition_inputs['reference_path']=prepared['classifiedPath']
        if not data.get('svg'):
            require(selected.get('overlayOrigin')=='canonical_plan' and selected.get('planSignature'),
                    'Partition candidate lacks signed canonical preview; prepare again')
    require(selected.get('eligible') or data.get('svg'),
            'Candidate failed quality/topology gates; provide a reviewed corrected SVG rather than force approval')
    old=state.get('approval') or {}
    candidate_source=(old.get('svgPath') if state['status']=='completed' and
                      old.get('candidateId')==selected['id'] else selected.get('svgPath'))
    source=safe_path(data.get('svg') or candidate_source,'approved SVG',True)
    if not data.get('svg'):
        require(source.resolve().is_relative_to(Path(state['runPath']).resolve()),'Candidate SVG escapes run')
    content=source.read_bytes();sha=hashlib.sha256(content).hexdigest()
    if old.get('candidateId')==selected['id'] and old.get('svgSha256')==sha:return state
    require(state['status']!='completed' and not state.get('build'),'A built run cannot change approval; start a new run')
    from image_boundaries import parse_svg
    palette=json.loads(Path(prepared['palettePath']).read_text(encoding='utf8'))
    fills=[palette['background']]+[c['color'] for c in palette['colors']]
    paths=parse_svg(content,prepared['imageSize'],fills)
    require({label for label,_ in paths if label}==set(range(1,request_colors(state)+1)),
            'Approved SVG must retain every requested foreground color and exclude undeclared colors')
    folder=Path(state['runPath'])/'approvals';folder.mkdir(exist_ok=True)
    identity=uuid.uuid4().hex[:10]
    target=folder/(identity+'.svg')
    with target.open('xb') as f:f.write(content)
    # Only the overlay is visible to the user; editable SVG data stays hidden.
    from PIL import Image
    from keychain_prepare import _overlay
    display_path=prepared.get('displaySourcePath',prepared['sourcePath'])
    if prepared.get('displaySourceSha256'):
        require(digest(display_path)==prepared['displaySourceSha256'],'Frozen display-source hash changed')
    original=Path(display_path).read_bytes()
    with Image.open(display_path) as image:mime=Image.MIME.get(image.format,'image/png')
    uri='data:'+mime+';base64,'+base64.b64encode(original).decode('ascii')
    from keychain_signature import plan_signature
    approved_signature=None
    if not data.get('svg') and selected.get('overlayOrigin')=='canonical_plan':
        require(selected.get('planSignature'),'Prepared candidate lacks geometry signature; prepare again')
        cached_plan=Path(selected['planningCheckPath']).parent/'plan.json'
        require(plan_signature(json.loads(cached_plan.read_text(encoding='utf8')))==selected['planSignature'],
                'Prepared geometry changed after preview; prepare again')
        require(digest(selected['overlayPath'])==selected.get('overlaySha256'),
                'Preview overlay changed; provide the explicitly corrected geometry SVG')
        approved_signature=selected['planSignature']
        overlay=Path(selected['overlayPath']).read_bytes()
    elif data.get('svg'):
        from keychain_preview import render_plan
        params=state['request']
        plan_dir=folder/(identity+'-plan')
        from offline_execution import call_offline
        plan_args=[str(target),prepared['palettePath'],prepared['outlineColor'],params['widthMm'],
                   params['thicknessMm'],params['frontMm'],params['imageSide'],str(plan_dir)]
        if partition:
            reviewed=call_offline('keychain_partition','make_partition_plan',plan_args,
                                  log_parent=folder,kwargs=partition_inputs)
        else:
            reviewed=call_offline('keychain_plan','make_plan',plan_args,log_parent=folder)
        approved_signature=plan_signature(reviewed)
        overlay=render_plan(reviewed,prepared['imageSize'],palette['background'],uri,plan_dir)['overlay']
    else:
        overlay,_=_overlay(target,prepared['imageSize'],palette['background'],uri)
    public=Path(state['publicPath'])/'overlays'/('approved-'+identity+'-overlay.svg')
    with public.open('xb') as f:f.write(overlay)
    approval={'candidateId':selected['id'],'svgPath':str(target),'svgSha256':sha,
              'approvedAt':now(),'corrected':bool(data.get('svg')),'overlayPath':str(public)}
    if approved_signature:approval['planSignature']=approved_signature
    if partition:
        approval['construction']='partition_prisms'
        approval['partitionInputs']=partition_inputs
    return checkpoint({'status':'approved','approval':approval,'error':None})


def request_colors(state):return state['request']['colors']


def _execute(request):
    global cleanup_bytes_freed
    import offline_execution
    before_cleanup=cleanup_bytes_freed+storage.cleanup_bytes_freed+offline_execution.cleanup_bytes_freed+retention.cleanup_bytes_freed
    require(isinstance(request,dict),'Keychain request must be an object')
    operation=request.get('operation')
    require(operation in ALLOWED,'Unknown keychain operation')
    require(not set(request)-ALLOWED[operation]-{'operation'},'Unknown keychain request fields')
    data={k:v for k,v in request.items() if k!='operation'}
    if 'debug' in data:require(type(data['debug']) is bool,'debug must be a boolean')
    if operation=='prepare':result=prepare(data)
    elif operation=='verify':
        from keychain_verify import verify
        result=verify(data)
    else:
        run=safe_path(data.get('run'),'run')
        state=storage.read(run)
        if operation=='status':result=compact(state)
        else:
            with storage.locked(run):
                state=storage.read(run)
                def checkpoint(patch):
                    nonlocal state
                    state=copy.deepcopy(dict(state,**patch,updatedAt=now()))
                    storage.write(run,state)
                    return state
                if 'debug' in data:
                    checkpoint({'request':dict(state['request'],debug=data['debug'])})
                os.environ['FMCAD_KEYCHAIN_DEBUG']='true' if state['request'].get('debug') else 'false'
                generated={}
                try:
                    with retention.produced(state) as generated:
                        if operation=='approve' or any(k in data for k in SELECT):
                            state=approve(state,data,checkpoint)
                        if operation=='build':
                            # A failed offline planner is not an uncertain Fusion mutation.
                            if (state['status']=='blocked' and state.get('approval') and not state.get('build')
                                    and not state.get('planPath') and not (run/'cad-plan').exists()
                                    and not (run/'cad-build').exists()):
                                checkpoint({'status':'approved','error':None,'preflightRecheckedAt':now()})
                            from keychain_build import build,can_resume_save,can_resume_export
                            require(state['status'] in ('approved','completed') or can_resume_save(state) or can_resume_export(state),
                                    'Build requires approved state; no automatic selection or retry of partial mutations')
                            try:
                                patch=build(state,checkpoint,data.get('backendOptions',[]))
                                if patch.get('status')=='completed':patch['error']=None
                                if state['status']!='completed' or patch.get('status')!='completed':checkpoint(patch)
                            except Exception as e:
                                checkpoint({'status':'blocked','error':{'phase':'build','type':type(e).__name__,
                                    'message':str(e),'automaticRetry':False}})
                finally:
                    if retention.enabled(state):
                        state.setdefault('ownedDirectories',{}).update(generated.get('directories',{}))
                        state.setdefault('ownedFiles',{}).update(generated.get('files',{}))
                        cleanup_bytes_freed+=retention.cleanup(state)
                        storage.write(run,state)
                removed=False
                if operation=='build' and state['status']=='completed':
                    try:
                        cleanup_bytes_freed+=retention.purge_completed(state)
                        removed=not run.exists()
                    except (OSError,ValueError) as error:
                        # Geometry/export success is not silently reported as full cleanup success.
                        checkpoint({'status':'blocked','error':{'phase':'cleanup','type':type(error).__name__,
                            'message':str(error),'automaticRetry':False}})
                result=compact(state,include_candidates=False)
                result['workspaceRemoved']=removed
    result['cleanupBytesFreed']=cleanup_bytes_freed+storage.cleanup_bytes_freed+offline_execution.cleanup_bytes_freed+retention.cleanup_bytes_freed-before_cleanup
    return {'success':result['status'] not in ('failed','blocked'),
            'operation':'keychain.'+operation,'result':result}


def execute(request):
    previous=os.environ.get('FMCAD_KEYCHAIN_DEBUG')
    try:
        return _execute(request)
    finally:
        if previous is None:os.environ.pop('FMCAD_KEYCHAIN_DEBUG',None)
        else:os.environ['FMCAD_KEYCHAIN_DEBUG']=previous


def main():
    request={}
    try:
        from keychain_deadline import command_deadline
        with command_deadline():
            request=json.load(sys.stdin)
            result=execute(request)
        print(json.dumps(result,ensure_ascii=False,allow_nan=False))
        return 0 if result['success'] else 1
    except Exception as error:
        if isinstance(request,dict) and request.get('operation')=='verify':
            from keychain_verify import report_base
            if isinstance(error,(TimeoutError,InterruptedError)):
                error=type(error)('Local keychain verification stopped; file checks incomplete')
            result=dict(report_base(),error={'type':type(error).__name__,'message':str(error)})
            print(json.dumps({'success':False,'operation':'keychain.verify','result':result},allow_nan=False))
        print('keychain: '+str(error),file=sys.stderr)
        if isinstance(error,(ImportError,ModuleNotFoundError)):
            print('Install local dependencies with the selected Python: -m pip install -r '+
                  str(ASSETS/'keychain_requirements.txt'),file=sys.stderr)
        return 1


if __name__=='__main__':raise SystemExit(main())
