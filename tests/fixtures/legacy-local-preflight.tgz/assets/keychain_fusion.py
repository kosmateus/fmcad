"""Generic SDK gaps used only through fmcad run, scoped to a unique document.

Read-only operations never activate documents. API lengths/volumes are cm/cm3;
the helper returns mm/mm3. analyzeInterference uses native SDK entity identity,
never opaque token-string equality. Only save_version saves, once with pinned
cloud identity and baseline version. No close, delete, or preferences here.
"""
import json
import math
import itertools
import hashlib
import re
import sys
import time
import types

ARGS = {}
MARKER_GROUP = 'fmcad.keychain'
MARKER_NAME = 'runId'


def _geometry_readback(sketch, template):
    def xyz(point):
        return [point.x, point.y, point.z]
    observed = []
    for curve in _items(sketch.sketchCurves):
        if curve.isConstruction:
            raise ValueError('Unexpected construction curve')
        if curve.objectType.endswith('SketchLine'):
            observed.append(('line', [xyz(curve.startSketchPoint.geometry), xyz(curve.endSketchPoint.geometry)]))
        elif curve.objectType.endswith('SketchFixedSpline'):
            geometry = curve.geometry
            if geometry.degree != 3 or geometry.isRational or list(geometry.knots) != [0, 0, 0, 0, 1, 1, 1, 1]:
                raise ValueError('Native spline is not the approved cubic Bezier')
            observed.append(('bezier', [xyz(p) for p in geometry.controlPoints]))
        else:
            raise ValueError('Unexpected native sketch curve type')
    if len(observed) != len(template['geometry']):
        raise ValueError('Native geometry count mismatch')
    # SDK collections group curve types, so creation order is not a stable key.
    # Index both endpoints, then apply the original exact per-control tolerance.
    # Neighbor buckets preserve tolerance across grid boundaries without O(N^2)
    # scans for artwork containing thousands of lines and fixed splines.
    tolerance = 1e-8
    def bucket(point):
        return tuple(math.floor(v / tolerance) for v in point)
    index_by_endpoint = {}
    for index, (kind, points) in enumerate(observed):
        for key in {bucket(points[0]), bucket(points[-1])}:
            index_by_endpoint.setdefault((kind, key), set()).add(index)
    remaining = set(range(len(observed)))
    for item in template['geometry']:
        raw = item['controlPoints'] if item['type'] == 'bezier' else [item['start'], item['end']]
        expected = [[float(v[:-3]) / 10 for v in p] for p in raw]
        expected = [p + [0] if len(p) == 2 else p for p in expected]
        def matches(row):
            kind, points = row
            return kind == item['type'] and len(points) == len(expected) and any(
                all(abs(a - b) <= 1e-8 for p, q in zip(order, expected) for a, b in zip(p, q))
                for order in (points, points[::-1]))
        center = bucket(expected[0])
        candidates = set()
        for delta in itertools.product((-1, 0, 1), repeat=3):
            key = tuple(a + b for a, b in zip(center, delta))
            candidates.update(index_by_endpoint.get((item['type'], key), ()))
        index = next((i for i in sorted(candidates & remaining) if matches(observed[i])), None)
        if index is None:
            raise ValueError('Native geometry controlPoints cm mismatch')
        remaining.remove(index)
    return {'checked': True, 'curveCount': len(observed), 'controlPointUnits': 'cm', 'toleranceCm': 1e-8}


def _items(collection):
    return [collection.item(i) for i in range(collection.count)]


def _one(items, description):
    if len(items) != 1:
        raise ValueError(description + ' must be unique; found ' + str(len(items)))
    return items[0]


def _prism(root, spec, template, start, depth):
    """Command execute geometry kernel; preserve every sketch/readback/extrude gate."""
    import adsk.core
    import adsk.fusion
    name = 'kc_' + spec['id']
    if any(s.name == name for s in _items(root.sketches)):
        raise ValueError('Prism sketch already exists; partial mutations cannot be retried')
    if not math.isfinite(start) or not math.isfinite(depth) or depth <= 0:
        raise ValueError('Invalid prism range')
    def point(raw):
        if len(raw) not in (2, 3) or any(not isinstance(v, str) or not v.endswith(' mm') for v in raw):
            raise ValueError('Prism points require explicit mm coordinates')
        values = [float(v[:-3]) / 10 for v in raw]
        if not all(math.isfinite(v) for v in values):
            raise ValueError('Nonfinite prism coordinate')
        return adsk.core.Point3D.create(*(values + [0] if len(values) == 2 else values))
    prepared = []
    for item in template['geometry']:
        if item['type'] == 'line':
            prepared.append(('line', [point(item['start']), point(item['end'])]))
        elif item['type'] == 'bezier' and len(item['controlPoints']) == 4:
            prepared.append(('bezier', [point(p) for p in item['controlPoints']]))
        else:
            raise ValueError('Unsupported prism geometry')
    if not prepared:
        raise ValueError('Empty prism geometry')
    sketch = root.sketches.add(root.xYConstructionPlane)
    sketch.name = name
    sketch.isLightBulbOn = False
    # These SDK collection/method lookups are invariant for this new sketch.
    # Keep them out of the per-curve loop without changing insertion order.
    curves = sketch.sketchCurves
    add_line = curves.sketchLines.addByTwoPoints
    add_spline = curves.sketchFixedSplines.addByNurbsCurve
    try:
        sketch.isComputeDeferred = True
        for kind, points in prepared:
            if kind == 'line':
                made = add_line(*points)
            else:
                nurbs = adsk.core.NurbsCurve3D.createNonRational(points, 3, [0, 0, 0, 0, 1, 1, 1, 1], False)
                made = add_spline(nurbs)
            if made is None:
                raise RuntimeError('Prism curve creation failed')
    finally:
        # Owned fresh sketch: restore computation even if enabling deferral fails.
        # Complete this solve before geometry/profile validation or extrusion.
        sketch.isComputeDeferred = False
    readback = _geometry_readback(sketch, template)
    profile = _one([p for p in _items(sketch.profiles) if p.profileLoops.count == spec['loopCount']],
                   'Profile loop count: ' + spec['id'])
    area = profile.areaProperties(adsk.fusion.CalculationAccuracy.HighCalculationAccuracy).area * 100
    if abs(area - spec['areaMm2']) > spec['areaMm2'] * .015:
        raise ValueError('Live profile area differs from approved plan')
    extrudes = root.features.extrudeFeatures
    request = extrudes.createInput(profile, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
    request.startExtent = adsk.fusion.OffsetStartDefinition.create(adsk.core.ValueInput.createByReal(start / 10))
    extent = adsk.fusion.DistanceExtentDefinition.create(adsk.core.ValueInput.createByReal(depth / 10))
    if not request.setOneSideExtent(extent, adsk.fusion.ExtentDirections.PositiveExtentDirection):
        raise RuntimeError('Prism extent setup failed')
    feature = extrudes.add(request)
    feature.name = 'kc_extrude_' + spec['id']
    bodies = _items(feature.bodies)
    if not bodies or len({b.name for b in bodies}) != len(bodies):
        raise ValueError('Extrude returned ambiguous bodies')
    return {'bodies': [{'kind': 'body', 'name': b.name} for b in bodies], 'readback': readback, 'areaMm2': area}


def _prism_request_digest(payload):
    """Typed v2 digest stable across Python JSON -> JS Number -> Python JSON.

    Only schema-real attributes use binary64 semantics. Coordinate expressions
    remain verbatim strings; counts/other integers retain integer semantics.
    This pure helper is also imported by the offline sender (no adsk import).
    """
    real_paths = {('start',), ('depth',), ('spec', 'areaMm2'),
                  ('spec', 'zMinMm'), ('spec', 'zMaxMm')}

    def canonical(value, path=()):
        real = path in real_paths or (len(path) == 3 and path[:2] == ('spec', 'boundsPx'))
        if real:
            if type(value) not in (int, float):
                raise ValueError('Prism real attribute requires a finite number: ' + str(path))
            try:
                number = float(value)
            except OverflowError:
                raise ValueError('Prism real attribute exceeds binary64: ' + str(path)) from None
            if not math.isfinite(number):
                raise ValueError('Prism real attribute must be finite: ' + str(path))
            # JSON.stringify removes numeric negative zero. Explicit coordinate
            # strings (including their signs/format) are never normalized.
            return ['real', (0.0 if number == 0 else number).hex()]
        if path == ('spec', 'loopCount') and (type(value) is not int or value <= 0):
            raise ValueError('Prism loopCount requires a positive integer')
        if path == ('spec', 'boundsPx') and (not isinstance(value, (list, tuple)) or len(value) != 4):
            raise ValueError('Prism boundsPx requires four real numbers')
        if value is None:
            return ['null']
        if type(value) is bool:
            return ['bool', value]
        if type(value) is int:
            if abs(value) > 2**53 - 1:
                raise ValueError('Prism integer is outside the JSON transport safe range: ' + str(path))
            return ['int', str(value)]
        if type(value) is float:
            if not math.isfinite(value):
                raise ValueError('Prism numeric attribute must be finite: ' + str(path))
            return ['float', value.hex()]
        if isinstance(value, str):
            return ['string', value]
        if isinstance(value, (list, tuple)):
            return ['array', [canonical(item, path + (i,)) for i, item in enumerate(value)]]
        if isinstance(value, dict) and all(isinstance(key, str) for key in value):
            return ['object', [[key, canonical(value[key], path + (key,))] for key in sorted(value)]]
        raise ValueError('Unsupported prism request value: ' + str(path))

    encoded = json.dumps(['fmcad-prism-request-v2', canonical(payload)],
                         separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()
    return hashlib.sha256(encoded).hexdigest()


def _prism_transaction(app, doc, root, args):
    """Start once; observe or finalize; definition cleanup only after destroy.

    The immutable model marker witnesses submission, not success. Missing Python
    state after a restart is unknown even if the marker or sketch still exists.
    """
    import adsk.core
    command_id, profile_id = args['commandId'], args['profileId']
    if (not re.fullmatch(r'fmcad_prism_[0-9a-f]{32}', command_id)
            or not re.fullmatch(r'[A-Za-z0-9_]+', profile_id)
            or not re.fullmatch(r'[0-9a-f]{64}', args['requestSha256'])
            or not args.get('creationId') or not args.get('runId')):
        raise ValueError('Prism transaction requires pinned request identity')
    run_marker = root.attributes.itemByName(MARKER_GROUP, MARKER_NAME)
    if run_marker is None or run_marker.value != args['runId']:
        raise ValueError('Prism transaction run marker mismatch')
    marker_name = 'prism_' + profile_id
    marker = root.attributes.itemByName(MARKER_GROUP, marker_name)
    module_name = '_fmcad_' + command_id
    holder = sys.modules.get(module_name)
    identity = {k: args[k] for k in ('commandId', 'profileId', 'requestSha256', 'creationId', 'runId')}
    operation = args['operation']
    finalize_flags = dict(cleanupCompleted=False, definitionDeleted=False) if operation == 'prism_finalize' else {}
    if operation != 'prism_start':
        if marker is None:
            raise ValueError('Prism transaction submission marker missing; inspect the original start result, never replay')
        if json.loads(marker.value) != identity:
            raise ValueError('Prism transaction submission marker mismatch')
        if holder is None:
            return dict(identity, status='unavailable', accepted=None, completed=False,
                        destroyed=False, outcome='unknown', error='Live command state lost; inspect model, never replay',
                        **finalize_flags)
        if holder.identity != identity:
            raise ValueError('Prism command session identity mismatch')
        state = dict(holder.state, **finalize_flags)
        if operation in ('prism_status', 'prism_finalize'):
            file = doc.dataFile if doc.isSaved else None
            current = (file.id, file.versionNumber) if file else (None, None)
            if current != holder.file_identity:
                state.update(status='identity_changed', completed=False, outcome='unknown',
                             error='Document file/version changed; inspect native model')
            if operation == 'prism_status':
                return state  # No activation, attribute update, definition cleanup or model mutation.
            if not state['destroyed']:
                return dict(state, completed=False, outcome='unknown')
        if operation not in ('prism_cleanup', 'prism_finalize') or not state['destroyed']:
            raise ValueError('Command definition cleanup requires observed destroy')
        if app.userInterface.activeCommand not in ('', 'SelectCommand'):
            if operation == 'prism_finalize':
                return dict(state, status='cleanup_pending', completed=False, outcome='unknown')
            raise ValueError('Prism cleanup requires idle command context')
        definition = app.userInterface.commandDefinitions.itemById(command_id)
        if definition is None or definition.isNative or definition != holder.definition:
            raise ValueError('Owned prism command definition changed')
        if not definition.deleteMe() or app.userInterface.commandDefinitions.itemById(command_id) is not None:
            raise RuntimeError('Prism command definition cleanup not confirmed')
        holder.handlers.clear()
        del sys.modules[module_name]
        return dict(state, definitionDeleted=True, cleanupCompleted=True)

    # CommandDefinition.execute is unsupported inside command-related events.
    # Both backends use this guard; no fallback to slow/direct or nested execution.
    if app.userInterface.activeCommand not in ('', 'SelectCommand'):
        raise ValueError('Prism start requires an idle non-command host context; nested Command execution is unsupported')
    if app.activeDocument != doc:
        raise ValueError('Prism requires the pinned document to be active')
    if marker is not None or holder is not None or app.userInterface.commandDefinitions.itemById(command_id) is not None:
        raise ValueError('Prism was already submitted; inspect existing state, never replay')
    if args['spec']['id'] != profile_id:
        raise ValueError('Prism profile identity mismatch')
    payload = {k: args[k] for k in ('spec', 'template', 'start', 'depth')}
    digest = _prism_request_digest(payload)
    if digest != args['requestSha256']:
        raise ValueError('Prism request digest mismatch')
    deadline = args.get('deadlineEpoch')
    if deadline is not None and (not isinstance(deadline, (int, float)) or not math.isfinite(deadline) or deadline <= time.time()):
        raise ValueError('Prism launch deadline expired or invalid')
    # Cross-process epoch is converted once; later wall-clock corrections must
    # not extend the queued command's local execution-start deadline.
    host_deadline = time.monotonic() + (deadline - time.time()) if deadline is not None else None
    file = doc.dataFile if doc.isSaved else None
    file_id, version = (file.id, file.versionNumber) if file else (None, None)
    if file and (file.isReadOnly or not file.isComplete):
        raise ValueError('Prism requires a writable complete cloud file')
    if args.get('expectedVersion') is not None and version != args['expectedVersion']:
        raise ValueError('Prism cloud version changed')
    before = (root.sketches.count, root.bRepBodies.count)
    if any(s.name == 'kc_' + profile_id for s in _items(root.sketches)):
        raise ValueError('Prism sketch already exists; no replay')
    # Persist before queuing so aborted sketches or lost Python sessions cannot
    # make a second submission appear safe. Clear removes these with the run.
    marker = root.attributes.add(MARKER_GROUP, marker_name, json.dumps(identity, sort_keys=True))
    if marker is None or json.loads(marker.value) != identity:
        raise RuntimeError('Prism submission marker could not be verified')
    holder = types.ModuleType(module_name)
    holder.identity, holder.handlers = identity, []
    holder.file_identity = (file_id, version)
    holder.state = dict(identity, status='submitted', accepted=None, completed=False,
                        destroyed=False, createdCount=0, executeCount=0, executeCompleted=False,
                        terminationCompleted=False, result=None, error=None, outcome='unknown')
    sys.modules[module_name] = holder  # Event handlers must survive nonpersistent script calls.

    class Execute(adsk.core.CommandEventHandler):
        def notify(self, event):
            holder.state['executeCount'] += 1
            holder.state['status'] = 'executing'
            try:
                if holder.state['executeCount'] != 1 or holder.state['error']:
                    raise RuntimeError('Repeated/failed command execution refused')
                if host_deadline is not None and time.monotonic() > host_deadline:
                    raise TimeoutError('Prism deadline expired before execution; no late mutation')
                current = _one([d for d in _items(app.documents) if d.creationId == identity['creationId']], 'Prism document')
                current_file = current.dataFile if current.isSaved else None
                current_identity = (current_file.id, current_file.versionNumber) if current_file else (None, None)
                if (current != doc or app.activeDocument != doc or current_identity != (file_id, version)
                        or (current_file and (current_file.isReadOnly or not current_file.isComplete))
                        or (root.sketches.count, root.bRepBodies.count) != before
                        or root.attributes.itemByName(MARKER_GROUP, MARKER_NAME).value != identity['runId']
                        or json.loads(root.attributes.itemByName(MARKER_GROUP, marker_name).value) != identity):
                    raise ValueError('Prism document, version, marker or geometry changed before execute')
                result = _prism(root, payload['spec'], payload['template'], payload['start'], payload['depth'])
                holder.state.update(result=result, executeCompleted=True, status='executed')
            except Exception as error:
                holder.state.update(error=type(error).__name__ + ': ' + str(error), status='failed')
                event.executeFailedMessage = holder.state['error']
                event.executeFailed = True  # Request abort, never assume rollback without inspection.

    class Destroy(adsk.core.CommandEventHandler):
        def notify(self, event):
            good = event.terminationReason == adsk.core.CommandTerminationReason.CompletedTerminationReason
            complete = (good and holder.state['executeCompleted'] and not holder.state['error']
                        and holder.state['accepted'] is not False)
            holder.state.update(destroyed=True, terminationReason=int(event.terminationReason),
                                terminationCompleted=good, completed=bool(complete),
                                status='completed' if complete else 'terminated',
                                outcome='complete' if complete else 'unknown')

    class Created(adsk.core.CommandCreatedEventHandler):
        def notify(self, event):
            try:
                holder.state['createdCount'] += 1
                if holder.state['createdCount'] != 1:
                    raise RuntimeError('Repeated CommandCreated event refused')
                execute_handler, destroy_handler = Execute(), Destroy()
                holder.handlers.extend([execute_handler, destroy_handler])
                if not event.command.destroy.add(destroy_handler) or not event.command.execute.add(execute_handler):
                    raise RuntimeError('Prism command event attachment failed')
                event.command.isRepeatable = False
                event.command.isExecutedWhenPreEmpted = False
                event.command.isAutoExecute = True
                if event.command.commandInputs.count:
                    raise RuntimeError('Prism command must not have inputs')
                holder.state['status'] = 'created'
            except Exception as error:
                holder.state.update(error=type(error).__name__ + ': ' + str(error), status='failed')

    try:
        holder.definition = app.userInterface.commandDefinitions.addButtonDefinition(
            command_id, 'Keychain prism ' + profile_id, 'Create one validated keychain prism')
        if holder.definition is None:
            raise RuntimeError('Prism command definition creation failed')
        created = Created()
        holder.handlers.append(created)
        if not holder.definition.commandCreated.add(created):
            raise RuntimeError('Prism CommandCreated attachment failed')
        holder.state['accepted'] = bool(holder.definition.execute())
        if not holder.state['accepted']:
            holder.state.update(completed=False, outcome='unknown')
    except Exception as error:
        holder.state.update(error=type(error).__name__ + ': ' + str(error), status='unknown',
                            completed=False, outcome='unknown')
        raise
    return dict(holder.state)


def _body(body):
    box = _bounds(body)
    return {'name': body.name, 'component': body.parentComponent.name,
            'isSolid': bool(body.isSolid), 'volumeMm3': body.volume * 1000,
            'boundsMm': [[p.x * 10, p.y * 10, p.z * 10] for p in (box.minPoint, box.maxPoint)]}


def _bounds(body):
    return body.preciseBoundingBox if hasattr(body, 'preciseBoundingBox') else body.boundingBox


def _opaque_template(app):
    import adsk.core
    libraries = _items(app.materialLibraries)
    official = [library for library in libraries if library.id == 'BA5EE55E-9982-449B-9D66-9F036540E140']
    if official:
        template = _one(official, 'Official appearance library').appearances.itemById('Prism-127')
        if template is None or template.id != 'Prism-127':
            raise ValueError('Official appearance library lacks Prism-127')
    else:
        template = _one([a for library in libraries for a in _items(library.appearances)
                         if a.id == 'Prism-127'], 'Fallback opaque Prism-127 template')
    if not adsk.core.ColorProperty.cast(template.appearanceProperties.itemById('opaque_albedo')):
        raise ValueError('Prism-127 lacks a validated opaque_albedo ColorProperty')
    return template


def _interference(design, entities):
    import adsk.core
    if len(entities) < 2:
        return []
    collection = adsk.core.ObjectCollection.create()
    for entity in entities:
        collection.add(entity)
    request = design.createInterferenceInput(collection)
    request.areCoincidentFacesIncluded = False
    result = design.analyzeInterference(request)
    if result is None:
        raise RuntimeError('Native interference analysis returned no result')
    return _items(result)


def _saved_transition(app, args):
    import adsk.fusion
    run_id, name = args['expectedRunId'], args['expectedFileName']
    reusable = args.get('existingFile') is True
    if reusable and args.get('allowLegacyFingerprint'):
        raise ValueError('Reusable save requires a run marker, never legacy fingerprint-only recovery')
    if not run_id or (not reusable and not name.endswith('-' + run_id)) or (reusable and not args.get('expectedFileId')):
        raise ValueError('Save transition requires an exact run-qualified filename')
    project = _one([p for p in _items(app.data.dataProjects) if p.id == args['projectId']], 'Pinned project')
    folder = project.rootFolder
    if folder.id != args['folderId']:
        raise ValueError('Pinned project root changed')
    file = _one([f for f in _items(folder.dataFiles)
                 if (f.id == args['expectedFileId'] if reusable else f.name == name)], 'Exact saved filename/ID in pinned root')
    if args.get('expectedFileId') is not None and file.id != args['expectedFileId']:
        raise ValueError('Pinned cloud file ID changed; export recovery rejected')
    docs = [d for d in _items(app.documents) if d.dataFile and d.dataFile.id == file.id and d.dataFile.name == name]
    doc = _one(docs, 'Open document for pinned saved file')
    if not doc.creationId or not doc.isSaved or doc.isModified or not file.isComplete:
        raise ValueError('Pinned save is not complete and unmodified')
    if reusable and file.isReadOnly is not False:
        raise ValueError('Reusable saved file must remain writable')
    design = adsk.fusion.Design.cast(doc.products.itemByProductType('DesignProductType'))
    if design is None:
        raise ValueError('Pinned saved file is not a design')
    marker = design.rootComponent.attributes.itemByName(MARKER_GROUP, MARKER_NAME)
    if marker is not None and marker.value != run_id:
        raise ValueError('Saved document has a conflicting run marker')
    evidence = args.get('nativeEvidence')
    if marker is None and (args.get('allowLegacyFingerprint') is not True or not evidence):
        raise ValueError('Saved document lacks the expected run marker')
    # Also check the fingerprint for stamped builds when supplied. A copied
    # marker must never authorize export of different native geometry.
    if evidence:
        expected = evidence['native']
        current = execute({'operation': 'validate', 'creationId': doc.creationId,
                           'groups': evidence['groups'], 'backZMm': evidence['backZMm'],
                           **expected.get('partitionMetadata', {})})
        old = {(b['component'], b['name']): b for b in expected['bodies']}
        new = {(b['component'], b['name']): b for b in current['bodies']}
        if (not old or old.keys() != new.keys()
                or (not expected.get('partitionMetadata') and current['interferenceCount'] != 0)):
            raise ValueError('Saved native fingerprint body identities differ')
        for key, body in old.items():
            actual = new[key]
            if (actual['isSolid'] is not True or not math.isclose(body['volumeMm3'], actual['volumeMm3'], rel_tol=1e-7, abs_tol=1e-6)
                    or any(not math.isclose(a, b, rel_tol=0, abs_tol=1e-5)
                           for p, q in zip(body['boundsMm'], actual['boundsMm']) for a, b in zip(p, q))):
                raise ValueError('Saved native fingerprint geometry differs')
        canvas = _one([c for c in _items(design.rootComponent.canvases) if c.name == evidence['canvas']['name']], 'Source canvas')
        transform = list(canvas.transform.asArray())
        if (canvas.imageFilename != evidence['canvas']['sourcePath'] or len(transform) != 9 or len(evidence['canvas']['transform']) != 9
                or any(not math.isclose(a, b, rel_tol=1e-10, abs_tol=1e-10)
                       for a, b in zip(transform, evidence['canvas']['transform']))):
            raise ValueError('Saved native fingerprint source canvas differs')
    status = execute({'operation': 'saved_status', 'creationId': doc.creationId, 'projectId': project.id})
    if not status['rootMembershipVerified'] or status['modified'] or not status['isComplete']:
        raise ValueError('Saved document changed during identity verification')
    return dict(status, identityProof='run_marker' if marker else 'legacy_fingerprint',
                verifiedRunId=run_id, fingerprintVerified=bool(evidence))


def _reusable_identity(app, args):
    file_id = args['expectedFileId']
    if not isinstance(file_id, str) or not file_id:
        raise ValueError('Reusable target requires a cloud file ID')
    documents = _items(app.documents)
    doc = _one([d for d in documents if d.dataFile and d.dataFile.id == file_id],
               'Open reusable cloud document')
    if len([d for d in documents if d.name == doc.name]) != 1:
        raise ValueError('Reusable target display name is not unique among open documents: ' + repr(doc.name)
                         + '. Core CAD resolves names before checking ID pins; rename or close the conflicting '
                         'document before building.')
    status = execute({'operation': 'saved_status', 'creationId': doc.creationId, 'projectId': args['projectId']})
    file = doc.dataFile
    if (not doc.creationId or doc.isValid is not True or file.isValid is not True
            or status['rootMembershipVerified'] is not True or status['folderId'] != args['folderId']
            or doc.isSaved is not True or file.isComplete is not True or type(doc.isModified) is not bool
            or file.isReadOnly is not False or type(file.versionNumber) is not int or file.versionNumber < 1
            or (args.get('creationId') and doc.creationId != args['creationId'])
            or (args.get('expectedVersion') is not None and file.versionNumber != args['expectedVersion'])):
        raise ValueError('Reusable target identity, root, editability or version mismatch')
    if not args.get('allowModified') and status['modified'] is not False:
        raise ValueError('Reusable target must be unmodified')
    return doc, dict(status, version=file.versionNumber, readOnly=False)


def execute(args):
    import adsk.core
    import adsk.fusion
    app = adsk.core.Application.get()
    operation = args['operation']
    if args.get('allowIdentityTransition'):
        if operation != 'saved_status' or args['allowIdentityTransition'] is not True:
            raise ValueError('Identity transition is allowed only for saved_status')
        return _saved_transition(app, args)
    if operation in ('reusable_identity', 'save_version'):
        doc, status = _reusable_identity(app, dict(args, allowModified=operation == 'save_version'))
        if operation == 'reusable_identity':
            return status
        if (not args.get('expectedVersion') or not args.get('creationId') or not args.get('runId')
                or status['modified'] is not True):
            raise ValueError('Version save requires pinned modified run and baseline version')
        design = adsk.fusion.Design.cast(doc.products.itemByProductType('DesignProductType'))
        marker = design.rootComponent.attributes.itemByName(MARKER_GROUP, MARKER_NAME)
        if marker is None or marker.value != args['runId']:
            raise ValueError('Version save run marker mismatch')
        return {'accepted': doc.save('Approved keychain ' + args['runId'])}
    if operation == 'preflight':
        documents = _items(app.documents)
        if any(not d.creationId for d in documents) or not hasattr(adsk.core.Document, 'creationId'):
            raise ValueError('Installed SDK lacks document creationId inspection')
        if any(d.name.casefold() == args['name'].casefold() for d in documents):
            raise ValueError('Unique document name already exists')
        if any(p.name.casefold() == args['projectName'].casefold() for p in _items(app.data.dataProjects)):
            raise ValueError('Unique project name already exists')
        if not all(hasattr(adsk.fusion.Canvases, name) for name in ('createInput', 'add')):
            raise ValueError('Installed SDK lacks autonomous canvas insertion')
        for api, members in ((adsk.fusion.ExportManager, ('createSTLExportOptions', 'createFusionArchiveExportOptions', 'execute')),
                             (adsk.fusion.STLExportOptions, ('surfaceDeviation', 'unitType', 'sendToPrintUtility', 'isOneFilePerBody')),
                             (adsk.fusion.CanvasInput, ('transform',)), (adsk.core.Matrix2D, ('setWithArray', 'asArray'))):
            if not all(hasattr(api, member) for member in members):
                raise ValueError('Installed SDK lacks required export/canvas APIs: ' + str(members))
        template = _opaque_template(app)
        return {'passed': True, 'appearanceTemplateId': template.id, 'exportCapabilitiesVerified': True}
    if args.get('creationId'):
        doc = _one([d for d in _items(app.documents) if d.creationId == args['creationId']], 'creationId')
    else:
        doc = _one([d for d in _items(app.documents) if d.name == args['doc']], 'Document name')
    if args.get('expectedFileId') and (not doc.dataFile or doc.dataFile.id != args['expectedFileId']):
        raise ValueError('Pinned cloud file ID changed')
    design = adsk.fusion.Design.cast(doc.products.itemByProductType('DesignProductType'))
    if design is None:
        raise ValueError('Target is not a Fusion design')
    root = design.rootComponent
    if operation in ('prism_start', 'prism_status', 'prism_cleanup', 'prism_finalize'):
        return _prism_transaction(app, doc, root, args)
    if operation in ('set_deferred', 'geometry_readback'):
        name = args['sketch']['name'] if isinstance(args['sketch'], dict) else args['sketch']
        sketch = _one([s for s in _items(root.sketches) if s.name == name], 'Scoped sketch')
        if operation == 'geometry_readback':
            return _geometry_readback(sketch, args['template'])
        marker_name = 'deferred_' + name
        marker = root.attributes.itemByName(MARKER_GROUP, marker_name)
        if args['deferred']:
            if sketch.sketchCurves.count or sketch.isComputeDeferred or marker is not None:
                raise ValueError('Defer requires a new empty nondeferred sketch')
            root.attributes.add(MARKER_GROUP, marker_name, doc.creationId)
            sketch.isLightBulbOn = False
            sketch.isComputeDeferred = True
        else:
            if marker is None or marker.value != doc.creationId:
                raise ValueError('Cannot clear deferral not owned by this helper')
            sketch.isComputeDeferred = False
            marker.value = 'completed'
        if bool(sketch.isComputeDeferred) != args['deferred']:
            raise RuntimeError('Sketch deferral readback mismatch')
        return {'deferred': bool(sketch.isComputeDeferred), 'sketch': name}
    if operation == 'view':
        # camera.set owns the UI mutation. This read-only check is independent
        # of ViewCube orientation and never falls back to another active view.
        if not args.get('creationId') or app.activeDocument is None or app.activeDocument.creationId != doc.creationId:
            raise ValueError('Colored-side view requires the verified document to be active')
        viewport = app.activeViewport
        if viewport.parentDocument.creationId != doc.creationId:
            raise ValueError('Viewport belongs to a different document')
        camera = viewport.camera
        if camera.cameraType != adsk.core.CameraTypes.OrthographicCameraType or args['imageSide'] not in ('bottom', 'top'):
            raise ValueError('Colored-side view requires orthographic projection and a valid image side')
        eye, target, up = ([getattr(p, axis) for axis in ('x', 'y', 'z')]
                           for p in (camera.eye, camera.target, camera.upVector))
        delta = [a - b for a, b in zip(eye, target)]
        length = math.sqrt(sum(v*v for v in delta))
        if not math.isfinite(length) or length <= 0:
            raise ValueError('Invalid camera eye/target')
        normal = [v / length for v in delta]
        sign = -1 if args['imageSide'] == 'bottom' else 1
        plane_z = 0 if sign == -1 else args['thicknessMm']
        if (any(not math.isclose(a, b, abs_tol=1e-7) for a, b in zip(normal, [0, 0, sign]))
                or any(not math.isclose(a, b, abs_tol=1e-7) for a, b in zip(up, [0, 1, 0]))
                or sign * (eye[2] * 10 - plane_z) <= 0):
            raise ValueError('Camera is not facing the colored side with +Y up')
        ok, width, height = camera.getExtents()
        if not ok or not all(math.isfinite(v) and v > 0 for v in (width, height)):
            raise ValueError('Camera extents unavailable')
        for i, extent in enumerate((width, height)):
            if any(abs(point[i] - target[i] * 10) > extent * 5 + .001 for point in args['boundsMm']):
                raise ValueError('Colored-side camera does not fit the validated geometry')
        return {'creationId': doc.creationId, 'imageSide': args['imageSide'], 'planeZMm': plane_z,
                'projection': 'orthographic', 'normal': normal, 'normalDefinition': 'target-to-eye', 'up': up,
                'eyeMm': [v * 10 for v in eye], 'targetMm': [v * 10 for v in target],
                'extentsMm': [width * 10, height * 10], 'fitsGeometry': True}
    if operation == 'stamp':
        reusable = args.get('expectedFileId') is not None
        if reusable:
            _reusable_identity(app, args)
        if ((doc.isSaved and not reusable) or root.bRepBodies.count or root.sketches.count or root.allOccurrences.count
                or root.attributes.itemByName(MARKER_GROUP, MARKER_NAME) is not None):
            raise ValueError('Run stamp requires a new empty unsaved design')
        if not args['runId'] or (not reusable and not doc.name.endswith('-' + args['runId'])):
            raise ValueError('Run stamp/document mismatch')
        if reusable and app.activeDocument != doc:
            if not doc.activate() or app.activeDocument != doc:
                raise ValueError('Reusable target activation failed')
            _reusable_identity(app, args)
        root.attributes.add(MARKER_GROUP, MARKER_NAME, args['runId'])
        marker = root.attributes.itemByName(MARKER_GROUP, MARKER_NAME)
        if marker is None or marker.value != args['runId']:
            raise RuntimeError('Run marker readback failed')
        return {'creationId': doc.creationId, 'runId': marker.value}
    if operation in ('identity', 'saved_status'):
        if not doc.creationId:
            raise ValueError('Target document has no creationId')
        project = _one([p for p in _items(app.data.dataProjects) if p.id == args['projectId']], 'Project ID')
        folder, file = project.rootFolder, doc.dataFile
        # Do not read DataFile.parentProject: some accepted saves throw an
        # InternalValidationError there. Prove membership through the exact root.
        members = [f for f in _items(folder.dataFiles) if file and f.id == file.id]
        return {'name': doc.name, 'creationId': doc.creationId, 'saved': bool(doc.isSaved),
                'modified': bool(doc.isModified), 'fileId': file.id if file else None,
                'fileName': file.name if file else None, 'isComplete': bool(file.isComplete) if file else False,
                'version': getattr(file, 'versionNumber', None) if file else None,
                'projectId': project.id if members else None, 'folderId': folder.id,
                'rootMembershipVerified': len(members) == 1}
    if operation == 'bodies':
        bodies = [_one([b for b in _items(root.bRepBodies) if b.name == name], 'Body name') for name in args['names']]
        return {'bodies': [_body(b) for b in bodies]}
    if operation == 'overlap':
        bodies = _items(root.bRepBodies)
        target = _one([b for b in bodies if b.name == args['target']], 'Target body')
        tools = [_one([b for b in bodies if b.name == name], 'Tool body') for name in args['tools']]
        overlapping = []
        a = _bounds(target)
        for tool in tools:
            b = _bounds(tool)
            if any(getattr(a.maxPoint, axis) <= getattr(b.minPoint, axis) or
                   getattr(b.maxPoint, axis) <= getattr(a.minPoint, axis) for axis in ('x', 'y', 'z')):
                continue
            if _interference(design, [target, tool]):
                overlapping.append(tool.name)
        return {'overlapping': overlapping}
    groups = args.get('groups', [])
    if operation in ('appearance', 'validate'):
        components = {g['name']: _one([c for c in _items(design.allComponents) if c.name == g['name']],
                                     'Color component') for g in groups}
    if operation == 'appearance':
        template = _opaque_template(app)
        # document.clear retains appearances. Reuse verified swatches across
        # fresh keychain runs; a kc_rgb name alone is not proof of its color.
        existing = {}
        for group in groups:
            name = 'kc_rgb_' + group['hex'][1:].lower()
            matches = [a for a in _items(design.appearances) if a.name == name]
            if matches:
                appearance = _one(matches, 'Keychain appearance name')
                color = adsk.core.ColorProperty.cast(appearance.appearanceProperties.itemById('opaque_albedo'))
                rgb = [int(group['hex'][i:i + 2], 16) for i in (1, 3, 5)]
                if color is None or color.hasConnectedTexture:
                    raise ValueError('Appearance name collision: incompatible opaque_albedo: ' + name)
                observed = color.value
                if [observed.red, observed.green, observed.blue, observed.opacity] != rgb + [255]:
                    raise ValueError('Appearance name collision: RGBA differs from palette: ' + name)
                existing[name] = appearance
        assigned = []
        for group in groups:
            name = 'kc_rgb_' + group['hex'][1:].lower()
            rgb = [int(group['hex'][i:i + 2], 16) for i in (1, 3, 5)]
            appearance = existing.get(name)
            if appearance is None:
                appearance = design.appearances.addByCopy(template, name)
                color = adsk.core.ColorProperty.cast(appearance.appearanceProperties.itemById('opaque_albedo'))
                color.value = adsk.core.Color.create(*rgb, 255)
                observed = color.value
                if [observed.red, observed.green, observed.blue, observed.opacity] != rgb + [255]:
                    raise RuntimeError('Appearance RGB readback mismatch')
                existing[name] = appearance
            for body in _items(components[group['name']].bRepBodies):
                body.appearance = appearance
            assigned.append({'component': group['name'], 'rgb': rgb, 'appearance': appearance.name})
        return {'assigned': assigned}
    if operation == 'canvas':
        # Canvas insertion is not in older public SDKs. Never open an interactive
        # command or pretend an image was inserted when this capability is absent.
        canvases = getattr(root, 'canvases', None)
        if canvases is None or not hasattr(canvases, 'createInput'):
            raise RuntimeError('Installed Fusion SDK lacks autonomous canvas insertion; native model retained')
        plane = root.xYConstructionPlane if args['plane'] == 'XY' else _one(
            [p for p in _items(root.constructionPlanes) if p.name == args['plane']], 'Canvas plane')
        # Confirmed against installed API/Python/packages/adsk/defs/adsk/fusion.py:
        # Canvases.createInput(imageFilename, planarEntity), add(CanvasInput).
        input_ = canvases.createInput(args['sourcePath'], plane)
        if input_ is None:
            raise RuntimeError('Canvas input creation failed')
        input_.isRenderable = False
        input_.isSelectable = False
        w, h = args['imageSize']
        cx, cy = args['centerPx']
        s = args['mmPerPixel'] / 10
        if args['imageSide'] not in ('bottom', 'top') or min(w, h, s) <= 0:
            raise ValueError('Invalid canvas dimensions or image side')
        sign = -1 if args['imageSide'] == 'bottom' else 1
        # CanvasInput maps normalized image coordinates [0,1] into plane cm.
        expected = [sign*w*s, 0, -sign*cx*s, 0, h*s, (cy-h)*s, 0, 0, 1]
        if not all(math.isfinite(v) for v in expected):
            raise ValueError('Nonfinite canvas calibration')
        matrix = adsk.core.Matrix2D.create()
        if not matrix.setWithArray(expected):
            raise RuntimeError('Canvas calibration matrix rejected')
        input_.transform = matrix
        observed = list(input_.transform.asArray())
        if len(observed) != 9 or any(not math.isclose(a, b, rel_tol=1e-10, abs_tol=1e-10) for a, b in zip(observed, expected)):
            raise RuntimeError('Canvas input calibration readback mismatch')
        canvas = canvases.add(input_)
        if canvas is None:
            raise RuntimeError('Canvas insertion failed')
        canvas.name = 'kc_original_source'
        canvas.isLightBulbOn = False
        if canvas.imageFilename != args['sourcePath']:
            raise RuntimeError('Canvas source readback mismatch')
        observed = list(canvas.transform.asArray())
        if len(observed) != 9 or any(not math.isclose(a, b, rel_tol=1e-10, abs_tol=1e-10) for a, b in zip(observed, expected)):
            raise RuntimeError('Canvas calibration readback mismatch')
        return {'name': canvas.name, 'sourcePath': canvas.imageFilename, 'visible': False,
                'calibrated': True, 'transform': observed, 'transformUnits': 'cm',
                'purpose': 'Calibrated original source reference; geometry follows approved SVG'}
    if operation == 'validate':
        rows, color_rows, occurrences, back_area = [], {}, [], 0.
        for group in groups:
            component = components[group['name']]
            bodies = _items(component.bRepBodies)
            if not bodies:
                raise ValueError('Color has no bodies')
            occurrence = _one([o for o in _items(root.allOccurrences) if o.component == component], 'Color occurrence')
            occurrences.append(occurrence)
            proxies = [body.createForAssemblyContext(occurrence) for body in bodies]
            if any(body is None for body in proxies):
                raise ValueError('Failed to resolve color bodies in root assembly context')
            values = [_body(b) for b in proxies]
            if any(b['component'] != component.name for b in values):
                raise ValueError('Body owner differs from selected color component')
            rows.extend(values)
            rgb = [int(group['hex'][i:i + 2], 16) for i in (1, 3, 5)]
            for body, proxy in zip(bodies, proxies):
                appearance = body.appearance
                color = adsk.core.ColorProperty.cast(appearance.appearanceProperties.itemById('opaque_albedo')).value
                if [color.red, color.green, color.blue, color.opacity] != rgb + [255]:
                    raise RuntimeError('Final appearance RGB differs from palette')
                for face in _items(proxy.faces):
                    plane = adsk.core.Plane.cast(face.geometry)
                    if plane and abs(abs(plane.normal.z) - 1) < 1e-8 and abs(plane.origin.z * 10 - args['backZMm']) < 1e-5:
                        back_area += face.area * 100
            # Occurrence-wide analysis below checks cross-color interference;
            # check same-color bodies too, since they share one occurrence.
            if args.get('construction') != 'partition_prisms' and _interference(design, proxies):
                raise ValueError('Same-color bodies have positive native overlap')
            color_rows[group['name']] = {'volumeMm3': sum(b['volumeMm3'] for b in values),
                'boundsMm': [[min(b['boundsMm'][0][i] for b in values) for i in range(3)],
                             [max(b['boundsMm'][1][i] for b in values) for i in range(3)]]}
            if args.get('construction') == 'partition_prisms':
                color_rows[group['name']]['colorId'] = group['colorId']
        if root.bRepBodies.count or len(_items(root.allOccurrences)) != len(occurrences):
            raise ValueError('Unexpected retained bodies/occurrences would create export duplicates')
        if len({(b['component'], b['name']) for b in rows}) != len(rows):
            raise ValueError('Native body names are not unique within their component')
        if args.get('construction') == 'partition_prisms':
            geometry = []
            for spec in args['profileMetadata']:
                sketch = _one([s for s in _items(root.sketches) if s.name == spec['sketch']], 'Partition sketch')
                readback = _geometry_readback(sketch, spec['template'])
                profile = _one([p for p in _items(sketch.profiles) if p.profileLoops.count == spec['loopCount']], 'Partition profile')
                area = profile.areaProperties().area * 100
                if abs(area - spec['areaMm2']) > spec['areaMm2'] * .015:
                    raise ValueError('Native profile area mismatch')
                geometry.append(dict(readback, id=spec['id'], areaMm2=area, loopCount=profile.profileLoops.count))
            healthy = all(t.healthState == adsk.fusion.FeatureHealthStates.HealthyFeatureHealthState
                          for t in _items(design.timeline) if hasattr(t, 'healthState'))
            if not healthy:
                raise ValueError('Partition history unhealthy')
            return {'creationId': doc.creationId, 'bodies': rows, 'colors': color_rows,
                'backFaceAreaMm2': back_area, 'interferenceCount': None,
                'nativeBulkQuery': {'status': 'not_called', 'reason': 'constructive partition and actual target mesh proof'},
                'healthy': healthy, 'profileGeometry': geometry,
                'partitionMetadata': {k: args[k] for k in ('construction', 'profileMetadata', 'backZMinMm', 'backZMaxMm')},
                'constructionProof': {'method': 'direct-shared-partition-prisms', 'geometryReadbackChecked': True,
                                      'targetMeshCollisionProof': {'checked': False, 'status': 'pending'}}}
        return {'creationId': doc.creationId, 'bodies': rows, 'colors': color_rows, 'backFaceAreaMm2': back_area,
                'interferenceCount': len(_interference(design, occurrences))}
    raise ValueError('Unsupported keychain helper operation: ' + operation)


def run(_context: str):
    print('KEYCHAIN_RESULT ' + json.dumps({'success': True, 'result': execute(ARGS)}, allow_nan=False))
