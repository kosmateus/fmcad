"""Offline approved-SVG planner. Sampling is evidence, never exported geometry.

Trusted generated SVG only: flat paths, M/L/C/Z, translations, opaque palette
fills, and explicit nonzero (default) or evenodd fill rules. No CAD imports.
"""

import hashlib
import importlib.util
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

import numpy as np
from shapely.geometry import Polygon, box
from shapely.ops import unary_union
from shapely.validation import explain_validity

_spec = importlib.util.spec_from_file_location('_keychain_trace', Path(__file__).with_name('image_trace.py'))
trace = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(trace)

SAMPLE_ERROR_PX = 0.001
BOUNDARY_TOLERANCE_PX = 0.05
FIELD_SEAM_DISTANCE_PX = 2.0
FIELD_SEAM_AREA_FRACTION = 0.01
FIELD_DOMINANT_MIN_FRACTION = 0.10
FIELD_DISTANCE_STEPS = 12
BOUNDARY_SEAM_DISTANCE_PX = 4.0
BOUNDARY_SEAM_AREA_FRACTION = 0.05
INTERNAL_OVERHANG_DISTANCE_PX = 4.0
INTERNAL_OVERHANG_AREA_FRACTION = 0.05
MAX_RECONCILIATION_COMPONENTS = 4096
HOLE_MIN_IOU = 0.98
HOLE_MAX_HAUSDORFF_PX = 2.0
HOLE_MIN_BACKGROUND_FRACTION = 0.98
MAX_SOURCE_SEGMENTS = 12000
MAX_RINGS = 1000
MAX_SAMPLE_POINTS = 250000
MAX_GEOMETRY_SEGMENTS = 20000
MAX_PROFILES = 512


def _coefficients(kind, points):
    p = np.asarray(points, dtype=float)
    if kind == 'L':
        return np.array([p[0], p[1] - p[0]])
    return np.array([p[0], 3 * (p[1] - p[0]),
                     3 * (p[0] - 2 * p[1] + p[2]), -p[0] + 3*p[1] - 3*p[2] + p[3]])


def _bounds(segments):
    points = []
    for kind, raw in segments:
        c = _coefficients(kind, raw)
        ts = [0., 1.]
        if kind == 'C':
            for axis in range(2):
                roots = np.polynomial.polynomial.polyroots([c[1, axis], 2*c[2, axis], 3*c[3, axis]])
                ts.extend(float(t.real) for t in roots if abs(t.imag) < 1e-12 and 0 < t.real < 1)
        points.extend(np.polynomial.polynomial.polyval(t, c) for t in ts)
    p = np.asarray(points)
    return [*p.min(axis=0).tolist(), *p.max(axis=0).tolist()]


def _area(segments):
    # Green's theorem integrates the original polynomial, not the sampled ring.
    total = 0.
    for kind, raw in segments:
        c = _coefficients(kind, raw)
        x, y = c[:, 0], c[:, 1]
        cross = np.polynomial.polynomial.polysub(
            np.polynomial.polynomial.polymul(x, np.polynomial.polynomial.polyder(y)),
            np.polynomial.polynomial.polymul(y, np.polynomial.polynomial.polyder(x)))
        total += sum(v / (i + 1) for i, v in enumerate(cross)) / 2
    return total


def _sample(segments, tolerance, budget):
    result = [segments[0][1][0]]
    stack = []
    for kind, raw in segments:
        stack.append((kind, np.asarray(raw, dtype=float), 0))
        while stack:
            kind, p, depth = stack.pop()
            if kind == 'C':
                chord = p[-1] - p[0]
                length2 = float(chord @ chord)
                t = np.clip(((p[1:3] - p[0]) @ chord) / length2, 0, 1) if length2 else np.zeros(2)
                error = np.linalg.norm(p[1:3] - (p[0] + t[:, None]*chord), axis=1).max()
                if error > tolerance:
                    if depth >= 24:
                        raise ValueError('Curve sampling complexity exceeded; simplify approved SVG')
                    a, b, c = (p[:-1] + p[1:]) / 2
                    d, e = (a+b)/2, (b+c)/2
                    m = (d+e)/2
                    stack.extend([('C', np.array([m, e, c, p[3]]), depth+1),
                                  ('C', np.array([p[0], a, d, m]), depth+1)])
                    continue
            result.append(tuple(p[-1]))
            budget[0] += 1
            if budget[0] > MAX_SAMPLE_POINTS:
                raise ValueError('Sample point complexity cap exceeded; simplify approved SVG')
    return result


def _hierarchy(rings):
    """Containment, not sign, locates parents; crossing/touching rings are unsafe."""
    for ring in rings:
        containers = []
        for other in rings:
            if other is ring or not other['polygon'].intersects(ring['polygon']):
                continue
            a, b = other['polygon'], ring['polygon']
            if a.boundary.intersects(b.boundary):
                raise ValueError(f"Crossing/touching rings {ring['id']} and {other['id']}; correct SVG")
            if a.contains(b):
                containers.append(other)
            elif not b.contains(a):
                raise ValueError(f"Overlapping rings {ring['id']} and {other['id']}")
        ring['parent'] = min(containers, key=lambda r: r['polygon'].area) if containers else None


def _region(shell, holes):
    shape = Polygon(shell['polygon'].exterior.coords,
                    [h['polygon'].exterior.coords for h in holes])
    if not shape.is_valid or shape.is_empty or shape.area <= 0:
        raise ValueError(f"Invalid region {shell['id']}: {explain_validity(shape)}; correct SVG")
    return shape


def _bounded_distance(shape, reference, maximum, label):
    """Conservative distance bound over the whole sampled geometry, not vertices.

    A local reference window reduces buffer work without omitting any reference
    point within the allowed radius. Round distance masks never become exported
    geometry. Fixed-step bisection bounds the maximum distance, including gap
    interiors; it is sampled evidence, not an exact native CAD metric.
    """
    if shape.is_empty:
        return 0.
    l, t, r, b = shape.bounds
    reference = reference.intersection(box(l-maximum, t-maximum, r+maximum, b+maximum))
    if not reference.buffer(maximum).covers(shape):
        raise ValueError(f'{label}: {shape.area:.9g} px2, maximum distance exceeds {maximum:g} px; '
                         f'bounds {list(shape.bounds)}; correct approved SVG')
    minimum = 0.
    for _ in range(FIELD_DISTANCE_STEPS):
        middle = (minimum + maximum) / 2
        if reference.buffer(middle).covers(shape):
            maximum = middle
        else:
            minimum = middle
    return maximum


def _field_coverage(shape, coverage, dominant_area, label):
    """Reconcile boundary seams separately from detached interior missing paint.

    Polygon components must actually intersect the authoritative field boundary
    to qualify as boundary seams; proximity alone is insufficient. Point-only
    contacts between separate polygons are not merged. Category caps aggregate
    all components, and total missing paint is additionally capped at 5%.
    Physical holes are already excluded from shape and are never filled here.
    """
    missing = shape.difference(coverage)
    parts = list(missing.geoms) if hasattr(missing, 'geoms') else ([] if missing.is_empty else [missing])
    if len(parts) > MAX_RECONCILIATION_COMPONENTS:
        raise ValueError('Reconciliation component complexity cap exceeded; simplify approved SVG')
    fraction = dominant_area / shape.area
    if not missing.is_empty and fraction < FIELD_DOMINANT_MIN_FRACTION:
        raise ValueError(f'Missing coverage in field {label}: dominant coverage {fraction:.9g} '
                         f'is below {FIELD_DOMINANT_MIN_FRACTION}; correct approved SVG')
    area_limit = min(BOUNDARY_SEAM_AREA_FRACTION * shape.area,
                     BOUNDARY_SEAM_DISTANCE_PX * coverage.boundary.length)
    if missing.area > area_limit:
        raise ValueError(f'Missing coverage in field {label}: {missing.area:.9g} px2 '
                         f'exceeds total seam area cap {area_limit:.9g} px2; correct approved SVG')
    grouped = {'boundary': [], 'interior': []}
    for part in parts:
        grouped['boundary' if part.intersects(shape.boundary) else 'interior'].append(part)
    reports = {}
    for kind, distance, ratio in [('boundary', BOUNDARY_SEAM_DISTANCE_PX, BOUNDARY_SEAM_AREA_FRACTION),
                                  ('interior', FIELD_SEAM_DISTANCE_PX, FIELD_SEAM_AREA_FRACTION)]:
        area = sum(part.area for part in grouped[kind])
        limit = min(ratio * shape.area, distance * coverage.boundary.length)
        if area > limit:
            raise ValueError(f'Missing coverage in field {label}: {kind} missing area {area:.9g} px2 '
                             f'exceeds seam area cap {limit:.9g} px2; correct approved SVG')
        components = [dict(areaPx2=part.area, boundsPx=list(part.bounds),
                           maxDistancePx=_bounded_distance(part, coverage, distance,
                               f'Missing coverage in field {label}, {kind} seam from existing non-outline fill'))
                      for part in grouped[kind]]
        reports[kind] = dict(missingAreaPx2=area, missingAreaFraction=area / shape.area,
                             missingAreaLimitPx2=limit, maxDistancePx=max((p['maxDistancePx'] for p in components), default=0.),
                             policy=dict(maxDistancePx=distance, maxMissingAreaFraction=ratio,
                                         maxMissingAreaBoundaryFactorPx=distance), components=components)
    return dict(missingAreaPx2=missing.area, missingAreaFraction=missing.area / shape.area,
                missingAreaLimitPx2=area_limit, maxDistancePx=max(r['maxDistancePx'] for r in reports.values()),
                dominantCoverageFraction=fraction, **reports)


def _internal_overhang(paint, fields, label):
    """Check one visible source region before its native curves are field-clipped."""
    removed = paint.difference(fields)
    if removed.is_empty:
        return None
    retained = paint.intersection(fields).area
    if retained <= 1e-12:
        raise ValueError(f'Non-outline artwork outside fields {label}: source region wholly outside internal fields; '
                         'cannot discard a floating paint region or an entire color')
    fraction = removed.area / paint.area
    if fraction > INTERNAL_OVERHANG_AREA_FRACTION:
        raise ValueError(f'Non-outline artwork outside fields {label}: overhang {fraction:.6%} '
                         f'exceeds {INTERNAL_OVERHANG_AREA_FRACTION:.0%} of visible source-region paint')
    maximum = _bounded_distance(removed, fields.boundary, INTERNAL_OVERHANG_DISTANCE_PX,
                                f'Non-outline artwork outside fields {label}, internal overhang')
    return dict(visibleAreaPx2=paint.area, retainedAreaPx2=retained, removedAreaPx2=removed.area,
                removedAreaFraction=fraction, maxDistancePx=maximum, boundsPx=list(removed.bounds))


def _canonical_background_holes(holes, outline, background_visible, foreground_visible):
    """Select existing cavity curves only for unique, strongly evidenced holes.

    Hausdorff on sampled vertices alone can miss deviations along long lines.
    Bidirectional whole-boundary distance masks additionally certify the cap;
    these masks are never used as replacement/export geometry.
    """
    canonical, matches, used = [], [], set()
    foreground_parts = list(foreground_visible.geoms) if hasattr(foreground_visible, 'geoms') else [foreground_visible]
    for hole in holes:
        a = hole['polygon']
        candidates = []
        for cavity in outline:
            b = cavity['polygon']
            if not cavity['hole'] or not a.intersects(b):
                continue
            iou = a.intersection(b).area / a.union(b).area
            if iou < HOLE_MIN_IOU:
                continue
            distance = a.boundary.hausdorff_distance(b.boundary)
            if (distance > HOLE_MAX_HAUSDORFF_PX or
                    not a.boundary.buffer(HOLE_MAX_HAUSDORFF_PX).covers(b.boundary) or
                    not b.boundary.buffer(HOLE_MAX_HAUSDORFF_PX).covers(a.boundary)):
                continue
            candidates.append((cavity, iou, distance))
        if len(candidates) > 1:
            raise ValueError(f"Ambiguous background hole {hole['id']}: outline matches "
                             + ', '.join(c['id'] for c, _, _ in candidates))
        if not candidates:
            for cavity in outline:
                if (cavity['hole'] and a.intersects(cavity['polygon']) and
                        not cavity['polygon'].contains(a)):
                    raise ValueError(f"Background hole crosses field {cavity['id']}; no unique bounded outline match for {hole['id']}")
            if not background_visible.covers(a):
                raise ValueError(f"Partly overpainted background hole {hole['id']}; provide explicit final hole curves")
            canonical.append(hole)
            continue
        cavity, iou, distance = candidates[0]
        if cavity['id'] in used:
            raise ValueError(f"Ambiguous background holes share outline cavity {cavity['id']}")
        b = cavity['polygon']
        fraction = b.intersection(background_visible).area / b.area
        if fraction <= HOLE_MIN_BACKGROUND_FRACTION:
            raise ValueError(f"Background hole match {hole['id']} to {cavity['id']}: "
                             f"visible background fraction {fraction:.9g} must exceed {HOLE_MIN_BACKGROUND_FRACTION}")
        if (any(r['parent'] is cavity for r in outline) or
                any(not part.is_empty and b.contains(part) and not b.boundary.intersects(part)
                    for part in foreground_parts)):
            raise ValueError(f"Background hole match {hole['id']} to {cavity['id']} contains a nested foreground island; preserve counter features")
        canonical.append(cavity)
        used.add(cavity['id'])
        matches.append(dict(backgroundRingId=hole['id'], outlineRingId=cavity['id'],
                            iou=iou, hausdorffPx=distance, backgroundVisibleFraction=fraction,
                            sourceAreaPx2=hole['area'], canonicalAreaPx2=cavity['area']))
    return canonical, matches


def make_plan(svg_path, palette_path, outline_color, width_mm, thickness_mm,
              front_mm, image_side, output_dir):
    """Return/write contract v1 plan; all preflight failures have no output effects.

    areaMm2 is exact for native rings, sampled for clipped/painted intersections.
    Patch loopCount/areaMm2 describe its *unclipped* single source profile.
    Builder must clipToField, apply ascending paint priorities (including base-
    colored repaint patches), and verify resulting solids independently.
    Admitted missing paint uses the dominant field base via the common cavity;
    field.coverage and validation.fieldCoveragePolicy record the bounded policy.
    backgroundHoleMatches identifies the canonical rings used both as base holes
    and skipped color cavities; all native controls come from the approved SVG.
    internalPaintClipping reports bounded source-region overhangs discarded by
    the builder's existing field clips, never by modifying the physical envelope.
    omittedRedundantBasePaint records base-color patches with an empty sampled
    intersection against all earlier non-base source paint clipped to that field.
    Remaining patch IDs/priorities stay stable; real base-color repaint is kept.
    """
    out = Path(output_dir).absolute()
    if out.exists() or out.is_symlink() or not out.parent.is_dir():
        raise ValueError('output_dir must be a new directory with an existing parent')
    for name, value in [('width_mm', width_mm), ('thickness_mm', thickness_mm), ('front_mm', front_mm)]:
        if not trace.numeric(value) or value <= 0:
            raise ValueError(name + ' must be finite and positive')
    if front_mm >= thickness_mm or image_side not in ('bottom', 'top'):
        raise ValueError('Require front_mm < thickness_mm and image_side bottom or top')
    palette = json.loads(Path(palette_path).read_text(encoding='utf-8'))
    background = trace.color(palette['background'])
    outline_color = trace.color(outline_color)
    colors, by_hex, names = [], {}, set()
    for i, entry in enumerate(palette['colors']):
        fill = trace.color(entry['color'])
        name = entry['name']
        if not isinstance(name, str) or not name.strip() or name in names or fill in by_hex or fill == background:
            raise ValueError('Palette needs unique nonempty names and colors excluding background')
        record = dict(id=f'color_{i+1:03d}', name=name, hex=fill)
        colors.append(record)
        by_hex[fill] = record['id']
        names.add(name)
    if not colors or outline_color not in by_hex:
        raise ValueError('Palette must include at least one foreground color and outline_color')
    source = Path(svg_path).read_bytes()
    root = ET.fromstring(source)
    if root.tag.split('}')[-1] != 'svg' or set(root.attrib) - {'width', 'height', 'viewBox', 'version'}:
        raise ValueError('Unsupported SVG root attributes; use flat generated SVG')
    paths, all_rings, budget = [], [], [0]
    segment_count = 0
    for index, element in enumerate(root):
        if (element.tag.split('}')[-1] != 'path' or len(element) or
                set(element.attrib) - {'d', 'fill', 'transform', 'fill-rule', 'id'}):
            raise ValueError('Only flat opaque SVG paths with M/L/C/Z and translate are supported')
        fill = trace.color(element.get('fill'))
        if fill not in by_hex and fill != background:
            raise ValueError(f'Unapproved SVG color {fill} at path {index}')
        rule = element.get('fill-rule', 'nonzero')
        if rule not in ('nonzero', 'evenodd'):
            raise ValueError('Unsupported SVG fill-rule: ' + rule)
        rings, current = [], (0., 0.)
        data = element.get('d', '').strip()
        if not data or data[0] not in 'Mm':
            raise ValueError(f'Empty/missing move at path {index}')
        for part in re.split(r'(?=[Mm])', data):
            if not part:
                continue
            if len(re.findall('[Zz]', part)) != 1 or part.rstrip()[-1] not in 'Zz':
                raise ValueError(f'Every ring must explicitly close with Z at path {index}')
            prefix = f'M {current[0]} {current[1]} ' if part[0] == 'm' else ''
            raw = trace.parse_path(prefix + part)
            segments = trace.parse_path(prefix + part, element.get('transform', ''))
            if not segments or segments[0][1][0] != segments[-1][1][-1]:
                raise ValueError(f'Open/empty ring at path {index}')
            current = raw[-1][1][-1]
            segment_count += len(segments)
            if segment_count > MAX_SOURCE_SEGMENTS or len(all_rings) >= MAX_RINGS:
                raise ValueError('Source feature complexity cap exceeded; simplify approved SVG')
            bounds = _bounds(segments)
            size = min(bounds[2]-bounds[0], bounds[3]-bounds[1])
            if size <= 0:
                raise ValueError(f'Degenerate ring at path {index}')
            tolerance = min(SAMPLE_ERROR_PX, size / 1000)
            for refinement in range(4):
                polygon = Polygon(_sample(segments, tolerance / 10**refinement, budget))
                if polygon.is_valid and polygon.area > 0:
                    break
            if not polygon.is_valid or polygon.area <= 0:
                raise ValueError(f'Invalid ring at path {index}: {explain_validity(polygon)}; correct SVG (no repair applied)')
            signed_area = _area(segments)
            if not np.isfinite(signed_area) or signed_area == 0:
                raise ValueError(f'Unresolvable exact ring area at path {index}; normalize SVG coordinates')
            ring = dict(id=f'path_{index:04d}_ring_{len(rings):03d}', segments=segments,
                        polygon=polygon, area=abs(signed_area), bounds=bounds,
                        sign=1 if signed_area > 0 else -1)
            rings.append(ring)
            all_rings.append(ring)
        _hierarchy(rings)
        active = []
        for ring in rings:
            ancestors, parent = [], ring['parent']
            while parent is not None:
                ancestors.append(parent)
                parent = parent['parent']
            outside = len(ancestors) % 2 if rule == 'evenodd' else sum(r['sign'] for r in ancestors)
            inside = (len(ancestors)+1) % 2 if rule == 'evenodd' else outside + ring['sign']
            if bool(outside) != bool(inside):
                ring['hole'] = bool(outside)
                active.append(ring)
        _hierarchy(active)
        regions = []
        for ring in active:
            if not ring['hole']:
                holes = [r for r in active if r['parent'] is ring]
                regions.append(dict(shell=ring, holes=holes, polygon=_region(ring, holes)))
        paths.append(dict(id=f'path_{index:04d}', priority=index, fill=fill,
                          rings=active, regions=regions,
                          polygon=unary_union([r['polygon'] for r in regions])))
    outline = [r for p in paths if p['fill'] == outline_color for r in p['rings']]
    exteriors = [r for r in outline if not r['hole']]
    if not exteriors:
        raise ValueError('No outline-color exterior found')
    envelope = max(exteriors, key=lambda r: r['area'])
    env = envelope['polygon']
    warnings = ['Topology, coverage and clipped areas are sampled evidence, not native CAD validation; native curves unchanged, admitted seam normalization reported per field.']

    def thin_only(shape, boundary, label):
        if shape.is_empty or shape.area <= 1e-12:
            return
        # A buffer is a declared measurement mask only; never replace any ring.
        if not boundary.buffer(BOUNDARY_TOLERANCE_PX).covers(shape):
            raise ValueError(f'{label}: significant uncontained/uncovered area {shape.area:.9g} px2, bounds {list(shape.bounds)}; correct approved SVG, no bridges invented')
        warnings.append(f'{label}: ignored thin boundary deviation {shape.area:.9g} px2 within {BOUNDARY_TOLERANCE_PX} px; native boundaries unchanged.')

    for p in paths:
        if p['fill'] != background:
            for region in p['regions']:
                shape = region['polygon']
                if not shape.intersects(env):
                    raise ValueError(f"Disconnected floating foreground {p['id']} {region['shell']['id']}; no bridges invented")
                thin_only(shape.difference(env), env.boundary, f"Outside envelope {p['id']}")
    _hierarchy(outline)
    for ring in outline:
        if ring is envelope:
            continue
        parent = ring['parent']
        if parent is None or parent['hole'] == ring['hole']:
            raise ValueError(f"Disconnected/inconsistent outline hierarchy at {ring['id']}; correct SVG")

    # Visible paint respects document order, including background and overpainting.
    covered = Polygon()
    visible = {}
    for p in reversed(paths):
        visible[p['id']] = p['polygon'].difference(covered)
        covered = covered.union(p['polygon'])
    background_holes = []
    for p in paths:
        if p['fill'] != background:
            continue
        for region in p['regions']:
            shell = region['shell']
            if env.contains(shell['polygon']):
                if region['holes']:
                    raise ValueError(f"Floating foreground islands inside background hole {shell['id']}")
                background_holes.append(shell)
    background_holes, hole_matches = _canonical_background_holes(
        background_holes, outline,
        unary_union([visible[p['id']] for p in paths if p['fill'] == background]),
        unary_union([visible[p['id']] for p in paths if p['fill'] != background]))
    matched_cavities = {m['outlineRingId'] for m in hole_matches}
    for match in hole_matches:
        warnings.append(f"physical-hole canonicalization {match['backgroundRingId']} to "
                        f"{match['outlineRingId']}: IoU {match['iou']:.9g}, "
                        f"Hausdorff {match['hausdorffPx']:.9g} px, "
                        f"visible background {match['backgroundVisibleFraction']:.6%}; "
                        'existing outline controls retained for base hole and skipped field; hole remains open.')
    if len(colors) == 1:
        # With no approved non-outline fill, empty outline cavities are physical
        # holes, not color fields. Islands inside them would float in space.
        for cavity in [r for r in outline if r['hole']]:
            if any(r['parent'] is cavity for r in outline):
                raise ValueError(f"Disconnected floating monochrome island inside {cavity['id']}")
            if not any(r['polygon'].equals(cavity['polygon']) for r in background_holes):
                background_holes.append(cavity)
    # Local hole nesting must not mutate the original outline parent links.
    background_holes = [dict(r) for r in background_holes]
    _hierarchy(background_holes)
    if any(r['parent'] is not None for r in background_holes):
        raise ValueError('Nested background holes are ambiguous')
    base_shape = _region(envelope, background_holes)
    holes_shape = unary_union([r['polygon'] for r in background_holes])
    bounds = envelope['bounds']
    scale = width_mm / (bounds[2]-bounds[0])
    center = [(bounds[0]+bounds[2])/2, (bounds[1]+bounds[3])/2]
    templates = {}

    def profile(identifier, shell, holes):
        rings = [shell] + holes
        segments = [s for r in rings for s in r['segments']]
        if len(templates) >= MAX_PROFILES or sum(len(t['geometry']) for t in templates.values()) + len(segments) > MAX_GEOMETRY_SEGMENTS:
            raise ValueError('Export feature complexity cap exceeded; simplify approved SVG')
        templates[identifier] = dict(sketch=identifier, geometry=trace.geometry_for(segments, bounds, width_mm, image_side == 'bottom'))
        return dict(id=identifier, geometryPath=str(out / (identifier + '.json')),
                    loopCount=len(rings), areaMm2=(shell['area']-sum(r['area'] for r in holes))*scale**2,
                    boundsPx=shell['bounds'], sourceRings=[r['id'] for r in rings])

    base = profile('base', envelope, background_holes)
    base.update(colorId=by_hex[outline_color], zMinMm=0, zMaxMm=thickness_mm)
    fields = []
    foreground_sources = [p for p in paths if p['fill'] not in (background, outline_color)]
    assigned_areas = {fill: 0. for fill in by_hex}
    total_fields = Polygon()
    for cavity in [r for r in outline if r['hole']]:
        if cavity['id'] in matched_cavities:
            continue
        islands = [r for r in outline if r['parent'] is cavity]
        shape = _region(cavity, islands)
        if holes_shape.covers(shape):
            continue
        contained_holes = [r for r in background_holes if shape.contains(r['polygon'])]
        if not shape.intersection(holes_shape).equals(unary_union([r['polygon'] for r in contained_holes])):
            raise ValueError(f"Background hole crosses field {cavity['id']}; correct shared boundaries")
        shape = _region(cavity, islands + contained_holes)
        coverage = unary_union([visible[p['id']].intersection(shape) for p in foreground_sources])
        if coverage.is_empty:
            raise ValueError(f"Missing non-outline coverage in field {cavity['id']}; no color invented")
        areas = {fill: sum(visible[p['id']].intersection(shape).area for p in foreground_sources if p['fill'] == fill)
                 for fill in by_hex if fill != outline_color}
        dominant = max(areas, key=areas.get)
        coverage_report = _field_coverage(shape, coverage, areas[dominant], cavity['id'])
        coverage_report.update(missingAreaMm2=coverage_report['missingAreaPx2'] * scale**2,
                               normalizedColorId=by_hex[dominant])
        if coverage_report['missingAreaPx2'] > 0:
            warnings.append(f"common-cavity seam normalization in {cavity['id']}: "
                            f"{coverage_report['missingAreaPx2']:.9g} px2 missing paint "
                            f"({coverage_report['missingAreaFraction']:.6%} of field), "
                            f"maxDistancePx <= {coverage_report['maxDistancePx']:.9g}; "
                            f"boundary {coverage_report['boundary']['missingAreaPx2']:.9g} px2 under 4 px/5% policy, "
                            f"interior {coverage_report['interior']['missingAreaPx2']:.9g} px2 under 2 px/1% policy; "
                            f"assigned to dominant base {by_hex[dominant]}; native curves and background holes unchanged.")
        if sum(abs(area-areas[dominant]) <= 1e-12 for area in areas.values()) > 1:
            warnings.append(f"Tied dominant paint areas in {cavity['id']}; palette order selects base color, ordered patches preserve paint.")
        field = profile(f'field_{len(fields)+1:04d}', cavity, islands + contained_holes)
        field.update(colorId=by_hex[dominant], patches=[], coverage=coverage_report,
                     omittedRedundantBasePaint=[])
        if sum(a > 1e-12 for a in areas.values()) > 1:
            # Track even finally hidden contrasting source paint. Omitting only
            # empty intersections is conservative: no overlap-area epsilon, and
            # touching boundaries retain the repaint. A pure field needs none.
            earlier_nonbase = Polygon()
            for p in foreground_sources:
                for region in p['regions']:
                    intersection = region['polygon'].intersection(shape)
                    if p['fill'] != dominant:
                        earlier_nonbase = earlier_nonbase.union(intersection)
                    painted = visible[p['id']].intersection(intersection)
                    if painted.area <= 1e-12:
                        continue
                    ordinal = len(field['patches']) + len(field['omittedRedundantBasePaint']) + 1
                    patch_id = f"{field['id']}_patch_{ordinal:04d}"
                    if p['fill'] == dominant and intersection.intersection(earlier_nonbase).is_empty:
                        rings = [region['shell']] + region['holes']
                        field['omittedRedundantBasePaint'].append(dict(
                            id=patch_id, sourcePathId=p['id'], sourceRings=[r['id'] for r in rings],
                            colorId=by_hex[dominant], priority=p['priority'], clipToField=field['id'],
                            loopCount=len(rings), boundsPx=region['shell']['bounds'],
                            areaMm2=(rings[0]['area']-sum(r['area'] for r in rings[1:]))*scale**2,
                            clippedAreaMm2=intersection.area*scale**2, visibleAreaMm2=painted.area*scale**2,
                            earlierNonBaseIntersectionEmpty=True, earlierNonBaseOverlapAreaPx2=0.))
                        continue
                    patch = profile(patch_id, region['shell'], region['holes'])
                    patch.update(colorId=by_hex[p['fill']], priority=p['priority'], sourcePathId=p['id'],
                                 clipToField=field['id'], clippedAreaMm2=intersection.area*scale**2,
                                 visibleAreaMm2=painted.area*scale**2)
                    field['patches'].append(patch)
        field['patchReduction'] = len(field['omittedRedundantBasePaint'])
        if field['patchReduction']:
            warnings.append(f"redundant base paint omitted in {field['id']}: "
                            + ', '.join(p['sourcePathId'] + '/' + p['id'] for p in field['omittedRedundantBasePaint'])
                            + '; empty intersection with earlier non-base paint inside the field; ordered paint result unchanged.')
        for fill, area in areas.items():
            assigned_areas[fill] += area
        assigned_areas[dominant] += coverage_report['missingAreaPx2']
        total_fields = total_fields.union(shape)
        fields.append(field)
    # Bound internal paint clipping separately from physical-envelope containment.
    clipping_reports = []
    for p in foreground_sources:
        for region in p['regions']:
            paint = visible[p['id']].intersection(region['polygon']).intersection(env)
            report = _internal_overhang(paint, total_fields, region['shell']['id'])
            if report is not None:
                report.update(sourcePathId=p['id'], sourceRingId=region['shell']['id'],
                              colorId=by_hex[p['fill']], removedAreaMm2=report['removedAreaPx2'] * scale**2)
                clipping_reports.append(report)
                warnings.append(f"internal field overhang clipping {report['sourceRingId']}: "
                                f"{report['removedAreaPx2']:.9g} px2 removed "
                                f"({report['removedAreaFraction']:.6%} of visible source-region paint), "
                                f"maxDistancePx <= {report['maxDistancePx']:.9g}; "
                                'native field clips only, physical envelope unchanged.')
    assigned_areas[outline_color] = base_shape.difference(total_fields).area
    empty = [fill for fill, area in assigned_areas.items() if area <= 1e-12]
    if empty:
        raise ValueError('Empty approved foreground colors: ' + ', '.join(empty))
    plan = dict(schemaVersion=1, widthMm=width_mm, heightMm=(bounds[3]-bounds[1])*scale,
                thicknessMm=thickness_mm, frontMm=front_mm, imageSide=image_side,
                mmPerPixel=scale, centerPx=center, boundsPx=bounds, outlineColor=outline_color,
                colors=colors, base=base, fields=fields, backgroundHoleMatches=hole_matches,
                internalPaintClipping=clipping_reports,
                patchOptimization=dict(
                    policy='omit base paint only when clipped intersection with all earlier non-base source paint is empty',
                    overlapAreaTolerancePx2=0., boundaryContact='retain repaint',
                    patchReduction=sum(f['patchReduction'] for f in fields),
                    originalPatchCount=sum(len(f['patches']) + f['patchReduction'] for f in fields),
                    emittedPatchCount=sum(len(f['patches']) for f in fields)),
                sourceSha256=hashlib.sha256(source).hexdigest(), warnings=warnings,
                colorZMinMm=0 if image_side == 'bottom' else thickness_mm-front_mm,
                colorZMaxMm=front_mm if image_side == 'bottom' else thickness_mm,
                validation=dict(sampleErrorPx=SAMPLE_ERROR_PX, boundaryTolerancePx=BOUNDARY_TOLERANCE_PX,
                                backgroundHolePolicy=dict(minIoU=HOLE_MIN_IOU,
                                    maxHausdorffPx=HOLE_MAX_HAUSDORFF_PX,
                                    minBackgroundVisibleFractionExclusive=HOLE_MIN_BACKGROUND_FRACTION,
                                    distanceMethod='sampled boundary Hausdorff plus bidirectional whole-boundary distance masks',
                                    requireUniqueMatch=True, allowNestedForegroundIslands=False),
                                fieldCoveragePolicy=dict(name='common-cavity seam normalization',
                                    maxDistancePx=BOUNDARY_SEAM_DISTANCE_PX,
                                    maxMissingAreaFraction=BOUNDARY_SEAM_AREA_FRACTION,
                                    maxMissingAreaBoundaryFactorPx=BOUNDARY_SEAM_DISTANCE_PX,
                                    boundary=dict(maxDistancePx=BOUNDARY_SEAM_DISTANCE_PX,
                                        maxMissingAreaFraction=BOUNDARY_SEAM_AREA_FRACTION,
                                        classification='missing polygon component intersects authoritative field boundary'),
                                    interior=dict(maxDistancePx=FIELD_SEAM_DISTANCE_PX,
                                        maxMissingAreaFraction=FIELD_SEAM_AREA_FRACTION,
                                        classification='missing polygon component detached from authoritative field boundary'),
                                    areaScope='aggregate per category, total additionally capped at boundary allowance',
                                    minDominantCoverageFraction=FIELD_DOMINANT_MIN_FRACTION,
                                    distanceMethod='whole missing geometry contained in round coverage buffer; conservative upper bound on sampled geometry',
                                    distanceBisectionSteps=FIELD_DISTANCE_STEPS,
                                    distanceBisectionResolutionPx=BOUNDARY_SEAM_DISTANCE_PX / 2**FIELD_DISTANCE_STEPS),
                                internalOverhangPolicy=dict(maxDistancePx=INTERNAL_OVERHANG_DISTANCE_PX,
                                    maxRemovedAreaFraction=INTERNAL_OVERHANG_AREA_FRACTION,
                                    areaScope='each visible source polygon region inside physical envelope',
                                    distanceReference='common field boundary', allowWholeRegionRemoval=False),
                                areaMethod='exact polynomial rings; sampled intersections',
                                maxProfiles=MAX_PROFILES, maxGeometrySegments=MAX_GEOMETRY_SEGMENTS,
                                maxSourceSegments=MAX_SOURCE_SEGMENTS, maxRings=MAX_RINGS,
                                maxSamplePoints=MAX_SAMPLE_POINTS, samplePointCount=budget[0],
                                maxReconciliationComponents=MAX_RECONCILIATION_COMPONENTS,
                                sourceSegmentCount=segment_count, sourceRingCount=len(all_rings),
                                profileCount=len(templates), geometrySegmentCount=sum(len(t['geometry']) for t in templates.values())))
    # Serialize before mkdir so NaN/JSON validation cannot leave partial output.
    payloads = {identifier + '.json': json.dumps(value, indent=2, allow_nan=False) + '\n'
                for identifier, value in templates.items()}
    payloads['plan.json'] = json.dumps(plan, indent=2, allow_nan=False) + '\n'
    out.mkdir(exist_ok=False)
    for name, payload in payloads.items():
        with (out / name).open('x', encoding='utf-8') as stream:
            stream.write(payload)
    return plan
