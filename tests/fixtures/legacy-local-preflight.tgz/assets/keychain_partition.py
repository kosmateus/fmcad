"""Offline shared partition planner. Source pixels/curves are never overwritten.

Topology chains use original SVG pixels, x right/y down. ring_refs are ordered
{chain, reversed} references; regions identify one shell and its holes. Geometry
JSON uses the identical controls transformed to native millimetres.
"""
import copy
from fractions import Fraction
import hashlib
import importlib.util
import io
import json
import math
from pathlib import Path
import re
import xml.etree.ElementTree as ET

import cairosvg
import cv2
import numpy as np
from PIL import Image
from scipy import ndimage
from shapely.geometry import Point, Polygon, box
from shapely.ops import unary_union
from scipy.optimize import minimize_scalar


def _module(name):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).with_name(name+'.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


legacy = _module('keychain_plan')
shared = _module('image_shared_boundaries')
mesh = _module('keychain_mesh')


def _render(root, width, height):
    png = cairosvg.svg2png(bytestring=ET.tostring(root), output_width=width,
                          output_height=height, background_color='#000000')
    return np.asarray(Image.open(io.BytesIO(png)).convert('RGB'))[:, :, 0]


def _occupancy(root, fills, width, height):
    labels = np.zeros((height, width), np.int32)
    best = np.zeros((height, width), np.uint8)
    for index, fill in enumerate(fills):
        mask = copy.deepcopy(root)
        for path in mask:
            path.set('fill', '#ffffff' if legacy.trace.color(path.get('fill')) == fill else '#000000')
        values = _render(mask, width, height)
        take = values > best
        labels[take] = index
        best[take] = values[take]
    return labels


def _mask(shape, root, width, height):
    svg = ET.Element(root.tag, root.attrib)
    parts = list(shape.geoms) if hasattr(shape, 'geoms') else [shape]
    for part in parts:
        rings = [part.exterior, *part.interiors]
        data = ' '.join('M '+' L '.join(f'{x},{y}' for x,y in ring.coords)+' Z' for ring in rings)
        ET.SubElement(svg, 'path', {'d':data, 'fill':'#ffffff', 'fill-rule':'evenodd'})
    return _render(svg, width, height) >= 128


def _resolve_gaps(labels, domain, source_domain, outline, reference=None):
    """Assign unpainted cell-edge discrepancies from frozen source neighbours.

    A candidate must share a working-cell face with ORIGINAL occupied paint.
    All such seeds are one cell away; the reference breaks that local distance
    tie, never seeds a new colour. No propagation through newly assigned cells,
    radius/area filter, or reassignment of source paint is performed. Uncovered
    interiors and explicit hull support retain the implicit outline material.
    """
    result = labels.copy()
    result[~domain] = 0
    missing = domain & (result == 0)
    added = missing & ~source_domain
    ys, xs = np.nonzero(missing & source_domain)
    padded = np.pad(result, 1)
    neighbours = np.stack([padded[ys+1+dy, xs+1+dx]
                           for dy, dx in ((-1,0), (1,0), (0,-1), (0,1))])
    owners = np.full(len(ys), outline, np.int32)
    votes = np.zeros(len(ys), np.int32)
    for color in sorted(set(np.unique(neighbours)) - {0}, reverse=True):
        count = (neighbours == color).sum(axis=0)
        take = (count > 0) & (count >= votes)
        owners[take] = color
        votes[take] = count[take]
    guided = np.zeros(len(ys), bool)
    if reference is not None:
        proposed = reference[ys, xs]
        guided = (proposed != 0) & np.any(neighbours == proposed, axis=0)
        owners[guided] = proposed[guided]
    result[missing] = outline
    result[ys, xs] = owners
    prevented_merges = 0
    for color in [c for c in np.unique(labels) if c not in (0, outline)] + [outline]:
        seeds, count = ndimage.label((labels == color) & (source_domain if color == outline else domain))
        if count < 2:
            continue
        # Explicit hull support is allowed to connect separate outline islands.
        # Test source-area connectivity separately so that authorization does
        # not also permit an accidental merge inside the original artwork.
        assigned, _ = ndimage.label((result == color) & (source_domain if color == outline else domain))
        destinations = ndimage.minimum(assigned, seeds, np.arange(1, count+1)).astype(int)
        merged = np.flatnonzero(np.bincount(destinations) > 1)
        if len(merged):
            bridge = missing & (result == color) & np.isin(assigned, merged)
            if color == outline:
                raise ValueError('Gap ownership would merge distinct source outline regions')
            result[bridge] = outline
            prevented_merges += int(bridge.sum())
    if reference is not None:
        guided &= result[ys,xs] == reference[ys,xs]
    return result, dict(policy='original four-face-adjacent paint only; frozen reference resolves local ownership; '
                        'no new reference seeds or recursive growth; unsupported interiors and added support are outline',
                        missingCells=int(missing.sum()), locallyOwnedCells=int((votes > 0).sum()),
                        referenceResolvedCells=int(guided.sum()),
                        unsupportedReferenceCells=int(((reference[ys,xs] != 0) & ~guided).sum())
                            if reference is not None else 0,
                        implicitOutlineCells=int((votes == 0).sum()),
                        preventedSourceMergeCells=prevented_merges,
                        addedSupportOutlineCells=int(added.sum()),
                        outlineOwnedCells=int(np.count_nonzero(missing & (result == outline))))


def _outer_refs(topology):
    labels = {p['region']:p['label'] for p in topology['paths']}
    directed = []
    for chain in topology['chains']:
        left, right = (labels.get(r, 0) for r in chain['regions'])
        if bool(left) == bool(right):
            continue
        reverse = not bool(left)
        segments = shared._reverse(chain['segments']) if reverse else chain['segments']
        directed.append((tuple(segments[0][1][0]), tuple(segments[-1][1][-1]),
                         dict(chain=chain['id'], reversed=reverse)))
    outgoing = {}
    for start, end, ref in directed:
        if start in outgoing:
            raise ValueError('Physical envelope has point contacts')
        outgoing[start] = (end,ref)
    rings = []
    while outgoing:
        start = next(iter(outgoing)); node = start; refs = []
        while True:
            node, ref = outgoing.pop(node); refs.append(ref)
            if node == start:
                break
        rings.append(refs)
    return rings


def _source_paint_regions(source_rings):
    """Sampled visible source provenance, including later-paint occlusion.

    These polygons only authorize joining raster fragments. Invalid source
    paths authorize no joins; their bounding boxes conservatively occlude
    earlier provenance. No repaired/filtered polygons become output geometry.
    """
    paths = {}
    for source in source_rings:
        source['samples'] = shared._sample(source['segments'], .005)
        paths.setdefault(source['path'], []).append(source)
    covered = Polygon()
    regions = []
    for path in reversed(list(paths.values())):
        shells = [Polygon(r['samples']) for r in path if shared._area(r['samples']) > 0]
        holes = [Polygon(r['samples']) for r in path if shared._area(r['samples']) < 0]
        try:
            shapes = [Polygon(s.exterior, [h.exterior for h in holes if s.contains(h) and
                       not any(t.area < s.area and t.contains(h) for t in shells)]) for s in shells]
            if not shapes or not all(s.is_valid for s in shapes):
                raise ValueError('Invalid source polygon for provenance')
            shape = unary_union(shapes)
            visible = shape.difference(covered)
            if path[0]['label']:
                parts = list(visible.geoms) if hasattr(visible, 'geoms') else [visible]
                for part in parts:
                    if part.geom_type == 'Polygon' and not part.is_empty:
                        regions.append((len(regions)+1, path[0]['label'], part))
            covered = unary_union([covered, shape])
        except (ValueError, shared.GEOSException):
            points = np.concatenate([r['samples'] for r in path])
            covered = unary_union([covered, box(*points.min(axis=0), *points.max(axis=0))])
    return regions


def _reuse_source_rings(topology, source_rings, scale, fit_error_px):
    """Reuse whole source L/C rings only at isolated two-region interfaces.

    No spline splitting, snapping, or independent fitting of opposite sides.
    A nearby source ring is a candidate, not an automatic replacement: preserve
    nesting, simple regions and the complete partition before accepting it.
    Distance is a correspondence bound from cell quantization, one-cell gap
    ownership and the raster fit, NOT a relaxed fitting tolerance.
    """
    chains = topology['chains']
    palette = {p['region']: p['label'] for p in topology['paths']}
    flatness = min(.005, fit_error_px/16, 1/(scale*16))
    samples = [shared._sample(c['segments'], flatness) for c in chains]
    def polygons():
        rings = []
        for path in topology['paths']:
            points = []
            for ref in path['chain_refs']:
                part = samples[ref['chain']][::-1] if ref['reversed'] else samples[ref['chain']]
                points.extend(part if not points else part[1:])
            rings.append((path['region'], points, path['is_hole']))
        return shared._polygons(rings)
    domain = unary_union(polygons())
    epsilon = max(1e-10, domain.area*1e-12)
    records, rejected = [], []
    candidates = []
    for source in source_rings:
        points = source['samples'] if flatness == .005 and 'samples' in source else shared._sample(source['segments'], flatness)
        candidates.append((source, points, Polygon(points)))
    for i, chain in enumerate(chains):
        if -1 in chain['regions'] or samples[i][0] != samples[i][-1]:
            continue
        # A closed walk returning to a junction is not an isolated interface.
        if any(len(p['chain_refs']) != 1 for p in topology['paths']
               if any(ref['chain'] == i for ref in p['chain_refs'])):
            continue
        labels = {palette[r] for r in chain['regions']}
        old = samples[i]
        shape = Polygon(old)
        physical = 0 in labels
        bound = math.sqrt(2)/scale + fit_error_px + (0 if physical else 1/scale)
        choices = []
        for source, points, polygon in candidates:
            if source['label'] not in labels or (physical and source['label'] != 0):
                continue
            if not polygon.is_valid or polygon.area <= 0:
                continue
            if max(abs(a-b) for a,b in zip(shape.bounds, polygon.bounds)) > bound:
                continue
            if not polygon.covers(shape.representative_point()) or not shape.covers(polygon.representative_point()):
                continue
            deviation = shared._sampled_deviation(old, points)
            if deviation <= bound:
                choices.append((source['path'], -deviation, source, points))
        # Source painter order resolves overlapping independently traced rings.
        for _, negative_deviation, source, points in sorted(choices, key=lambda c:c[:2], reverse=True):
            reverse = (shared._area(old) < 0) != (shared._area(points) < 0)
            samples[i] = points[::-1] if reverse else points
            try:
                fitted = polygons()
                union = unary_union(fitted)
                overlap = max(0., sum(p.area for p in fitted)-union.area)
                gap = domain.symmetric_difference(union).area
                if overlap > epsilon or gap > epsilon:
                    raise ValueError('Source ring changes partition coverage')
            except (ValueError, shared.GEOSException) as exc:
                samples[i] = old
                rejected.append(dict(chain=i, path=source['path'], ring=source['ring'], reason=str(exc)))
                continue
            chain['segments'] = shared._reverse(source['segments']) if reverse else source['segments']
            records.append(dict(chain=i, path=source['path'], ring=source['ring'], reversed=reverse,
                                sourceLabel=source['label'], correspondenceBoundPx=bound,
                                sampledChangeFromRasterFitPx=-negative_deviation))
            break
    for path in topology['paths']:
        path['segments'] = [s for ref in path['chain_refs'] for s in
            (shared._reverse(chains[ref['chain']]['segments']) if ref['reversed'] else chains[ref['chain']]['segments'])]
    fitted = polygons(); union = unary_union(fitted)
    topology['diagnostics'].update(
        fitDiagnosticsScope='raster fit before exact source-ring reuse; source curves retain original controls',
        sourceCurveReuse=dict(accepted=records, rejected=rejected, samplingFlatnessPx=flatness,
                             policy='isolated complete rings; original controls; source paint order; full partition revalidation'),
        sampled_overlap_area_px2=max(0., sum(p.area for p in fitted)-union.area),
        sampled_gap_area_px2=domain.symmetric_difference(union).area)


def _trim_segment(segment, low, high):
    """Exact de Casteljau subcurve; full spans retain their original controls."""
    kind, controls = segment
    def split(p, t):
        rows = [np.asarray(p, float)]
        while len(rows[-1]) > 1:
            rows.append((1-t)*rows[-1][:-1] + t*rows[-1][1:])
        return [r[0].tolist() for r in rows], [r[-1].tolist() for r in rows[::-1]]
    if high < 1:
        controls = split(controls, high)[0]
    if low > 0:
        controls = split(controls, low/high)[1]
    return kind, controls


def _source_interval(source, a, b, reverse=False):
    """Reconstruct one oriented interval from original controls, never joined trims."""
    if reverse:
        return shared._reverse(_source_interval(source, b, a))
    i, low = a; j, high = b
    result = []
    if i == j and high > low:
        return [_trim_segment(source[i], low, high)]
    if low < 1:
        result.append(_trim_segment(source[i], low, 1))
    i = (i+1) % len(source)
    while i != j:
        result.append(source[i]); i = (i+1) % len(source)
    if high > 0:
        result.append(_trim_segment(source[j], 0, high))
    return result


def _source_arc(source, start, end, provenance=False):
    """Return both arcs, optionally with exact projected segment/parameter pairs."""
    def project(point):
        point = np.asarray(point)
        candidates = []
        for i, (kind, controls) in enumerate(source):
            p = np.asarray(controls)
            delta = np.maximum(np.maximum(p.min(axis=0)-point, point-p.max(axis=0)), 0)
            candidates.append((float(delta@delta), i))
        best = (float('inf'), 0, 0.)
        for lower, i in sorted(candidates):
            if lower > best[0]:
                break
            def distance(t):
                p = np.asarray(source[i][1])
                while len(p) > 1:
                    p = (1-t)*p[:-1] + t*p[1:]
                return float(np.sum((p[0]-point)**2))
            fit = minimize_scalar(distance, bounds=(0,1), method='bounded', options={'xatol':1e-12})
            value, t = min((distance(0),0.), (distance(1),1.), (fit.fun,float(fit.x)))
            best = min(best, (value,i,t))
        return best[1:]
    a, b = project(start), project(end)
    arcs = (_source_interval(source, a, b), _source_interval(source, a, b, True))
    return (arcs, a, b) if provenance else arcs


def _span_connectors(arc, start, end, with_provenance=False):
    """Existing outer-junction endpoint policy, never applied at coalesced nodes."""
    arc = copy.deepcopy(arc)
    distances = [float(np.linalg.norm(np.asarray(a)-b)) for a,b in
                 ((start,arc[0][1][0]),(end,arc[-1][1][-1]))]
    if any(1e-7 < d < .001 for d in distances):
        raise ValueError('Source span connector below minimum length')
    if distances[0] <= 1e-7:
        arc[0][1][0] = start
    if distances[1] <= 1e-7:
        arc[-1][1][-1] = end
    generated = (tuple(start) != tuple(arc[0][1][0]), tuple(end) != tuple(arc[-1][1][-1]))
    result = []
    if start != arc[0][1][0]:
        result.append(('L', [start, arc[0][1][0]]))
    result.extend(arc)
    if end != arc[-1][1][-1]:
        result.append(('L', [arc[-1][1][-1], end]))
    return (result, generated) if with_provenance else result


def _assemble_source_spans(original, replacements, closure_junction=False):
    """Coalesce only contiguous ranges with identical source parameter provenance.

    Distinct parameters (even at coincident coordinates) are not equivalent.
    A union must traverse at most one ring; otherwise refuse the local proposal.
    Closed isolated chains may rotate their seam, but actual junctions stay fixed.
    """
    def merge(left, right, closure=False):
        if (left['source'] is not right['source'] or left['b'] != right['a']):
            return None
        if left['reverse'] != right['reverse']:
            raise ValueError('Ambiguous source span joint: opposite orientations')
        if closure and closure_junction:
            raise ValueError('Source span closure is an actual chain junction')
        n = len(left['source']['segments'])
        def travel(span):
            # Exact arithmetic: adding a tiny parameter to its segment index must
            # not hide a distinct near-return or an extra traversal of the ring.
            a, b = (span[k][0] + Fraction(span[k][1]) for k in ('a', 'b'))
            value = ((a-b) if span['reverse'] else (b-a)) % n
            return value or n
        length = left.get('travel', travel(left)) + right.get('travel', travel(right))
        if length > n:
            raise ValueError('Ambiguous source span union: more than one source ring')
        return dict(left, high=right['high'], b=right['b'], end=right['end'], travel=length)
    blocks = []; i = 0
    while i < len(original):
        if i not in replacements:
            blocks.append((None, [original[i]])); i += 1
            continue
        span = replacements[i]
        if blocks and blocks[-1][0] is not None:
            joined = merge(blocks[-1][0], span)
            if joined:
                blocks.pop(); span = joined
        blocks.append((span, None)); i = span['high']
    closed = original[0][1][0] == original[-1][1][-1]
    if closed and len(blocks) > 1 and blocks[0][0] is not None and blocks[-1][0] is not None:
        joined = merge(blocks[-1][0], blocks[0][0], closure=True)
        if joined:
            blocks = [(joined, None)] + blocks[1:-1]
    result = []
    for span, segments in blocks:
        if span is not None:
            arc = _source_interval(span['source']['segments'], span['a'], span['b'], span['reverse'])
            if closed and len(blocks) == 1 and span['a'] == span['b']:
                if closure_junction:
                    raise ValueError('Source span closure is an actual chain junction')
                segments = (shared._reverse(span['source']['segments']) if span['reverse']
                            else span['source']['segments'])
            else:
                segments = _span_connectors(arc, span['start'], span['end'])
        result.extend(segments)
    return result


def _terminal_source_connectors(original, span, generated):
    """Exact provenance of nonzero generated connectors at original chain ends.

    Inspect emitted connectors, not coordinate proximity: snapped endpoints and
    original source lines/curves are not registered. Orientation is immaterial
    because opposite incident chains can traverse the same connector in reverse.
    """
    source = span['source']
    keys = []
    for terminal, node, parameter, emitted in (
            (span['low'] == 0, span['start'], span['a'], generated[0]),
            (span['high'] == len(original), span['end'], span['b'], generated[1])):
        if terminal and emitted:
            keys.append((id(source), source['path'], source['ring'], *parameter, tuple(node)))
    return keys


def _reuse_source_spans(topology, source_rings, scale, fit_error_px):
    """Trim original source curves, retaining shared raster junction endpoints.

    Short endpoint connectors are explicit. A replacement must stay inside the
    same quantization correspondence bound as ring reuse and preserve every
    simple region, nesting, disjointness and domain coverage. No region removal
    or independent opposite-side fit is allowed.
    """
    chains = topology['chains']
    palette = {p['region']: p['label'] for p in topology['paths']}
    sample_cache = {}
    def sample_segments(segments):
        result = []
        for segment in segments:
            key = id(segment)
            if key not in sample_cache:
                sample_cache[key] = (segment, shared._sample([segment], .005))
            points = sample_cache[key][1]
            result.extend(points if not result else points[1:])
        return result
    samples = [sample_segments(c['segments']) for c in chains]
    def polygons():
        rings = []
        for path in topology['paths']:
            points = []
            for ref in path['chain_refs']:
                part = samples[ref['chain']][::-1] if ref['reversed'] else samples[ref['chain']]
                points.extend(part if not points else part[1:])
            rings.append((path['region'], points, path['is_hole']))
        return shared._polygons(rings)
    domain = unary_union(polygons())
    epsilon = max(1e-10, domain.area*1e-12)
    from shapely.geometry import LineString
    sources = [(s, LineString(sample_segments(s['segments']))) for s in source_rings]
    reused = {r['chain'] for r in topology['diagnostics']['sourceCurveReuse']['accepted']}
    accepted, rejected = [], []
    incident = {}
    for index, chain in enumerate(chains):
        for node in (chain['segments'][0][1][0], chain['segments'][-1][1][-1]):
            incident.setdefault(tuple(node), set()).add(index)
    registered = {}
    for index, chain in enumerate(chains):
        if index in reused or -1 in chain['regions']:
            continue
        labels = {palette[r] for r in chain['regions']}
        physical = 0 in labels
        bound = math.sqrt(2)/scale + fit_error_px + (0 if physical else 1/scale)
        available = [(s,line) for s,line in sources if s['label'] in labels and
                     (not physical or s['label'] == 0)]
        original = chain['segments']
        node = original[0][1][0]
        closure_junction = any(c is not chain and
            (c['segments'][0][1][0] == node or c['segments'][-1][1][-1] == node)
            for c in chains)
        # Work from large spans down; failed topology tests leave originals.
        pending = [(0,len(original))]
        replacements = {}
        chain_connectors = {}
        def assembled(extra=None):
            changes = dict(replacements)
            if extra:
                changes[extra['low']] = extra
            return _assemble_source_spans(original, changes, closure_junction)
        while pending:
            low, high = pending.pop()
            if high-low < 8:
                continue
            old_segments = original[low:high]
            old = sample_segments(old_segments)
            start, end = old[0], old[-1]
            witness = [Point(old[k]) for k in (0,len(old)//4,len(old)//2,3*len(old)//4,len(old)-1)]
            choices = [(s,line) for s,line in available if all(line.distance(p) <= bound for p in witness)]
            success = False
            for source, line in sorted(choices, key=lambda c:c[0]['path'], reverse=True):
                if start == end:
                    continue
                arcs, a, b = _source_arc(source['segments'], start, end, provenance=True)
                for reverse, arc in enumerate(arcs):
                    if not arc or len(arc)+2 >= high-low:
                        continue
                    proposal = dict(low=low, high=high, source=source, a=a, b=b,
                                    reverse=bool(reverse), start=start, end=end)
                    try:
                        replacement, generated = _span_connectors(arc, start, end, with_provenance=True)
                        connectors = [key for key in _terminal_source_connectors(original, proposal, generated)
                                      if len(incident[key[-1]]) > 1]
                        for key in connectors:
                            if key in registered:
                                raise ValueError('Duplicate generated source connector at shared chain junction; '
                                                 f'conflicts with chain {registered[key]} at {key[-1]}')
                        trial = assembled(proposal)
                    except ValueError as exc:
                        rejected.append(dict(chain=index, path=source['path'], ring=source['ring'],
                                             originalRange=[low,high], reason=str(exc)))
                        continue
                    sampled = sample_segments(replacement)
                    deviation = shared._sampled_deviation(old, sampled)
                    if deviation > bound:
                        continue
                    samples[index] = sample_segments(trial)
                    try:
                        shapes = polygons(); union = unary_union(shapes)
                        if max(0.,sum(p.area for p in shapes)-union.area) > epsilon or domain.symmetric_difference(union).area > epsilon:
                            raise ValueError('Source span changes partition coverage')
                    except (ValueError, shared.GEOSException) as exc:
                        samples[index] = sample_segments(assembled())
                        rejected.append(dict(chain=index, path=source['path'], ring=source['ring'],
                                             originalRange=[low,high], reason=str(exc)))
                        continue
                    replacements[low] = proposal
                    chain_connectors.update((key, index) for key in connectors)
                    accepted.append(dict(chain=index, path=source['path'], ring=source['ring'],
                        originalRange=[low,high], originalCount=high-low, replacementCount=len(replacement),
                        sourceStart=list(a), sourceEnd=list(b), reversed=bool(reverse),
                        correspondenceBoundPx=bound, sampledChangeFromRasterFitPx=deviation))
                    success = True
                    break
                if success:
                    break
            if not success:
                middle = (low+high)//2
                pending.extend([(middle,high),(low,middle)])
        chain['segments'] = assembled()
        registered.update(chain_connectors)
    for path in topology['paths']:
        path['segments'] = [s for ref in path['chain_refs'] for s in
            (shared._reverse(chains[ref['chain']]['segments']) if ref['reversed'] else chains[ref['chain']]['segments'])]
    shapes = polygons(); union = unary_union(shapes)
    topology['diagnostics'].update(sourceSpanReuse=dict(accepted=accepted, rejected=rejected,
        policy='exact source subcurve unions at contiguous identical source parameters; explicit outer endpoint connectors; refuse duplicate generated connectors at shared junctions; unchanged shared junctions; full partition revalidation'),
        sampled_overlap_area_px2=max(0.,sum(p.area for p in shapes)-union.area),
        sampled_gap_area_px2=domain.symmetric_difference(union).area)


def make_partition_plan(svg_path, palette_path, outline_color, width_mm,
                        thickness_mm, front_mm, image_side, output_dir,
                        reference_path=None, backing='silhouette', fit_error_px=0.35,
                        corner_angle=55, scale=2):
    out = Path(output_dir).absolute()
    if out.exists() or out.is_symlink() or not out.parent.is_dir():
        raise ValueError('output_dir must be new with an existing parent')
    for value in (width_mm, thickness_mm, front_mm, scale, fit_error_px):
        if not legacy.trace.numeric(value) or value <= 0:
            raise ValueError('Dimensions, scale and tolerance must be finite positive numbers')
    if front_mm >= thickness_mm or image_side not in ('top','bottom'):
        raise ValueError('Require front < thickness and image_side top or bottom')
    if backing not in ('silhouette','convex-hull'):
        raise ValueError('Unknown backing')
    palette = json.loads(Path(palette_path).read_text())
    background = legacy.trace.color(palette['background'])
    colors = [dict(id=f'color_{i+1:03d}', name=c['name'], hex=legacy.trace.color(c['color']))
              for i,c in enumerate(palette['colors'])]
    fills = [background]+[c['hex'] for c in colors]
    outline_color = legacy.trace.color(outline_color)
    if len(set(fills)) != len(fills) or outline_color not in fills[1:]:
        raise ValueError('Unique palette including outline required')
    outline = fills.index(outline_color)
    source = Path(svg_path).read_bytes(); root = ET.fromstring(source)
    view = [float(v) for v in root.get('viewBox', f"0 0 {root.get('width')} {root.get('height')}").split()]
    if len(view) != 4 or view[:2] != [0,0]:
        raise ValueError('Require zero-origin SVG viewBox')
    w, h = math.ceil(view[2]*scale), math.ceil(view[3]*scale)
    if w*h > 64_000_000 or w != view[2]*scale or h != view[3]*scale:
        raise ValueError('Working grid must be integral and at most 64 million cells')
    negative, positive, source_rings = [], [], []
    paint_mapping = {}
    palette_rgb = np.array([[int(f[k:k+2],16) for k in (1,3,5)] for f in fills])
    for path_index, element in enumerate(root):
        if element.tag.split('}')[-1] != 'path' or set(element.attrib)-{'d','fill','id','transform','fill-rule'}:
            raise ValueError('Only generated flat opaque paths supported')
        fill = legacy.trace.color(element.get('fill'))
        if fill not in fills:
            rgb = np.array([int(fill[k:k+2],16) for k in (1,3,5)])
            mapped = fills[int(np.argmin(np.sum((palette_rgb-rgb)**2,axis=1)))]
            paint_mapping[fill] = mapped
            fill = mapped
            element.set('fill', mapped)
        current = (0,0)
        for ring_index, part in enumerate(re.split(r'(?=[Mm])', element.get('d',''))):
            if not part.strip():
                continue
            prefix = f'M {current[0]} {current[1]} ' if part[0]=='m' else ''
            raw = legacy.trace.parse_path(prefix+part)
            segments = legacy.trace.parse_path(prefix+part, element.get('transform',''))
            current = raw[-1][1][-1]
            source_rings.append(dict(path=path_index, ring=ring_index, label=fills.index(fill), segments=segments))
            if fill != background:
                continue
            points = shared._sample(segments, 0.01)
            polygon = Polygon(points)
            if not polygon.is_valid:
                raise ValueError('Invalid background physical ring')
            (negative if legacy._area(segments)<0 else positive).append(polygon)
    if not negative:
        raise ValueError('No background negative silhouette rings')
    silhouette = unary_union(negative)
    holes = unary_union([p for p in positive if silhouette.contains(p)])
    original = silhouette.difference(holes)
    if backing == 'silhouette' and original.geom_type != 'Polygon':
        raise ValueError('Disconnected silhouette; explicit convex-hull backing required')
    labels = _occupancy(root, fills, w, h)
    hull_source = silhouette
    if backing == 'convex-hull':
        contours, _ = cv2.findContours((labels != 0).astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        vertices = np.concatenate(contours).reshape(-1,2).astype(float)/scale
        # Include complete occupied cells, not just their centers.
        from shapely.geometry import MultiPoint
        hull_source = unary_union([silhouette, MultiPoint(np.concatenate(
            [vertices+[dx/scale,dy/scale] for dx,dy in ((0,0),(1,0),(0,1),(1,1))])).convex_hull])
    envelope = (hull_source.convex_hull if backing=='convex-hull' else silhouette).difference(holes)
    if envelope.geom_type != 'Polygon' or not envelope.is_valid:
        raise ValueError('Physical envelope must be one connected outer with holes')
    domain = _mask(envelope, root, w, h)
    outside_count = int(np.count_nonzero((labels != 0) & ~domain))
    reference = None
    if reference_path:
        image = Image.open(reference_path).convert('RGB').resize((w,h), Image.Resampling.NEAREST)
        rgb = np.asarray(image).astype(np.int32)
        reference = np.zeros((h,w),np.int32)
        for i,fill in enumerate(fills):
            color = np.array([int(fill[k:k+2],16) for k in (1,3,5)])
            reference[np.all(rgb==color,axis=2)] = i
    source_domain = domain if backing == 'silhouette' else _mask(original, root, w, h)
    # One immutable witness per source component, regardless of its area. The
    # junction repair may adjust a fringe, but cannot erase a genuine island.
    protected = ~domain
    anchors = {}
    source_groups = np.zeros(labels.shape, np.int32)
    shells = _source_paint_regions(source_rings)
    next_group = len(shells)+1
    for color in np.unique(labels):
        if not color:
            continue
        components, _ = ndimage.label((labels == color) & domain)
        anchors[int(color)] = []
        lookup = np.zeros(int(components.max())+1, np.int32)
        for component, bounds in enumerate(ndimage.find_objects(components), 1):
            yy, xx = np.argwhere(components[bounds] == component)[0]
            y, x = yy+bounds[0].start, xx+bounds[1].start
            point = Point((x+.5)/scale, (y+.5)/scale)
            candidates = [(polygon.distance(point), polygon.area, group)
                          for group, label, polygon in shells if label == color and polygon.is_valid]
            nearest = min(candidates, default=(float('inf'), 0, 0))
            group = nearest[2] if nearest[0] <= math.sqrt(2)/scale else next_group
            next_group += 1
            lookup[component] = group
            protected[y,x] = True
            anchors[int(color)].append((y,x,group))
        occupied = components > 0
        source_groups[occupied] = lookup[components[occupied]]
    labels, ownership = _resolve_gaps(labels, domain, source_domain, outline, reference)
    labels, repairs = shared.repair_junctions(labels, scale, reference, protected=protected,
                                             allow_component_joins=False, join_groups=source_groups)
    for color, witnesses in anchors.items():
        components, _ = ndimage.label((labels == color) & (source_domain if color == outline else domain))
        destinations = {}
        for y,x,group in witnesses:
            if color == outline and not source_domain[y,x]:
                continue  # Explicit support has no original-artwork connectivity.
            region = int(components[y,x])
            if not region or (region in destinations and destinations[region] != group):
                raise ValueError('Junction repair merged or removed distinct source paint regions')
            destinations[region] = group
    topology = shared.vectorize_shared(labels, scale, fit_error_px, corner_angle)
    reusable = [r for r in source_rings if not (backing == 'convex-hull' and
                r['label'] == 0 and legacy._area(r['segments']) < 0)]
    _reuse_source_rings(topology, reusable, scale, fit_error_px)
    span_sources = list(source_rings)
    if backing == 'convex-hull':
        points = list(envelope.exterior.coords)
        span_sources.append(dict(path=len(root), ring=0, label=0,
            segments=[('L',[list(a),list(b)]) for a,b in zip(points,points[1:])]))
    _reuse_source_spans(topology, span_sources, scale, fit_error_px)
    chains = topology['chains']
    def segments_for(refs):
        return [s for ref in refs for s in (shared._reverse(chains[ref['chain']]['segments'])
                if ref['reversed'] else chains[ref['chain']]['segments'])]
    base_refs = _outer_refs(topology)
    base_refs.sort(key=lambda r: -legacy._area(segments_for(r)))
    if sum(legacy._area(segments_for(r)) > 0 for r in base_refs) != 1:
        raise ValueError('Raster physical footprint disconnected')
    if len(base_refs)-1 != len(envelope.interiors):
        raise ValueError('Working grid changed source physical holes; exact source topology requires a finer representation')
    bounds = legacy._bounds(segments_for(base_refs[0])); mm = width_mm/(bounds[2]-bounds[0])
    templates = {}; regions = []
    def profile(identifier, refs, color):
        segments = [s for ring in refs for s in segments_for(ring)]
        templates[identifier+'.json'] = dict(sketch=identifier, geometry=legacy.trace.geometry_for(
            segments, bounds, width_mm, image_side=='bottom'))
        regions.append(dict(id=identifier,colorId=color,ring_refs=refs,
                            role='base' if identifier=='base' else 'front'))
        return dict(id=identifier,colorId=color,geometryPath=str(out/(identifier+'.json')),
                    loopCount=len(refs), areaMm2=sum(legacy._area(segments_for(r)) for r in refs)*mm**2,
                    boundsPx=legacy._bounds(segments))
    back_min,back_max = (front_mm,thickness_mm) if image_side=='bottom' else (0,thickness_mm-front_mm)
    base = profile('base',base_refs,colors[outline-1]['id'])
    base.update(zMinMm=back_min,zMaxMm=back_max)
    grouped = {}
    for path in topology['paths']:
        if path['label']:
            grouped.setdefault(path['region'],[]).append(path)
    fields = []
    for region, paths in grouped.items():
        paths.sort(key=lambda p:p['is_hole'])
        field = profile(f'field_{region:04d}',[p['chain_refs'] for p in paths],colors[paths[0]['label']-1]['id'])
        field['patches'] = []; fields.append(field)
    area_gap = abs(base['areaMm2']-sum(f['areaMm2'] for f in fields))
    if area_gap > max(1e-8,base['areaMm2']*1e-10):
        raise ValueError('Exact polynomial partition area mismatch')
    plan = dict(schemaVersion=1,construction='partition_prisms',backing=backing,
                widthMm=width_mm,heightMm=(bounds[3]-bounds[1])*mm,thicknessMm=thickness_mm,
                frontMm=front_mm,imageSide=image_side,mmPerPixel=mm,boundsPx=bounds,
                centerPx=[(bounds[0]+bounds[2])/2,(bounds[1]+bounds[3])/2],
                outlineColor=outline_color,colors=colors,base=base,fields=fields,
                colorZMinMm=0 if image_side=='bottom' else thickness_mm-front_mm,
                colorZMaxMm=front_mm if image_side=='bottom' else thickness_mm,
                backZMinMm=back_min,backZMaxMm=back_max,sourceSha256=hashlib.sha256(source).hexdigest(),
                partitionTopology=dict(coordinateSpace='source_px',axes='x right, y down',
                    ringOrientation='positive outer, negative holes',
                    regionRoles='front regions partition the footprint; base duplicates the full footprint for the back layer',
                    chains=chains,regions=regions,baseRingRefs=base_refs),
                warnings=['Explicit convex-hull outline-color backing added'] if backing=='convex-hull' else [],
                validation=dict(**topology['diagnostics'],junctionRepair=repairs,workingScale=scale,
                    physicalComponents=1,physicalHoles=len(base_refs)-1,exactAreaGapMm2=area_gap,
                    sampledPartitionComplete=True,sampledPartitionDisjoint=True,
                    backingAddedAreaPx2=envelope.difference(original).area,
                    referenceFilledCells=ownership['referenceResolvedCells'],
                    outlineFilledCells=ownership['outlineOwnedCells'],gapOwnership=ownership,
                    protectedSourceRasterComponents=sum(map(len, anchors.values())),
                    preservedSourcePaintGroups=len({g for witnesses in anchors.values() for y,x,g in witnesses}),
                    referenceClassification='exact immutable palette occupancy; tie-break among original adjacent source paint only',
                    referenceSha256=hashlib.sha256(Path(reference_path).read_bytes()).hexdigest() if reference_path else None,
                    sourcePhysicalHoles=len(envelope.interiors),
                    physicalRasterRemovedCells=int(np.count_nonzero(domain & (labels==0))),
                    outsidePaintClippedCells=outside_count,removedNoiseCells=repairs['removedNoiseCells'],
                    sourcePathPaintMapping=paint_mapping,
                    areaMethod='exact polynomial native controls; sampled topology validation'))
    payloads = {name:json.dumps(value,indent=2,allow_nan=False)+'\n' for name,value in templates.items()}
    # Actual fitted front partition, not source paths or an independently fit overlay.
    preview = ET.Element('svg',xmlns='http://www.w3.org/2000/svg',viewBox=f'0 0 {view[2]} {view[3]}')
    ET.SubElement(preview,'title').text = 'Actual shared partition; '+backing+' backing'
    for region in regions:
        if region['role'] != 'front':
            continue
        data = []
        for refs in region['ring_refs']:
            segments = segments_for(refs)
            data.append('M '+ ' '.join(map(str,segments[0][1][0])))
            for kind, points in segments:
                data.append(kind+' '+' '.join(str(v) for point in points[1:] for v in point))
            data.append('Z')
        ET.SubElement(preview,'path',d=' '.join(data),fill=next(c['hex'] for c in colors if c['id']==region['colorId']),
                      **{'fill-rule':'evenodd','data-region':region['id']})
    payloads['partition-preview.svg'] = ET.tostring(preview,encoding='unicode')
    out.mkdir()
    for name,payload in payloads.items():
        with (out/name).open('x') as stream:
            stream.write(payload)
    # Audit the actual serialized millimetre templates, not source-space curves.
    # Failed output remains diagnostic evidence; no ready plan is published.
    try:
        _, audit = mesh.planar_partition(plan)
    except Exception as exc:
        failure = dict(diagnosticOnly=True, geometryPlanReady=False, geometryValidated=False,
            failure=dict(stage='serialized_partition', type=type(exc).__name__, message=str(exc)),
            inputs=dict(svg_path=str(svg_path), palette_path=str(palette_path), outline_color=outline_color,
                width_mm=width_mm, thickness_mm=thickness_mm, front_mm=front_mm, image_side=image_side,
                reference_path=str(reference_path) if reference_path else None, backing=backing,
                fit_error_px=fit_error_px, corner_angle=corner_angle, scale=scale), plan=plan)
        with (out/'failure-plan.json').open('x') as stream:
            stream.write(json.dumps(failure,indent=2,allow_nan=False)+'\n')
        raise
    plan['validation']['serializedPartitionCheck'] = dict(
        validator='keychain_mesh.planar_partition', offline=True,
        scope='serialized model XY templates; not native CAD validation',
        geometryValidated=False, audit=audit)
    payload = json.dumps(plan,indent=2,allow_nan=False)+'\n'
    with (out/'plan.json').open('x') as stream:
        stream.write(payload)
    # JSON is the persisted interchange contract (tuples become lists).
    return json.loads(payload)
