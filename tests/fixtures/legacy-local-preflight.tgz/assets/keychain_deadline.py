"""Optional command deadline. Never cancel or retry the remote Fusion engine."""
import os
import math
import signal
import time
from contextlib import contextmanager

_legacy = None
_active = False
_interrupted = None


class _CommandStopped(BaseException):
    """Unwind broad Exception handlers, then translate at the command boundary."""


def note_signal(signum):
    global _interrupted
    if _active and signum in (signal.SIGINT, signal.SIGTERM):
        _interrupted = signum


def remaining():
    global _legacy
    if _interrupted:
        raise InterruptedError('Keychain command interrupted; Fusion outcome may be unknown')
    value = os.environ.get('FMCAD_KEYCHAIN_DEADLINE_MONOTONIC_MS')
    if value is not None:
        deadline = float(value) / 1000
    else:
        value = os.environ.get('FMCAD_KEYCHAIN_DEADLINE_MS', '0')
        # Legacy wall-clock input is converted once, never repeatedly extended
        # by wall-clock corrections. The Node parent has its own monotonic timer.
        if _legacy is None or _legacy[0] != value:
            wall = float(value)
            _legacy = (value, time.monotonic() + wall / 1000 - time.time() if wall else 0)
        deadline = _legacy[1]
    if not math.isfinite(deadline):
        raise ValueError('Invalid keychain command deadline')
    if not deadline:
        return None
    seconds = deadline - time.monotonic()
    if seconds <= 0:
        raise TimeoutError('Keychain command timeout; inspect pending Fusion operations before retry')
    return seconds


@contextmanager
def command_deadline():
    global _active, _interrupted
    if not hasattr(signal, 'setitimer') and remaining() is not None:
        raise RuntimeError('Command timeout currently requires POSIX/WSL')
    previous = {}
    old_active, old_interrupted = _active, _interrupted
    _active, _interrupted = True, None
    def stopped(signum, _frame):
        note_signal(signum)
        raise _CommandStopped()
    try:
        for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGALRM):
            previous[signum] = signal.signal(signum, stopped)
        seconds = remaining()
        if seconds is not None:
            signal.setitimer(signal.ITIMER_REAL, seconds)
        try:
            yield
        except _CommandStopped:
            if _interrupted:
                raise InterruptedError('Keychain command interrupted; Fusion work may have an unknown outcome') from None
            raise TimeoutError('Keychain command timeout; Fusion work may have an unknown outcome') from None
        remaining()  # A swallowed ordinary timeout cannot become command success.
    finally:
        if hasattr(signal, 'setitimer'):
            signal.setitimer(signal.ITIMER_REAL, 0)
        for signum, handler in previous.items():
            signal.signal(signum, handler)
        _active, _interrupted = old_active, old_interrupted
